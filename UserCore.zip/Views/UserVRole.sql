CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `usercore`.`uservrole` AS
    SELECT 
        `ro`.`IDNum` AS `IDNum`,
        `ro`.`CompanyIDn` AS `CompanyIDn`,
        `be01`.`IDName` AS `Company`,
        `ro`.`RoleIDn` AS `RoleIDn`,
        `be02`.`IDName` AS `Role`,
        `ro`.`RoleTypeIDn` AS `RoleTypeIDn`,
        `be03`.`IDName` AS `UserType`,
        `ro`.`StateIDn` AS `StateIDn`,
        `ro`.`CreatedByIDn` AS `CreatedByIDn`,
        `ro`.`DateTimeStamp` AS `DateTimeStamp`,
        `ro`.`TzNameIDn` AS `TzNameIDn`,
        `ro`.`TzOffset` AS `TzOffset`,
        `ro`.`LastModifiedByIDn` AS `LastModifiedByIDn`,
        `ro`.`OwnerIDn` AS `OwnerIDn`,
        `ro`.`DateCreated` AS `DateCreated`,
        `ro`.`TableHistory` AS `TableHistory`
    FROM
        (((`usercore`.`usertrole` `ro`
        JOIN `bpmncore`.`bpmfoutbaseelement` `be01` ON ((`ro`.`CompanyIDn` = `be01`.`IDNum`)))
        JOIN `bpmncore`.`bpmfoutbaseelement` `be02` ON ((`ro`.`RoleIDn` = `be02`.`IDNum`)))
        JOIN `bpmncore`.`bpmfoutbaseelement` `be03` ON ((`ro`.`RoleTypeIDn` = `be03`.`IDNum`)))