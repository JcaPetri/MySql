-- uservpermissionsetobjectfield
-- Detalle de los PermissionSetObjectField
SELECT `pof`.`ID`,
		`pof`.`IDNum`,
		`ps`.`CompanyIDn`,
        `be01`.`IDName` AS 'Company',
        `ps`.`PermiSetIDn`,
        `be02`.`IDName` AS 'PermiSet',
		`pof`.`ObjectIDn`,
        `be03`.`IDName` AS 'Object',
		`pof`.`ObjectFieldIDn`,
        `be04`.`IDName` AS 'ObjectField',
		`pof`.`TsFieldOrder`,
		`pof`.`PermiFieldRead`,
		`pof`.`PermiFieldEdit`,
		`pof`.`StateIDn`,
        `be05`.`IDName` AS 'State',
		`pof`.`CreatedByIDn`,
		`pof`.`LastModifiedByIDn`,
		`pof`.`OwnerIDn`,
		`pof`.`DateCreated`,
		`pof`.`DateTimeStamp`,
		`pof`.`TzNameIDn`,
		`pof`.`TzOffset`,
		`pof`.`TableHistory`
FROM `usercore`.`usertpermissionsetobjectfield` `pof`
	JOIN `usercore`.`usertpermissionset` `ps` ON `pof`.`PermiSetIDn` = `ps`.`IDNum`
		JOIN `bpmncore`.`bpmfoutbaseelement` `be01` ON `ps`.`CompanyIDn` = `be01`.`IDNum`
        JOIN `bpmncore`.`bpmfoutbaseelement` `be02` ON `ps`.`PermiSetIDn` = `be02`.`IDNum`
    JOIN `bpmncore`.`bpmfoutbaseelement` `be03` ON `pof`.`ObjectIDn` = `be03`.`IDNum`
    JOIN `bpmncore`.`bpmfoutbaseelement` `be04` ON `pof`.`ObjectFieldIDn` = `be04`.`IDNum`
    JOIN `bpmncore`.`bpmfoutbaseelement` `be05` ON `pof`.`StateIDn` = `be05`.`IDNum`
;
