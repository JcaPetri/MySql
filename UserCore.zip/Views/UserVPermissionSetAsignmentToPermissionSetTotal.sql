-- ###########################################################################################################################################################
-- uservpermissionsetassignmenttotal
-- Lista los PermissionSet que tienen los PermissionSetAssignment, ya se en forma directa o por un Group
SELECT distinct `Pstt`.`ID`,
			`Pstt`.`IDNum`,
            `Pstt`.`CompanyIDn`,
			`Pstt`.`ProfileIDn`,
            `Pstt`.`PermiSetIDn`,
            `pstt`.`PermiSetIsGrant`,
			`Pstt`.`HasActivationRequired`,
			`Pstt`.`PermiSetTypeIDn`,
            `Pstt`.`StateIDn`
FROM (
		-- Lista los PermissionSet que tiene asignados los PermissionSetAsignment, en forma directa
		SELECT `psa`.`ID`,
				`psa`.`IDNum`,
				`psa`.`CompanyIDn`,
				`psa`.`ProfileIDn`,
				`ps`.`PermiSetIDn`,
				`ps`.`PermiSetIsGrant`,
				`ps`.`HasActivationRequired`,
				`ps`.`PermiSetTypeIDn`,
				`psa`.`StateIDn`
		FROM `usercore`.`usertpermissionsetassignment` `psa`
			JOIN `usercore`.`usertpermissionset` `ps` 
				ON `psa`.`CompanyIDn` = `ps`.`CompanyIDn` 
					AND `psa`.`PermiSetoGroupIDn` = `ps`.`PermiSetIDn`
		UNION ALL
		-- Lista los PermissionSet que tiene asignados los PermissionSetAsignment, a traves de los PermissionSetGroup
		SELECT `psa`.`ID`,
				`psa`.`IDNum`,
				`psa`.`CompanyIDn`,
				`psa`.`ProfileIDn`,
				`ps`.`PermiSetIDn`,
				`ps`.`PermiSetIsGrant`,
				`ps`.`HasActivationRequired`,
				`ps`.`PermiSetTypeIDn`,
				`psa`.`StateIDn`
		FROM `usercore`.`usertpermissionsetassignment` `psa`
			JOIN `usertpermissionsetgroup` `psg` 
				ON `psa`.`CompanyIDn` = `psg`.`CompanyIDn` AND `psa`.`PermiSetoGroupIDn` = `psg`.`PermiSetGroupIDn`
			JOIN `usercore`.`usertpermissionsetgroupcomponent` `psgc` 
				 ON `psgc`.`PermiSetGroupIDn` = `psg`.`IDNum`
			JOIN `usercore`.`uservpermissionset` `ps` ON `psgc`.`PermiSetIDn` = `ps`.`IDNum`
	) `Pstt`
ORDER BY `Pstt`.`CompanyIDn`,
			`Pstt`.`ProfileIDn`,
            `Pstt`.`PermiSetIDn`

-- ###########################################################################################################################################################    
/*
	-- Lista los PermissionSetAssignment con sus PermissionSets
	SELECT `psa`.`ID`,
		`psa`.`IDNum`,
		`psa`.`CompanyIDn`,
		`psa`.`ProfileIDn`,
		-- `psa`.`PermiSetoGroupIDn`,
		`ps`.`PermiSetIDn`,
		`ps`.`PermiSetIsGrant`,
		`ps`.`HasActivationRequired`,
		`ps`.`PermiSetTypeIDn`,
		`psa`.`StateIDn`,
		`psa`.`CreatedByIDn`,
		`psa`.`LastModifiedByIDn`,
		`psa`.`OwnerIDn`,
		`psa`.`DateCreated`,
		`psa`.`DateTimeStamp`,
		`psa`.`TzNameIDn`,
		`psa`.`TzOffset`,
		`psa`.`TableHistory`
	FROM `usercore`.`usertpermissionsetassignment` `psa`
		JOIN `usercore`.`usertpermissionset` `ps` 
			ON `psa`.`CompanyIDn` = `ps`.`CompanyIDn` 
				AND `psa`.`PermiSetoGroupIDn` = `ps`.`PermiSetIDn`
	;
*/


/*
	SELECT `psa`.`ID`,
		`psa`.`IDNum`,
		`psa`.`CompanyIDn`,
		`psa`.`ProfileIDn`,
		`ps`.`PermiSetIDn`,
		`ps`.`PermiSetIsGrant`,
		`ps`.`HasActivationRequired`,
		`ps`.`PermiSetTypeIDn`,
		`psa`.`StateIDn`,
		`psa`.`CreatedByIDn`,
		`psa`.`LastModifiedByIDn`,
		`psa`.`OwnerIDn`,
		`psa`.`DateCreated`,
		`psa`.`DateTimeStamp`,
		`psa`.`TzNameIDn`,
		`psa`.`TzOffset`,
		`psa`.`TableHistory`
	FROM `usercore`.`usertpermissionsetassignment` `psa`
		JOIN `usertpermissionsetgroup` `psg` 
			ON `psa`.`CompanyIDn` = `psg`.`CompanyIDn` AND `psa`.`PermiSetoGroupIDn` = `psg`.`PermiSetGroupIDn`
		JOIN `usercore`.`usertpermissionsetgroupcomponent` `psgc` 
			 ON `psgc`.`PermiSetGroupIDn` = `psg`.`IDNum`
		JOIN `usercore`.`uservpermissionset` `ps` ON `psgc`.`PermiSetIDn` = `ps`.`IDNum`
	;
*/

