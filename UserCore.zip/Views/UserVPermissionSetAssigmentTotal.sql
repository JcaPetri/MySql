-- #################################################################################################################################################################################
-- uservpermissionsetassignmenttotal
-- Por lo tanto, aqui se listan los PermissionSet asociados con un PermissionSetAssigment, para una empresa determinada
    SELECT DISTINCT
        `pstt`.`ID` AS `ID`,
        `pstt`.`IDNumPsa` AS `IDNumPsa`,
        `pstt`.`IDNumPs` AS `IDNumPs`,
        `pstt`.`CompanyIDn` AS `CompanyIDn`,
        `pstt`.`ProfileIDn` AS `ProfileIDn`,
        `pstt`.`PermiSetIDn` AS `PermiSetIDn`,
        `pstt`.`PermiSetIsGrant` AS `PermiSetIsGrant`,
        `pstt`.`HasActivationRequired` AS `HasActivationRequired`,
        `pstt`.`PermiSetTypeIDn` AS `PermiSetTypeIDn`
		FROM
        (SELECT 	-- Lista los PermissionSet asignados a un Profile de una Company.
            `psa`.`ID` AS `ID`,
			`psa`.`IDNum` AS `IDNumPsa`,
			`psa`.`CompanyIDn` AS `CompanyIDn`,
			`psa`.`ProfileIDn` AS `ProfileIDn`,
			`ps`.`IDNum` AS `IDNumPs`,
			`ps`.`PermiSetIDn` AS `PermiSetIDn`,
			`ps`.`PermiSetIsGrant` AS `PermiSetIsGrant`,
			`ps`.`HasActivationRequired` AS `HasActivationRequired`,
			`ps`.`PermiSetTypeIDn` AS `PermiSetTypeIDn`
        FROM `usercore`.`usertpermissionsetassignment` `psa`
			JOIN `usercore`.`usertpermissionset` `ps` ON `psa`.`CompanyIDn` = `ps`.`CompanyIDn`
				AND `psa`.`PermiSetoGroupIDn` = `ps`.`PermiSetIDn`
		WHERE `ps`.`StateIDn` = 514 AND `psa`.`StateIDn` = 514	-- Establece solo los registros habilitados
		UNION ALL 
		SELECT 
            `psa`.`ID` AS `ID`,
			`psa`.`IDNum` AS `IDNumPsa`,
			`psa`.`CompanyIDn` AS `CompanyIDn`,
			`psa`.`ProfileIDn` AS `ProfileIDn`,
			`ps`.`IDNum` AS `IDNumPs`,
			`ps`.`PermiSetIDn` AS `PermiSetIDn`,
			`ps`.`PermiSetIsGrant` AS `PermiSetIsGrant`,
			`ps`.`HasActivationRequired` AS `HasActivationRequired`,
			`ps`.`PermiSetTypeIDn` AS `PermiSetTypeIDn`
        FROM `usercore`.`usertpermissionsetassignment` `psa`		-- Va desde el PermissionSetGroup hasta el PermissionSet, para ello los busca en el prmissionSetComponent
			JOIN `usercore`.`usertpermissionsetgroup` `psg` 
				ON `psa`.`CompanyIDn` = `psg`.`CompanyIDn`
					AND `psa`.`PermiSetoGroupIDn` = `psg`.`PermiSetGroupIDn`
			JOIN `usercore`.`usertpermissionsetgroupcomponent` `psgc` 
				ON `psgc`.`PermiSetGroupIDn` = `psg`.`IDNum`
			JOIN `usercore`.`usertpermissionset` `ps` ON `psgc`.`PermiSetIDn` = `ps`.`IDNum`
		WHERE `psa`.`StateIDn` = 514 AND `psg`.`StateIDn` = 514 AND `psgc`.`StateIDn` = 514 AND `ps`.`StateIDn` = 514 	-- Establece solo los registros habilitados
		) `pstt`
    ORDER BY `pstt`.`CompanyIDn` , `pstt`.`ProfileIDn` , `pstt`.`PermiSetIDn`
    
    
    /*
    Tablas que forman la Consulta:
		SELECT * FROM `usercore`.`usertpermissionsetassignment` `psa`
        SELECT * FROM  `usercore`.`usertpermissionset` `ps`
		SELECT * FROM `usercore`.`usertpermissionsetgroup` `psg` 
        SELECT * FROM `usercore`.`usertpermissionsetgroupcomponent` `psgc` 
    */