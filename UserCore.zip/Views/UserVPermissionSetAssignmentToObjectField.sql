
-- Muestra los ObjectFields de los PermissionSetAssignmentTotal
SELECT `psatof`.`CompanyIDn`,
		`be01`.`IDName` AS `Company`,
		`psatof`.`ProfileIDn`,
        `be02`.`IDName` AS `Profile`,
		`psatof`.`ObjectIDn`,
        `be03`.`IDName` AS `Object`,
		`psatof`.`ObjectFieldIDn`,
        `be04`.`IDName` AS `ObjectField`,        
		`psatof`.`TsFieldOrder`,
		`psatof`.`PermiFieldRead`,
		`psatof`.`PermiFieldEdit`,
		`psatof`.`HasActivationRequired`
FROM `usercore`.`usertpermissionsetassignmenttoobjectfield` `psatof`
    JOIN `bpmncore`.`bpmfoutbaseelement` `be01` ON `be01`.`IDNum` = `psatof`.`CompanyIDn`
	JOIN `bpmncore`.`bpmfoutbaseelement` `be02` ON `be02`.`IDNum` = `psatof`.`ProfileIDn`
	JOIN `bpmncore`.`bpmfoutbaseelement` `be03` ON `be03`.`IDNum` = `psatof`.`ObjectIDn`
	JOIN `bpmncore`.`bpmfoutbaseelement` `be04` ON `be04`.`IDNum` = `psatof`.`ObjectFieldIDn`
ORDER BY `psatof`.`CompanyIDn`, `psatof`.`ProfileIDn`, `psatof`.`ObjectIDn`, `psatof`.`TsFieldOrder`
;

    
/*
	SELECT * FROM `usercore`.`usertpermissionsetassignmenttoobjectfield` `pof`;
	SELECT * FROM `usercore`.`usertpermissionset` `ps`;
	SELECT * FROM `usercore`.`uservpermissionsetassignmenttotal` `pst`;



*/

