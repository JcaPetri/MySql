-- uservpermissionsetgroupcomponent
SELECT `psgc`.`ID`,
    `psgc`.`IDNum`,
    `psg`.`CompanyIDn`,
    `psg`.`Company`,
    `psgc`.`PermiSetGroupIDn`,
    `psg`.`PermiSetGroup`,
    `psg`.`PermiStatusIDn`,
    `psg`.`PermiStatus` 'PermiSetGroupStatus',
    `psgc`.`PermiSetIDn`,
    `ps`.`PermiSet`,
    `ps`.`PermiSetIsGrant`,
    if(`ps`.`PermiSetIsGrant` = 1, 'IsGrant', 'NoGrant') `IsGrant?`,
    `psgc`.`StateIDn`,
    `be01`.`IDName` `State`,
    `psgc`.`CreatedByIDn`,
    `psgc`.`DateTimeStamp`,
    `psgc`.`TzNameIDn`,
    `psgc`.`TzOffset`,
    `psgc`.`LastModifiedByIDn`,
    `psgc`.`OwnerIDn`,
    `psgc`.`DateCreated`,
    `psgc`.`TableHistory`
FROM `usercore`.`usertpermissionsetgroupcomponent` `psgc`
    LEFT JOIN `usercore`.`uservpermissionsetgroup` `psg` ON `psgc`.`PermiSetGroupIDn` = `psg`.`IDNum`
	LEFT JOIN `usercore`.`uservpermissionset` `ps` ON `psgc`.`PermiSetIDn` = `ps`.`IDNum`
	JOIN `bpmncore`.`bpmfoutbaseelement` `be01` ON `psgc`.`StateIDn` = `be01`.`IDNum`
    ;

/*
SELECT * FROM `usercore`.`uservpermissionset`;
SELECT * FROM `usercore`.`uservpermissionsetgroup`;

*/