-- Profile, lista los Profile del sistema
/*CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `usercore`.`uservprofile` AS*/
    SELECT `up`.`ID`,
    `up`.`IDNum`,
    `up`.`CompanyIDn`,
    `be01`.`IDName` AS `Company`,
    `up`.`ProfileIDn`,
    `be02`.`IDName` AS `Profile`,
    `up`.`ProfileTypeIDn`,
    `be03`.`IDName` AS `ProfileType`,
    `up`.`LicenseIDn`,
    `ul`.`LicenseName`,
    `up`.`StateIDn`,
    `up`.`CreatedByIDn`,
    `up`.`LastModifiedByIDn`,
    `up`.`OwnerIDn`,
    `up`.`DateCreated`,
    `up`.`DateTimeStamp`,
    `up`.`TzNameIDn`,
    `up`.`TzOffset`,
    `up`.`TableHistory`
FROM `usercore`.`usertprofile` `up`
		JOIN `bpmncore`.`bpmfoutbaseelement` `be01` ON `up`.`CompanyIDn` = `be01`.`IDNum`
        JOIN `bpmncore`.`bpmfoutbaseelement` `be02` ON `up`.`ProfileIDn` = `be02`.`IDNum`
        JOIN `bpmncore`.`bpmfoutbaseelement` `be03` ON `up`.`ProfileTypeIDn` = `be03`.`IDNum`
        JOIN `usercore`.`usertlicense` `ul` ON `up`.`LicenseIDn` = `ul`.`IDNum`
ORDER BY `up`.`IDNum`;