SELECT `Utp`.`FirstName`,
		`Utp`.`LastName`,
		`Utp`.`Alias`,
		`Utp`.`CommunityNickname`,
		`Utp`.`Email`,
        `Utp`.`EmployeeNumber`,
        `Utp`.`FkBeIDnCompany`,
        `be01`.`IDName` AS `Company`,
		`Utp`.`FkBeIDnRole`,
        `be02`.`IDName` AS `Role`,
		`Utp`.`FkBeIDnRoleType`,
        `be03`.`IDName` AS `RoleType`,
		`Utp`.`FkBeIDnProfile`,
        `be04`.`IDName` AS `Profile`,
		`Utp`.`FkBeIDnProfileType`,
        `be05`.`IDName` AS `ProfileType`,
		`Utp`.`FkBeIDnLicense`,
        `Utp`.`LicenseName`,
        `Utp`.`UsedLicensesLastUpdated`
	-- ,`Utp`.* 
FROM (
	SELECT `use`.`ID`,
		`use`.`IDNum`,
		`use`.`EmployeeNumber`,
		`use`.`FkBeIDnUserType`,
		`use`.`FkBeIDnLanguage`,
		`use`.`FirstName`,
		`use`.`LastName`,
		`use`.`Alias`,
		`use`.`CommunityNickname`,
		`use`.`Email`,
		`rol`.`FkBeIDnCompany`,
		`rol`.`FkBeIDnRole`,
		`rol`.`FkBeIDnRoleType`,
		`pro`.`FkBeIDnProfile`,
		`pro`.`FkBeIDnProfileType`,
		`pro`.`FkBeIDnLicense`,
		`lic`.`LicenseDefinitionKey`,
		`lic`.`LicenseName`,
		`lic`.`UsedLicensesLastUpdated`
	FROM `usercore`.`usertuser` `use`
		INNER JOIN `usercore`.`usertuserrole` `ur` ON `use`.`IDNum` = `ur`.`FkBeIDnUser`
		INNER JOIN `usercore`.`usertrole` `rol` ON `ur`.`FkBeIDnRole` = `rol`.`IDNum`
		INNER JOIN `usercore`.`usertroleprofile` `rp` ON `rol`.`IDNum` = `rp`.`FkBeIDnRole`
		INNER JOIN `usercore`.`usertprofile` `pro` ON `rp`.`FkBeIDnProfile` = `pro`.`FkBeIDnProfile`
        INNER JOIN `usercore`.`usertlicense` `lic` ON `pro`.`FkBeIDnLicense` = `lic`.`IDnLicense`
	) AS `Utp`
		INNER JOIN `bpmncore`.`bpmtfounbaseelement` `be01` ON `be01`.`IDnum` = `Utp`.`FkBeIDnCompany`
        INNER JOIN `bpmncore`.`bpmtfounbaseelement` `be02` ON `be02`.`IDnum` = `Utp`.`FkBeIDnRole`
        INNER JOIN `bpmncore`.`bpmtfounbaseelement` `be03` ON `be03`.`IDnum` = `Utp`.`FkBeIDnRoleType`
        INNER JOIN `bpmncore`.`bpmtfounbaseelement` `be04` ON `be04`.`IDnum` = `Utp`.`FkBeIDnProfile`
        INNER JOIN `bpmncore`.`bpmtfounbaseelement` `be05` ON `be05`.`IDnum` = `Utp`.`FkBeIDnProfileType`
   ;

   /*
		`Utp`.`FkBeIDnProfile`,
		`Utp`.`FkBeIDnProfileType`,
		`Utp`.`FkBeIDnLicense`,*/
   
   
    /*
    SELECT `ur`.`FkBeIDnUser`,
    `ur`.`FkBeIDnRole`,
FROM ;


SELECT `rol`.`ID`,
    `rol`.`IDNum`,
    `rol`.`FkBeIDnCompany`,
    `rol`.`FkBeIDnRole`,
    `rol`.`FkBeIDnRoleType`
FROM `usercore`.`usertrole` `rol`;   

SELECT `rp`.`FkBeIDnRole`,
    `rp`.`FkBeIDnProfile`
FROM `usercore`.`usertroleprofile` `rp`;

SELECT `pro`.`FkBeIDnProfile`,
    `pro`.`FkBeIDnProfileType`,
    `pro`.`FkBeIDnLicense`
FROM `usercore`.`usertprofile` `pro`;

SELECT `lic`.`IDnLicense`,
    `lic`.`LicenseDefinitionKey`,
    `lic`.`LicenseName`,
    `lic`.`MonthlyLoginsEntitlement`,
    `lic`.`MonthlyLoginsUsed`,
    `lic`.`TotalLicenses`,
    `lic`.`UsedLicenses`,
    `lic`.`UsedLicensesLastUpdated`,
    `lic`.`FkBeIDnState`,
    `lic`.`DateTimeStamp`,
    `lic`.`FkBeIDnTzName`,
    `lic`.`TzOffset`,
    `lic`.`UserIDNum`,
    `lic`.`TableHistory`
FROM `usercore`.`usertlicense` `lic`;


*/

