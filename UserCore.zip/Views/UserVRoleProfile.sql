SELECT `rp`.`RoleIDn`,
    `ur`.`Role`,
	`ur`.`CompanyIDn` AS 'urCompanyIDn',
    `ur`.`Company` AS 'urCompany',
    `ur`.`RoleTypeIDn`,
    `ur`.`UserType`,
    `rp`.`ProfileIDn`,
    `up`.`Profile`,    
    `up`.`CompanyIDn` AS 'upCompanyIDn',
    `up`.`Company` AS 'upCompany',
    `up`.`ProfileTypeIDn`,
    `up`.`ProfileType`,
    `up`.`LicenseIDn`,
    `up`.`LicenseName`,
    `rp`.`StateIDn`,
    `rp`.`CreatedByIDn`,
    `rp`.`LastModifiedByIDn`,
    `rp`.`OwnerIDn`,
    `rp`.`DateCreated`,
    `rp`.`DateTimeStamp`,
    `rp`.`TzNameIDn`,
    `rp`.`TzOffset`,
    `rp`.`TableHistory`
FROM `usercore`.`usertroleprofile` `rp`
	INNER JOIN `usercore`.`uservprofile` `up` ON
		`rp`.`ProfileIDn` = `up`.`IDNum`
	INNER JOIN `usercore`.`uservrole` `ur` ON
		`rp`.`RoleIDn` = `ur`.`IDNum`
   ;
   