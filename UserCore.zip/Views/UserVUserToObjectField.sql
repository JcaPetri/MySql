-- Muestra los ObjetosField que tiene acceso un usuario, para ello debe pasar por todas las tablas del User
-- Con esta informacion se debe hacer una tabla que tenga las siguientes columnas
-- Columnas Claves: UserID, FkBeIDnCompany, FkBeIDnObject, FkBeIDnObjectField, estas son claves primarias
-- 			las columnas con los distintos permisos: PermiFieldRead, PermiFieldEdit
-- de esta manera se define para un usuario, en una determinada compañia a que objectos puede acceder, dentro de este objeto que Columans/Campos puede ver o editar
SELECT `UtO`.`FirstName`,
		`UtO`.`LastName`,
		`UtO`.`Alias`,
		`UtO`.`CommunityNickname`,
		`UtO`.`Email`,
        `UtO`.`EmployeeNumber`,
        `UtO`.`FkBeIDnCompany`,
        `be01`.`IDName` AS `Company`,
		`UtO`.`FkBeIDnRole`,
        `be02`.`IDName` AS `Role`,
		`UtO`.`FkBeIDnRoleType`,
        `be03`.`IDName` AS `RoleType`,
		`UtO`.`FkBeIDnProfile`,
        `be04`.`IDName` AS `Profile`,
		`UtO`.`FkBeIDnProfileType`,
        `be05`.`IDName` AS `ProfileType`,
		`UtO`.`FkBeIDnLicense`,
        `UtO`.`LicenseName`,
        `UtO`.`UsedLicensesLastUpdated`,
		`UtO`.`FkBeIDnPermiSetoGroup`,
		`UtO`.`FkBeIDnPermiSet`,
        `be06`.`IDName` AS `PermiSet`,
		`UtO`.`FkBeIDnPermiSetType`,
        `be07`.`IDName` AS `PermiSetType`,
		`UtO`.`HasActivationRequired`,
		`UtO`.`FkBeIDnObject`,
        `be08`.`IDName` AS `Object`,        
		`UtO`.`FkBeIDnObjectField`,
        `be09`.`IDName` AS `ObjectField`,  
		`UtO`.`TsFieldOrder`,
		`UtO`.`PermiFieldRead`,
		`UtO`.`PermiFieldEdit`
	-- ,`UtO`.* 
FROM (
		SELECT `use`.`ID`,
			`use`.`IDNum`,
			`use`.`EmployeeNumber`,
			`use`.`FkBeIDnUserType`,
			`use`.`FkBeIDnLanguage`,
			`use`.`FirstName`,
			`use`.`LastName`,
			`use`.`Alias`,
			`use`.`CommunityNickname`,
			`use`.`Email`,
			`rol`.`FkBeIDnCompany`,
			`rol`.`FkBeIDnRole`,
			`rol`.`FkBeIDnRoleType`,
			`pro`.`FkBeIDnProfile`,
			`pro`.`FkBeIDnProfileType`,
			`pro`.`FkBeIDnLicense`,
			`lic`.`LicenseDefinitionKey`,
			`lic`.`LicenseName`,
			`lic`.`UsedLicensesLastUpdated`,
			-- `Psa`.`FkBeIDnProfile`,
			`Psa`.`FkBeIDnPermiSetoGroup`,
			`Pst`.`FkBeIDnPermiSet`,
			`Pst`.`HasActivationRequired`,
			`Pst`.`FkBeIDnPermiSetType`,
			`Psof`.`FkBeIDnObject`,
			`Psof`.`FkBeIDnObjectField`,
			`Psof`.`TsFieldOrder`,
			`Psof`.`PermiFieldRead`,
			`Psof`.`PermiFieldEdit`
		FROM `usercore`.`usertuser` `use`
			INNER JOIN `usercore`.`usertuserrole` `ur` ON `use`.`IDNum` = `ur`.`FkBeIDnUser`
			INNER JOIN `usercore`.`usertrole` `rol` ON `ur`.`FkBeIDnRole` = `rol`.`IDNum`
			INNER JOIN `usercore`.`usertroleprofile` `rp` ON `rol`.`IDNum` = `rp`.`FkBeIDnRole`
			INNER JOIN `usercore`.`usertprofile` `pro` ON `rp`.`FkBeIDnProfile` = `pro`.`FkBeIDnProfile`
			INNER JOIN `usercore`.`usertlicense` `lic` ON `pro`.`FkBeIDnLicense` = `lic`.`IDnLicense`
			INNER JOIN `usercore`.`usertpermissionsetassignment` `Psa` ON `pro`.`FkBeIDnProfile` = `Psa`.`FkBeIDnProfile`
			INNER JOIN `usercore`.`usertpermissionset` `Pst` ON `Psa`.`FkBeIDnPermiSetoGroup` = `Pst`.`FkBeIDnPermiSet`
            INNER JOIN `usercore`.`usertpermissionsetobjectfield` `Psof` ON `Pst`.`FkBeIDnPermiSet` = `Psof`.`FkBeIDnPermiSet`
	) AS `UtO`
		INNER JOIN `bpmncore`.`bpmtfounbaseelement` `be01` ON `be01`.`IDnum` = `UtO`.`FkBeIDnCompany`
        INNER JOIN `bpmncore`.`bpmtfounbaseelement` `be02` ON `be02`.`IDnum` = `UtO`.`FkBeIDnRole`
        INNER JOIN `bpmncore`.`bpmtfounbaseelement` `be03` ON `be03`.`IDnum` = `UtO`.`FkBeIDnRoleType`
        INNER JOIN `bpmncore`.`bpmtfounbaseelement` `be04` ON `be04`.`IDnum` = `UtO`.`FkBeIDnProfile`
        INNER JOIN `bpmncore`.`bpmtfounbaseelement` `be05` ON `be05`.`IDnum` = `UtO`.`FkBeIDnProfileType`
        INNER JOIN `bpmncore`.`bpmtfounbaseelement` `be06` ON `be06`.`IDNum` = `UtO`.`FkBeIDnPermiSet`
		INNER JOIN `bpmncore`.`bpmtfounbaseelement` `be07` ON `be07`.`IDNum` = `UtO`.`FkBeIDnPermiSetType`
        INNER JOIN `bpmncore`.`bpmtfounbaseelement` `be08` ON `be08`.`IDNum` = `UtO`.`FkBeIDnObject`
        INNER JOIN `bpmncore`.`bpmtfounbaseelement` `Be09` ON `be05`.`IDNum` = `UtO`.`FkBeIDnObjectField`
   ;

   /*
		`Utp`.`FkBeIDnProfile`,
		`Utp`.`FkBeIDnProfileType`,
		`Utp`.`FkBeIDnLicense`,*/
   
   
    /*
    SELECT `ur`.`FkBeIDnUser`,
    `ur`.`FkBeIDnRole`,
FROM ;


SELECT `rol`.`ID`,
    `rol`.`IDNum`,
    `rol`.`FkBeIDnCompany`,
    `rol`.`FkBeIDnRole`,
    `rol`.`FkBeIDnRoleType`
FROM `usercore`.`usertrole` `rol`;   

SELECT `rp`.`FkBeIDnRole`,
    `rp`.`FkBeIDnProfile`
FROM `usercore`.`usertroleprofile` `rp`;

SELECT `pro`.`FkBeIDnProfile`,
    `pro`.`FkBeIDnProfileType`,
    `pro`.`FkBeIDnLicense`
FROM `usercore`.`usertprofile` `pro`;

SELECT `lic`.`IDnLicense`,
    `lic`.`LicenseDefinitionKey`,
    `lic`.`LicenseName`,
    `lic`.`MonthlyLoginsEntitlement`,
    `lic`.`MonthlyLoginsUsed`,
    `lic`.`TotalLicenses`,
    `lic`.`UsedLicenses`,
    `lic`.`UsedLicensesLastUpdated`,
    `lic`.`FkBeIDnState`,
    `lic`.`DateTimeStamp`,
    `lic`.`FkBeIDnTzName`,
    `lic`.`TzOffset`,
    `lic`.`UserIDNum`,
    `lic`.`TableHistory`
FROM `usercore`.`usertlicense` `lic`;

SELECT `Psa`.`ID`,
    `Psa`.`IDNum`,
    `Psa`.`FkBeIDnProfile`,
    `Psa`.`FkBeIDnPermiSetoGroup`,
    `Psa`.`FkBeIDnState`,
    `Psa`.`DateTimeStamp`,
    `Psa`.`FkBeIDnTzName`,
    `Psa`.`TzOffset`,
    `Psa`.`UserIDNum`,
    `Psa`.`TableHistory`
FROM `usercore`.`usertpermissionsetassignment` `Psa`;

SELECT `Pst`.`FkBeIDnPermiSet`,
    `Pst`.`HasActivationRequired`,
    `Pst`.`FkBeIDnPermiSetType`,
    `Pst`.`FkBeIDnState`,
    `Pst`.`DateTimeStamp`,
    `Pst`.`FkBeIDnTzName`,
    `Pst`.`TzOffset`,
    `Pst`.`UserIDNum`,
    `Pst`.`TableHistory`
FROM `usercore`.`usertpermissionset` `Pst`;

SELECT `Pso`.`ID`,
    `Pso`.`IDNum`,
    `Pso`.`FkBeIDnPermiSet`,
    `Pso`.`FkBeIDnObject`,
    `Pso`.`PermiObjCreate`,
    `Pso`.`PermiObjRead`,
    `Pso`.`PermiObjDelete`,
    `Pso`.`PermiObjEdit`,
    `Pso`.`PermiObjViewAllRecord`,
    `Pso`.`PermiObjModiyAllRecord`,
    `Pso`.`PermiObjViewAllField`,
    `Pso`.`PermiObjEditAllField`,
    `Pso`.`FkBeIDnState`,
    `Pso`.`DateTimeStamp`,
    `Pso`.`FkBeIDnTzName`,
    `Pso`.`TzOffset`,
    `Pso`.`UserIDNum`,
    `Pso`.`TableHistory`
FROM `usercore`.`usertpermissionsetobject` `Pso`;

*/

