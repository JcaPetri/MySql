-- uservsysentitystructure
-- Listado de las Estructuras de las Entidades Disponibles
SELECT `ss`.`ID`,
    `ss`.`IDNum`,
    `Be01`.`IDName` `IDName`,
    `ss`.`EntityTypeIDn`,
    `Be02`.`IDName` `EntityType`,
    `ss`.`EntityIDn`,
    `Be03`.`IDName` `Entity`,
    `ss`.`FieldIDn`,
    `Be04`.`IDName` `Field`,
    `ss`.`FieldTypeIDn`,
    `Be05`.`IDName` `FieldType`,
    `ss`.`TsFieldOrder`,
    `ss`.`StateIDn`,
    `Be06`.`IDName` `State`
FROM `usercore`.`usertsysentitystructure` `ss`
	INNER JOIN `bpmncore`.`bpmfoutbaseelement` `Be01` ON `ss`.`IDNum` = `Be01`.`IDNum`
    INNER JOIN `bpmncore`.`bpmfoutbaseelement` `Be02` ON `ss`.`EntityTypeIDn` = `Be02`.`IDNum`
    INNER JOIN `bpmncore`.`bpmfoutbaseelement` `Be03` ON `ss`.`EntityIDn` = `Be03`.`IDNum`
    INNER JOIN `bpmncore`.`bpmfoutbaseelement` `Be04` ON `ss`.`FieldIDn` = `Be04`.`IDNum`
    INNER JOIN `bpmncore`.`bpmfoutbaseelement` `Be05` ON `ss`.`FieldTypeIDn` = `Be05`.`IDNum`
    INNER JOIN `bpmncore`.`bpmfoutbaseelement` `Be06` ON `ss`.`StateIDn` = `Be06`.`IDNum`
    ;
