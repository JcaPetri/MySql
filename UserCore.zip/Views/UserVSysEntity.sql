-- UserVSysEntity
-- Listado de las Entidades Disponibles
SELECT `ue`.`ID`,
		`ue`.`IDNum`,
		`ue`.`IDName`,
		`ue`.`ScopeIDn`,
        `Be01`.`IDName` `Scope`,
		`ue`.`LanguageIDn`,
        `Be02`.`IDName` `Language`,
		`ue`.`EntityTypeIDn`,
        `Be03`.`IDName` `EntityType`,
		`ue`.`StateIDn`,
        `Be04`.`IDName` `State`
FROM `usercore`.`usertsysentity` `ue`
	INNER JOIN `bpmncore`.`bpmfoutbaseelement` `Be01` ON `ue`.`ScopeIDn` = `Be01`.`IDNum`
    INNER JOIN `bpmncore`.`bpmfoutbaseelement` `Be02` ON `ue`.`LanguageIDn` = `Be02`.`IDNum`
    INNER JOIN `bpmncore`.`bpmfoutbaseelement` `Be03` ON `ue`.`EntityTypeIDn` = `Be03`.`IDNum`
    INNER JOIN `bpmncore`.`bpmfoutbaseelement` `Be04` ON `ue`.`StateIDn` = `Be04`.`IDNum`
    
    