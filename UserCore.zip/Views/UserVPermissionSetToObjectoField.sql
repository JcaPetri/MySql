

-- Lista por cada PermissionSet los objetos y que derechos tiene sobre cada uno
SELECT `ps`.`ID`,
    `ps`.`IDNum`,
    `ps`.`CompanyIDn`,
    `ps`.`PermiSetIDn`,
    `ps`.`PermiSetIsGrant`,
    `ps`.`HasActivationRequired`,
    -- `ps`.`PermiSetTypeIDn`,		-- Define si es un permiso del Sistema o Usuario    
    -- `pso`.`ID`,
    -- `pso`.`IDNum`,
    -- `pso`.`PermiSetIDn`,
    `pso`.`ObjectIDn`,
    `pso`.`PermiObjCreate`,
    `pso`.`PermiObjRead`,
    `pso`.`PermiObjDelete`,
    `pso`.`PermiObjEdit`,
    `pso`.`PermissionField`
    /*`ps`.`StateIDn`,
    `ps`.`CreatedByIDn`,
    `ps`.`LastModifiedByIDn`,
    `ps`.`OwnerIDn`,
    `ps`.`DateCreated`,
    `ps`.`DateTimeStamp`,
    `ps`.`TzNameIDn`,
    `ps`.`TzOffset`,
    `ps`.`TableHistory`*/
FROM `usercore`.`usertpermissionset` `ps`
	LEFT JOIN `usercore`.`usertpermissionsetobject` `pso` ON `ps`.`IDNum` = `pso`.`PermiSetIDn`;

/*
SELECT `pso`.`ID`,
    `pso`.`IDNum`,
    `pso`.`PermiSetIDn`,
    `pso`.`ObjectIDn`,
    `pso`.`PermiObjCreate`,
    `pso`.`PermiObjRead`,
    `pso`.`PermiObjDelete`,
    `pso`.`PermiObjEdit`,
    `pso`.`PermissionField`,
    `pso`.`StateIDn`,
    `pso`.`CreatedByIDn`,
    `pso`.`LastModifiedByIDn`,
    `pso`.`OwnerIDn`,
    `pso`.`DateCreated`,
    `pso`.`DateTimeStamp`,
    `pso`.`TzNameIDn`,
    `pso`.`TzOffset`,
    `pso`.`TableHistory`
FROM `usercore`.`usertpermissionsetobject` `pso`;



SELECT `psof`.`ID`,
    `psof`.`IDNum`,
    `psof`.`PermiSetIDn`,
    `psof`.`ObjectIDn`,
    `psof`.`ObjectFieldIDn`,
    `psof`.`TsFieldOrder`,
    `psof`.`PermiFieldRead`,
    `psof`.`PermiFieldEdit`,
    `psof`.`StateIDn`,
    `psof`.`CreatedByIDn`,
    `psof`.`LastModifiedByIDn`,
    `psof`.`OwnerIDn`,
    `psof`.`DateCreated`,
    `psof`.`DateTimeStamp`,
    `psof`.`TzNameIDn`,
    `psof`.`TzOffset`,
    `psof`.`TableHistory`
FROM `usercore`.`usertpermissionsetobjectfield` `psof`;

*/


-- Lista por cada PermissionSet las columnas de los objetos y que derechos tiene sobre cada una
-- aqui ingresa si el PermissionField del objeto es igual a True
SELECT `ps`.`ID`,
    `ps`.`IDNum`,
    `ps`.`CompanyIDn`,
    `ps`.`PermiSetIDn`,
    `ps`.`PermiSetIsGrant`,
    `ps`.`HasActivationRequired`,
    -- `ps`.`PermiSetTypeIDn`,		-- Define si es un permiso del Sistema o Usuario    
    -- `psof`.`ID`,
    -- `psof`.`IDNum`,
    -- `psof`.`PermiSetIDn`,
    `psof`.`ObjectIDn`,
    `psof`.`ObjectFieldIDn`,
    `psof`.`TsFieldOrder`,
    `psof`.`PermiFieldRead`,
    `psof`.`PermiFieldEdit`
    /*`ps`.`StateIDn`,
    `ps`.`CreatedByIDn`,
    `ps`.`LastModifiedByIDn`,
    `ps`.`OwnerIDn`,
    `ps`.`DateCreated`,
    `ps`.`DateTimeStamp`,
    `ps`.`TzNameIDn`,
    `ps`.`TzOffset`,
    `ps`.`TableHistory`*/
FROM `usercore`.`usertpermissionset` `ps`
	LEFT JOIN `usertpermissionsetobjectfield` `psof` ON `ps`.`IDNum` = `psof`.`PermiSetIDn`
WHERE `psof`.`PermiSetIDn` IS NOT NULL;
