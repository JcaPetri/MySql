-- uservpermissionset
-- Lista los PermissionSet Disponibles
SELECT `ps`.`IDNum`,
		`ps`.`CompanyIDn`,
        `be01`.`IDName` AS `Company`,
		`ps`.`PermiSetIDn`,
		`be02`.`IDName` AS `PermiSet`,
		`ps`.`PermiSetIsGrant`,
		`ps`.`HasActivationRequired`,
		`ps`.`PermiSetTypeIDn`,
        `be03`.`IDName` AS `PermiSetType`,
		`ps`.`StateIDn`,
        `be04`.`IDName` AS `State`,
		`ps`.`CreatedByIDn`,
		`ps`.`LastModifiedByIDn`,
		`ps`.`OwnerIDn`,
		`ps`.`DateCreated`,
		`ps`.`DateTimeStamp`,
		`ps`.`TzNameIDn`,
		`ps`.`TzOffset`,
		`ps`.`TableHistory`
FROM `usercore`.`usertpermissionset` `ps`
	JOIN `bpmncore`.`bpmfoutbaseelement` `be01` ON `ps`.`CompanyIDn` = `be01`.`IDNum`
    JOIN `bpmncore`.`bpmfoutbaseelement` `be02` ON `ps`.`PermiSetIDn` = `be02`.`IDNum`
    JOIN `bpmncore`.`bpmfoutbaseelement` `be03` ON `ps`.`PermiSetTypeIDn` = `be03`.`IDNum`
    JOIN `bpmncore`.`bpmfoutbaseelement` `be04` ON `ps`.`StateIDn` = `be04`.`IDNum`
;
