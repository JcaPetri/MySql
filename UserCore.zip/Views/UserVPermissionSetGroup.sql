-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Muestra los distintos permissionSetGroup disponibles
-- estos agrupan una serie de PermissionSets, de esta forma se simplifica la asignacion de permisos a los usuarios
-- userVPermissionSetGroup
SELECT `psg`.`ID`,
    `psg`.`IDNum`,
    `psg`.`CompanyIDn`,
    `be01`.`IDName` AS `Company`,
    `psg`.`PermiSetGroupIDn`,
    `be02`.`IDName` AS `PermiSetGroup`,
    `psg`.`PermiStatusIDn`,
	`be03`.`IDName` AS `PermiStatus`,
    `psg`.`StateIDn`,
    `psg`.`CreatedByIDn`,
    `psg`.`LastModifiedByIDn`,
    `psg`.`OwnerIDn`,
    `psg`.`DateCreated`,
    `psg`.`DateTimeStamp`,
    `psg`.`TzNameIDn`,
    `psg`.`TzOffset`,
    `psg`.`TableHistory`
FROM `usercore`.`usertpermissionsetgroup` `psg`
	JOIN `bpmncore`.`bpmfoutbaseelement` `be01` ON `psg`.`CompanyIDn` = `be01`.`IDNum`
	JOIN `bpmncore`.`bpmfoutbaseelement` `be02` ON `psg`.`PermiSetGroupIDn` = `be02`.`IDNum`
	JOIN `bpmncore`.`bpmfoutbaseelement` `be03` ON `psg`.`PermiStatusIDn` = `be03`.`IDNum`;

