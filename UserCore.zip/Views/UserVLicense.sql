CREATE VIEW `UserVLicense` AS
	SELECT `ul`.`IDNum`,
		`ul`.`LicenseDefinitionKey`,
		`ul`.`LicenseName`,
		`ul`.`MonthlyLoginsEntitlement`,
		`ul`.`MonthlyLoginsUsed`,
		`ul`.`TotalLicenses`,
		`ul`.`UsedLicenses`,
		`ul`.`UsedLicensesLastUpdated`,
		`ul`.`StateIDn`,
        `be01`.`IDName` AS `State`,
		`ul`.`CreatedByIDn`,
		`ul`.`LastModifiedByIDn`,
		`ul`.`OwnerIDn`,
		`ul`.`DateCreated`,
		`ul`.`DateTimeStamp`,
		`ul`.`TzNameIDn`,
		`ul`.`TzOffset`,
		`ul`.`TableHistory`
	FROM `usercore`.`usertlicense` `ul`
		JOIN `bpmncore`.`bpmfoutbaseelement` `be01` ON `ul`.`StateIDn` = `be01`.`IDNum`;
