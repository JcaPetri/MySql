-- RoleType, es un ambito de aplicacion solamente
-- Lista la Tabla, esta informacion esta en la tabla BaseElement
SELECT * FROM `bpmncore`.`bpmfoutbaseelement` WHERE `ScopeIDn` = 22;

-- esto se utiliza para generar distintas clasificaciones y filtros.
SELECT * FROM `bpmncore`.`bpmfouVscopedet` WHERE ScopeIDCode = 22 ORDER BY IDNum;
	/*
	22	tSisRoleType		1
	5569	Manager			2
	5570	Supervisor		3
	5571	Responsable		4
	5572	Receptionist	5
	5573	Secretary		6
	5574	Operator		7
	*/


-- Actualiza el Un Valor de la Tabla BaseElement    
UPDATE `bpmncore`.`bpmfoutbaseelement`
SET `IDName` = 'PartsOperator',
/*
`ScopeIDn` = <{ScopeIDn: }>,
`LanguageIDn` = <{LanguageIDn: }>,
`IDCode` = <{IDCode: }>,
`DefinitionIDn` = <{DefinitionIDn: }>,
`InformationTypeIDn` = <{InformationTypeIDn: }>,
`IDIsUsed` = <{IDIsUsed: }>,
`StateIDn` = <{StateIDn: }>,
*/
	`TableHistory` = "SetOff"				-- 	"SetNull", "SetOff"
WHERE `IDNum` = 5576
	AND `ScopeIDn` = 22;		-- Doble Control

-- Lista Resultados
SELECT * FROM `bpmncore`.`bpmfoutbaseelement` WHERE `ScopeIDn` = 22;



-- Inserta Realmente un nuevo elemento
INSERT INTO `bpmncore`.`bpmfoutbaseelement`
	(-- `ID`,
	-- `IDNum`,
	`IDName`,
	`ScopeIDn`,
	`LanguageIDn`,
	-- `IDCode`,
	`DefinitionIDn`,
	`InformationTypeIDn`,
	`IDIsUsed`,
	`StateIDn`,
	`CreatedByIDn`,
	`LastModifiedByIDn`,
	`OwnerIDn`,
	-- `DateCreated`,
	-- `DateTimeStamp`,
	`TzNameIDn`,
	`TzOffset`,
	`TableHistory`)
SELECT -- `ID`,
	-- `IDNum`,
	'' `IDName`,				-- Código en letras del ID
	22 `ScopeIDn`,				-- codigo del ambito de aplicacion.
	779 `LanguageIDn`,			-- Codigo del idioma por defecto elegido. Este es el mismo durante todo el sistema.
	-- `IDCode`,				-- Codigo numerico establecido por el usuario, permite organizar los contenidos de la tabla por rangos, se carga automaticamente si no se especifica
	533 `DefinitionIDn`,		-- 17 tSisDefinition, 533 bpmndefaultdefinition -- Establece el tipo de definicion del elemento
	524 `InformationTypeIDn`,	-- 12 tSisInfoType, 523 Data, 524 Software = definición del código, bajo que estandar esta escrito.
	1 `IDIsUsed`,
	514 `StateIDn`,				-- Define el tipo de dato que es el BaseElement, puede ser: Data (son los elementos reales que forman el sistema, los procesos, etc.), Software (es la estructura BMPN, XML, XSD).	
	1 `CreatedByIDn`,
	0 `LastModifiedByIDn`,
	0 `OwnerIDn`,
	-- `DateCreated`,			 UTC_TIMESTAMP(),				-- Tabla BpmfouTBaseElement [DateBaseElement] -- Fecha de actualizacion.
	-- `DateTimeStamp`,			 UTC_TIMESTAMP(),				-- Tabla BpmfouTBaseElement [DateBaseElement] -- Fecha de actualizacion.
	1333 `TzNameIDn`,			-- Tabla BpmfouTBaseElement [TzName] -- Define el Time Zone del UTC
	-233 `TzOffset`,			-- Tabla BpmfouTBaseElement [TzOffset] -- Carga el tiempo Offset del UTC hasta la hora del servidor 
	null `TableHistory`;
    

