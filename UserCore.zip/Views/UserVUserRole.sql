SELECT 
        `ro`.`CompanyIDn` AS `CompanyIDn`,
        `be01`.`IDName` AS `Company`,
        `ro`.`RoleIDn` AS `RoleIDn`,
        `be02`.`IDName` AS `Role`,
        `ur`.`UserIDn` AS `UserIDn`,
        `us01`.`Alias` AS `Alias`,
        `us01`.`CommunityNickname` AS `Nickname`,
        `ur`.`StateIDn` AS `StateIDn`,
        `ur`.`CreatedByIDn` AS `CreatedByIDn`,
        `ur`.`DateTimeStamp` AS `DateTimeStamp`,
        `ur`.`TzNameIDn` AS `TzNameIDn`,
        `ur`.`TzOffset` AS `TzOffset`,
        `ur`.`LastModifiedByIDn` AS `LastModifiedByIDn`,
        `ur`.`OwnerIDn` AS `OwnerIDn`,
        `ur`.`DateCreated` AS `DateCreated`,
        `ur`.`TableHistory` AS `TableHistory`
    FROM
        ((((`usercore`.`usertuserrole` `ur`
        JOIN `usercore`.`usertrole` `ro` ON ((`ur`.`RoleIDn` = `ro`.`IDNum`)))
        JOIN `bpmncore`.`bpmfoutbaseelement` `be01` ON ((`ro`.`CompanyIDn` = `be01`.`IDNum`)))
        JOIN `bpmncore`.`bpmfoutbaseelement` `be02` ON ((`ro`.`RoleIDn` = `be02`.`IDNum`)))
        JOIN `usercore`.`usertuser` `us01` ON ((`ur`.`UserIDn` = `us01`.`IDNum`)))