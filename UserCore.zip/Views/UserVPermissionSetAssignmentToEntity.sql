-- PermissionSetAssignment To PermissionSetEntity
-- Muestra para un determinado PermisionSet Asignment las Entity habilitadas
SELECT `PsTe`.`ID`,
		`PsTe`.`IDNum`,
		`PsTe`.`FkBeIDnProfile`,
		`be01`.`IDName` AS `Profile`,
        `PsTe`.`FkBeIDnPermiSet`,
        `be02`.`IDName` AS `PermiSet`,
		`PsTe`.`FkBeIDnPermiSetType`,
        `be03`.`IDName` AS `PermiSetType`,
        `PsTe`.`PermiSetIsGrant`,
        `PsTe`.`HasActivationRequired`,
        `PsTe`.`FkBeIDnEntity`,
        `be04`.`IDName` AS `Entity`,
		`PsTe`.`PermiEntityUse`
FROM (
		SELECT `Psat`.`ID`,
				`Psat`.`IDNum`,
				`Psat`.`FkBeIDnProfile`,
				`Psat`.`FkBeIDnPermiSet`,
				`Psat`.`PermiSetIsGrant`,
				`Psat`.`HasActivationRequired`,
				`Psat`.`FkBeIDnPermiSetType`,
				`Pse`.`FkBeIDnEntity`,
				`Pse`.`PermiEntityUse`
			FROM `usercore`.`uservpermissionsetassignmenttopermissionsettotal` `Psat`
				INNER JOIN `usercore`.`usertpermissionsetentity` `Pse` ON `Psat`.`FkBeIDnPermiSet` = `Pse`.`FkBeIDnPermiSet`
	) `PsTe`
			INNER JOIN `bpmncore`.`bpmtfounbaseelement` `be01` ON `be01`.`IDNum` = `PsTe`.`FkBeIDnProfile`
            INNER JOIN `bpmncore`.`bpmtfounbaseelement` `be02` ON `be02`.`IDNum` = `PsTe`.`FkBeIDnPermiSet`
            INNER JOIN `bpmncore`.`bpmtfounbaseelement` `be03` ON `be03`.`IDNum` = `PsTe`.`FkBeIDnPermiSetType`
            INNER JOIN `bpmncore`.`bpmtfounbaseelement` `be04` ON `be04`.`IDNum` = `PsTe`.`FkBeIDnEntity`
;


/*

SELECT `Psa`.`ID`,
    `Psa`.`IDNum`,
    `Psa`.`FkBeIDnProfile`,
    `Psa`.`FkBeIDnPermiSetoGroup`,
    `Psa`.`FkBeIDnState`,
    `Psa`.`DateTimeStamp`,
    `Psa`.`FkBeIDnTzName`,
    `Psa`.`TzOffset`,
    `Psa`.`UserIDNum`,
    `Psa`.`TableHistory`
FROM `usercore`.`usertpermissionsetassignment` `Psa`;


SELECT `Pst`.`FkBeIDnPermiSet`,
    `Pst`.`HasActivationRequired`,
    `Pst`.`FkBeIDnPermiSetType`,
    `Pst`.`FkBeIDnState`,
    `Pst`.`DateTimeStamp`,
    `Pst`.`FkBeIDnTzName`,
    `Pst`.`TzOffset`,
    `Pst`.`UserIDNum`,
    `Pst`.`TableHistory`
FROM `usercore`.`usertpermissionset` `Pst`;

SELECT `Pse`.`ID`,
    `Pse`.`IDNum`,
    `Pse`.`FkBeIDnPermiSet`,
    `Pse`.`FkBeIDnEntity`,
    `Pse`.`PermiEntityUse`,
    `Pse`.`FkBeIDnState`,
    `Pse`.`DateTimeStamp`,
    `Pse`.`FkBeIDnTzName`,
    `Pse`.`TzOffset`,
    `Pse`.`UserIDNum`,
    `Pse`.`TableHistory`
FROM `usercore`.`usertpermissionsetentity` `Pse`;


*/
