SELECT Us.`ID`, Us.`IDNum`, Us.`EmployeeNumber`,
    Us.`UserTypeIDn`, Be01.IDName `UserType`,
    Us.`LanguageIDn`,
    Us.`FirstName`, Us.`LastName`, Us.`Alias`, Us.`CommunityNickname`, Us.`Email`,
    Us.`UserPassword`, Us.`UserPasswordExpiration`,
    Us.`StateIDn`, Us.`CreatedByIDn`, Us.`LastModifiedByIDn`, Us.`OwnerIDn`, Us.`DateCreated`, Us.`DateTimeStamp`, Us.`TzNameIDn`, Us.`TzOffset`, Us.`TableHistory`
FROM `usercore`.`usertuser` `Us` 
	INNER JOIN `bpmncore`.`bpmfoutbaseelement` `Be01` ON `Us`.`UserTypeIDn` = `Be01`.`IDNum`;
    