-- UserVPermissionSetObject
-- Detalle de los PermissionSet para cada Object
SELECT`po`.`ID`,
	   `po`.`IDNum`,
	   `ps`.`CompanyIDn`,
       `be01`.`IDName` AS 'Company',
       `ps`.`PermiSetIDn`,
       `be02`.`IDName` AS 'PermiSet',
       `ps`.`PermiSetIsGrant`,
       IF(`ps`.`PermiSetIsGrant`=1,'True','False') AS `PermiSetIsGrant?`,
	   `po`.`ObjectIDn`,
       `be03`.`IDName` AS 'Object',
	   `po`.`PermiObjCreate`,
	   `po`.`PermiObjRead`,
	   `po`.`PermiObjDelete`,
	   `po`.`PermiObjEdit`,
	   `po`.`PermissionField`,
	   `po`.`StateIDn`,
       `be04`.`IDName` AS 'State',
	   `po`.`CreatedByIDn`,
	   `po`.`LastModifiedByIDn`,
	   `po`.`OwnerIDn`,
	   `po`.`DateCreated`,
	   `po`.`DateTimeStamp`,
	   `po`.`TzNameIDn`,
	   `po`.`TzOffset`,
	   `po`.`TableHistory`
FROM `usercore`.`usertpermissionsetobject` `po`
	JOIN `usercore`.`usertpermissionset` `ps` ON `po`.`PermiSetIDn` = `ps`.`IDNum`
		JOIN `bpmncore`.`bpmfoutbaseelement` `be01` ON `ps`.`CompanyIDn` = `be01`.`IDNum`
        JOIN `bpmncore`.`bpmfoutbaseelement` `be02` ON `ps`.`PermiSetIDn` = `be02`.`IDNum`
    JOIN `bpmncore`.`bpmfoutbaseelement` `be03` ON `po`.`ObjectIDn` = `be03`.`IDNum`
    JOIN `bpmncore`.`bpmfoutbaseelement` `be04` ON `po`.`StateIDn` = `be04`.`IDNum`
;
        
        
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

-- SELECT * FROM usercore.uservpermissionset;

-- Al 32781 UserSystemReadExcep (este permissionSet saca derechos), hay que asignale los siguientes objetos, 
/*
24319	UserTSysEntity
24320	UserTSysEntityStructure
24321	UserTUserToEntityObject

*/



-- 32769
-- SELECT * FROM usercore.uservpermissionsetobject where PermiSetIDn = 32769;


