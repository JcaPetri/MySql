-- Detalle de los PermissionSetEntity
SELECT Pse.`ID`,
    Pse.`IDNum`,
    Pse.`FkBeIDnPermiSet`,
    Be01.IDName `PermiSet`,
    Pse.`FkBeIDnEntity`,
    Be02.IDName `Entity`,    
    Pse.`PermiEntityUse`,
    Pse.`FkBeIDnState`,
    Pse.`DateTimeStamp`,
    Pse.`FkBeIDnTzName`,
    Pse.`TzOffset`,
    Pse.`UserIDNum`,
    Pse.`TableHistory`
FROM `usercore`.`usertpermissionsetentity` Pse 
	INNER JOIN bpmncore.bpmtfounbaseelement Be01 ON
		Pse.FkBeIDnPermiSet = Be01.IDNum
	INNER JOIN bpmncore.bpmtfounbaseelement Be02 ON
		Pse.FkBeIDnEntity = Be02.IDNum;
;
