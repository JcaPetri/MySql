-- #################################################################################################################################################################################
-- uservpermissionsetassigmenttoobjectfield
-- PermissionSetAssignment To PermissionSetObject (Aqui los PermissionSet desaparecen, para que se sumen y resten los derechos de los objetos, ya que se consolidan los Objects)
-- Muestra para un determinado PermisionSet Asigment los Objects habilitados
		SELECT `psato`.`CompanyIDn`,
				`be01`.`IDName` AS 'Company',
				`psato`.`ProfileIDn`,
                `be02`.`IDName` AS 'Profile',
				`psato`.`ObjectIDn`,
                `be03`.`IDName` AS 'Object',
				`psato`.`PermiObjCreate`,
				`psato`.`PermiObjRead`,
				`psato`.`PermiObjDelete`,
				`psato`.`PermiObjEdit`,
				`psato`.`PermissionField`,
				`psato`.`HasActivationRequired`
			FROM `usercore`.`usertpermissionsetassignmenttoobject` `psato`
				JOIN `bpmncore`.`bpmfoutbaseelement` `be01` ON `psato`.`CompanyIDn` = `be01`.`IDNum`
				JOIN `bpmncore`.`bpmfoutbaseelement` `be02` ON `psato`.`ProfileIDn` = `be02`.`IDNum`
				JOIN `bpmncore`.`bpmfoutbaseelement` `be03` ON `psato`.`ObjectIDn` = `be03`.`IDNum`
				;
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
/*
    Tablas que forman la Consulta:
		SELECT * FROM `usercore`.`usertpermissionsetassignmenttoobject` `psat`
		SELECT * FROM `bpmncore`.`bpmfoutbaseelement` `be0`
*/
