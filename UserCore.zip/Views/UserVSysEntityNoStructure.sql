-- UserVSysEntityNoStructure
-- Listado de las Entidades Disponibles
SELECT `ne`.`ID`,
		`ne`.`IDNum`,
		`ne`.`IDName`,
		`ne`.`ScopeIDn`,
        `Be01`.`IDName` `Scope`,
		`ne`.`LanguageIDn`,
        `Be02`.`IDName` `Language`,
		`ne`.`EntityTypeIDn`,
        `Be03`.`IDName` `EntityType`,
		`ne`.`StateIDn`,
        `Be04`.`IDName` `State`
FROM `bpmncore`.`bpmfouventitynostructure` `ne`
	INNER JOIN `bpmncore`.`bpmfoutbaseelement` `Be01` ON `ne`.`ScopeIDn` = `Be01`.`IDNum`
    INNER JOIN `bpmncore`.`bpmfoutbaseelement` `Be02` ON `ne`.`LanguageIDn` = `Be02`.`IDNum`
    INNER JOIN `bpmncore`.`bpmfoutbaseelement` `Be03` ON `ne`.`EntityTypeIDn` = `Be03`.`IDNum`
    INNER JOIN `bpmncore`.`bpmfoutbaseelement` `Be04` ON `ne`.`StateIDn` = `Be04`.`IDNum`