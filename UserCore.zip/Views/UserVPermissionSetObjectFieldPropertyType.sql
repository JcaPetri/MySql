
-- Muestra los PermissionObjectFiels
SELECT * FROM usercore.uservpermissionsetobjectfield;

-- Actualiza el campo PermiFieldEdit = 0 (False), del PermissionSetObjectField
-- estos Fields son generados por el sistema (MySql/Java) y por lo tanto no interviene el usuario
UPDATE `usercore`.`usertpermissionsetobjectfield` `pof`
	JOIN `bpmncore`.`bpmfoutfieldproperties` `fp` 
			ON `pof`.`ObjectFieldIDn` = `fp`.`FieldIDn` 
			AND `fp`.`FieldPropertyTypeIDn` = 2482
            AND `fp`.`FieldPropertyValueIDn` = 1
SET `pof`.`PermiFieldEdit` = 0,
	`pof`.`TableHistory` = "SetOff"				-- 	"SetNull", "SetOff"
WHERE `pof`.`PermiFieldEdit` = 1;


-- Muestra los PermissionSetObjectField que deberian estar bloqueados para su edicion, ya que los actualiza el sistema.
-- si esta todo OK, no debe mostrar ninguna fila esta consulta
SELECT `pof`.`ID`,
    `pof`.`IDNum`,
    `pof`.`PermiSetIDn`,
    `pof`.`ObjectIDn`,
    `pof`.`ObjectFieldIDn`,
    `pof`.`TsFieldOrder`,
    `pof`.`PermiFieldRead`,
    `pof`.`PermiFieldEdit`,
    `pof`.`StateIDn`,
    `pof`.`CreatedByIDn`,
    `pof`.`LastModifiedByIDn`,
    `pof`.`OwnerIDn`,
    `pof`.`DateCreated`,
    `pof`.`DateTimeStamp`,
    `pof`.`TzNameIDn`,
    `pof`.`TzOffset`,
    `pof`.`TableHistory`
FROM `usercore`.`usertpermissionsetobjectfield` `pof`
	JOIN `bpmncore`.`bpmfoutfieldproperties` `fp` 
			ON `pof`.`ObjectFieldIDn` = `fp`.`FieldIDn` 
			AND `fp`.`FieldPropertyTypeIDn` = 2482
            AND `fp`.`FieldPropertyValueIDn` = 1
WHERE `pof`.`PermiFieldEdit` = 1;

