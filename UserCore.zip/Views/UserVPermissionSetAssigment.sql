-- uservpermissionsetassigment
-- Muestra los PermissionSetAssigment, tabla que relaciona los Perfiles con sus Permisos
 SELECT 
        `ps`.`IDNum` AS `IDNum`,
        `ps`.`CompanyIDn` AS `CompanyIDn`,
        `be01`.`IDName` AS `Company`,
        `ps`.`PermiSetIDn` AS `PermiSetIDn`,
        `be02`.`IDName` AS `PermiSet`,
        `ps`.`PermiSetIsGrant` AS `PermiSetIsGrant`,
        `ps`.`HasActivationRequired` AS `HasActivationRequired`,
        `ps`.`PermiSetTypeIDn` AS `PermiSetTypeIDn`,
        `be03`.`IDName` AS `PermiSetType`,
        `ps`.`StateIDn` AS `StateIDn`,
        `be04`.`IDName` AS `State`,
        `ps`.`CreatedByIDn` AS `CreatedByIDn`,
        `ps`.`LastModifiedByIDn` AS `LastModifiedByIDn`,
        `ps`.`OwnerIDn` AS `OwnerIDn`,
        `ps`.`DateCreated` AS `DateCreated`,
        `ps`.`DateTimeStamp` AS `DateTimeStamp`,
        `ps`.`TzNameIDn` AS `TzNameIDn`,
        `ps`.`TzOffset` AS `TzOffset`,
        `ps`.`TableHistory` AS `TableHistory`
    FROM
        ((((`usercore`.`usertpermissionset` `ps`
        JOIN `bpmncore`.`bpmfoutbaseelement` `be01` ON ((`ps`.`CompanyIDn` = `be01`.`IDNum`)))
        JOIN `bpmncore`.`bpmfoutbaseelement` `be02` ON ((`ps`.`PermiSetIDn` = `be02`.`IDNum`)))
        JOIN `bpmncore`.`bpmfoutbaseelement` `be03` ON ((`ps`.`PermiSetTypeIDn` = `be03`.`IDNum`)))
        JOIN `bpmncore`.`bpmfoutbaseelement` `be04` ON ((`ps`.`StateIDn` = `be04`.`IDNum`)))
        
        