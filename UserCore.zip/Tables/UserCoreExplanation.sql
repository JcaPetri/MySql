-- ##############################################################################################################################################################################################
-- UserCore Explanation
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Desde PermissionSetAssignment to SysEntity/SysEntityStructure

-- Lo de estructura funciona para las tablas, no para las Clases java, ya que pueden o no tener estructura las JavaClass
-- Esto funciona nada mas para las Tablas, ya que las Entity pueden o no tener estructura.


-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Para poder darle acceso a un SysEntity, la misma debe ser insertada dentro de la base de datos UserCore 
-- se deben ejecutar dos procedimientos almacenados
-- Actualiza la Tabla UserSysEntity, donde estan las Entity java y las Tabla sql
CALL `usercore`.`userpsysentity`();			-- Archivo: UserPSysEntity.sql
	SELECT * FROM `usercore`.`uservsysentity`;		-- Muestra los User SysEntity
    
    
-- Actualiza la Tabla UserSysEntityStructure, donde estan los Fields de las Entity java y las Columns de las Tabla sql
CALL `usercore`.`userpsysentitystructure`();	-- Archivo: UserPSysEntityStructure.sql
	SELECT * FROM `usercore`.`uservsysentitystructure`;		-- Muestra los Sys Entity Structure
    
-- Aclaracion;
-- 			  Para que una Entity pueda insertarse debe estar habilitada y debe tener estructura en la tabla EntityStructure
-- 			  Tablas que estan en bpmncore.bpmfoutbaseelement = Entity y bpmncore.bpmfoutentitystructure
-- 			  por lo tanto si aparece un objeto dentro de estas tablas hay que ir a bpmncore y ver que esten creados correctamente.

-- Muestra las tablas que no tienen asociada una estructura, por lo tanto, nunca se van a trasladar de BpmCore a UserCore
SELECT * FROM usercore.uservsysentitynostructure;

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Proceso para otorgar derechos a una Table Sql
-- Primero: 
-- 			Crear un UserPermissionSet, Archivo: UserPPermissionSet.sql
			SELECT * FROM usercore.uservpermissionset;		-- Archivo: UserVPermissionSet.sql, muestra los permissionSet para cada Company
-- Segundo: 
-- 			Asignarle a un PermissionSet una Entity Tabla sql
-- 			Crear un UserPermissionSetObject, Archivo: UserPPermissionSetObject.sql
			SELECT * FROM usercore.uservpermissionsetobject;	-- Archivo: UserVPermissionSetObject.sql, muestra los PermissionsetObject
-- Tips:
-- 		Se pueden hacer via importacion de excel y se dan masivamente permisos

-- Aclaracion;
-- 				Aqui hay que Tomar el valor unico del TableStructure, lo mismo para las Entity, por lo tanto, en el programa de Java tienen un unico valor
-- 				Todos las Entity, Field, Tables, Column, deben tener su unico numero tanto en SqL como en Java, para luego desde esto definir los permisos
-- 		Si tiene PermissionSet, Delete o Edit o Create, si o si tiene PermissionSet Read, sino seria imposible que trabaje con los datos
-- 		Combinaciones posibles:
--    			PermiObjRead (puede estar solo, lo que hace es mostrar los datos), este puede tener el detalle de PermissionField
--    			PermiObjCreate, debe tener el Read, para leer los record insertados
--    			PermiObjDelete, debe tener el Read, para elegir el record a borrar
--    			PermiObjEdit, debe tener el Read, para elegir el record a editar.


-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Proceso para otorgar derechos a una Column de una Tabla Sql
-- Primero: 
-- 			El PermissionSet ya esta creado
			SELECT * FROM usercore.uservpermissionset;		-- Archivo: UserVPermissionSet.sql, muestra los permissionSet para cada Company
             
-- Segundo: 
			SELECT * FROM usercore.uservpermissionsetobject WHERE PermissionField = 1;	-- Archivo: , muestra los permissionSetObject que tiene PermissionSetField = True
            
-- 			Cuando al campo PermissionField se establece en True = 1, se ejecuta el procedimiento almacenado
-- 			que inserta la EntityStructure dentro de la tabla PermissionSetObjectField, asi quedan disponibles 
-- 			para asignarles o quitarles los derechos, estos pueden ser de Read o Edit unicamente. Si es Edit, si o si debe tener True en Read.
-- 			Un Trigger dentro de la tabla usertPermissionSetObject, ejecuta el StoredProcedure siguiente:
		CALL `usercore`.`userppeermissionsetobjectfieldinsert`();		-- Archivo: UserPPermissionSetObjectFieldInsert.sql
				-- Este StoredProcedure, incluye el vinculo con Fields Properties, para segurar que los campos del sistema no se pueden editar por el usuario
-- Consulta para ver como estan los datos.
	SELECT * FROM usercore.uservpermissionsetobjectfield;	-- Archivo: UserVPermissionSetObjectField.sql, muestra los PermissionsetObjectField

-- Aclaracion:
-- 				Cuando se insertan los registros en la Tabla PermissionSetObjectField, se cargan con todos los derechos, PermiFielRead y PermiFieldEdit en True.
-- 				Hay campos que por su tipo nunca tienen el PermiFieldEdit en true, Ej: SystemFields
-- 				para ello se debe buscar la informacion en la tabla bpmfoutfieldproperties

-- Cuando se cambia el valor del PermissionField = 0 (False), de la tabla PermissionSetObject, 
-- se eliminan los registros de la tabla PermissionSetObjectField, ya que no se definen los accesos a nivel de Field o Columna
-- Se ejecuta el StoredProcedure siguiente, que esta en la tabla usertPermissionSetObject
	CALL `usercore`.`userppeermissionsetobjectfielddelete`();		-- Archivo: UserPPermissionSetObjectFielddelete.sql

-- FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- PermissionSetGroup
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
SELECT * FROM usercore.usertpermissionsetgroup;
	SELECT * FROM usercore.uservpermissionsetgroup;
-- estos agrupan una serie de PermissionSets, de esta forma se simplifica la asignacion de permisos a los usuarios

-- PermissionSetGroupComponent
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Aqui se muestran los permissionSet que tienen cada grupo
SELECT * FROM usercore.usertpermissionsetgroupcomponent;
	SELECT * FROM usercore.uservpermissionsetgroupcomponent;

-- Aclaraciones:
-- 				Puede ser que un perfil, tenga asignado un PermissionSetGroup y que alguno de los PermissionSet estan asignados directamente
-- 				No hay que duplicar la informacion, por eso, lo que se deberia hacer es que la informacion se guarde por PERFIL
-- 				Ya que en un Perfil tiene asignado los PermissionSetGroups y los PermissionSet
-- 				ESTE ES EL NIVEL DE CONSOLIDACION PARA QUE NO HAYA DUPLICACIONES

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- PermissionSetAssigment
SELECT * FROM usercore.usertpermissionsetassignment;
		SELECT * FROM usercore.uservpermissionsetassigment;
		-- La clave primaria es Company - Profile - PermissionSet o Group
-- En esta tabla se asignan para una Company el perfil (profile), los permissionSet o los PermissionSetGroup
-- aqui se consolidan todos los derechos para un perfil (profile).
-- ^^^^^^^^^^^^^^^^^
-- De esta tabla, surge la tabla usertPermissionSetSssigmentToObject, donde esta el listado directo al objeto
-- Para un compania, un Perfil, los objetos/field a los que accede
-- Esta tabla es ser autogenerada, se muestra en la consulta siguiente
SELECT * FROM usercore.uservpermissionsetassigmenttoobject;
       
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Detalle de los PermissionSet o PermissionSetGroup que se pueden asignar a un Perfil
-- para hacer esto se deben unificar la dos tablas, y los campos que se unifican son:
-- 		ID, IDNum, CompanyIDn, PermiSetIDn/PermiSetGroupIDn, PermiSetIsGrant
SELECT * FROM usercore.usertpermissionsetgroup;
SELECT * FROM usercore.usertpermissionset;

-- Si el permissionSet no esta asignado, para la empresa no esta disponible
SELECT * FROM usercore.uservpermissionsetassignmenttotal;

-- Esta consulta genera el detalle de los PermissionSet para un determinado perfil (Profile) de una Compania
-- Aqui se listan los PermissionSet asociados con un PermissionSetAssigment, para una empresa determinada
-- Con esta informacion se debe vincular con los Objects y los Fields para determinar 
-- a que objetos tiene acceso un determinado Profile (perfil)

-- ACLARACIONES:
	-- Como un profile puede tener acceso a varios PermissionSet o PermissionSetGroup, es que la tabla se debe hacer desde el
	-- permissionSetTotal (aqui se consolida el Group y el PermissionSet), por lo tanto es como si solo ubiera un permissionset, 
	-- recordemos que el permissionSetGroup es para simplificar la asignacion a los objetos.


-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- PermissionSetAssigmentTotal	To Object
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Ahora lo que hay que hacer es ver los objetos que esos permissionSet afecta y consolidar los mismos
-- para obtener una unica tabla que tenga Company - Profile - Object (los derechos sobre cada objeto)
-- De esta relacion se crea la Tabla usertpermissionsetassignmenttoobject, esta tabla se actualiza 
-- desde el procedimiento almacenado UserPPermissionSetAssigmentToObject.sql, hay un procedimiento que inserta los nuevo valores y otro actualiza
-- (en este procedimiento almacenado se utiliza la informacion de los PermissionSet, pero los mismos desaparecen, y surge la relacion Company/Profile/Object)
-- luego se genera la tabla:
	SELECT * FROM usercore.usertpermissionsetassignmenttoobject;

	-- Consulta
	SELECT * FROM usercore.uservpermissionsetassigmenttoobject;

-- Esta es la tabla que se utilizara en el programa Java para determinar los accesos
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^



-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- PermissionSetAssigmentTotal	To ObjectField
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Ahora lo que hay que hacer es ver los objetosfield que esos permissionSet afecta y consolidar los mismos
-- para obtener una unica tabla que tenga Company - Profile - ObjectField (los derechos sobre cada objetofield)
-- De esta relacion se crea la Tabla usertpermissionsetassignmenttoobjectfield, esta tabla se actualiza 
-- desde el procedimiento almacenado UserPPermissionSetAssigmentToObjectfield.sql, hay un procedimiento que inserta los nuevo valores y otro actualiza
-- (en este procedimiento almacenado se utiliza la informacion de los PermissionSet, pero los mismos desaparecen, y surge la relacion Company/Profile/Object)
-- luego se genera la tabla:
	SELECT * FROM usercore.usertpermissionsetassignmenttoobjectfield;

	-- Consulta
		SELECT * FROM usercore.uservpermissionsetassigmenttoobjectfield;

-- Pendiente: hacer una matriz donde se muestre la duplicacion de derechos,
-- ###############################################################################################################################################################################3
-- ###############################################################################################################################################################################3

-- ENTITY
/*
La clase Java Entity, se puede o no habilitar, ya que esta clase puede ejecutar multiples acciones. 
Un profile puede o no tener acceso a la misma.

*/



-- Controles de funcionamiento
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- PermissionSet asignados a un perfil de una empresa
SELECT * FROM usercore.uservpermissionsetassigment WHERE CompanyIDn = 7566 AND ProfileIDn = 34310 AND PermiSetoGroupIDn = 32777;
/*
# ID	IDNum	CompanyIDn	Company	ProfileIDn	Profile	PermiSetoGroupIDn	PermiSet/Group	StateIDn	CreatedByIDn	LastModifiedByIDn	OwnerIDn	DateCreated	DateTimeStamp	TzNameIDn	TzOffset	TableHistory
2743ccd5-70d3-11eb-9258-26cb863fa993	3	7566	Tagle	34310	AfterSalesManagerRead	32777	BaseElementRead	514	1	0	0	2021-02-17 00:49:36	2021-02-17 00:49:36	1333	-233	
*/

-- PermissionSet disponibles, por empresa
SELECT * FROM usercore.uservpermissionset WHERE CompanyIDn = 7566 AND PermiSetIDn = 32777;
/*
# IDNum	CompanyIDn	Company	PermiSetIDn	PermiSet	PermiSetIsGrant	HasActivationRequired	PermiSetTypeIDn	PermiSetType	StateIDn	State	CreatedByIDn	LastModifiedByIDn	OwnerIDn	DateCreated	DateTimeStamp	TzNameIDn	TzOffset	TableHistory
9	7566	Tagle	32777	BaseElementRead	1	0	2435	IsSystem	514	ENA	1	0	0	2020-12-10 16:59:42	2021-02-16 10:25:02	1333	-233	
*/
	-- Si el permissionSet no esta asignado a un perfil, no se tiene en cuenta en la empresa para su utilizacion
	-- Estos permissionSet pueden tener object y field asignados, que se ven en las siguientes consultas
		-- Lista todos los permissionSetObject, de una empresa
		SELECT * FROM usercore.uservpermissionsetobject WHERE CompanyIDn = 7566 AND PermiSetIDn = 32777;
        
		-- Estos estan disponibles para asignarlos
		-- Lista todos los permissionSetObjectField, de una empresa
		SELECT * FROM usercore.uservpermissionsetobjectfield WHERE CompanyIDn = 7566 AND PermiSetIDn = 32777 ORDER BY PermiSetIDn,  ObjectIDn, TsFieldOrder;
			-- Estos estan disponibles para asignarlos

		-- Lista los permissionSetGroup de un empresa
		SELECT * FROM usercore.uservpermissionsetgroup;
			-- Estos pueden tener asignados permissionSet, que a su vez tiene Object y Fields
			-- Si el permissionSetGroup no esta asignado a un perfil, no se tiene en cuenta en la empresa para su utilizacion

			-- Lista los PpermissionSet asignados al permissionSetGroup, para una determinada empresa
			SELECT * FROM usercore.uservpermissionsetgroupcomponent;
-- ###############################################################################################################################################################################3

