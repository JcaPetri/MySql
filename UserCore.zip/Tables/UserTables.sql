-- ##############################################################################################################################################################################################
-- 


-- Tabla con la informacion dle Usuario
SELECT * FROM usercore.uservuser;			-- Vista de los Usuario
	SELECT * FROM usercore.usertuser;			-- Datos de los Usuarios	

-- Tabla con los Roles Disponibles
SELECT * FROM usercore.uservrole;			-- Vista de los roles, para una compania/empresa
	SELECT * FROM usercore.usertrole;			-- Datos de los Roles posibles que tienen los Usuario

-- Tabla con la asiacion del Usuario con el Rol que puede cumplir, Estos Roles estan asociados a una empresa especifica. Un Usuario puede tener distintos roles en distintas empresas.
SELECT * FROM usercore.uservuserrole;    	-- Vista de los UserRole, asociacion de un Usuario con Un Rol entro de una compania/empresa
	SELECT * FROM usercore.usertuserrole;		-- Relacion entre los Usuarios y los Roles que pueden asumir en una determinada empresa

-- Tabla con los Perfiles disponibles (Profile),
SELECT * FROM usercore.uservprofile;		-- Vista de los Profile, son todos los perfiles disponibles que se le pueden asignar a un rol especifico
	SELECT * FROM usercore.usertprofile;		-- Datos de los Profiles

-- Tabla con la asociacion de los Roles con los Perfiles de Usuario, por lo tanto, aqui se define que ese perfil se aplica a una determinada empresa
SELECT * FROM usercore.uservroleprofile;	-- Vista de los Role-Profile, asociacion de un Role con un Profile
	SELECT * FROM usercore.usertroleprofile;	-- Relacion entre los Roles y los Profiles

-- Hasta aqui nos da la informacion del Usuario
-- Consulta desde el Usuario hasta el Perfil
SELECT * FROM usercore.uservusertoprofile;

-- Consuta desde el Usuario hasta el Object
SELECT * FROM usercore.uservusertoobject;


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Lista los PermissionSet totales que tiene un PermissionSetAsignment
-- esta consulta es el vinculo la parte del Usuario/Rol/Perfil y los Objetos que se le pueden asignar al Perfil
-- por eso todas las consultas entre estos submodulos deben llamar a esta subconsulta de union
SELECT * FROM usercore.uservpermissionsetassignmenttopermissionsettotal;
-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

-- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- ##############################################################################################################################################################################################
-- Desde aqui nos da la informacion de los Objectos del Sistema al que el Profile tiene acceso
-- Tabla con los permissionSetAssignment, que son la asociacion entre los Profile y los PermissionSet o los PermissionSetGroup
-- en esta consulta solo lista y muestra los valores de la tabla usertpermissionsetassignment, su vinculo es con BaseElement
SELECT * FROM usercore.uservpermissionsetassignment;		-- Vista de los PermissionSetAssignment, asocia los Perfiles con los PermissionSet o los PermissionSetGroup
	SELECT * FROM usercore.usertpermissionsetassignment;	-- Relacion entre los Profiles y los PermissionSet o los PermissionSetGroup


-- Vincula PermissionSetAssignment con las Entity, para ello debe utilizar la subconsulta de uservpermissionsetassignmenttopermissionsettotal
-- donde esta el vinculo a traves de los Groups y en forma directa con PermissionSet
-- Muestra los PermissionSetAssignment To Entity
SELECT * FROM usercore.uservpermissionsetassigmenttoentity;

-- Muestra los PermissionSet Assignment To Object, para ello debe utilizar la subconsulta de uservpermissionsetassignmenttopermissionsettotal
-- donde esta el vinculo a traves de los Groups y en forma directa con PermissionSet
SELECT * FROM usercore.uservpermissionsetassigmenttoobject;

-- Muestra los PermissionSet Assignment To ObjectField, para ello debe utilizar la subconsulta de uservpermissionsetassignmenttopermissionsettotal
-- donde esta el vinculo a traves de los Groups y en forma directa con PermissionSet
SELECT * FROM usercore.uservpermissionsetassigmenttoobjectfield;



-- ##############################################################################################################################################################################################
-- Determinar realmente que PermissionSet Tiene cada PermissionSetAsignment, ya que los mismos se pueden asignar al usuario a traves del PermissionSetGroup
-- el resultado final es una lista con todos los PermissionSet

-- El Muting hace que el PermissionSet excluya los Object o Field que estan incluidos en el PermitionSet.
-- Cuando se define un PermissionSet, se puede establecer que sea True o False el IsGrant

-- Tabla con los PermissionSet, que contiene los distintos permisos disponibles. Estos se crean en la Tabla BaseElement. Cada uno de ellos da acceso a determinados objetos.
SELECT * FROM usercore.uservpermissionset;				-- Vista de los PermissionSet, estos permission set pueden ser creados por IsSystem o el Usuario
	SELECT * FROM usercore.usertpermissionset;				-- Detalle de los PermissionSet disponibles

-- Tabla con los PermissionSetGroup, contiene los grupos de permission disponibles. Se utiliza para crear un grupo que contenga un Set de Permission y simplificar la asignacion
SELECT * FROM usercore.uservpermissionsetgroup;			-- Vista con los PermissionSetGroup.
	SELECT * FROM usercore.usertpermissionsetgroup;			-- Detalle de los PermissionSetGroup disponibles

-- Tabla con el detalle de los PermissionSet que tienen los distintos PermissionSetGroup
SELECT * FROM usercore.uservpermissionsetgroupcomponent;		-- Vista con los PermissionSetGroupComponent, donde esta para cada PermissionSetGroup lo PermissionSet habilitados
	SELECT * FROM usercore.usertpermissionsetgroupcomponent;		-- Detalle de los PermissionSet que componen cada PermissionSetGroup
-- ##############################################################################################################################################################################################


-- Tabla con los Object al que tiene acceso cada PermissionSet. 
SELECT * FROM usercore.uservpermissionsetobject;			-- Vista con los PermissionSetObject, donde se detalle el tipo de acceso que tiene cada permissionSet
		SELECT * FROM usercore.usertpermissionsetobject;		-- Define para cada PermissionSet, que Tablas accede y con que derechos
-- ##############################################################################################################################################################################################


-- #############################################################################################################################################################################################################
-- Vincula el PermissionSetAssignment con el PermissionSetObject
SELECT * FROM usercore.usertpermissionsetassignment;

SELECT * FROM usercore.usertpermissionsetobject;

-- #############################################################################################################################################################################################################

SELECT * FROM usercore.uservpermissionsetobjectfield;		-- Vista con los PermissionSetObjectField, donde se detalle el permiso para Leer o Editar una columna o campo
	SELECT * FROM usercore.usertpermissionsetobjectfield;		-- Define para cada PermissionSetObject, que Fields tiene habilitado para lectura o escritura. Si o Si debe tener que no Leer/Escribir todos los valores de la tabla para que se habilite para la seleccion individual





SELECT * FROM usercore.usertpermissionsetentity;		-- Define para cada PermissionSet, que Entity Java accede
-- De un Usuario que roles tiene

