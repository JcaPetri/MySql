-- Roles, tipos de perfilesbpmtfounbaseelementbpmtfounbaseelement
SELECT * FROM usercore.uservrole;
/*
		1	7566	Tagle	5070	GeneralManager				5569	Manager
		2	7566	Tagle	5071	SalesManager				5569	Manager
		3	7566	Tagle	5072	AfterSalesManager			5569	Manager
		4	7566	Tagle	5107	SparePartsManager			5571	Responsable
		5	7566	Tagle	5108	SparePartsSeller			5575	Seller
		6	7566	Tagle	5109	SparePartsSellerCounter		5575	Seller
		7	7566	Tagle	5110	SparePartsSellerInsurance	5575	Seller
		8	7566	Tagle	5111	SparePartsSellerCallCenter	5575	Seller
		9	7566	Tagle	5112	SparePartsSellerWeb			5575	Seller
		10	7566	Tagle	5113	SparePartsSupply			5576	PartsOperator
		11	7566	Tagle	5114	SparePartsReceiver			5576	PartsOperator
		12	7566	Tagle	5115	SparePartsWarehouseManager	5570	Supervisor
		13	7566	Tagle	5116	SparePartsWherehouseRepository	5576	PartsOperator
		14	7566	Tagle	5117	SparePartsWarehouseReceiver	5576	PartsOperator
*/

-- Profile
SELECT * FROM usercore.uservprofile;
/*
	1	7566	Tagle	5768	AllSistem						2395	Complete
	3	7566	Tagle	5769	Visitor							2395	Complete
	4	7566	Tagle	5770	Customer						2395	Complete
	5	7566	Tagle	5771	ManagerRead						2396	Read
	6	7566	Tagle	5772	ManagerWrite					2397	Write
	7	7566	Tagle	5775	AfterSalesManagerRead			2396	Read
	8	7566	Tagle	5776	AfterSalesManagerWrite			2397	Write
	9	7566	Tagle	5779	ResponsableRead					2396	Read
	10	7566	Tagle	5780	ResponsableWrite				2397	Write
	11	7566	Tagle	5781	SparePartResponsableRead		2396	Read
	12	7566	Tagle	5782	SparePartResponsableWrite		2397	Write
	13	7566	Tagle	5783	SparePartWarehouseRead			2396	Read
	14	7566	Tagle	5784	SparePartWarehouseWrite			2397	Write
	15	7566	Tagle	5785	SparePartWarehouseManagerRead	2396	Read
	16	7566	Tagle	5786	SparePartWarehouseManagerWrite	2397	Write
	17	7566	Tagle	5787	SparePartWarehouseOperatorRead	2396	Read
	18	7566	Tagle	5788	SparePartWarehouseOperatorWrite	2397	Write
	19	7566	Tagle	5789	SparePartSellerRead				2396	Read
	20	7566	Tagle	5790	SparePartSellerWrite			2397	Write
*/

-- Inserta un Role Profile
INSERT INTO `usercore`.`usertroleprofile`
		(`RoleIDn`,
		`ProfileIDn`,
		`StateIDn`,
		`CreatedByIDn`,
		`LastModifiedByIDn`,
		`OwnerIDn`,
		-- `DateCreated`,
		-- `DateTimeStamp`,
		`TzNameIDn`,
		`TzOffset`,
		`TableHistory`)
	SELECT 14 `RoleIDn`,
		18 `ProfileIDn`,
		514 `StateIDn`,
		1 `CreatedByIDn`,
		0 `LastModifiedByIDn`,
		0 `OwnerIDn`,
		-- `DateCreated`,
		-- `DateTimeStamp`,
		1333 `TzNameIDn`,
		-233 `TzOffset`,
		null `TableHistory`;

-- Profile, lista los Profile del sistema
SELECT * FROM usercore.uservroleprofile;