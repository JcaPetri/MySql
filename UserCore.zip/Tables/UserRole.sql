-- ######################################################################################################################################################################
-- INICIO
-- Para asociar un usuario a un Rol, se hace a traves de una tabla intermedia ya que un Usuario puede tener muchos roles y un Rol puede estar en muchos usuarios

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Usuarios
-- Estos no tienen asociada una empresa ni un rol, asi que un usuario puede tener acceso a varias organizaciones
-- Un usuario, perde ser un Grupo, no es necesario que sea una persona. Este es un concepto importante. 
-- Cuando se crea el grupo el ID viene de esta tabla.
SELECT * FROM usercore.uservuser;
	SELECT * FROM usercore.usertuser;

/*
1	Juan Carlos	Petri
2	Leandro	Pagnone
3	Adrian	Robles
4	Marcelo	Franzone
6	Nelson	Opovin
8	Lucas	Bossetti
9	Ramon	Moreno
10	Aurelio	Sosa
11	Daniel	Guignard
12	Sergio	Ortiz
13	Jose	Peres
13	jpe	JoPer
*/

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Roles
-- Detalle de los para una determinada organizacion. Aqui es donde se arma la estructura de la empresa.
-- para hacer esto, se deben haber creado en los scopes, de compay, role y roletype los valores que estos en si no representan nada.
SELECT * FROM usercore.uservrole;
	SELECT * FROM usercore.usertrole;

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- UserRole
-- Asocia los Usuario/Grupos con los Posibles Roles en una organizacion.
-- los valores son el UserIDn (usuario o grupo) o el RoleIDn (es el role dentro de una organizacion)
SELECT * FROM usercore.uservuserrole;
	SELECT * FROM usercore.usertuserrole;

-- FIN
-- ######################################################################################################################################################################

-- tSisBusiness, se utiliza para definir a que empresa pertenece el UserRole,
-- Un Usuario, puede tener un Rol determinado en una empresa y otro en otra.
SELECT * FROM `bpmncore`.`bpmfouVscopedet` WHERE ScopeIDCode = 19 ORDER BY IDNum;
/*
		19		tSisCompany	1
		7565	Peperina	2
		7566	Tagle		3
*/

-- #########################################################################################################################
-- Roles Disponibles, es un ambito de aplicacion solamente
-- El Role en si no tiene ningun significado hasta que se utiliza en la empresa.
SELECT * FROM `bpmncore`.`bpmfouVscopedet` WHERE ScopeIDCode = 21;
	/*
	21		tSisUserRole				1
	5070	GeneralManager				2
	5071	SalesManager				3
	5072	AfterSalesManager			4
		5073	SystemsManager				5
		5074	AdministrationManager		6
		5075	MasterAdmin					7
		5089	SystemsLeader				21
		5090	SystemsUser					22
	5107	SparePartsManager			39
	5108	SparePartsSeller			40
	5109	SparePartsSellerCounter		41
	5110	SparePartsSellerInsurance	42
	5111	SparePartsSellerCallCenter	43
	5112	SparePartsSellerWeb			44
	5113	SparePartsSupply			45
	5114	SparePartsReceiver			46
	5115	SparePartsWarehouseManager	47
	5116	SparePartsWherehouseRepository	48
	5117	SparePartsWarehouseReceiver	49
	*/

-- RoleType, es un ambito de aplicacion solamente
-- esto se utiliza para generar distintas clasificaciones y filtros.
SELECT * FROM `bpmncore`.`bpmfouVscopedet` WHERE ScopeIDCode = 22 ORDER BY IDNum;
	/*
	22	tSisRoleType		1
	5569	Manager			2
	5571	Responsable		4
	5570	Supervisor		3
	5572	Receptionist	5
	5573	Secretary		6
	5574	Operator		7
    5575	Seller			8
    5576	PartsOperator	9
	*/

-- El Rol se inserta para una determinada Compania
-- Para insertar un UserRole, primero se debe crear el Role en BaseElement, luego insertarlo en esta tabla
INSERT INTO `usercore`.`usertrole`
	(-- `ID`,
	-- `IDNum`,
	`CompanyIDn`,
	`RoleIDn`,
	`RoleTypeIDn`,
	`StateIDn`,
	`CreatedByIDn`,
	`LastModifiedByIDn`,
	`OwnerIDn`,
	-- `DateCreated`,
	-- `DateTimeStamp`,
	`TzNameIDn`,
	`TzOffset`,
	`TableHistory`)
SELECT 7566 `CompanyIDn`,		-- 7566 Tagle
		5070 `RoleIDn`,			-- 5072	AfterSalesManager
		5569 `RoleTypeIDn`,			-- 5569 Manager, 5571 Responsable, 5570	Supervisor, 5572 Receptionist, 5573 Secretary, 5574 Operator, 5575 Seller, 5576 PartsOperator
		514 `StateIDn`,
		1 `CreatedByIDn`,
		0 `LastModifiedByIDn`,
		0 `OwnerIDn`,
		-- `DateCreated`,
		-- `DateTimeStamp`,
		1333 `TzNameIDn`,
		-233 `TzOffset`,
		null `TableHistory`;

-- Muestra el resultado, para la Compania definida
SELECT * FROM `usercore`.`uservrole` WHERE `CompanyIDn` = 7566 Order by RoleIDn Desc;

-- Actualiza el Role
UPDATE `usercore`.`usertrole`
SET -- `CompanyIDn` = 7566,	-- 7566	Repuestar
    `RoleTypeIDn` = 5571,
    /* `RoleIDn` = 5108,	-- 5569 Manager, 5571 Responsable, 5570	Supervisor, 5572 Receptionist, 5573 Secretary, 5574 Operator, 5575 Seller, 5576 PartsOperator
    `StateIDn` = 514,
	`TzNameIDn` = 1333,*/
	`TableHistory` = "SetOff"				-- 	"SetNull", "SetOff"
WHERE `IDNum` = 6;

-- ######################################################################################################################################################
-- UsertUserRole
-- Hay que ver las dos tablas User y Role 
SELECT * FROM usercore.uservuser;
SELECT * FROM usercore.uservrole;
SELECT * FROM usercore.uservuserrole;

-- ######################################################################################################################################################
-- User Roles, (Company, Roles, User)
-- Inserta los Roles al Usuario
INSERT INTO `usercore`.`usertuserrole`
		(`UserIDn`,
		`RoleIDn`,
		`StateIDn`,
		`CreatedByIDn`,
        `LastModifiedByIDn`,
        `OwnerIDn`,
		-- `DateCreated`,
		-- `DateTimeStamp`,
		`TzNameIDn`,
		`TzOffset`,
		`TableHistory`)
SELECT 13 `UserIDn`,			-- El Usuario/Grupo que va a acceder al Rol
		15 `RoleIDn`,			-- El Rol de la empresa especificada (Recordar que el Rol es para una determinada empresa)
        514 `StateIDn`,
		1 `CreatedByIDn`,
        0 `LastModifiedByIDn`,
        0 `OwnerIDn`,
		-- `DateCreated`,
		-- `DateTimeStamp`,
		1333 `TzNameIDn`,
		-233 `TzOffset`,
		null `TableHistory`;
-- Muestra el Resultado
SELECT * FROM usercore.uservuserrole;

-- Actualiza el UserTUserRole
UPDATE `usercore`.`usertuserrole`
SET `UserIDn` = 2,
	-- `RoleIDn` = <{RoleIDn: }>,
	TableHistory = "SetOff"				-- 	"SetNull", "SetOff"
WHERE `UserIDn` = 1 AND `RoleIDn` = 1;

-- #########################################################################################################################
