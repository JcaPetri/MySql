SELECT * FROM usercore.usertlicense;

-- Inserta Una Licencia Nueva
INSERT INTO `usercore`.`usertlicense`
	(-- `IDNum`,					-- Valor Autoincremental
	-- `LicenseDefinitionKey`,		-- Valor UniqueID
	`LicenseName`,
	`MonthlyLoginsEntitlement`,
	`MonthlyLoginsUsed`,
	`TotalLicenses`,
	`UsedLicenses`,
	`UsedLicensesLastUpdated`,
	`StateIDn`,
	`CreatedByIDn`,
	`LastModifiedByIDn`,
	`OwnerIDn`,
	-- `DateCreated`,
	-- `DateTimeStamp`,
	`TzNameIDn`,
	`TzOffset`,
	`TableHistory`)
	SELECT 'TagleWrite' `LicenseName`,
		1000 `MonthlyLoginsEntitlement`,		-- Int, El número máximo de inicios de sesión permitidos por mes.
		1000 `MonthlyLoginsUsed`,				-- Int, La cantidad de inicios de sesión exitosos para todos los usuarios asociados con una licencia de usuario.
		1000 `TotalLicenses`,					-- Int, El número de licencias de usuario en la organización.
		1000 `UsedLicenses`,						-- Int, El número de licencias de usuario asignadas a los usuarios activos de la organización.
		'2021-12-31 23:59:00' `UsedLicensesLastUpdated`,			-- DateTime, La marca de tiempo de la consulta. Si el recuento de licencias supera el umbral asignado a su organización, la marca de tiempo del recuento refleja el día anterior; de lo contrario, la marca de tiempo refleja el día y la hora actuales.
		514 `StateIDn`,
		1 `CreatedByIDn`,
		0 `LastModifiedByIDn`,
		0 `OwnerIDn`,
		-- `DateCreated`,
		-- `DateTimeStamp`,
		1333 `TzNameIDn`,
		-233 `TzOffset`,
		null TableHistory;

-- Listado de Licencias
SELECT * FROM usercore.uservlicense;

        
UPDATE `usercore`.`usertlicense`
SET	`StateIDn` = 514,
	`CreatedByIDn` = 1,
	`LastModifiedByIDn` = 0,
	`OwnerIDn` = 0,
-- 	`DateCreated` = <{DateCreated: }>,
-- 	`DateTimeStamp` = <{DateTimeStamp: }>,
	`TzNameIDn` = 1333,
	`TzOffset` = -233,
	`TableHistory` = "SetOff"		-- 	"SetNull", "SetOff"
WHERE `IDNum` = 1;
