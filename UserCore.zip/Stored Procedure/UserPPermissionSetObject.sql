-- Permission Set Object
-- Esto administra la gestion de las distintas tablas de la base de datos, 
-- es aplicable cuando se le habilita un acceso directo al usuario a que realice sentencias SQL

-- PermissionSet,
SELECT * FROM usercore.uservpermissionset;
/*
	El valor que se toma como IDNum, para asociar un permissionSet en permissionSetObject es IDNum, no el valor del 
		IDNum	Company			PermiSet						PermiSetIsGrant
		1		7566	Tagle	32769	UserSystemRead			1
		2		7566	Tagle	32770	UserSystemWrite			1
		3		7566	Tagle	32771	UserRead				1
		4		7566	Tagle	32772	UserWrite				1
		5		7566	Tagle	32773	UserRoleRead			1
		6		7566	Tagle	32774	UserRoleWrite			1
		7		7566	Tagle	32775	UserPermissionRead		1
		8		7566	Tagle	32776	UserPermissionWrite		1
		9		7566	Tagle	32777	BaseElementRead			1
		10		7566	Tagle	32778	BaseElementWrite		1
		11		7566	Tagle	32779	BpmFoundRead			1
		12		7566	Tagle	32780	BpmFoundWrite			1
		13		7566	Tagle	32781	UserSystemReadExcep		0


*/

-- usertsysentity, Lista los Tablas Disponibles disponibles, Scope 500 Entity, 502 Table
SELECT * FROM usercore.uservsysentity WHERE EntityTypeIDn = 502;		-- 500 Entity, 501 EntityField, 502 Table, 503 TableColumn
/*
		IDNum	
		23990	BpmInfTDefinition
		23991	BpmInfTImport
		23997	BpmFouTBaseElement
		23998	BpmFouTBaseElementLanguage
		23999	BpmFouTDocumentation
		24000	BpmFouTEntityDefaultValue
		24001	BpmFouTEntityStructure
		24002	BpmFouTExtension
		24007	BpmFouTRelationshipDirection
		24009	BpmFouTRootElement
		24302	UserTUserRole
		24303	UserTUserRecordAccess
		24304	UserTGroup
		24305	UserTGroupMember
		24306	UserTRole
		24307	UserTRoleProfile
		24308	UserTRoleStructure
		24309	UserTProfile
		24310	UserTLicense
		24311	UserTPermissionSet
		24312	UserTPermissionSetAssignment
		24313	UserTPermissionSetEntity
		24314	UserTPermissionSetEntityField
		24315	UserTPermissionSetGroup
		24316	UserTPermissionSetGroupComponent
		24317	UserTPermissionSetObject
		24318	UserTPermissionSetObjectField
		24319	UserTSysEntity
		24320	UserTSysEntityStructure
		24321	UserTUserToEntityObject
*/

-- Lista los PermissionSetObject
SELECT * FROM usercore.uservpermissionsetobject;
	SELECT * FROM usercore.usertpermissionsetobject;
/*
	Cuando el PermissionSet es de eliminacion de derechos, el valor 1 elimina el derecho, el 0 no hace nada.
    Por lo tanto, en la consulta de union se deben restar los derechos y sale lo que realmente tiene el usuario
*/


-- Inserta los PermissionSetObject 
INSERT INTO `usercore`.`usertpermissionsetobject`
		(-- `ID`,
		-- `IDNum`,
		`PermiSetIDn`,
		`ObjectIDn`,
		`PermiObjCreate`,
		`PermiObjRead`,
		`PermiObjDelete`,
		`PermiObjEdit`,
		`PermissionField`,
		`StateIDn`,
		`CreatedByIDn`,
		`LastModifiedByIDn`,
		`OwnerIDn`,
		-- `DateCreated`,
		-- `DateTimeStamp`,
		`TzNameIDn`,
		`TzOffset`,
		`TableHistory`)
	SELECT -- `ID`,
		-- `IDNum`,
		13	`PermiSetIDn`,			-- Va el IDNum de la tabla usertPermissionSet, no el de la tabla BaseElement
		 `ObjectIDn`,				-- Va el IDNum de la tabla BaseElement, este es el codigo unico de objeto para todo el sistema
         /*
         24319	UserTSysEntity
		24320	UserTSysEntityStructure
		24321	UserTUserToEntityObject
         */
		1 `PermiObjCreate`,			-- Si el PermiSetIsGrant = 0 (False), cuando el valor del PermissionSetObject es 1, cuando se consolidan los permissionSet, este resta al mismo que tiene otorgado.
		1 `PermiObjRead`,			-- Si el PermiSetIsGrant = 0 (False), cuando el valor del PermissionSetObject es 1, cuando se consolidan los permissionSet, este resta al mismo que tiene otorgado.
		1 `PermiObjDelete`,			-- Si el PermiSetIsGrant = 0 (False), cuando el valor del PermissionSetObject es 1, cuando se consolidan los permissionSet, este resta al mismo que tiene otorgado.
		1 `PermiObjEdit`,			-- Si el PermiSetIsGrant = 0 (False), cuando el valor del PermissionSetObject es 1, cuando se consolidan los permissionSet, este resta al mismo que tiene otorgado.
		0 `PermissionField`,		-- Si el PermiSetIsGrant = 0 (False), cuando el valor del PermissionSetObject es 1, cuando se consolidan los permissionSet, este resta al mismo que tiene otorgado.
		514 `StateIDn`,				-- Define el tipo de dato que es el BaseElement, puede ser: Data (son los elementos reales que forman el sistema, los procesos, etc.), Software (es la estructura BMPN, XML, XSD).	
		1 `CreatedByIDn`,
		0 `LastModifiedByIDn`,
		0 `OwnerIDn`,
		-- `DateCreated`,			 UTC_TIMESTAMP(),				-- Tabla BpmfouTBaseElement [DateBaseElement] -- Fecha de actualizacion.
		-- `DateTimeStamp`,			 UTC_TIMESTAMP(),				-- Tabla BpmfouTBaseElement [DateBaseElement] -- Fecha de actualizacion.
		1333 `TzNameIDn`,			-- Tabla BpmfouTBaseElement [TzName] -- Define el Time Zone del UTC
		-233 `TzOffset`,			-- Tabla BpmfouTBaseElement [TzOffset] -- Carga el tiempo Offset del UTC hasta la hora del servidor 
		null `TableHistory`;
        
	


-- Inserta los PermissionSet Object DESDE LA TABLA DE IMPORTACION dataimport-permisetobj
INSERT INTO `usercore`.`usertpermissionsetobject`
		(-- `ID`,
		-- `IDNum`,
		`PermiSetIDn`,
		`ObjectIDn`,
		`PermiObjCreate`,
		`PermiObjRead`,
		`PermiObjDelete`,
		`PermiObjEdit`,
		`PermissionField`,
		`StateIDn`,
		`CreatedByIDn`,
		`LastModifiedByIDn`,
		`OwnerIDn`,
		-- `DateCreated`,
		-- `DateTimeStamp`,
		`TzNameIDn`,
		`TzOffset`,
		`TableHistory`)
SELECT `po`.`PermiSetIDn`,
		`po`.`ObjectIDn`,
		`po`.`PermiObjCreate`,
		`po`.`PermiObjRead`,
		`po`.`PermiObjDelete`,
		`po`.`PermiObjEdit`,
		`po`.`PermissionField`,
		`po`.`StateIDn`,
		`po`.`CreatedByIDn`,
		`po`.`LastModifiedByIDn`,
		`po`.`OwnerIDn`,
		`po`.`TzNameIDn`,
		`po`.`TzOffset`,
        null `TableHistory`
FROM `usercore`.`dataimport-permisetobj` `po`;

SELECT * FROM `usercore`.`dataimport-permisetobj` `po`;
-- DELETE FROM `usercore`.`dataimport-permisetobj`;

/*
	SELECT 	`PermiSetIDn`,				-- Es el PermissionSet
			`ObjectIDn`,				-- Es el Objeto que se asociara al PermissionSet
			1 `PermiObjCreate`,			-- 1 (Enable), 0 (Diseable)
			1 `PermiObjRead`,			-- 1 (Enable), 0 (Diseable)
			1 `PermiObjDelete`,			-- 1 (Enable), 0 (Diseable)
			1 `PermiObjEdit`,			-- 1 (Enable), 0 (Diseable)
			1 `PermissionField`,		-- 1 (Enable), 0 (Diseable), si esta Enable, se tiene en cuenta los permission a nivel de Field
			514 `StateIDn`,				-- Define el tipo de dato que es el BaseElement, puede ser: Data (son los elementos reales que forman el sistema, los procesos, etc.), Software (es la estructura BMPN, XML, XSD).	
			1 `CreatedByIDn`,
			0 `LastModifiedByIDn`,
			0 `OwnerIDn`,
			-- `DateCreated`,			 UTC_TIMESTAMP(),				-- Tabla BpmfouTBaseElement [DateBaseElement] -- Fecha de actualizacion.
			-- `DateTimeStamp`,			 UTC_TIMESTAMP(),				-- Tabla BpmfouTBaseElement [DateBaseElement] -- Fecha de actualizacion.
			1333 `TzNameIDn`,			-- Tabla BpmfouTBaseElement [TzName] -- Define el Time Zone del UTC
			-233 `TzOffset`,			-- Tabla BpmfouTBaseElement [TzOffset] -- Carga el tiempo Offset del UTC hasta la hora del servidor 
			null `TableHistory`;
*/

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Lista los PermitionSetObject
SELECT * FROM usercore.uservpermissionsetobject WHERE ObjectIDn = 23997;

-- Aqui hay que Tomer el valor unico del TableStructure, lo mismo para las Entity, por lo tanto, en el programa de Java tienen un unico valor
-- Todos las Entity, Field, Tables, Column, deben tener su unico numero tanto en SqL como en Java, para luego desde esto definir los permisos

-- Si tiene PermissionSet, Delete o Edit o Create, si o si tiene PermissionSet Read, sino seria imposible que trabaje con los datos
-- Combinaciones posibles:
--    PermiObjRead (puede estar solo, lo que hace es mostrar los datos), este puede tener el detalle de PermissionField
--    PermiObjCreate, debe tener el Read, para leer los record insertados
--    PermiObjDelete, debe tener el Read, para elegir el record a borrar
--    PermiObjEdit, debe tener el Read, para elegir el record a editar.

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Actualiza un registro del PermissionSetObject, asegurandose que si Create, Delete o Edit estan habilitados, Read lo este
UPDATE `usercore`.`usertpermissionsetobject`
SET `PermiObjRead` = 1,
	TableHistory = "SetOff"				-- 	"SetNull", "SetOff"
WHERE `PermiObjCreate` = 1 OR `PermiObjDelete` = 1 OR `PermiObjEdit` = 1;

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Actualiza el PermissionField
-- luego de que se cambia el valor se debe ejecutar los Stored Procedure que permiten insert/eliminar los PermissionSetObjectFields
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
UPDATE `usercore`.`usertpermissionsetobject`
SET `PermissionField` = 0,
	TableHistory = "SetOff"				-- 	"SetNull", "SetOff"
WHERE IDNum = 103; -- `PermiSetIDn` = 6078 AND `ObjectIDn`= 23999;
-- Estos StoredProcedure se incorporaron dentro del Trigger PermissionSetObject
-- CALL `usercore`.`userppeermissionsetobjectfieldinsert`();
	-- CALL `usercore`.`userpfieldpropertiesupdate`(); Este procedimiento esta dentro del anterior
-- CALL `userppermissionsetobjectfielddelete`();
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

-- Muestra los resultados
-- Lista los PermissionSetObject
SELECT * FROM usercore.uservpermissionsetobject WHERE `PermiSetIDn` = 6078 AND `ObjectIDn`= 23999;

-- Lista los PermissionSetObjectFields
SELECT * FROM usercore.uservpermissionsetobjectfield WHERE `PermiSetIDn` = 6078 AND `ObjectIDn`= 23999;
