-- Lista Tabla PermissionSetAssignmentToObject
SELECT * FROM `usercore`.`uservpermissionsetassigmenttoobjectfield`;
		SELECT * FROM `usercore`.`usertpermissionsetassignmenttoobjectfield`;

-- La idea de estas 3 consultas es tocar lo menos posible los valores que ya estan cargados

-- Elimina los Objetos, que ya no tiene mas acceso los Profile y compañia que se insertaran
USE usercore;
 	DELETE `patof` 
		FROM `usercore`.`usertpermissionsetassignmenttoobjectfield` `patof`
			INNER JOIN (
						 SELECT `psatoof`.`CompanyIDn`,
								`psatoof`.`ProfileIDn`,
								`psatoof`.`ObjectIDn`,
                                `psatoof`.`ObjectFieldIDn`
									-- ,`psatof`.`CompanyIDn` 
							FROM (
									SELECT `psat`.`CompanyIDn`,
											`psat`.`ProfileIDn`,
											/*Esta campos se consolidan y se utiliza su informacion*/
											-- `psat`.`PermiSetIDn`,
											-- `psat`.`PermiSetIsGrant`,
											-- `psat`.`PermiSetTypeIDn`,
											`psof`.`ObjectIDn`,
											`psof`.`ObjectFieldIDn`,
											`psof`.`TsFieldOrder`,
											SUM(IF(`psat`.`PermiSetIsGrant`=1, `psof`.`PermiFieldRead`, `psof`.`PermiFieldRead` * -1)) AS `PermiFieldRead`,
											SUM(IF(`psat`.`PermiSetIsGrant`=1, `psof`.`PermiFieldEdit`, `psof`.`PermiFieldEdit` * -1)) AS `PermiFieldEdit`,
											SUM(`psat`.`HasActivationRequired`) AS `HasActivationRequired`	-- Si el Object en algun permissionSet tenia activado en True el HasActivationRequired, este se traslada y ese objeto tiene True
										FROM `usercore`.`uservpermissionsetassignmenttotal` `psat`
											JOIN `usercore`.`usertpermissionsetobjectfield` `psof` ON `psat`.`IDNumPs` = `psof`.`PermiSetIDn`
										WHERE `psof`.`StateIDn` = 514  
										GROUP BY `psat`.`CompanyIDn`,
											`psat`.`ProfileIDn`,
											`psof`.`ObjectIDn`,
											`psof`.`ObjectFieldIDn`
									) AS `psatof`
										RIGHT JOIN `usercore`.`usertpermissionsetassignmenttoobjectfield` `psatoof`
											 ON `psatof`.`CompanyIDn` = `psatoof`.`CompanyIDn` 
												AND `psatof`.`ProfileIDn` = `psatoof`.`ProfileIDn` 
												AND `psatof`.`ObjectIDn` = `psatoof`.`ObjectIDn`
                                                AND `psatof`.`ObjectFieldIDn` = `psatoof`.`ObjectFieldIDn`
								WHERE `psatof`.`CompanyIDn` IS NULL 
								) `pstofd` 
									ON `patof`.`CompanyIDn` = `pstofd`.`CompanyIDn`
										AND `patof`.`ProfileIDn` = `pstofd`.`ProfileIDn`
                                        AND `patof`.`ObjectIDn` = `pstofd`.`ObjectIDn`
                                        AND `patof`.`ObjectFieldIDn` = `pstofd`.`ObjectFieldIDn`
                                        ;
 
-- Inserta los Nuevos PermissionSetAssignment to ObjectField
	INSERT INTO `usercore`.`usertpermissionsetassignmenttoobjectfield`
			(`CompanyIDn`,
			`ProfileIDn`,
			`ObjectIDn`,
			`ObjectFieldIDn`,
			`TsFieldOrder`,
			`PermiFieldRead`,
			`PermiFieldEdit`,
			`HasActivationRequired`)
		SELECT `psoft`.`CompanyIDn`,
				`psoft`.`ProfileIDn`,
                `psoft`.`ObjectIDn`,
                `psoft`.`ObjectFieldIDn`,
                `psoft`.`TsFieldOrder`,
                IF(`psoft`.`PermiFieldRead`<=0,0,1) AS `PermiObjCreate`,
                IF(`psoft`.`PermiFieldEdit`<=0,0,1) AS `PermiObjRead`,
                IF(`psoft`.`HasActivationRequired`<=0,0,1) AS `HasActivationRequired`
        FROM (
				SELECT `psat`.`CompanyIDn`,
						`psat`.`ProfileIDn`,
                        /*Esta campos se consolidan y se utiliza su informacion*/
						-- `psat`.`PermiSetIDn`,
						-- `psat`.`PermiSetIsGrant`,
                        -- `psat`.`PermiSetTypeIDn`,
						`psof`.`ObjectIDn`,
                        `psof`.`ObjectFieldIDn`,
                        `psof`.`TsFieldOrder`,
						SUM(IF(`psat`.`PermiSetIsGrant`=1, `psof`.`PermiFieldRead`, `psof`.`PermiFieldRead` * -1)) AS `PermiFieldRead`,
						SUM(IF(`psat`.`PermiSetIsGrant`=1, `psof`.`PermiFieldEdit`, `psof`.`PermiFieldEdit` * -1)) AS `PermiFieldEdit`,
						SUM(`psat`.`HasActivationRequired`) AS `HasActivationRequired`	-- Si el Object en algun permissionSet tenia activado en True el HasActivationRequired, este se traslada y ese objeto tiene True
					FROM `usercore`.`uservpermissionsetassignmenttotal` `psat`
						JOIN `usercore`.`usertpermissionsetobjectfield` `psof` ON `psat`.`IDNumPs` = `psof`.`PermiSetIDn`
					WHERE `psof`.`StateIDn` = 514  
					GROUP BY `psat`.`CompanyIDn`,
						`psat`.`ProfileIDn`,
						`psof`.`ObjectIDn`,
                        `psof`.`ObjectFieldIDn`
				) AS `psoft`
					LEFT JOIN `usercore`.`usertpermissionsetassignmenttoobjectfield` `psatof`
						 ON `psoft`.`CompanyIDn` = `psatof`.`CompanyIDn` 
							AND `psoft`.`ProfileIDn` = `psatof`.`ProfileIDn` 
							AND `psoft`.`ObjectIDn` = `psatof`.`ObjectIDn`
                            AND `psoft`.`ObjectFieldIDn` = `psatof`.`ObjectFieldIDn`
			WHERE `psatof`.`CompanyIDn` IS NULL 
            ;


            
-- Actualiza los registros que cambian el permiso
UPDATE `usercore`.`usertpermissionsetassignmenttoobjectfield` `psatof`
	JOIN (
			SELECT `psoft`.`CompanyIDn`,
							`psoft`.`ProfileIDn`,
							`psoft`.`ObjectIDn`,
                            `psoft`.`ObjectFieldIDn`,
							IF(`psoft`.`PermiFieldRead`<=0,0,1) AS `PermiFieldRead`,
							IF(`psoft`.`PermiFieldEdit`<=0,0,1) AS `PermiFieldEdit`,
							IF(`psoft`.`HasActivationRequired`<=0,0,1) AS `HasActivationRequired`
					FROM (
							SELECT `psat`.`CompanyIDn`,
									`psat`.`ProfileIDn`,
									/*Esta campos se consolidan y se utiliza su informacion*/
									-- `psat`.`PermiSetIDn`,
									-- `psat`.`PermiSetIsGrant`,
									-- `psat`.`PermiSetTypeIDn`,
									`psof`.`ObjectIDn`,
									`psof`.`ObjectFieldIDn`,
									`psof`.`TsFieldOrder`,
									SUM(IF(`psat`.`PermiSetIsGrant`=1, `psof`.`PermiFieldRead`, `psof`.`PermiFieldRead` * -1)) AS `PermiFieldRead`,
									SUM(IF(`psat`.`PermiSetIsGrant`=1, `psof`.`PermiFieldEdit`, `psof`.`PermiFieldEdit` * -1)) AS `PermiFieldEdit`,
									SUM(`psat`.`HasActivationRequired`) AS `HasActivationRequired`	-- Si el Object en algun permissionSet tenia activado en True el HasActivationRequired, este se traslada y ese objeto tiene True
								FROM `usercore`.`uservpermissionsetassignmenttotal` `psat`
									JOIN `usercore`.`usertpermissionsetobjectfield` `psof` ON `psat`.`IDNumPs` = `psof`.`PermiSetIDn`
								WHERE `psof`.`StateIDn` = 514  
								GROUP BY `psat`.`CompanyIDn`,
									`psat`.`ProfileIDn`,
									`psof`.`ObjectIDn`,
									`psof`.`ObjectFieldIDn`
							) AS `psoft`
			) `psatoq`
				ON `psatof`.`CompanyIDn` = `psatoq`.`CompanyIDn` 
					AND `psatof`.`ProfileIDn` = `psatoq`.`ProfileIDn` 
					AND `psatof`.`ObjectIDn` = `psatoq`.`ObjectIDn`
					AND `psatof`.`ObjectFieldIDn` = `psatoq`.`ObjectFieldIDn`
SET
	`psatof`.`PermiFieldRead` = `psatoq`.`PermiFieldRead`,
	`psatof`.`PermiFieldEdit` = `psatoq`.`PermiFieldEdit`,
	`psatof`.`HasActivationRequired` = `psatoq`.`HasActivationRequired`
;




-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
/*
    Tablas que forman la Consulta:
		SELECT * FROM `usercore`.`uservpermissionsetassignmenttotal` `psat`
        
												IDNumPsA, IDNumPs, Company, ProfileIDn, PermiSetIDn
        4c0889a4-70d3-11eb-9258-26cb863fa993	4		  1			7566	34304		32769	UserSystemRead 		1	0	2435
		4c0889a4-70d3-11eb-9258-26cb863fa993	4		  3			7566	34304		32771	UserRead 			1	0	2435
		4c0889a4-70d3-11eb-9258-26cb863fa993	4		  5			7566	34304		32773	UserRoleRead 		1	0	2435
		4c0889a4-70d3-11eb-9258-26cb863fa993	4		  7			7566	34304		32775	UserPermissionRead	1	0	2435
	
		Si a un mismo Profile le doy acceso a varios perfiles que estos le dan derecho al mismo objeto, esto se debe consolidar


		SELECT * FROM `usercore`.`usertpermissionsetobjectfield` `psof`	

        SELECT * FROM usercore.usertpermissionset WHERE PermiSetIDn = 33793;
        
*/
