-- Ejecuta el procedimiento almacenado 
CALL `usercore`.`userpsysentitystructure`();

-- UserPSysEntityStructure
-- Inserta Las Entity Structure pendientes
INSERT INTO `usercore`.`usertsysentitystructure`
	(`ID`,
	`IDNum`,
	`EntityTypeIDn`,
	`EntityIDn`,
	`FieldIDn`,
	`FieldTypeIDn`,
	`TsFieldOrder`,
	`StateIDn`)
		SELECT `es`.`ID`,
				`es`.`IDNum`,
				`es`.`EntityTypeIDn`,
				-- `es`.`EntityType`,
				`es`.`EntityIDn`,
				-- `es`.`Entity`,
				`es`.`FieldIDn`,
				-- `es`.`ield`,
				`es`.`FieldTypeIDn`,
				-- `es`.`FieldTyp`,
				`es`.`TsFieldOrder`,
				-- `es`.`AdmitDefaultValueIDn`,
				`es`.`StateIDn`
				-- `es`.`State`,
				-- `es`.`CreatedByIDn`,
				-- `es`.`LastModifiedByIDn`,
				-- `es`.`OwnerIDn`,
				-- `es`.`DateCreated`,
				-- `es`.`DateTimeStamp`,
				-- `es`.`TzNameIDn`,
				-- `es`.`TzOffset`,
				-- `es`.`TableHistory`
		FROM `bpmncore`.`bpmfouventitystructure` `es`
			LEFT OUTER JOIN `usercore`.`usertsysentitystructure` `ss` ON `es`.`IDNum` = `ss`.`IDNum`
		WHERE `ss`.`IDNum`IS NULL;


-- Lista las Tablas y Sus Columnas Disponibles para darles autorizacion
SELECT * FROM usercore.uservsysentitystructure;
