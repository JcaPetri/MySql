-- Muestra los PermissionSetGroup disponibles
SELECT * FROM usercore.uservpermissionsetgroup;

-- Lista los Company disponibles
SELECT * FROM `bpmncore`.`bpmfoutbaseelement` WHERE `ScopeIDn` = 19 Order by IDNum;
/*
	19	tSisCompany
	7565	Peperina
	7566	Tagle
*/

-- Lista los posibles PermissionSetGroup
SELECT * FROM `bpmncore`.`bpmfoutbaseelement` WHERE `ScopeIDn` = 24315 Order by IDNum;
/*
		33791	tSisPermissionSetGroup
		33792	UserGroupAll
		33793	UserGroupView
		33794	tSisPermissionSetGroupFree 4
*/

-- Lista los PermissionSetGroup Status
SELECT * FROM `bpmncore`.`bpmfoutbaseelement` WHERE `ScopeIDn` = 27 Order by IDNum;
/*
		27	tSisPermissionSetGroupStatus
		7066	Updated				27
		7067	Outdated			27
		7068	Updating			27
		7069	Failed				27
		7070	tSisPermissionSetGroupFree 6	27
*/
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Inserta un PermissionSetGroup
INSERT INTO `usercore`.`usertpermissionsetgroup`
		(-- `ID`,
		-- `IDNum`,
		`CompanyIDn`,
		`PermiSetGroupIDn`,
		`PermiStatusIDn`,
		`StateIDn`,
		`CreatedByIDn`,
		`LastModifiedByIDn`,
		`OwnerIDn`,
		-- `DateCreated`,
		-- `DateTimeStamp`,
		`TzNameIDn`,
		`TzOffset`,
		`TableHistory`)
SELECT 	7566 `CompanyIDn`,			-- 7566 Tagle, 7565 Peperina
		33793 `PermiSetGroupIDn`,	-- 33792 UserGroupAll, 	33793 UserGroupView
		7066 `PermiStatusIDn`,		-- 7066	Updated, 7067	Outdated, 7068	Updating, 7069	Failed
		514 `StateIDn`,				-- Define el tipo de dato que es el BaseElement, puede ser: Data (son los elementos reales que forman el sistema, los procesos, etc.), Software (es la estructura BMPN, XML, XSD).	
		1 `CreatedByIDn`,
		0 `LastModifiedByIDn`,
		0 `OwnerIDn`,
		-- `DateCreated`,			 UTC_TIMESTAMP(),				-- Tabla BpmfouTBaseElement [DateBaseElement] -- Fecha de actualizacion.
		-- `DateTimeStamp`,			 UTC_TIMESTAMP(),				-- Tabla BpmfouTBaseElement [DateBaseElement] -- Fecha de actualizacion.
		1333 `TzNameIDn`,			-- Tabla BpmfouTBaseElement [TzName] -- Define el Time Zone del UTC
		-233 `TzOffset`,			-- Tabla BpmfouTBaseElement [TzOffset] -- Carga el tiempo Offset del UTC hasta la hora del servidor 
		null `TableHistory`;

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Lista los PermissionSetGroup disponibles
SELECT * FROM usercore.uservpermissionsetgroup;
