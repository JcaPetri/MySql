SELECT * FROM usercore.usertuser;

/*
20	tSisUserType		1
5001	MasterAdmin		2
5002	GeneralAdmin	3
5010	GralUser		11
5011	VisitUser		12

*/


INSERT INTO `usercore`.`usertuser`
(-- `ID`,		Se Genera Automaticamente
	 -- `IDNum`,	Se Genera uiid()
	`EmployeeNumber`,
	`UserTypeIDn`,
	`LanguageIDn`,
	`FirstName`,
	`LastName`,
	`Alias`,
	`CommunityNickname`,
	`Email`,
	`UserPassword`,
	`UserPasswordExpiration`,
	`StateIDn`,
	`CreatedByIDn`,
	`LastModifiedByIDn`,
	`OwnerIDn`,
	-- `DateCreated`,
	-- `DateTimeStamp`,
	`TzNameIDn`,
	`TzOffset`,
	`TableHistory`
	)
	SELECT -- `ID`,		Se Genera Automaticamente
		-- `IDNum`,	Se Genera uiid()
        134 `EmployeeNumber`,
		5010 `UserTypeIDn`,				-- 5001	MasterAdmin, 5002 GeneralAdmin, 5010	GralUser
		779 `LanguageIDn`,
		'Jose' `FirstName`,
		'Peres' `LastName`,
		'jpe' `Alias`,
		'JoPer' `CommunityNickname`,
		'joseperes@hotmail.com' `Email`,
		'1' `UserPassword`,
		'2100-12-31 23:59:00' `UserPasswordExpiration`,
		514 `StateIDn`,
		1 `CreatedByIDn`,
		0 `LastModifiedByIDn`,
		0 `OwnerIDn`,
    	-- `DateCreated`,
		-- `DateTimeStamp`,
		1333 `TzNameIDn`,
		-233 `TzOffset`,
		null `TableHistory`
;

-- Actualiza los usuario
UPDATE `usercore`.`usertuser`
	SET	
    /*
    `UserTypeIDn` = 5001,
    `FirstName` = 'Juan Carlos',
	`LastName` = 'Petri',
	`Alias` = 'jcp',
	`CommunityNickname` = 'JcaPetri',
	`Email` = 'juancpetri@hotmail.com',
	`UserIDNum` = 1,
    `StateIDn` = 514,
    `TzNameIDn` = '1333',
    */
    `LanguageIDn` = 779,
	`TableHistory` = "SetOff"				-- 	"SetNull", "SetOff"
WHERE `IDNum` = 1;

SELECT * FROM `usercore`.`usertuser`;
