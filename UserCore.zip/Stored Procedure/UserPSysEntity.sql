-- Llama al Stored Procedure
CALL `usercore`.`userpsysentity`();

-- Consulta que genera el StoredProcedure, para insertar las Entity/Tables Objects
-- Inserta las Tables and Entity Object en la base UserCore que Tienen una EntityStructure, si no no se listan.
INSERT INTO `usercore`.`usertsysentity`
	(`ID`,
	`IDNum`,
	`IDName`,
	`ScopeIDn`,
	`LanguageIDn`,
	`EntityTypeIDn`,
	`StateIDn`)
SELECT `en`.`ID`,
		`en`.`IDNum`,
		`en`.`IDName`,
		`en`.`ScopeIDn`,
		`en`.`LanguageIDn`,
		`en`.`EntityTypeIDn`,
		`en`.`StateIDn`
FROM `bpmncore`.`bpmfouventity` `en`
		LEFT OUTER JOIN `usercore`.`usertsysentity` `ue` ON
			`en`.`IDNum` = `ue`.`IDNum`
WHERE `ue`.`IDNum` IS NULL;		-- Quiere decir que no estan en la Base UserCore 
