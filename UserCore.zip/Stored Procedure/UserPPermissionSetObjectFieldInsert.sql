-- UserPPeermissionSetObjectField es un Stored Procedure
CALL `usercore`.`userppeermissionsetobjectfieldinsert`();

-- Inserta las Columnas en la tabla PermissionSetObjectField que dentro del PermisssionSetObject, 
-- esta habilitada la Columna PermissionField en True
-- Cuando las inserta se asegura que las columnas no editables se establezcan en false
INSERT INTO `usercore`.`usertpermissionsetobjectfield`
	(-- `ID`,
	-- `IDNum`,
	`PermiSetIDn`,
	`ObjectIDn`,
	`ObjectFieldIDn`,
	`TsFieldOrder`,
	`PermiFieldRead`,
	`PermiFieldEdit`,
	`StateIDn`,
	`CreatedByIDn`,
	`LastModifiedByIDn`,
	`OwnerIDn`,
	-- `DateCreated`,
	-- `DateTimeStamp`,
	`TzNameIDn`,
	`TzOffset`
	-- `TableHistory`
    )
SELECT `pi`.*
	FROM (
			SELECT `po`.`PermiSetIDn`,
				`po`.`ObjectIDn`,
				`es`.`FieldIDn`,
				`es`.`TsFieldOrder`,
				1 `PermiFieldRead`,
				if(isnull(`fp`.`FieldIDn`)=true, 1, 0) `PermiFieldEdit`,
                -- `fp`.`FieldIDn`,		Control de los Fields no editables
				`po`.`StateIDn`,
				`po`.`CreatedByIDn`,
				0 `LastModifiedByIDn`,
				`po`.`OwnerIDn`,
				-- `po`.`DateCreated`,
				-- `po`.`DateTimeStamp`,
				`po`.`TzNameIDn`,
				`po`.`TzOffset`
				-- `po`.`TableHistory`
			FROM `usercore`.`usertsysentitystructure` `es`
				INNER JOIN `usercore`.`usertpermissionsetobject` `po` ON `es`.`EntityIDn`  = `po`.`ObjectIDn`
                LEFT JOIN `bpmncore`.`bpmfoutfieldproperties` `fp` 		-- Establece los Fields No Editables
						ON `es`.`FieldIDn` = `fp`.`FieldIDn` 
						AND `fp`.`FieldPropertyTypeIDn` = 2482
						AND `fp`.`FieldPropertyValueIDn` = 1
			WHERE `po`.`PermissionField` = 1		-- True, permisos a nivel de detalle de las columnas de las tablas
				AND `es`.`EntityTypeIDn` = 502		-- Table
				AND `es`.`StateIDn` = 514			-- Enable
			) `pi` 
				LEFT OUTER JOIN `usercore`.`usertpermissionsetobjectfield` `of` ON 
					`pi`.`PermiSetIDn` = `of`.`PermiSetIDn` 
						AND `pi`.`ObjectIDn` = `of`.`ObjectIDn` 
						AND `pi`.`FieldIDn` = `of`.`ObjectFieldIDn`
	WHERE `of`.`ID` IS NULL;

-- Permission Set Object Field
/* 
	Cuando se establece en la tabla PermisionSetObject, la columna PermissionField en True = 1, se le da acceso a las Columnas/Fields a nivel detalle
    ya en la tabla PermisionSetObjectField, se le puede dar o no el permiso para leer o editar un dato. 
    Los Permission de Delete, Create, no son aplicables ya que estan a nivel de registro.
    Reglas:
           Si tiene PermissionEdit, si o si debe tener Read.
*/

-- Detalle de los PermissionSetObject, donde la visualizacion o Edicion se define por Columna
-- lo que debe estar el detalle en la tabla PermissionSetObjectField
SELECT * FROM usercore.uservpermissionsetobject `po` WHERE `po`.`PermissionField` = 1;


-- IMPORTANTE: Hay campos que nunca se pueden editar, como son los ID, IDnum, DateTimeStamp, etc., siempre van a estar en cero, como dehabilitado para la edicion.
/*
	Esto se maneja directamente desde la tabla PermissionSetObjectField	
	Esto se realiza automaticamente cuando se inserta la fila, se consulta lo PropertiesFields
    Tambien hay un StoredProcedure de userpFieldPropertiesUpdate
    
*/

-- #############################################################################################################################################################################################################
-- El procedimiento almacenado, "userppeermissionsetobjectfield", hace que cuando se agrega/actualiza un permissionSetObject, 
-- se ejecuta esta sentencia y se carga los nuevos datos
-- Si se desactiva desde el permissionSetObject, no se eliminanlos datos, solo se los desactiva con el estado
-- Si se desactivan de a uno se hacen desde permissionSetObjectField.
-- Como lo hace:
-- Inserta un PermissionSetObjectField, busca en los PermissionSetObject que tengan las columnas PermissionField en True = 1
-- Luego compara con los datos cargados en la tabla usertpermissionsetobjectfield, para no duplicar los registros para ese PermissionSet
-- Si el Campo es Ineditable por el sistema, la Columna PermiFieldRead se pone a cero False, esto se hace con un Trigger que esta en la Tabla usertPermissionSetObjectField


-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Este StoredProcedure ejecuta la consulta de actualizar todos los Fields que se generan por el sistema y el usuario no los puede modificar
-- UserPPeermissionSetObjectField es un Stored Procedure
CALL `usercore`.`userppeermissionsetobjectfieldinsert`();

-- Muestra los PermissionSetObjectField
SELECT * FROM usercore.uservpermissionsetobjectfield;

-- Elimina los PermissionSetObjectField, cuando el PermissionField de los PermissionSetObject se desactivan se ponen a 0

