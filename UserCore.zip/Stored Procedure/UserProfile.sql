-- ######################################################################################################################################################################
-- INICIO
-- Para agregar un Profile, 
-- Muestra el Resultado
SELECT * FROM usercore.uservprofile;

-- ######################################################################################################################################################################
-- tSisBusiness, se utiliza para definir a que empresa pertenece el UserRole,
-- Un Usuario, puede tener un Rol determinado en una empresa y otro en otra.
SELECT * FROM `bpmncore`.`bpmfouVscopedet` WHERE ScopeIDCode = 19 ORDER BY IDNum;
/*
		19		tSisCompany	1
		7565	Peperina	2
		7566	Tagle		3
*/

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Profile
-- Estos valores estan como un Scope dentro de la tabla bpmfoutbaseelement, en si no tiene significado.
-- cuando se inserta en la tabla UserTProfile es que toman sentido para una compañía
SELECT * FROM `bpmncore`.`bpmfoutbaseelement` WHERE `ScopeIDn` = 23 ORDER BY IDNum;
/*
	23	tSisProfile
	5768	AllSistem
	5769	Visitor
	5770	Customer
	5771	ManagerRead
	5772	ManagerWrite
	5773	SalesManagerRead
	5774	SalesManagerWrite
	5775	AfterSalesManagerRead
	5776	AfterSalesManagerWrite
	5777	AdministratorManagerRead
	5778	AdministratorManagerWrite
	5779	ResponsableRead
	5780	ResponsableWrite
	5781	SparePartResponsableRead
	5782	SparePartResponsableWrite
	5783	SparePartWarehouseRead
	5784	SparePartWarehouseWrite
	5785	SparePartWarehouseManagerRead
	5786	SparePartWarehouseManagerWrite
	5787	SparePartWarehouseOperatorRead
	5788	SparePartWarehouseOperatorWrite
	5789	SparePartSellerRead
	5790	SparePartSellerWrite
*/
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ProfileType
-- Estos valores estan como un Scope dentro de la tabla bpmfoutbaseelement, en si no tiene significado
-- cuando se inserta en la tabla UserTProfile es que toman sentido para una compañía
SELECT * FROM `bpmncore`.`bpmfoutbaseelement` WHERE `ScopeIDn` = 24 ORDER BY IDNum;
/*
	24		tSisProfileType
	2395	Complete
	2396	Read
	2397	Write
*/

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Listado de Licencias
SELECT * FROM usercore.usertlicense;
/*
	1	Eternity	495d2899-08bb-11eb-9baa-43cd3abbf9b1
	2	TagleRead	7bf57a7b-3558-11eb-a83a-d9f12c069bf6
	3	TagleWrite	88c2e3c5-3558-11eb-a83a-d9f12c069bf6
*/

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- UserTProfile
SELECT * FROM usercore.usertprofile;

-- ######################################################################################################################################################################
-- Inserta un Profile
-- Para hacer esto hay que definir la (Company y el Profile), esto no se puede repetir
INSERT INTO `usercore`.`usertprofile`
	(-- `ID`,
	-- `IDNum`,
	`CompanyIDn`,
	`ProfileIDn`,
	`ProfileTypeIDn`,
	`LicenseIDn`,
	`StateIDn`,
	`CreatedByIDn`,
	`LastModifiedByIDn`,
	`OwnerIDn`,
	-- `DateCreated`,
	-- `DateTimeStamp`,
	`TzNameIDn`,
	`TzOffset`,
	`TableHistory`)
	SELECT -- `ID`,
			-- `IDNum`,
			7566 `CompanyIDn`,			-- 7565 Peperina, 7566 Tagle
			5768 `ProfileIDn`,			-- 5768 AllSistem, 5769 Visitor, 5770 Customer, 5771 ManagerRead 5772 Write, 5775 AfterSalesManagerRead 5776 Write, 5779 ResponsableRead 5780 Write, 5781 SparePartResponsableRead 5782 Write
			2396 `ProfileTypeIDn`,		-- 2395 Complete, 2396 Read, 2397 Write	
			2 `LicenseIDn`,				-- 1 Eternity, 2 TagleRead, 3 TagleWrite
			514 `StateIDn`,
			1 `CreatedByIDn`,
			0 `LastModifiedByIDn`,
			0 `OwnerIDn`,
			-- `DateCreated`,
			-- `DateTimeStamp`,
			1333 `TzNameIDn`,
			-233 `TzOffset`,
			null TableHistory;

-- Muestra el Resultado
SELECT * FROM usercore.uservprofile;


-- ######################################################################################################################################################################
-- Actualiza
/*
UPDATE `usercore`.`usertprofile`
SET 
`ProfileTypeIDn` = 2395,
`TableHistory` = "SetOff"				-- 	"SetNull", "SetOff"
WHERE `IDNum` = 1;

*/