-- userppermissionsetobjectfielddelete
CALL `userppermissionsetobjectfielddelete`();

-- Elimna los PermissionSetObjectField, cuando en la tabla PermissionSetObject se especifico que no se determina a nivel de Field
DELETE FROM `usercore`.`usertpermissionsetobjectfield`
WHERE CONCAT(`PermiSetIDn`, `ObjectIDn`) 
		IN (
			SELECT `CID`
				FROM (SELECT CONCAT(`pof`.`PermiSetIDn`, `pof`.`ObjectIDn`) `CID`
						 FROM `usercore`.`usertpermissionsetobjectfield` `pof`
							JOIN `usercore`.`usertpermissionsetobject` `po` 
								ON `pof`.`ObjectIDn` = `po`.`ObjectIDn`
									AND `pof`.`PermiSetIDn` = `po`.`PermiSetIDn`
						 WHERE `po`.`PermissionField` = 0) `of`
			);

-- Muestra los PermissionSetObjectField, cuando en la tabla PermissionSetObject se especifico que no se determina a nivel de Field
-- Esta consulta deberia ser nula, si funciona todo OK
SELECT *
 FROM `usercore`.`usertpermissionsetobjectfield` `pof`
	JOIN `usercore`.`usertpermissionsetobject` `po` 
		ON `pof`.`ObjectIDn` = `po`.`ObjectIDn`
			AND `pof`.`PermiSetIDn` = `po`.`PermiSetIDn`
WHERE `po`.`PermissionField` = 0;
