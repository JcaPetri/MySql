-- Muestra los PermissionSetGroupComponent disponibles
SELECT * FROM usercore.usertpermissionsetgroupcomponent;

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Lista los posibles PermissionSetGroup, por empresas
SELECT * FROM usercore.uservpermissionsetgroup;
/*
			1	7566	Tagle	33792	UserGroupWrite
			2	7566	Tagle	33793	UserGroupRead
*/

-- Lista los PermissionSet, por empresas
-- El permissionSet puede ser positivo o negativo, quiere decir que puedo establecer un PermissionSet para que quite derechos a un Fiedl/Column especifico
SELECT * FROM usercore.uservpermissionset;
/*
	1	7566	Tagle	32769	UserSystemRead		1
	2	7566	Tagle	32770	UserSystemWrite		1
	3	7566	Tagle	32771	UserRead			1
	4	7566	Tagle	32772	UserWrite			1
	5	7566	Tagle	32773	UserRoleRead		1
	6	7566	Tagle	32774	UserRoleWrite		1
	7	7566	Tagle	32775	UserPermissionRead	1
	8	7566	Tagle	32776	UserPermissionWrite	1
	9	7566	Tagle	32777	BaseElementRead		1
	10	7566	Tagle	32778	BaseElementWrite	1
	11	7566	Tagle	32779	BpmFoundRead		1
	12	7566	Tagle	32780	BpmFoundWrite		1
*/


-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Inserta un PermissionSetGroupComponent
INSERT INTO `usercore`.`usertpermissionsetgroupcomponent`
		(-- `ID`,
		-- `IDNum`,
		`PermiSetGroupIDn`,
		`PermiSetIDn`,
		`StateIDn`,
		`CreatedByIDn`,
        `LastModifiedByIDn`,
		`OwnerIDn`,
		-- `DateTimeStamp`,
		-- `DateCreated`,
		`TzNameIDn`,
		`TzOffset`,
		`TableHistory`)
SELECT 	1 `PermiSetGroupIDn`,
		8 `PermiSetIDn`,
		514 `StateIDn`,				-- Define el tipo de dato que es el BaseElement, puede ser: Data (son los elementos reales que forman el sistema, los procesos, etc.), Software (es la estructura BMPN, XML, XSD).	
		1 `CreatedByIDn`,
		0 `LastModifiedByIDn`,
		0 `OwnerIDn`,
		-- `DateCreated`,			 UTC_TIMESTAMP(),				-- Tabla BpmfouTBaseElement [DateBaseElement] -- Fecha de actualizacion.
		-- `DateTimeStamp`,			 UTC_TIMESTAMP(),				-- Tabla BpmfouTBaseElement [DateBaseElement] -- Fecha de actualizacion.
		1333 `TzNameIDn`,			-- Tabla BpmfouTBaseElement [TzName] -- Define el Time Zone del UTC
		-233 `TzOffset`,			-- Tabla BpmfouTBaseElement [TzOffset] -- Carga el tiempo Offset del UTC hasta la hora del servidor 
		null `TableHistory`;

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Lista los PermissionSetGroup disponibles
SELECT * FROM usercore.uservpermissionsetgroupcomponent;
