-- Asigna un PermissionSet o PermissionSetGroup a un Profile.
-- el Profile esta asignado a un Rol que tiene un usuario
SELECT * FROM usercore.uservpermissionsetassigment;
	SELECT * FROM `usercore`.`usertpermissionsetassignment` `psa`;
/*
	Company			Profile							PermissionSet/Group
	7566	Tagle	34310	AfterSalesManagerRead	32771	UserRead
	7566	Tagle	34310	AfterSalesManagerRead	32777	BaseElementRead
	7566	Tagle	34304	Visitor					33793	UserGroupRead
*/

/*
IMPORTANTE: 
			Como la clave primaria es Company / Profile / PermissionSet o PermissionSetGroup, 
			es que si o si se ponen los IDNum de cada uno de ellos de la tabla BaseElement y no los ID de sus respectivas tablas, ya que estos ID todos inician en 1 y no se sabria cual es
*/

-- Profile Disponibles
SELECT * FROM usercore.uservprofile;
-- Debo tomar un profile de una company
/*		
		1	7566	Tagle	34303	AllSistem					2395	Complete
		3	7566	Tagle	34304	Visitor						2395	Complete
		4	7566	Tagle	34305	Customer					2395	Complete
		5	7566	Tagle	34306	ManagerRead					2396	Read
		6	7566	Tagle	34307	ManagerWrite				2397	Write
		7	7566	Tagle	34310	AfterSalesManagerRead		2396	Read
		8	7566	Tagle	34311	AfterSalesManagerWrite		2397	Write
		9	7566	Tagle	34314	ResponsableRead				2396	Read
		10	7566	Tagle	34315	ResponsableWrite			2397	Write
		11	7566	Tagle	34316	SparePartResponsableRead	2396	Read
		12	7566	Tagle	34317	SparePartResponsableWrite	2397	Write
		13	7566	Tagle	34318	SparePartWarehouseRead		2396	Read
		14	7566	Tagle	34319	SparePartWarehouseWrite		2397	Write
		15	7566	Tagle	34320	SparePartWarehouseManagerRead	2396	Read
		16	7566	Tagle	34321	SparePartWarehouseManagerWrite	2397	Write
		17	7566	Tagle	34322	SparePartWarehouseOperatorRead	2396	Read
		18	7566	Tagle	34323	SparePartWarehouseOperatorWrite	2397	Write
		19	7566	Tagle	34324	SparePartSellerRead				2396	Read
		20	7566	Tagle	34325	SparePartSellerWrite			2397	Write
*/

-- PermissionSet Disponibles
SELECT * FROM usercore.uservpermissionset;
	-- Lista los Objetos que muestra el permissionSet
    SELECT * FROM usercore.uservpermissionsetobject;
-- Debo tomar un PermissionSet de la misma Company que elegi el profile
/*
IDNum	Company			PermissionSet
	1	7566	Tagle	32769	UserSystemRead
	2	7566	Tagle	32770	UserSystemWrite
	3	7566	Tagle	32771	UserRead
	4	7566	Tagle	32772	UserWrite
	5	7566	Tagle	32773	UserRoleRead
	6	7566	Tagle	32774	UserRoleWrite
	7	7566	Tagle	32775	UserPermissionRead
	8	7566	Tagle	32776	UserPermissionWrite
	9	7566	Tagle	32777	BaseElementRead
	10	7566	Tagle	32778	BaseElementWrite
	11	7566	Tagle	32779	BpmFoundRead
	12	7566	Tagle	32780	BpmFoundWrite
    13	7566	Tagle	32781	UserSystemReadExcep
*/

-- PermissionSetGroup Disponibles
SELECT * FROM usercore.uservpermissionsetgroup;
-- Debo tomar un PermissionSetGroup de la misma Company que elegi el profile
/*
	IDNum	CompanyIDn	Company	PermiSetGroupIDn	PermiSetGroup	PermiStatusIDn	PermiStatus
		1		7566	Tagle		33792			UserGroupWrite		7066		Updated
		2		7566	Tagle		33793			UserGroupRead		7066		Updated
        
*/

-- Inserta una nuevo Permissionsetassignment
INSERT INTO `usercore`.`usertpermissionsetassignment`
		(-- `ID`,
		-- `IDNum`,
        `CompanyIDn`,
		`ProfileIDn`,
		`PermiSetoGroupIDn`,
		`StateIDn`,
		`CreatedByIDn`,
		`LastModifiedByIDn`,
		`OwnerIDn`,
		-- `DateCreated`,
		-- `DateTimeStamp`,
		`TzNameIDn`,
		`TzOffset`,
		`TableHistory`)
	SELECT 7566 `CompanyIDn`,			-- IDNum de la compania, 7566 Tagle
			34310 `ProfileIDn`,				-- IDNum del Profile, 
											/* 
												34304	Visitor
												34310	AfterSalesManagerRead
												34311	AfterSalesManagerWrite
                                            
                                            */
			32781 `PermiSetoGroupIDn`,   	-- IDNum del PermissionSet:
											/*
													32771	UserRead
													32772	UserWrite
                                                    32777	BaseElementRead
                                                    32779	BpmFoundRead
                                                    32781	UserSystemReadExcep
											   o del PermissionSetGroup:
													33793	UserGroupRead
                                                    33792	UserGroupWrite
													33793	serGroupRead
                                                    
                                        */
			514 `StateIDn`,					-- Define el tipo de dato que es el BaseElement, puede ser: Data (son los elementos reales que forman el sistema, los procesos, etc.), Software (es la estructura BMPN, XML, XSD).	
			1 `CreatedByIDn`,
			0 `LastModifiedByIDn`,
			0 `OwnerIDn`,
			-- `DateCreated`,			 UTC_TIMESTAMP(),				-- Tabla BpmfouTBaseElement [DateBaseElement] -- Fecha de actualizacion.
			-- `DateTimeStamp`,			 UTC_TIMESTAMP(),				-- Tabla BpmfouTBaseElement [DateBaseElement] -- Fecha de actualizacion.
			1333 `TzNameIDn`,			-- Tabla BpmfouTBaseElement [TzName] -- Define el Time Zone del UTC
			-233 `TzOffset`,			-- Tabla BpmfouTBaseElement [TzOffset] -- Carga el tiempo Offset del UTC hasta la hora del servidor 
			null `TableHistory`;

-- Muestra los PermissionSetAssigment
SELECT * FROM usercore.uservpermissionsetassigment;
	SELECT * FROM usercore.usertpermissionsetassignment;
    
