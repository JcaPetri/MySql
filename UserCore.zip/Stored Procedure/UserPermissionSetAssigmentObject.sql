SELECT `Psa`.`ID`,
    `Psa`.`IDNum`,
    `Psa`.`FkBeIDnProfile`,
    `Psa`.`FkBeIDnPermiSetoGroup`,
    `Psa`.`FkBeIDnState`,
    `Psa`.`DateTimeStamp`,
    `Psa`.`FkBeIDnTzName`,
    `Psa`.`TzOffset`,
    `Psa`.`UserIDNum`,
    `Psa`.`TableHistory`
FROM `usercore`.`usertpermissionsetassignment` `Psa`
	INNER JOIN `usercore`.`usertpermissionsetobject` `Pso` ON
		`Psa`.`FkBeIDnProfile`


;



SELECT `Pso`.`ID`,
    `Pso`.`IDNum`,
    `Pso`.`FkBeIDnPermiSet`,
    `Pso`.`FkBeIDnObject`,
    `Pso`.`PermiObjCreate`,
    `Pso`.`PermiObjRead`,
    `Pso`.`PermiObjDelete`,
    `Pso`.`PermiObjEdit`,
    `Pso`.`PermiObjViewAllRecord`,
    `Pso`.`PermiObjModiyAllRecord`,
    `Pso`.`PermiObjViewAllField`,
    `Pso`.`PermiObjEditAllField`,
    `Pso`.`FkBeIDnState`,
    `Pso`.`DateTimeStamp`,
    `Pso`.`FkBeIDnTzName`,
    `Pso`.`TzOffset`,
    `Pso`.`UserIDNum`,
    `Pso`.`TableHistory`
FROM `usercore`.`usertpermissionsetobject` `Pso`;

