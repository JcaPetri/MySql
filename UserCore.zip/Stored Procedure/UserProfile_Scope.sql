-- Profile
-- Muestra la lista de Profile, que surge de la tabla bpmfoutbaseelement
SELECT * FROM `bpmncore`.`bpmfouvscopegroup` WHERE `ScopeIDn` = 23;
	-- # IDNum	ID										IDName			ScopeIDn	ScopeStart		ScopeEnd	ScopeTotal
	-- 	23		d7d63e60-2b7d-11eb-a83a-d9f12c069bf6	tSisProfile			23			5768		   6066			299

-- Lista los IDName para ver cuales son los disponibles
SELECT * FROM `bpmncore`.`bpmfoutbaseelement` WHERE ScopeIDn = 23;

-- Actualiza el IDName y le da entidad a un nuevo baseelement
-- Como ya hay creado 299 Profile, lo que hago es cambiar el nombre nada mas
-- IDName LIKE '%MasterAdmin%'
UPDATE `bpmncore`.`bpmfoutbaseelement`
	SET `IDName` = 'SparePartSellerWrite',
		`IDIsUsed` = 1,
		`TableHistory` = "SetOff"				-- 	"SetNull", "SetOff"
WHERE `IDNum` = 5790 AND `ScopeIDn` = 23;

-- Lista los IDName para ver cuales son los disponibles
SELECT * FROM `bpmncore`.`bpmfoutbaseelement` WHERE `ScopeIDn` = 23;


