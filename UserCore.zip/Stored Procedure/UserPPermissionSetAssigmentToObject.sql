-- Lista Tabla PermissionSetAssignmentToObject
SELECT * FROM `usercore`.`uservpermissionsetassigmenttoobject`;
		SELECT * FROM `usercore`.`usertpermissionsetassignmenttoobject`;

-- Elimina los Objetos, que ya no tiene mas acceso los Profile y compañia que se insertaran
 	DELETE FROM `usercore`.`usertpermissionsetassignmenttoobject`
      WHERE (CONCAT(`CompanyIDn`,`ProfileIDn`,`ObjectIDn`)) 
		IN (
			 SELECT CONCAT(`psato`.`CompanyIDn`,`psato`.`ProfileIDn`,`psato`.`ObjectIDn`) AS `psatoid`
						-- ,`psot`.`CompanyIDn` 
				FROM (
						SELECT `psat`.`CompanyIDn`,
								`psat`.`ProfileIDn`,
								/*Esta campos se consolidan y se utiliza su informacion*/
								-- `psat`.`PermiSetIDn`,
								-- `psat`.`PermiSetIsGrant`,
								-- `psat`.`PermiSetTypeIDn`,
								`pso`.`ObjectIDn`,
								SUM(IF(`psat`.`PermiSetIsGrant`=1, `pso`.`PermiObjCreate`, `pso`.`PermiObjCreate` * -1)) AS `PermiObjCreate`,
								SUM(IF(`psat`.`PermiSetIsGrant`=1, `pso`.`PermiObjRead`, `pso`.`PermiObjRead` * -1)) AS `PermiObjRead`,
								SUM(IF(`psat`.`PermiSetIsGrant`=1, `pso`.`PermiObjDelete`, `pso`.`PermiObjDelete` * -1)) AS `PermiObjDelete`,
								SUM(IF(`psat`.`PermiSetIsGrant`=1, `pso`.`PermiObjEdit`, `pso`.`PermiObjEdit` * -1)) AS `PermiObjEdit`,
								SUM(IF(`psat`.`PermiSetIsGrant`=1, `pso`.`PermissionField`, `pso`.`PermissionField` * -1)) AS `PermissionField`,
								SUM(`psat`.`HasActivationRequired`) AS `HasActivationRequired`	-- Si el Object en algun permissionSet tenia activado en True el HasActivationRequired, este se traslada y ese objeto tiene True
							FROM `usercore`.`uservpermissionsetassignmenttotal` `psat`
								JOIN `usercore`.`usertpermissionsetobject` `pso` ON `psat`.`IDNumPs` = `pso`.`PermiSetIDn`
							WHERE `pso`.`StateIDn` = 514  
								-- AND ProfileIDn = 34304 -- AND (ObjectIDn = 24321)
							GROUP BY `psat`.`CompanyIDn`,
								`psat`.`ProfileIDn`,
								`pso`.`ObjectIDn`
						) AS `psot`
							RIGHT JOIN `usercore`.`usertpermissionsetassignmenttoobject` `psato`
								 ON `psot`.`CompanyIDn` = `psato`.`CompanyIDn` 
									AND `psot`.`ProfileIDn` = `psato`.`ProfileIDn` 
									AND `psot`.`ObjectIDn` = `psato`.`ObjectIDn`
					WHERE (`psot`.`PermiObjCreate`+`psot`.`PermiObjRead`+`psot`.`PermiObjDelete`+`psot`.`PermiObjEdit`+`psot`.`PermissionField`) > 0
						AND `psot`.`CompanyIDn` IS NULL 
					-- Si el permissionSet Object termina con todos los Permi en 0, se debe eliminar de la lista, si no, deben quedar solo los permissionSet habilitados, si estaba en cero y tiene uno que elimina queda en cero
					-- Si no hay valor que suma, se elimina, ya que no puede eliminar algo que no exista
					)
            ;


USE usercore;
 	DELETE `pato` 
		FROM `usercore`.`usertpermissionsetassignmenttoobject` `pato`
			INNER JOIN (
						 SELECT `psato`.`CompanyIDn`,
								`psato`.`ProfileIDn`,
								`psato`.`ObjectIDn`
									-- ,`psot`.`CompanyIDn` 
							FROM (
									SELECT `psat`.`CompanyIDn`,
											`psat`.`ProfileIDn`,
											/*Esta campos se consolidan y se utiliza su informacion*/
											-- `psat`.`PermiSetIDn`,
											-- `psat`.`PermiSetIsGrant`,
											-- `psat`.`PermiSetTypeIDn`,
											`pso`.`ObjectIDn`,
											SUM(IF(`psat`.`PermiSetIsGrant`=1, `pso`.`PermiObjCreate`, `pso`.`PermiObjCreate` * -1)) AS `PermiObjCreate`,
											SUM(IF(`psat`.`PermiSetIsGrant`=1, `pso`.`PermiObjRead`, `pso`.`PermiObjRead` * -1)) AS `PermiObjRead`,
											SUM(IF(`psat`.`PermiSetIsGrant`=1, `pso`.`PermiObjDelete`, `pso`.`PermiObjDelete` * -1)) AS `PermiObjDelete`,
											SUM(IF(`psat`.`PermiSetIsGrant`=1, `pso`.`PermiObjEdit`, `pso`.`PermiObjEdit` * -1)) AS `PermiObjEdit`,
											SUM(IF(`psat`.`PermiSetIsGrant`=1, `pso`.`PermissionField`, `pso`.`PermissionField` * -1)) AS `PermissionField`,
			-								SUM(`psat`.`HasActivationRequired`) AS `HasActivationRequired`	-- Si el Object en algun permissionSet tenia activado en True el HasActivationRequired, este se traslada y ese objeto tiene True
										FROM `usercore`.`uservpermissionsetassignmenttotal` `psat`
											JOIN `usercore`.`usertpermissionsetobject` `pso` ON `psat`.`IDNumPs` = `pso`.`PermiSetIDn`
										WHERE `pso`.`StateIDn` = 514  
											-- AND ProfileIDn = 34304 -- AND (ObjectIDn = 24321)
										GROUP BY `psat`.`CompanyIDn`,
											`psat`.`ProfileIDn`,
											`pso`.`ObjectIDn`
									) AS `psot`
										RIGHT JOIN `usercore`.`usertpermissionsetassignmenttoobject` `psato`
											 ON `psot`.`CompanyIDn` = `psato`.`CompanyIDn` 
												AND `psot`.`ProfileIDn` = `psato`.`ProfileIDn` 
												AND `psot`.`ObjectIDn` = `psato`.`ObjectIDn`
								WHERE (`psot`.`PermiObjCreate`+`psot`.`PermiObjRead`+`psot`.`PermiObjDelete`+`psot`.`PermiObjEdit`+`psot`.`PermissionField`) > 0
									AND `psot`.`CompanyIDn` IS NULL 
								-- Si el permissionSet Object termina con todos los Permi en 0, se debe eliminar de la lista, si no, deben quedar solo los permissionSet habilitados, si estaba en cero y tiene uno que elimina queda en cero
								-- Si no hay valor que suma, se elimina, ya que no puede eliminar algo que no exista
								) `pstod` 
									ON `pato`.`CompanyIDn` = `pstod`.`CompanyIDn`
										AND `pato`.`ProfileIDn` = `pstod`.`ProfileIDn`
                                        AND `pato`.`ObjectIDn` = `pstod`.`ObjectIDn`
                                        ;
 
-- Inserta los Nuevos PermissionSetAssignment to Object
	INSERT INTO `usercore`.`usertpermissionsetassignmenttoobject`
			(`CompanyIDn`,
			`ProfileIDn`,
			`ObjectIDn`,
			`PermiObjCreate`,
			`PermiObjRead`,
			`PermiObjDelete`,
			`PermiObjEdit`,
			`PermissionField`,
			`HasActivationRequired`)
		SELECT `psot`.`CompanyIDn`,
				`psot`.`ProfileIDn`,
                `psot`.`ObjectIDn`,
                IF(`psot`.`PermiObjCreate`<=0,0,1) AS `PermiObjCreate`,
                IF(`psot`.`PermiObjRead`<=0,0,1) AS `PermiObjRead`,
                IF(`psot`.`PermiObjDelete`<=0,0,1) AS `PermiObjDelete`,
                IF(`psot`.`PermiObjEdit`<=0,0,1) AS `PermiObjEdit`,
                IF(`psot`.`PermissionField`<=0,0,1) AS `PermissionField`,
                IF(`psot`.`HasActivationRequired`<=0,0,1) AS `HasActivationRequired`
        FROM (
				SELECT `psat`.`CompanyIDn`,
						`psat`.`ProfileIDn`,
                        /*Esta campos se consolidan y se utiliza su informacion*/
						-- `psat`.`PermiSetIDn`,
						-- `psat`.`PermiSetIsGrant`,
                        -- `psat`.`PermiSetTypeIDn`,
						`pso`.`ObjectIDn`,
						SUM(IF(`psat`.`PermiSetIsGrant`=1, `pso`.`PermiObjCreate`, `pso`.`PermiObjCreate` * -1)) AS `PermiObjCreate`,
						SUM(IF(`psat`.`PermiSetIsGrant`=1, `pso`.`PermiObjRead`, `pso`.`PermiObjRead` * -1)) AS `PermiObjRead`,
						SUM(IF(`psat`.`PermiSetIsGrant`=1, `pso`.`PermiObjDelete`, `pso`.`PermiObjDelete` * -1)) AS `PermiObjDelete`,
						SUM(IF(`psat`.`PermiSetIsGrant`=1, `pso`.`PermiObjEdit`, `pso`.`PermiObjEdit` * -1)) AS `PermiObjEdit`,
						SUM(IF(`psat`.`PermiSetIsGrant`=1, `pso`.`PermissionField`, `pso`.`PermissionField` * -1)) AS `PermissionField`,
						SUM(`psat`.`HasActivationRequired`) AS `HasActivationRequired`	-- Si el Object en algun permissionSet tenia activado en True el HasActivationRequired, este se traslada y ese objeto tiene True
					FROM `usercore`.`uservpermissionsetassignmenttotal` `psat`
						JOIN `usercore`.`usertpermissionsetobject` `pso` ON `psat`.`IDNumPs` = `pso`.`PermiSetIDn`
					WHERE `pso`.`StateIDn` = 514  
						-- AND ProfileIDn = 34304 -- AND (ObjectIDn = 24321)
					GROUP BY `psat`.`CompanyIDn`,
						`psat`.`ProfileIDn`,
						`pso`.`ObjectIDn`
				) AS `psot`
					LEFT JOIN `usercore`.`usertpermissionsetassignmenttoobject` `psato`
						 ON `psot`.`CompanyIDn` = `psato`.`CompanyIDn` 
							AND `psot`.`ProfileIDn` = `psato`.`ProfileIDn` 
							AND `psot`.`ObjectIDn` = `psato`.`ObjectIDn`
			WHERE `psato`.`CompanyIDn` IS NULL 
				AND (`psot`.`PermiObjCreate`+`psot`.`PermiObjRead`+`psot`.`PermiObjDelete`+`psot`.`PermiObjEdit`+`psot`.`PermissionField`) > 0
            -- Si el permissionSet Object termina con todos los Permi en 0, se debe eliminar de la lista, si no, deben quedar solo los permissionSet habilitados, si estaba en cero y tiene uno que elimina queda en cero
            -- Si no hay valor que suma, se elimina, ya que no puede eliminar algo que no exista
			;


            
-- Actualiza los registros que cambian el permiso
UPDATE `usercore`.`usertpermissionsetassignmenttoobject` `psato`
	JOIN (
			SELECT `psot`.`CompanyIDn`,
							`psot`.`ProfileIDn`,
							`psot`.`ObjectIDn`,
							IF(`psot`.`PermiObjCreate`<=0,0,1) AS `PermiObjCreate`,
							IF(`psot`.`PermiObjRead`<=0,0,1) AS `PermiObjRead`,
							IF(`psot`.`PermiObjDelete`<=0,0,1) AS `PermiObjDelete`,
							IF(`psot`.`PermiObjEdit`<=0,0,1) AS `PermiObjEdit`,
							IF(`psot`.`PermissionField`<=0,0,1) AS `PermissionField`,
							IF(`psot`.`HasActivationRequired`<=0,0,1) AS `HasActivationRequired`
					FROM (
							SELECT `psat`.`CompanyIDn`,
									`psat`.`ProfileIDn`,
									/*Esta campos se consolidan y se utiliza su informacion*/
									-- `psat`.`PermiSetIDn`,
									-- `psat`.`PermiSetIsGrant`,
									-- `psat`.`PermiSetTypeIDn`,
									`pso`.`ObjectIDn`,
									SUM(IF(`psat`.`PermiSetIsGrant`=1, `pso`.`PermiObjCreate`, `pso`.`PermiObjCreate` * -1)) AS `PermiObjCreate`,
									SUM(IF(`psat`.`PermiSetIsGrant`=1, `pso`.`PermiObjRead`, `pso`.`PermiObjRead` * -1)) AS `PermiObjRead`,
									SUM(IF(`psat`.`PermiSetIsGrant`=1, `pso`.`PermiObjDelete`, `pso`.`PermiObjDelete` * -1)) AS `PermiObjDelete`,
									SUM(IF(`psat`.`PermiSetIsGrant`=1, `pso`.`PermiObjEdit`, `pso`.`PermiObjEdit` * -1)) AS `PermiObjEdit`,
									SUM(IF(`psat`.`PermiSetIsGrant`=1, `pso`.`PermissionField`, `pso`.`PermissionField` * -1)) AS `PermissionField`,
									SUM(`psat`.`HasActivationRequired`) AS `HasActivationRequired`	-- Si el Object en algun permissionSet tenia activado en True el HasActivationRequired, este se traslada y ese objeto tiene True
								FROM `usercore`.`uservpermissionsetassignmenttotal` `psat`
									JOIN `usercore`.`usertpermissionsetobject` `pso` ON `psat`.`IDNumPs` = `pso`.`PermiSetIDn`
								WHERE `pso`.`StateIDn` = 514  
									-- AND ProfileIDn = 34304 -- AND (ObjectIDn = 24321)
								GROUP BY `psat`.`CompanyIDn`,
									`psat`.`ProfileIDn`,
									`pso`.`ObjectIDn`
							) AS `psot`
						WHERE (`psot`.`PermiObjCreate`+`psot`.`PermiObjRead`+`psot`.`PermiObjDelete`+`psot`.`PermiObjEdit`+`psot`.`PermissionField`) > 0
						-- Si el permissionSet Object termina con todos los Permi en 0, se debe eliminar de la lista, si no, deben quedar solo los permissionSet habilitados, si estaba en cero y tiene uno que elimina queda en cero
						-- Si no hay valor que suma, se elimina, ya que no puede eliminar algo que no exista
					) `psatoq`
						ON `psato`.`CompanyIDn` = `psatoq`.`CompanyIDn` 
							AND `psato`.`ProfileIDn` = `psatoq`.`ProfileIDn` 
							AND `psato`.`ObjectIDn` = `psatoq`.`ObjectIDn`
SET
	`psato`.`PermiObjCreate` = `psatoq`.`PermiObjCreate`,
	`psato`.`PermiObjRead` = `psatoq`.`PermiObjRead`,
	`psato`.`PermiObjDelete` = `psatoq`.`PermiObjDelete`,
	`psato`.`PermiObjEdit` = `psatoq`.`PermiObjEdit`,
	`psato`.`PermissionField` = `psatoq`.`PermissionField`,
	`psato`.`HasActivationRequired` = `psatoq`.`HasActivationRequired`
;




-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
/*
    Tablas que forman la Consulta:
		SELECT * FROM `usercore`.`uservpermissionsetassignmenttotal` `psat`
        
												IDNumPsA, IDNumPs, Company, ProfileIDn, PermiSetIDn
        4c0889a4-70d3-11eb-9258-26cb863fa993	4		  1			7566	34304		32769	UserSystemRead 		1	0	2435
		4c0889a4-70d3-11eb-9258-26cb863fa993	4		  3			7566	34304		32771	UserRead 			1	0	2435
		4c0889a4-70d3-11eb-9258-26cb863fa993	4		  5			7566	34304		32773	UserRoleRead 		1	0	2435
		4c0889a4-70d3-11eb-9258-26cb863fa993	4		  7			7566	34304		32775	UserPermissionRead	1	0	2435
	
		Si a un mismo Profile le doy acceso a varios perfiles que estos le dan derecho al mismo objeto, esto se debe consolidar


		SELECT * FROM `usercore`.`usertpermissionsetobject` `pso`	

        SELECT * FROM usercore.usertpermissionset WHERE PermiSetIDn = 33793;
        
*/
