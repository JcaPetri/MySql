select count(*) FROM `bpmncore`.`bpmtfounbaseelement`
WHERE <{where_expression}>;


SELECT count(*) FROM bpmncore.bpmtfounbaseelement `be`
	INNER JOIN bpmncore.dataimportbe `di` ON `be`.`IDNum` =  `di`.`IDNum`

WHERE `IDnum` = 1;

SELECT count(*) FROM bpmncore.dataimportbe WHERE `FkBeIDnScope` = 36;

SELECT `FkBeIDnScope`, `IDCode`, COUNT(*) 
FROM `bpmncore`.`dataimportbe` 
GROUP BY `FkBeIDnScope`, `IDCode`
HAVING COUNT(*) > 1;

UPDATE `bpmncore`.`dataimportbe`
SET `IDCode` = `IDCode` + 1
WHERE `FkBeIDnScope` = 36 AND `IDNum` >= 18992 AND 19990;
