/*
	Por definicion, un Scope no debe tener una tabla real en la base de datos, solo es virtual
    Las tablas a medida que se insertan los valores se agregan, no respetan un orden
    en cambio en lo Scope se guardan un grupo de filas para que tengan un orden
    (esto puede o no ser asi)
*/

-- Lista los Scopes
SELECT * FROM `bpmcore`.`bpmfouvscope`
-- WHERE IDName LIKE '%compan%'
;

SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE (ScopeIDn = 3 OR ScopeIDn = 3) AND IDName LIKE '%PermissionSetGroup%';




/*

							Scop	Start	End		Cant
tSisUserType				20		5001	5069	69
tSisUserRole				21		5070	5568	499
tSisRoleType				22		5569	5767	199
tSisProfile					23		5768	6066	299
tSisProfileType				24		2395	2433	39

tSisPermissionSet			25		6067	7065	999

tSisPermissionSetType		26		2434	2472	39			// Este queda

tSisPermissionSetGroup		27		7066	7564	499

ver la 19991
--	27987		Es la ultima fila, de los datos


tSystemFree 7764
*/

-- Detalle de Scopes
SELECT * FROM `bpmcore`.`bpmfouvscopedet`;

-- Rangos utilizados por cada Scope, Los valores Free son con el Scope 199
SELECT * FROM `bpmcore`.`bpmfouvscopegroup`;

SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 3 AND (IDName LIKE '%Sys%' OR IDName LIKE '%ree%');		-- Tables
SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 4;		-- Columns

SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 3 AND IDName LIKE '%SysT%' order by IDNUm, IDCode;
SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 6 order by IDCode;

SELECT CONCAT("SysT",SUBSTRING(IDName,5,length(IDName)-4)) FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 3 AND IDName LIKE '%tSis%';

SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE IDNum = 2144;

SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 11;

SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 24689;


SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE IDNum >= 48000;


SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 39;
/*
62498	Fundamental
62499	Supplementary
62500	Derived
62501	Custom
*/
/*

*/

-- tSysMeasures
-- measures

-- Detalle de Tablas
SELECT * FROM `bpmcore`.`bpmfouvscopedet` WHERE ScopeIDCode = 3 AND IDName LIKE "%UserT%" order by IDNum;
-- 1 AND IDName LIKE "%" Order by IDNum;
-- Detalle de Columnas
SELECT * FROM `bpmcore`.`bpmfouvscopedet` WHERE ScopeIDCode = 2 AND IDName LIKE "%" Order by IDCode;

-- Detalle de Entity
SELECT * FROM `bpmcore`.`bpmvfounscopedep` WHERE ScopeIDCode = 14 AND IDName LIKE "%" Order by IDNum;
-- Detalle de Field
SELECT * FROM `bpmcore`.`bpmvfounscopedep` WHERE ScopeIDCode = 15 AND IDName LIKE "%" Order by IDCode;


-- Detalle de un Scope
SELECT * FROM `bpmcore`.`bpmvfounscopedep` WHERE ScopeIDCode = 6 AND IDName LIKE "%" Order by IDCode;


-- ___________________________________________________________________________________________________________________________________________________________
-- Create a New Scope, and set its values
UPDATE `bpmcore`.`bpmfoutbaseelement`
	SET IDIsUsed = 0, 
		TableHistory = "SetOff"				-- 	"SetNull", "SetOff"
WHERE (IDNum >= 2483 AND IDNum <= 2523) AND ScopeIDn = 37 AND IDIsUsed = 1;


UPDATE `bpmcore`.`bpmfoutbaseelement`
	SET IDName = CONCAT('FieldPropertyTypeFree ', CAST(IDCode AS CHAR)),
		IDIsUsed = 1,
        ScopeIDn = 37,
        -- IDCode = 1, 
		TableHistory = "SetOff"				-- 	"SetNull", "SetOff"
WHERE (IDNum >= 2485 AND IDNum <= 2523) AND ScopeIDn = 0 AND IDIsUsed = 0;
/*
2523
-- 

*/

SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 37;


-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Migra Permission Set
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
INSERT INTO `bpmcore`.`bpmfoutbaseelement`
		(-- `ID`,
		-- `IDNum`,
		`IDName`,
		`ScopeIDn`,
		`LanguageIDn`,
		`IDCode`,
		`DefinitionIDn`,
		`InformationTypeIDn`,
		`IDIsUsed`,
		`StateIDn`,
		`CreatedByIDn`,
		`LastModifiedByIDn`,
		`OwnerIDn`,
		-- `DateCreated`,
		-- `DateTimeStamp`,
		`TzNameIDn`,
		`TzOffset`,
		`TableHistory`)
SELECT -- `be`.`ID`,
    -- `be`.`IDNum`,
    `be`.`IDName`,
    24309 `ScopeIDn`,			-- Cambia el Scope
    `be`.`LanguageIDn`,
    `be`.`IDCode`,
    `be`.`DefinitionIDn`,
    `be`.`InformationTypeIDn`,
    `be`.`IDIsUsed`,
    `be`.`StateIDn`,
    `be`.`CreatedByIDn`,
    `be`.`LastModifiedByIDn`,
    `be`.`OwnerIDn`,
    -- `be`.`DateCreated`,
    -- `be`.`DateTimeStamp`,
    `be`.`TzNameIDn`,
    `be`.`TzOffset`,
    null `TableHistory`
FROM `bpmcore`.`bpmfoutbaseelement` `be`
WHERE `be`.`ScopeIDn` = 23;

SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 23;
SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 24309;

SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE (ScopeIDn = 3 OR ScopeIDn = 23) AND IDName LIKE '%PermissionSetGroup%';

/*
User Tables
3	tSisTable	24301	UserTUser
3	tSisTable	24302	UserTUserRole
3	tSisTable	24303	UserTUserRecordAccess
3	tSisTable	24304	UserTGroup
3	tSisTable	24305	UserTGroupMember
3	tSisTable	24306	UserTRole
3	tSisTable	24308	UserTRoleStructure
3	tSisTable	24307	UserTRoleProfile
3	tSisTable	24310	UserTLicense
3	tSisTable	24312	UserTPermissionSetAssignment
3	tSisTable	24313	UserTPermissionSetEntity
3	tSisTable	24314	UserTPermissionSetEntityField
3	tSisTable	24316	UserTPermissionSetGroupComponent
3	tSisTable	24317	UserTPermissionSetObject
3	tSisTable	24318	UserTPermissionSetObjectField
3	tSisTable	24319	UserTSysEntity
3	tSisTable	24320	UserTSysEntityStructure
3	tSisTable	24321	UserTUserToEntityObject

Listo		3	tSisTable	24309	UserTProfile
Listo 		3	tSisTable	24311	UserTPermissionSet
Listo 		3	tSisTable	24315	UserTPermissionSetGroup


							Scop	Start	End		Cant
tSisUserType				20		5001	5069	69
tSisUserRole				21		5070	5568	499
tSisRoleType				22		5569	5767	199
tSisProfile					23		5768	6066	299
tSisProfileType				24		2395	2433	39

Borrar datos
		tSisPermissionSet			25		6067	7065	999
		tSisPermissionSetGroup		27		7066	7564	499
        tSisPermissionSetGroupStatus
        
Cambiar el Scope
		tSisPermissionSetType		26		2434	2472	39			// Este queda


tSystemFree 7764
*/
