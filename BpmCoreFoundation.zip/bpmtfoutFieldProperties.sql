-- Muestra el contenido de la tabla PropertyField
-- en esta tabla deben estar todas las propiedades de las columnas o fields
SELECT * FROM bpmncore.bpmfouvfieldproperty;

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Estructura del Sistema, Entity y Tables
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Aclaraciones:
-- 				para poder determinar que propiedad tiene cada fila, se debe analizar la estructura del sistema
-- 				para ello estan las siguientes consultas.

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Information to set the value to insert
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Scopes
SELECT * FROM `bpmncore`.`bpmfouvscope`;
-- Entity detail
SELECT * FROM `bpmncore`.`bpmfouvscopedet` WHERE `ScopeIDCode` = 1 order by `IDNum`;
-- 1 AND IDName LIKE "%" Order by IDNum;
-- Fields detail
SELECT * FROM `bpmncore`.`bpmfouvscopedet` WHERE `ScopeIDCode` = 2 AND `ScopeIDName` LIKE "%" Order by `IDNum`;

-- Table detail
SELECT * FROM `bpmncore`.`bpmfouvscopedet` WHERE `ScopeIDCode` = 3 AND `ScopeIDName` LIKE "%" Order by IDNum;
-- Column detail
SELECT * FROM `bpmncore`.`bpmfouvscopedet` WHERE `ScopeIDCode` = 4 AND `ScopeIDName` LIKE "%" Order by IDCode;

/*
-- Fields that the user cant't modify
	-- System fields, this fields are defined by the MySql system, the user can't modify them.
			25489	ID
			25490	IDNum
			27983	DateCreated
			27984	DateTimeStamp
			27985	TzNameIDn
			27986	TzOffset
			27987	TableHistory

	-- System fields, this fields are defined by the Java system, the user can't modify them.
			27980	CreatedByIDn
			27982	OwnerIDn
			27981	LastModifiedByIDn

	-- System fields, the user can modify them
			27979	StateIDn
*/


-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ________________________________________________________________________________________________________________________________________________________________________________________   
-- FieldPropertyTypeIDn
-- The Field property type define wich propertie is defined
SELECT * FROM `bpmncore`.`bpmfoutbaseelementcondatos` WHERE ScopeIDn = 37;

/*
		37	FieldPropertyType	37
		2473	DataTypeMySql	37
		2474	DataTypeJava	37
		2475	DataTypeCustom	37
		2476	IsPrimaryKey			is a boolean type
		2477	IsNotNull				is a boolean type
		2478	IsIndex					is a boolean type
		2479	IsBinary				is a boolean type
		2480	IsAutoIncremental		is a boolean type
		2481	IsGeneratedField		is a boolean type
		2482	IsSystemGenerated		is a boolean type
		2483	FieldPropertyTypeFree	to be defined
*/

-- ________________________________________________________________________________________________________________________________________________________________________________________
-- FieldPropertyValueIDn
-- It's the value of the property, depending of the kind, is the value that admit.
		/*
		9		tSisDataType
		10		tSisDataCustomType
		11		tSisMimeType
		12		tSisInfoType
		13		tSisItemKind
		14 		tSisTypeLanguage
		15 		tSisState
					514	ENA
					515	DIS
		16  	tSisObjectType
		17 		tSisDefinition
		*/
SELECT * FROM `bpmncore`.`bpmfoutbaseelementcondatos` WHERE ScopeIDn = 9;
	/*
	*/


-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Insertar el Valor de la propiedad para cada Field/Columna
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
INSERT INTO `bpmncore`.`bpmfoutfieldproperties`
	(-- `ID`,
	-- `IDNum`,
	`FieldIDn`,
	`FieldPropertyTypeIDn`,
	`FieldPropertyValueIDn`,
	`FieldOptionValue`,
	`StateIDn`,
	`CreatedByIDn`,
	`LastModifiedByIDn`,
	`OwnerIDn`,
	-- `DateCreated`,
	-- `DateTimeStamp`,
	`TzNameIDn`,
	`TzOffset`,
	`TableHistory`)
SELECT -- `es`.`ID`,			-- Valor autogenerado
		-- `es`.`IDNum`,		-- Valor autogenerado
		27986 `FieldIDn`,						-- IdNum del Field
		2482 `FieldPropertyTypeIDn`,			-- IdNum del tipo de propiedad
					-- 2482	IsSystemGenerated		is a boolean type
		1 `FieldPropertyValueIDn`,		-- IdNum del valor que puede tener la propiedad
					-- boolean 1 = true, 0 = false
		null `FieldOptionValue`,		-- Valor opcional
		514 `StateIDn`,
		1 `CreatedByIDn`,
		0 `LastModifiedByIDn`,
		0 `OwnerIDn`,
		-- `DateCreated`,		-- Valor autogenerado
		-- `DateTimeStamp`,		-- Valor autogenerado
		1333 `TzNameIDn`,
		-233 `TzOffset`,
		NULL `TableHistory`;
    
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Show the Fields Properties
SELECT * FROM bpmncore.bpmfouvfieldpropertycondatos;
