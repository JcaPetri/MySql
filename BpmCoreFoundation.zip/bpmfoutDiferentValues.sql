-- Scopes
USE bpmncore;
SELECT * FROM bpmncore.bpmtfoubaseelement Be where Be.IDNum = Be.FkBeIDnScope;

-- Data Types
SELECT * FROM `bpmncore`.`bpmtfounbaseelement` Be where  Be.FkBeIDnScope = 5;

/*
3831	tinyint
3832	smallint
3833	mediumint
3834	int
3835	bigint
3836	decimal
3837	numeric
3838	float
3839	double
3840	datetime
3841	date
3842	timestamp
3843	time
3844	year
3845	char
3846	varchar
3847	text
3848	string
3849	tinyblob
3850	mediumblob
3851	longblob
3852	binary
3853	varbinary
3854	enum
3855	set
3856	byte
3857	boolean
*/

/*  
	 = FkBeIDnLanguage			349 = en
	 = FkBeIDnDefinition			6389 = FkBeIDnDefinition
	 = FkBeIDnInformationType		903 Data / 904 Software		(Scope = 902)
	 = FkBeIDnState				3885 `FkBeIDnState` / 907 DIS			(Scope = 905)
    892 text/plain, 	893 text/css,	894 text/html,	895 text/javascript
*/

SELECT * FROM `bpmncore`.`bpmvfounscopedep` WHERE ScopeIDCode = 383;


SELECT * FROM `bpmncore`.`bpmtfounbaseelement` WHERE FkBeIDnScope = 383;
/* Detalle de los distintos Definition
	6389	bpmndefaultdefinition	383	
*/

SELECT * FROM `bpmncore`.`bpmtfounbaseelement` WHERE FkBeIDnScope = 12;
/*Information Type
12	tBpmInfoType	12	1	tBpmInfoType
12	tBpmInfoType	4086	2	Data	
12	tBpmInfoType	4087	3	Software
*/

SELECT * FROM `bpmncore`.`bpmtfounbaseelement` WHERE FkBeIDnScope = 3 AND IDName = "it";
/* Detalle de los distintos Definition
2008	en	3	2008 Ingles
2090	es	3	2008 Español
2037	it	3	2008 Italiano
*/


SELECT * FROM `bpmncore`.`bpmtfounbaseelement` Be where  Be.FkBeIDnScope = 9;
/* Text Format
   9	tSisMimeType		9	2008	1	6389	4087	3885	2020-09-18 13:27:04	2830	-233	0	
3913	text/plain			9	2008	2	6389	4087	3885	2020-09-18 13:27:04	2830	-233	0	
3914	text/css			9	2008	3	6389	4087	3885	2020-09-18 13:27:04	2830	-233	0	
3915	text/html			9	2008	4	6389	4087	3885	2020-09-18 13:27:04	2830	-233	0	
3916	text/javascript		9	2008	5	6389	4087	3885	2020-09-18 13:27:04	2830	-233	0	
3917	mimeTypeFree 05		9	2008	6	6389	4087	3885	2020-09-18 13:27:04	2830	-233	0	


 */