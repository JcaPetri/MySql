USE bpmncore;
CREATE TABLE `bpmfoutdbtablestructure` (
  `IDTs` char(38) COLLATE utf8_bin NOT NULL,
  `IDNumTs` int NOT NULL AUTO_INCREMENT,
  `FkBeIDnTable` int NOT NULL,
  `FkBeIDnColumn` int NOT NULL,
  `FkBeIDnColumnType` int DEFAULT NULL,
  `TsColumnOrder` int DEFAULT NULL,
  `FkBeIDnState` smallint NOT NULL,
  `DateTime` timestamp NOT NULL,
  `FkBeIDnTzName` smallint NOT NULL,
  `TzOffset` smallint NOT NULL,
  `UserIDNum` mediumint NOT NULL,
  PRIMARY KEY (`IDNumTs`),
  UNIQUE KEY `TableColumn_UNIQUE` (`FkBeIDnTable`,`FkBeIDnColumn`),
  KEY `FkBeIDnTable_idx` (`FkBeIDnTable`) /*!80000 INVISIBLE */,
  KEY `FkBeIDnColumn_idx` (`FkBeIDnColumn`) /*!80000 INVISIBLE */,
  CONSTRAINT `FkBeIDnColumn` FOREIGN KEY (`FkBeIDnColumn`) REFERENCES `bpmfoutbaseelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FkBeIDnTable` FOREIGN KEY (`FkBeIDnTable`) REFERENCES `bpmfoutbaseelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
	AUTO_INCREMENT=226 
    DEFAULT CHARSET=UTF8MB4 
    COLLATE=utf8_bin 
    COMMENT='contiene las tablas del sistema.';