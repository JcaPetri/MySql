CREATE TABLE IF NOT EXISTS `BpmnCore`.`BpmfouTDbDefaultValues` (
  `IDNumTdv` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `IDTDbDv` CHAR(38) NOT NULL,
  `FkBeIDnDefaultVersion` INT NOT NULL,
  `FkBeIDnTableStructure` INT NOT NULL,
  `FkBeIDnColumnValueDefault` NVARCHAR(250) NOT NULL,
  `FkBeIDnColumnValueType` INT NOT NULL,
  `FkBeIDnStateDefaultValue` INT NOT NULL,
  `DateDefaultValue` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `TzName` VARCHAR(5) NOT NULL,
  `TzOffset` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`IDNumTdv`, `FkBeIDnDefaultVersion`, `FkBeIDnTableStructure`),
  INDEX `FkBeIDnDefaultVersion_idx` (`FkBeIDnDefaultVersion` ASC) INVISIBLE,
  INDEX `FkBeIDnTableStructure_idx` (`FkBeIDnTableStructure` ASC) VISIBLE,
  CONSTRAINT `FkBeIDnDefaultVersion`
    FOREIGN KEY (`FkBeIDnDefaultVersion`)
    REFERENCES `BpmnCore`.`BpmfouTBaseElement` (`IDNum`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `FkBeIDnTableStructure`
    FOREIGN KEY (`FkBeIDnTableStructure`)
    REFERENCES `BpmnCore`.`BpmfouTDbTableStructure` (`IDNumTs`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
COMMENT = 'contiene para una tabla los valores default para cada columna. Puede haber distintas versiones de default, lo que permite que se pueda customizar la carga segun la necesidad.'
