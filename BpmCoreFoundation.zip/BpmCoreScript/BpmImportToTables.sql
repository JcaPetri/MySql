SELECT * FROM `bpmncore`.`bpmtimpfile`;

SET SQL_SAFE_UPDATES = 0;
DELETE FROM `bpmncore`.`bpmtimpfile`;
SET SQL_SAFE_UPDATES = 1;

DELETE FROM `bpmncore`.`bpmfoutbaseelement`;
SELECT * FROM `bpmncore`.`bpmfoutbaseelement`;

-- ALTER TABLE `bpmncore`.`bpmfoutbaseelement` AUTO_INCREMENT = 1;	-- Tenga en cuenta que no puede restablecer el contador a un valor menor o igual a cualquiera que ya se haya utilizado. 
TRUNCATE TABLE `bpmncore`.`bpmfoutbaseelement`;		-- restablece el contador AUTO_INCREMENT a cero, independientemente de si existe una restricción de clave externa.
/* DROP TABLE table_name;
CREATE TABLE table_name { ... };
*/
INSERT INTO `bpmncore`.`bpmfoutbaseelement`
		/*`IDNum`, `ID`,*/
		(`IDName`,
		`FkBeIDnScope`,
		`FkBeIDnLanguage`,
		`FkBeIDnDefinition`,
		`FkBeIDnInformationType`,
		`FkBeIDnState`,
		`DateBaseElement`,
		`TzName`,
		`TzOffset`)
	SELECT `bpmtimpfile`.`DataImport` AS `IDName`,
			0 AS `FkBeIDnScope`,
			0 AS `FkBeIDnLanguage`,
			0 AS `FkBeIDnDefinition`,
			0 AS `FkBeIDnInformationType`,
			0 AS `FkBeIDnState`,
			UTC_TIMESTAMP AS `DateBaseElement`,
			0 AS `TzName`,
			'-03:00' AS `TzOffset`	
		FROM `bpmncore`.`bpmtimpfile`;

SELECT `bpmfoutbaseelement`.`IDNum`,
    `bpmfoutbaseelement`.`ID`,
    `bpmfoutbaseelement`.`IDName`,
    `bpmfoutbaseelement`.`FkBeIDnScope`,
    `bpmfoutbaseelement`.`FkBeIDnLanguage`,
    `bpmfoutbaseelement`.`FkBeIDnDefinition`,
    `bpmfoutbaseelement`.`FkBeIDnInformationType`,
    `bpmfoutbaseelement`.`FkBeIDnState`,
    `bpmfoutbaseelement`.`DateBaseElement`,
    `bpmfoutbaseelement`.`TzName`,
    `bpmfoutbaseelement`.`TzOffset`
FROM `bpmncore`.`bpmfoutbaseelement`
ORDER BY `bpmfoutbaseelement`.`IDName`;


SELECT COUNT(*) FROM `bpmncore`.`bpmfoutbaseelement`;
