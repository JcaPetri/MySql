CREATE DEFINER=`root`@`localhost` PROCEDURE `BpmfouPBaseElementCRUD`( 
	-- Agrega parametros para mosstrar los resultados del procedimiento almacenado
	OUT vResult NVARCHAR(10) 		-- detalle del resultado.
	,OUT vResultNumber MEDIUMINT	-- informa el numero de resultado, este se vincula con una descripcion personalizada en la base de datos.
	,OUT vRowAffected MEDIUMINT 	-- variable para obtener el numero de registros afectados.
	,OUT vIdNumReturn INT 			-- idNum valor único autocalculado, surge de la tabla BpmfouTBaseElement.
	,OUT vResultMessage TEXT		-- detalle del resultado.
    
	-- Agrega parametros para definir el tipo de accion del procedimiento almacenado
	,IN vCRUD MEDIUMINT						-- Determina acción a realizar.
	,IN vIDnDefaultValueVersion MEDIUMINT	-- Tabla BpmfouTDbDefaultValues [FkBeIDnDefaultVersion] Establece la version del Default Table/Column; esto es porque se pueden generar multiples versiones de DefaultValues para una tabla.
	-- Agrega parametros para proveer informacion y ejecutar el procedimiento almacenado
    ,IN vID int								-- ID valor único autocalculado, surge de la tabla BpmfouTBaseElement.
	,IN vUniqueId VARCHAR(38)			-- Tabla BpmfouTBaseElement `ID` valor ID; debe ser único.
	,IN vIdName VARCHAR(250) 			-- Tabla BpmfouTBaseElement `IDName` Código en letras del ID.
	,IN vIdnScope INT					-- Tabla BpmfouTBaseElement `FkBeIDnScope` codigo del ambito de aplicacion.
    ,IN vIdnLang MEDIUMINT				-- Tabla BpmfouTBaseElement `FkBeIDnLanguage` codigo del idioma por defecto elegido. Este es el mismo durante todo el sistema.
    ,IN vIdnCode MEDIUMINT				-- Tabla BpmfouTBaseElement `IDCode` codigo unico estructurado
	,IN vIdnDefinition MEDIUMINT		-- Tabla BpmfouTBaseElement `FkBeIDnDefinition` definición del código; bajo que estandar esta escrito.
	,IN vIdnInformationType MEDIUMINT	-- Tabla BpmfouTBaseElement `FkBeIDnInformationType` Define el tipo de dato que es el BaseElement puede ser: Data (son los elementos reales que forman el sistema los procesos etc.); Software (es la estructura BMPN; XML; XSD).
	,IN vIdnState MEDIUMINT				-- Tabla BpmfouTBaseElement `FkBeIDnState` Código (Habilitado / Deshabilitado / Eliminado) por defecto va habilitado.
    ,IN vTzName MEDIUMINT				-- Tabla BpmfouTBaseElement `TzName`  valor ID del time zone name.
	,IN vTzOffset VARCHAR(6)			-- Tabla BpmfouTBaseElement `TzOffset` valor Offset respecto del UTC.
)
BEGIN

	-- Variables para obtener los valores del procedimiento almacenado de CGetErrorInfo
/*	INSERT INTO `bpmncore`.`bpmfoutsqltimes` (`TableProcess`, `Stage`, `Comments`) VALUES ('BpmfouPBaseElementCRUD','Verifica clave primaria vUniqueId:',vUniqueId);*/
    DECLARE vStoProc_NumConditions TINYINT DEFAULT 0;	-- cantidad de errores
    DECLARE vStoProc_sqlstate MEDIUMINT DEFAULT 0;		-- Numero del sqlstate
    DECLARE vStoProc_errornum MEDIUMINT DEFAULT 0;		-- Numero del errornum
    DECLARE vStoProc_msgtext MEDIUMINT DEFAULT 0;		-- Numero del errornum
	-- exit if Errors occurs
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
			ROLLBACK;		-- Deshace los cambios
            SET lc_messages = 'en_US';		-- Define el idioma del error	/ fr_FR
			-- Define el valor de las variables para el error
			IF vResultMessage <> '' THEN
				SET vResult = 'Err';				-- informa el resultado, OK o Err
				SET vResultNumber = 52001;			-- informa el numero de resultado, este se vincula con una descripcion personalizada
				SET vRowAffected = 0;				-- informa la cantidad de registros afectados
				SET vIdNumReturn = 0;				-- idNum valor único autocalculado, surge de la tabla BpmfouTBaseElement.
            ELSE
				-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
				GET DIAGNOSTICS vStoProc_NumConditions = NUMBER;		-- , @RowCount = ROW_COUNTNumero de Condicion, Numero de Filas Afectadas
				IF vStoProc_NumConditions > 0 THEN
					-- Informa el primer error
					GET DIAGNOSTICS CONDITION 1 vStoProc_sqlstate = RETURNED_SQLSTATE, vStoProc_errornum = MYSQL_ERRNO, vStoProc_msgtext = MESSAGE_TEXT;
						-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
						-- Carga la informacion general (de o no error se carga lo mismo)
						SET vResult = 'Err';				-- informa el resultado, OK o Err.
						SET vResultNumber = 52002;			-- informa el numero de resultado, este se vincula con una descripcion personalizada en la base de datos.
						SET vRowAffected = 0;	-- ROW_COUNT();		-- informa la cantidad de registros afectados.
						SET vIdNumReturn = 0;				-- idNum valor único autocalculado, surge de la tabla BpmfouTBaseElement.
						-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
						-- Resultado Erróneo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
						-- Todas estas variables se envian dentro del mensaje vResultMessage, concatenandolas.	-- , cast(251 AS CHAR), '†'
						SET vResultMessage = concat(cast(vStoProc_errornum AS CHAR), '†', vStoProc_sqlstate, '†', vStoProc_msgtext);
				ELSE
					-- NumConditions = 0, hay error pero no encontro la cantidad de error
					SET vResult = 'Err';				-- informa el resultado, OK o Err
					SET vResultNumber = 52003;			-- informa el numero de resultado, este se vincula con una descripcion personalizada
					SET vRowAffected = 0;	-- ROW_COUNT();		-- informa la cantidad de registros afectados
					SET vIdNumReturn = 0;				-- idNum valor único autocalculado, surge de la tabla BpmfouTBaseElement.
					SET vResultMessage = '52003†CU-000001†Error no especificado';			-- Detalle del resultado
				END IF;
			END IF;
            -- Se elimana el registro con el ID generado.
            IF vCRUD = 1648 THEN		-- CRUD (Create, Read, Update, Delete, Recover) rows		'1648', '5f0761e8-a6a9-11ea-81be-0a0027000004', 'create', '1644',
				DELETE FROM `bpmncore`.`bpmfoutbaseelement` WHERE `ID` = vUniqueId;
			END IF;
		END;

	-- Setea las variables OUT
	SET vResult = '';			-- informa el resultado, OK o Err
	SET vResultNumber = 0;		-- informa el numero de resultado, este se vincula con una descripcion personalizada
	SET vRowAffected = 0;		-- informa la cantidad de registros afectados
    SET vIdNumReturn = 0;		-- idNum valor único autocalculado, surge de la tabla BpmfouTBaseElement.
	SET vResultMessage = '';	-- informa la descripcion del resultado que envia el procediento almacenado
    
	-- SELECT 'Select02' AS Sel, vUniqueId, vIdName, vIdnScope, vIdnLang, vIdnCode, vIdnDefinition, vIdnInformationType, vIdnState, vTzName, vTzOffset;
       
   -- Setea los Default Values
	SELECT Ts.`FkBeIDnTable`,
				MAX(IF(vIdnDefinition = 0 AND Ts.`FkBeIDnColumn` = 69, Dv.`FkBeIDnColumnValueDefault`, vIdnDefinition)) AS IdnDefinition,
				MAX(IF(vIdnInformationType = 0 AND Ts.`FkBeIDnColumn` = 70, Dv.`FkBeIDnColumnValueDefault`, vIdnInformationType)) AS IdnInformationType,
				MAX(IF(vIdnState = 0 AND Ts.`FkBeIDnColumn` = 71, Dv.`FkBeIDnColumnValueDefault`, vIdnState)) AS IdnState
                -- esto genera un registro por columna, el maximo es el valor buscado luego el resto son ceros
		INTO @Tables, 
				vIdnDefinition,
				vIdnInformationType,
				vIdnState
			FROM `bpmncore`.`bpmfoutdbtablestructure` AS Ts
				LEFT OUTER JOIN `bpmncore`.`bpmfoutdbdefaultvalues` AS Dv ON 
					Ts.`IDNumTs` = Dv.`FkBeIDnTableStructure`
				WHERE Dv.`FkBeIDnDefaultVersion` = vIDnDefaultValueVersion			-- @IDnDefaultValueVersion	-- Parametro enviado por el usuario	ISNULL(@IDnDefaultValueVersion, 0)
					AND Ts.`FkBeIDnTable` = 2					-- @IDnTable 'BpmfouTBaseElement'
					AND Dv.`FkBeIDnStateDefaultValue` = 906		-- Estado habilitado
		GROUP BY Ts.`FkBeIDnTable`
        LIMIT 1;

    -- Setea los IdnCode, si la variable es 0, toma el valor segun el scope y le agrega 1
    IF vIdnScope <> 0 AND vIdnCode = 0 THEN
		SELECT MAX(Be.`IDCode`) + 1 AS 'IDCodeNext'
        INTO vIdnCode
		FROM `bpmncore`.`bpmfoutbaseelement` AS Be
		WHERE Be.`FkBeIDnScope` = vIdnScope;
    END IF;
    
	-- SELECT 'Select03' AS Sel, vUniqueId, vIdName, vIdnScope, vIdnLang, vIdnCode, vIdnDefinition, vIdnInformationType, vIdnState, vTzName, vTzOffset;
   
	-- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------   
	IF vCRUD = 1648 THEN		-- CRUD (Create, Read, Update, Delete, Recover) rows		'1648', '5f0761e8-a6a9-11ea-81be-0a0027000004', 'create', '1644',
		-- start a new transaction
		START TRANSACTION;
			-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			-- Etapa 1: Verifica Clave Primaria: un [IDName], un [FkBeIDnScope], un [FkBeIDnLanguage]
				-- Si alguno de los valores son encontrados, la variable @vUniqueId se pone a NULL
				SELECT IF(ID = NULL, vUniqueId, NULL)
						INTO vUniqueId
				  FROM `bpmncore`.`bpmfoutbaseelement` Be
					WHERE Be.IDName = vIdName AND Be.FkBeIDnScope = vIdnScope AND Be.FkBeIDnLanguage = vIdnLang;
					-- Para agregar un nuevo Código, se debe: un [IDName], un [FkBeIDnScope], un [FkBeIDnLanguage]
					-- Los otros campos pueden tener cualquier valor, no se validan.
					-- Aclaración: La combinación más ID del Ambito de Aplicación, puede haber dos códigos iguales, pero cada uno para un ambito de aplicación diferente.
								-- Como el Code es lenguaje de programación, no varía según el idioma, 						
					
			-- Etapa 2: Verifica si no infringe la clave primaria
				-- 1: Si el Código infringe la clave primaria, no hace el cambio e informa al usuario
				IF vUniqueId IS NULL THEN
					-- Con Signal genera un error, luego con Get Diagnostic lo recupera y llena las variables
                    BEGIN
						SET vResultMessage = '52001†CU-000001†El código ingresado ya esta utilizado para ese ámbito de aplicación. En la tabla BpmfouTBaseElement solo puede haber un codigo unico por cada ambito de aplicacion.';			-- Detalle del resultado
						SIGNAL SQLSTATE '45000' 	-- 45000 = excepción definida por el usuario no controlada
							SET MYSQL_ERRNO = 1062,  
								MESSAGE_TEXT = 'El código ingresado ya esta utilizado para ese ámbito de aplicación. En la tabla BpmfouTBaseElement solo puede haber un codigo unico por cada ambito de aplicacion.';
					END;
                ELSE
					-- Inserta el nuevo TBaseElement
                    INSERT INTO `bpmncore`.`bpmfoutbaseelement`
							(`ID`,
							`IDName`,
							`FkBeIDnScope`,
							`FkBeIDnLanguage`,
							`IDCode`,
							`FkBeIDnDefinition`,
							`FkBeIDnInformationType`,
							`FkBeIDnState`,
							`DateBaseElement`,
							`TzName`,
							`TzOffset`)
							SELECT vUniqueId		-- Tabla BpmfouTBaseElement `ID` -- valor ID, debe ser único.
								,VIdName			-- Tabla BpmfouTBaseElement `IDName` -- Código en letras del ID
								,vIdnScope			-- Tabla BpmfouTBaseElement `FkBeIDnScope` -- codigo del ambito de aplicacion.
								,vIdnLang			-- Tabla BpmfouTBaseElement `FkBeIDnLanguage` -- codigo del idioma por defecto elegido. Este es el mismo durante todo el sistema.
                                ,vIdnCode			-- Tabla BpmfouTBaseElement `IDCode`	-- codigo unico estructurado
								,vIdnDefinition		-- Tabla BpmfouTBaseElement `FkBeIDnDefinition` -- definición del código, bajo que estandar esta escrito.
								,vIdnInformationType	-- Tabla BpmfouTBaseElement `FkBeIDnInformationType` -- Define el tipo de dato que es el BaseElement, puede ser: Data (son los elementos reales que forman el sistema, los procesos, etc.), Software (es la estructura BMPN, XML, XSD).
								,vIdnState			-- Tabla BpmfouTBaseElement `FkBeIDnState` --  Código (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
								,UTC_TIMESTAMP()	-- Tabla BpmfouTBaseElement `DateBaseElement` -- Fecha de actualizacion.
								,vTzName 			-- Tabla BpmfouTBaseElement `TzName` 	-- valor ID del time zone name.
								,vTzOffset; 		-- Tabla BpmfouTBaseElement `TzOffset` -- valor Offset respecto del UTC.
					                   
                    -- Define el valor de las variables, ya que es una restriccion de clave primaria
						SET vResult = 'Ok';								-- informa el resultado, OK o Err
						SET vResultNumber = 100001;						-- informa el numero de resultado, este se vincula con una descripcion personalizada
						SET vRowAffected = ROW_COUNT();					-- informa la cantidad de registros afectados, no se puede utilizar el @@ROWCOUNT, ya que no se ejecuto ninguna consulta
						SET vResultMessage = 'Se cargo la informacion solicitada.';

					-- Toma el valor numerico único del ID que se incorporó
						SET vIdNumReturn = (SELECT `IDNum` FROM `bpmncore`.`bpmfoutbaseelement` WHERE `ID` = vUniqueId);

					-- Si el Scope es Null, quiere decir que el valor es Ambito de Aplicación nuevo.
						UPDATE `bpmncore`.`bpmfoutbaseelement` SET `FkBeIDnScope` = vIdNumReturn WHERE (`ID` = vUniqueId AND (`FkBeIDnScope` IS NULL OR `FkBeIDnScope` = 0));
                                
                END IF;
        -- commit changes    
		COMMIT;
	ELSEIF vCRUD = 1649 THEN		-- CRUD (Create, Read, Update, Delete) rows		'1649', '6d99370e-a6a9-11ea-81be-0a0027000004', 'read', '1644',
        SELECT * FROM bpmncore.bpmfoutbaseelement;

		-- Define el valor de las variables, ya que es una restriccion de clave primaria
			SET vResult = 'Ok';								-- informa el resultado, OK o Err
			SET vResultNumber = 100001;						-- informa el numero de resultado, este se vincula con una descripcion personalizada
			SET vRowAffected = ROW_COUNT();					-- informa la cantidad de registros afectados, no se puede utilizar el @@ROWCOUNT, ya que no se ejecuto ninguna consulta
			SET vResultMessage = 'Muestra la informacion solicitada.';

	ELSEIF vCRUD = 1650 THEN		-- CRUD (Create, Read, Update, Delete, Recover) rows		'1650', '7b2034cf-a6a9-11ea-81be-0a0027000004', 'update', '1644',
		SELECT 'Update';

	ELSEIF vCRUD = 1651 THEN		-- CRUD (Create, Read, Update, Delete, Recover) rows		'1651', '8727cda2-a6a9-11ea-81be-0a0027000004', 'delete', '1644',
		SELECT 'Delete';

	ELSEIF vCRUD = 1652 THEN		-- CRUD (Create, Read, Update, Delete, Recover) rows		'1651', '8727cda2-a6a9-11ea-81be-0a0027000004', 'delete', '1644',
		SELECT 'Recover';  
   END IF;

END