SET @IdnDefinition = 0;
SET @IdnInformationType = 0;
SET @IdnState = 0;

SELECT Ts.`FkBeIDnTable`,
		MAX(IF(@IdnDefinition = 0 AND Ts.`FkBeIDnColumn` = 69, Dv.`FkBeIDnColumnValueDefault`, @IdnDefinition)) AS IdnDefinition,
		MAX(IF(@IdnInformationType = 0 AND Ts.`FkBeIDnColumn` = 70, Dv.`FkBeIDnColumnValueDefault`, @IdnDefinition)) AS IdnInformationType,
		MAX(IF(@IdnState = 0 AND Ts.`FkBeIDnColumn` = 71, Dv.`FkBeIDnColumnValueDefault`, @IdnDefinition)) AS IdnState
	INTO @Tables,
		@IdnDefinition,
		@IdnInformationType,
		@IdnState
	FROM `bpmncore`.`bpmfoutdbtablestructure` AS Ts
		LEFT OUTER JOIN `bpmncore`.`bpmfoutdbdefaultvalues` AS Dv ON 
			Ts.`IDNumTs` = Dv.`FkBeIDnTableStructure`
		WHERE Dv.`FkBeIDnDefaultVersion` = 1640		-- @IDnDefaultValueVersion	-- Parametro enviado por el usuario	ISNULL(@IDnDefaultValueVersion, 0)
			AND Ts.`FkBeIDnTable` = 2	-- @IDnTable 'BpmfouTBaseElement'
			AND Dv.`FkBeIDnStateDefaultValue` = 906	-- Estado habilitado
	GROUP BY Ts.`FkBeIDnTable`
	LIMIT 1
    ;

SELECT @IdnDefinition,
		@IdnInformationType,
        @IdnState            
                    
                    
