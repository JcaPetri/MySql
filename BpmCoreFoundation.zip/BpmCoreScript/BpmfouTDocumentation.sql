CREATE TABLE IF NOT EXISTS `BpmnCore`.`BpmfouTDocumentation` (
  `FkBeIDnDocumentation` INT NOT NULL,
  `FkBeIDnLang` INT NOT NULL,
  `Description` TEXT NULL DEFAULT NULL,
  `DescriptionOrder` TINYINT NOT NULL,
  `FkBeIDnTextFormat` INT NOT NULL,
  `FkBeIDnStateDocumentation` INT NOT NULL,
  `DateDocumentation` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `TzName` VARCHAR(5) NOT NULL,
  `TzOffset` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`FkBeIDnDocumentation`, `FkBeIDnLang`),
  INDEX `FkBeIDnDocumentation_idx` (`FkBeIDnDocumentation` ASC) INVISIBLE,
  INDEX `FkBeIDnLang_idx` (`FkBeIDnLang` ASC) VISIBLE,
  CONSTRAINT `FkBeIDnDocumentation`
    FOREIGN KEY (`FkBeIDnDocumentation`)
    REFERENCES `BpmnCore`.`BpmfouTBaseElement` (`IDNum`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `FkBeIDnLang`
    FOREIGN KEY (`FkBeIDnLang`)
    REFERENCES `BpmnCore`.`BpmfouTBaseElement` (`IDNum`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
COMMENT = 'contiene una o más descriptiones del elemento de la tabla TBaseElement. La misma tiene definido un idioma, un orden cuando hay más de una descripcion, un formato de texto MimeType, un estado y la fecha de la ultima actualización.'
