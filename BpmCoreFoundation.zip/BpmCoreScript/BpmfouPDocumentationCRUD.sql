CREATE DEFINER=`root`@`localhost` PROCEDURE `BpmfouPDocumentationCRUD`(
	-- Agrega parametros para mosstrar los resultados del procedimiento almacenado
	OUT vResult NVARCHAR(10) 		-- detalle del resultado.
	,OUT vResultNumber MEDIUMINT	-- informa el numero de resultado, este se vincula con una descripcion personalizada en la base de datos.
	,OUT vRowAffected MEDIUMINT 	-- variable para obtener el numero de registros afectados.
	,OUT vIdNumReturn INT 			-- idNum valor único autocalculado, surge de la tabla BpmfouTBaseElement.
	,OUT vResultMessage TEXT		-- detalle del resultado.
    
	-- Agrega parametros para definir el tipo de accion del procedimiento almacenado
	,IN vCRUD MEDIUMINT						-- Determina acción a realizar.
	,IN vIDnDefaultValueVersion MEDIUMINT	-- Tabla BpmfouTDbDefaultValues [FkBeIDnDefaultVersion] Establece la version del Default Table/Column; esto es porque se pueden generar multiples versiones de DefaultValues para una tabla.
	-- Agrega parametros para proveer informacion y ejecutar el procedimiento almacenado
    ,IN vIdNum int						-- ID valor único autocalculado, surge de la tabla BpmfouTBaseElement.
    ,IN vIdnLang MEDIUMINT				-- Tabla BpmfouTBaseElement `FkBeIDnLanguage` codigo del idioma por defecto elegido. Este es el mismo durante todo el sistema.
    ,IN vDescription VARCHAR(250) 		-- Tabla BpmfouTDocumentation [Description] -- Es la descripción del código en letras.
	,IN vDescriptionOrder TINYINT		-- Tabla BpmfouTDocumentation [DescriptionOrder] -- Es el orden en que aparecen las descripciones para un idioma determinado.
    ,IN vIDnTextFormat MEDIUMINT		-- Tabla BpmfouTDocumentation [FkBeIDnTextFormat] -- definición del código, bajo que estandar esta escrito.
	,IN vIDnStateDocumentation MEDIUMINT	-- Tabla BpmfouTDocumentation [FkBeIDnStateDocumentation] --  Código (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
    ,IN vTzName MEDIUMINT				-- Tabla BpmfouTBaseElement `TzName`  valor ID del time zone name.
	,IN vTzOffset VARCHAR(6)			-- Tabla BpmfouTBaseElement `TzOffset` valor Offset respecto del UTC.
    )
BEGIN
	-- Variables para obtener los valores del procedimiento almacenado de CGetErrorInfo
/*	INSERT INTO `bpmncore`.`bpmfoutsqltimes` (`TableProcess`, `Stage`, `Comments`) VALUES ('BpmfouPBaseElementCRUD','Verifica clave primaria vUniqueId:',vUniqueId);*/
    DECLARE vStoProc_NumConditions TINYINT DEFAULT 0;	-- cantidad de errores
    DECLARE vStoProc_sqlstate MEDIUMINT DEFAULT 0;		-- Numero del sqlstate
    DECLARE vStoProc_errornum MEDIUMINT DEFAULT 0;		-- Numero del errornum
    DECLARE vStoProc_msgtext MEDIUMINT DEFAULT 0;		-- Numero del errornum
	-- exit if Errors occurs
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
			ROLLBACK;		-- Deshace los cambios
            SET lc_messages = 'en_US';		-- Define el idioma del error	/ fr_FR
			-- Define el valor de las variables para el error
			IF vResultMessage <> '' THEN
				SET vResult = 'Err';				-- informa el resultado, OK o Err
				SET vResultNumber = 52001;			-- informa el numero de resultado, este se vincula con una descripcion personalizada
				SET vRowAffected = 0;				-- informa la cantidad de registros afectados
				SET vIdNumReturn = 0;				-- idNum valor único autocalculado, surge de la tabla BpmfouTBaseElement.
            ELSE
				-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
				GET DIAGNOSTICS vStoProc_NumConditions = NUMBER;		-- , @RowCount = ROW_COUNTNumero de Condicion, Numero de Filas Afectadas
				IF vStoProc_NumConditions > 0 THEN
					-- Informa el primer error
					GET DIAGNOSTICS CONDITION 1 vStoProc_sqlstate = RETURNED_SQLSTATE, vStoProc_errornum = MYSQL_ERRNO, vStoProc_msgtext = MESSAGE_TEXT;
						-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
						-- Carga la informacion general (de o no error se carga lo mismo)
						SET vResult = 'Err';				-- informa el resultado, OK o Err.
						SET vResultNumber = 52002;			-- informa el numero de resultado, este se vincula con una descripcion personalizada en la base de datos.
						SET vRowAffected = 0;	-- ROW_COUNT();		-- informa la cantidad de registros afectados.
						SET vIdNumReturn = 0;				-- idNum valor único autocalculado, surge de la tabla BpmfouTBaseElement.
						-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
						-- Resultado Erróneo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
						-- Todas estas variables se envian dentro del mensaje vResultMessage, concatenandolas.	-- , cast(251 AS CHAR), '†'
						SET vResultMessage = concat(cast(vStoProc_errornum AS CHAR), '†', vStoProc_sqlstate, '†', vStoProc_msgtext);
				ELSE
					-- NumConditions = 0, hay error pero no encontro la cantidad de error
					SET vResult = 'Err';				-- informa el resultado, OK o Err
					SET vResultNumber = 52003;			-- informa el numero de resultado, este se vincula con una descripcion personalizada
					SET vRowAffected = 0;	-- ROW_COUNT();		-- informa la cantidad de registros afectados
					SET vIdNumReturn = 0;				-- idNum valor único autocalculado, surge de la tabla BpmfouTBaseElement.
					SET vResultMessage = '52003†CU-000001†Error no especificado';			-- Detalle del resultado
				END IF;
			END IF;
            -- Se elimana el registro con el ID generado.
			IF vCRUD = 1648 THEN		-- CRUD (Create, Read, Update, Delete, Recover) rows		'1648', '5f0761e8-a6a9-11ea-81be-0a0027000004', 'create', '1644',
				DELETE FROM `bpmncore`.`bpmfoutdocumentation` WHERE FkBeIDnDocumentation = vIdNum;
			END IF;
		END;

	-- Setea las variables OUT
	SET vResult = '';			-- informa el resultado, OK o Err
	SET vResultNumber = 0;		-- informa el numero de resultado, este se vincula con una descripcion personalizada
	SET vRowAffected = 0;		-- informa la cantidad de registros afectados
    SET vIdNumReturn = 0;		-- idNum valor único autocalculado, surge de la tabla BpmfouTBaseElement.
	SET vResultMessage = '';	-- informa la descripcion del resultado que envia el procediento almacenado
    
	-- SELECT 'Select02' AS Sel, vUniqueId, vIdName, vIdnScope, vIdnLang, vIdnCode, vIdnDefinition, vIdnInformationType, vIdnState, vTzName, vTzOffset;
       
   -- Setea los Default Values
	SELECT Ts.`FkBeIDnTable`,
				MAX(IF(vIDnLang = 0 AND Ts.`FkBeIDnColumn` = 74, Dv.`FkBeIDnColumnValueDefault`, vIDnLang)) AS IDnLang,
				MAX(IF(vIDnTextFormat = 0 AND Ts.`FkBeIDnColumn` = 77, Dv.`FkBeIDnColumnValueDefault`, vIDnTextFormat)) AS IDnTextFormat,
				MAX(IF(vIDnStateDocumentation = 0 AND Ts.`FkBeIDnColumn` = 78, Dv.`FkBeIDnColumnValueDefault`, vIDnStateDocumentation)) AS IDnStateDocumentation
                -- esto genera un registro por columna, el maximo es el valor buscado luego el resto son ceros
		INTO @Tables, 
				vIDnLang,
				vIDnTextFormat,
				vIDnStateDocumentation
			FROM `bpmncore`.`bpmfoutdbtablestructure` AS Ts
				LEFT OUTER JOIN `bpmncore`.`bpmfoutdbdefaultvalues` AS Dv ON 
					Ts.`IDNumTs` = Dv.`FkBeIDnTableStructure`
				WHERE Dv.`FkBeIDnDefaultVersion` = vIDnDefaultValueVersion			-- @IDnDefaultValueVersion	-- Parametro enviado por el usuario	ISNULL(@IDnDefaultValueVersion, 0)
					AND Ts.`FkBeIDnTable` = 3					-- @IDnTable 'BpmfouTBaseElement'
					AND Dv.`FkBeIDnStateDefaultValue` = 906		-- Estado habilitado
		GROUP BY Ts.`FkBeIDnTable`
        LIMIT 1;
   
	-- SELECT 'Select03' AS Sel, vUniqueId, vIdName, vIdnScope, vIdnLang, vIdnCode, vIdnDefinition, vIdnInformationType, vIdnState, vTzName, vTzOffset;
   
	-- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------   
	IF vCRUD = 1648 THEN		-- CRUD (Create, Read, Update, Delete, Recover) rows		'1648', '5f0761e8-a6a9-11ea-81be-0a0027000004', 'create', '1644',
		-- start a new transaction
		START TRANSACTION;
			-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			-- Etapa 1: Verifica Clave Primaria: un [IDName], un [FkBeIDnScope], un [FkBeIDnLanguage]
				-- Si alguno de los valores son encontrados, la variable @vUniqueId se pone a NULL
				SELECT IF(FkBeIDnDocumentation = NULL, vIdNum, NULL)
						INTO vIdNum
				  FROM `bpmncore`.`bpmfoutdocumentation` Dc
					WHERE Dc.FkBeIDnDocumentation = vIdNum AND Dc.FkBeIDnLang = vIdnLang AND Dc.Description = vDescription;
					-- Para agregar un nuevo Código, se debe: un [vIdNum], un [vIdnLang], un [vDescription]
					-- Los otros campos pueden tener cualquier valor, no se validan.
					-- Aclaración: para un IDNum, para un idioma, no puede tener la misma descripcion 2 veces.						
					
			-- Etapa 2: Verifica si no infringe la clave primaria
				-- 1: Si el Código infringe la clave primaria, no hace el cambio e informa al usuario
				IF vIdNum IS NULL THEN
					-- Con Signal genera un error, luego con Get Diagnostic lo recupera y llena las variables
                    BEGIN
						SET vResultMessage = '52001†CU-000001†La descripcion a ingresar para el idioma y codigo elegido ya esta ingresada.';			-- Detalle del resultado
						SIGNAL SQLSTATE '45000' 	-- 45000 = excepción definida por el usuario no controlada
							SET MYSQL_ERRNO = 1082,  
								MESSAGE_TEXT = 'La descripcion a ingresar para el idioma y codigo elegido ya esta ingresada.';
					END;
                ELSE
					-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
					-- Primero determina si es el primer valor para ese BaseElement, si la consulta no trae valor, pone el valor 1
                    SELECT IFNULL((SELECT Dc.DescriptionOrder FROM `bpmncore`.`bpmfoutdocumentation` AS Dc WHERE Dc.FkBeIDnDocumentation = 1), 0) + 1 AS 'DesOrd' INTO vDescriptionOrder;

					-- ##############################################################################################################################################
					-- INICIO -- ALTA DE LAS DESCRIPCIONES
                    INSERT INTO `bpmncore`.`bpmfoutdocumentation`
								(`FkBeIDnDocumentation`,
								`FkBeIDnLang`,
								`Description`,
								`DescriptionOrder`,
								`FkBeIDnTextFormat`,
								`FkBeIDnStateDocumentation`,
								`DateDocumentation`,
								`TzName`,
								`TzOffset`)
							SELECT vIdNum			-- ID valor único autocalculado, surge de la tabla BpmfouTBaseElement.
								,vIdnLang			-- Tabla BpmfouTBaseElement `FkBeIDnLanguage` codigo del idioma por defecto elegido. Este es el mismo durante todo el sistema.
								,vDescription		-- Tabla BpmfouTDocumentation [Description] -- Es la descripción del código en letras.
								,vDescriptionOrder			-- Tabla BpmfouTDocumentation [DescriptionOrder] -- Es el orden en que aparecen las descripciones para un idioma determinado.
                                ,vIDnTextFormat				-- Tabla BpmfouTDocumentation [FkBeIDnTextFormat] -- definición del código, bajo que estandar esta escrito.
								,vIDnStateDocumentation		-- Tabla BpmfouTDocumentation [FkBeIDnStateDocumentation] --  Código (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
								,UTC_TIMESTAMP()	-- Tabla BpmfouTBaseElement `DateBaseElement` -- Fecha de actualizacion.
								,vTzName 			-- Tabla BpmfouTBaseElement `TzName` 	-- valor ID del time zone name.
								,vTzOffset; 		-- Tabla BpmfouTBaseElement `TzOffset` -- valor Offset respecto del UTC.
					                   
                    -- Define el valor de las variables, ya que es una restriccion de clave primaria
						SET vResult = 'Ok';								-- informa el resultado, OK o Err
						SET vResultNumber = 100001;						-- informa el numero de resultado, este se vincula con una descripcion personalizada
						SET vRowAffected = ROW_COUNT();					-- informa la cantidad de registros afectados, no se puede utilizar el @@ROWCOUNT, ya que no se ejecuto ninguna consulta
						SET vResultMessage = 'Se cargo la informacion solicitada.';
					-- ##############################################################################################################################################
                END IF;
        -- commit changes    
		COMMIT;
	ELSEIF vCRUD = 1649 THEN		-- CRUD (Create, Read, Update, Delete) rows		'1649', '6d99370e-a6a9-11ea-81be-0a0027000004', 'read', '1644',
        SELECT * FROM bpmncore.bpmfoutdocumentation;

		-- Define el valor de las variables, ya que es una restriccion de clave primaria
			SET vResult = 'Ok';								-- informa el resultado, OK o Err
			SET vResultNumber = 100001;						-- informa el numero de resultado, este se vincula con una descripcion personalizada
			SET vRowAffected = ROW_COUNT();					-- informa la cantidad de registros afectados, no se puede utilizar el @@ROWCOUNT, ya que no se ejecuto ninguna consulta
			SET vResultMessage = 'Muestra la informacion solicitada.';

	ELSEIF vCRUD = 1650 THEN		-- CRUD (Create, Read, Update, Delete, Recover) rows		'1650', '7b2034cf-a6a9-11ea-81be-0a0027000004', 'update', '1644',
		SELECT 'Update';

	ELSEIF vCRUD = 1651 THEN		-- CRUD (Create, Read, Update, Delete, Recover) rows		'1651', '8727cda2-a6a9-11ea-81be-0a0027000004', 'delete', '1644',
		SELECT 'Delete';

	ELSEIF vCRUD = 1652 THEN		-- CRUD (Create, Read, Update, Delete, Recover) rows		'1651', '8727cda2-a6a9-11ea-81be-0a0027000004', 'delete', '1644',
		SELECT 'Recover';  
   END IF;

END