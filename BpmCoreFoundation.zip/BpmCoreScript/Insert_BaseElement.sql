-- SELECT * FROM bpmncore.bpmfoutbaseelement WHERE IDCode = 9700;

-- Actualiza el Scope    
UPDATE `bpmncore`.`bpmfoutbaseelement`
SET `FkBeIDnScope` = 1644
WHERE `IDNum` = 1644;

INSERT INTO `bpmncore`.`bpmfoutbaseelement`
		(`IDName`,
		`FkBeIDnScope`,
		`FkBeIDnLanguage`,
		`IDCode`,
		`FkBeIDnDefinition`,
		`FkBeIDnInformationType`,
		`FkBeIDnState`,
		`DateBaseElement`,
		`TzName`,
		`TzOffset`)
SELECT 'delete',			-- Tabla BpmfouTBaseElement [IDName] -- Código en letras del ID
    1644,					-- Tabla BpmfouTBaseElement [FkBeIDnScope] -- codigo del ambito de aplicacion.
    349,				-- Tabla BpmfouTBaseElement [FkBeIDnLanguage] -- Tabla BpmfouTBaseElement [FkBeIDnLanguage] -- codigo del idioma por defecto elegido. Este es el mismo durante todo el sistema.
    50704,				-- Tabla BpmfouTBaseElement [IDCode] -- Codigo numerico establecido por el usuario, permite organizar los contenidos de la tabla por rangos
    1050,				-- Tabla BpmfouTBaseElement [FkBeIDnDefinition] --  Código (Habilitado, Deshabilitado, Eliminado), por defecto va habilitado
    904, 				-- Tabla BpmfouTBaseElement [FkBeIDnInformationType] -- 903 Data / 904 Software = definición del código, bajo que estandar esta escrito.
    906,				-- Tabla BpmfouTBaseElement [FkBeIDnState] -- Define el tipo de dato que es el BaseElement, puede ser: Data (son los elementos reales que forman el sistema, los procesos, etc.), Software (es la estructura BMPN, XML, XSD).
    UTC_TIMESTAMP(),				-- Tabla BpmfouTBaseElement [DateBaseElement] -- Fecha de actualizacion.
    0,								-- Tabla BpmfouTBaseElement [TzName] -- Define el Time Zone del UTC
	'−03:00'						-- Tabla BpmfouTBaseElement [TzOffset] -- Carga el tiempo Offset del UTC hasta la hora del servidor 
	;
    
SELECT * FROM bpmncore.bpmfoutbaseelement WHERE FkBeIDnScope = 1644;


/*
UPDATE `bpmncore`.`bpmfoutbaseelement`
SET `ID` = UUID()
WHERE `IDNum` = 1644;
*/