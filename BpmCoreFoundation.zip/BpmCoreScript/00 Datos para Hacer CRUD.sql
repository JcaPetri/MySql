SELECT * FROM bpmncore.bpmfouvsscopedep where scopeidcode = 1;

SELECT * FROM bpmncore.bpmfouvsdbtablestdefaultvalue where fkbeidntable = 4;

UPDATE `bpmncore`.`bpmfoutbaseelement`
SET `IDName` = 'BpmfouTDefaultValues',
	`IDCode` = 30
WHERE `IDNum` = 1639;
