CREATE TABLE IF NOT EXISTS `BpmnCore`.`BpmfouTRootElement` (
  `FkBeIDnRootElement` INT NOT NULL,
  `FkBeIDnStateRootElement` INT NOT NULL,
  `DateBaseElement` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `TzName` VARCHAR(5) NOT NULL,
  `TzOffset` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`FkBeIDnRootElement`),
  INDEX `FkBeIDnRootElement_idx` (`FkBeIDnRootElement` ASC) INVISIBLE,
  CONSTRAINT `FkBeIDnRootElement`
    FOREIGN KEY (`FkBeIDnRootElement`)
    REFERENCES `BpmnCore`.`BpmfouTBaseElement` (`IDNum`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
COMMENT = 'RootElement es la superclase abstracta para todos los elementos BPMN contenidos en las Definiciones.'
