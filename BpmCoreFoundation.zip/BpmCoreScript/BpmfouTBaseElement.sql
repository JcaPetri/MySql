CREATE TABLE IF NOT EXISTS `BpmnCore`.`BpmfouTBaseElement` (
  `IDNum` INT NOT NULL AUTO_INCREMENT,
  `ID` CHAR(38) NOT NULL,
  `IDName` NVARCHAR(250) NOT NULL,
  `FkBeIDnScope` INT NOT NULL,
  `FkBeIDnLanguage` INT NOT NULL,
  `FkBeIDnDefinition` INT NULL DEFAULT NULL,
  `FkBeIDnState` INT NULL DEFAULT NULL,
  `DateBaseElement` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `TzName` VARCHAR(5) NOT NULL,
  `TzOffset` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`IDNum`, `ID`, `IDName`, `FkBeIDnScope`, `FkBeIDnLanguage`),
  INDEX `ID` (`ID` ASC) INVISIBLE)
ENGINE = InnoDB
COMMENT = 'contiene la mayoría de los elementos del sistema. Los mismos tienen un unico ID, unico Numero, Scope, su item definition, el estado y la ultima fecha de actualizacion. El resto de las tablas tienen un vinculo a esta tabla para identificar que tipo de elemento es.'
