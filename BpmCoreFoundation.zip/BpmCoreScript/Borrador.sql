SELECT `bpmfoutbaseelement`.`IDNum`,
    `bpmfoutbaseelement`.`ID`,
    `bpmfoutbaseelement`.`IDName`,
    `bpmfoutbaseelement`.`FkBeIDnScope`,
    `bpmfoutbaseelement`.`FkBeIDnLanguage`,
    `bpmfoutbaseelement`.`IDCode`,
    `bpmfoutbaseelement`.`FkBeIDnDefinition`,
    `bpmfoutbaseelement`.`FkBeIDnInformationType`,
    `bpmfoutbaseelement`.`FkBeIDnState`,
    `bpmfoutbaseelement`.`DateBaseElement`,
    `bpmfoutbaseelement`.`TzName`,
    `bpmfoutbaseelement`.`TzOffset`
FROM `bpmncore`.`bpmfoutbaseelement`
WHERE `bpmfoutbaseelement`.`FkBeIDnScope` = 1
ORDER BY `bpmfoutbaseelement`.`IDCode`;
-- WHERE `bpmfoutbaseelement`.`ID` = '9F26D184-288C-4926-8B72-A08FFB1F57C8';



