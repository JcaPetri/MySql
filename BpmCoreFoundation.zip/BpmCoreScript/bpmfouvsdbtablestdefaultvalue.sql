SELECT Ts.`IDNumTs`,
    Ts.`IDTs`,
    Ts.`FkBeIDnTable`,
    Be01.`IDName` AS 'TableName',
    Ts.`FkBeIDnColumn`,
    Be02.`IDName` AS 'ColumnName',
--    Ts.`FkBeIDnStateDbTableStructure`,
--    Ts.`DateDbTableStructure`,
--    Ts.`TzName`,
--    Ts.`TzOffset`,
    Dv.`FkBeIDnColumnValueDefault`,
    Be03.`IDName` AS 'DefaultValue',
    Dv.`IDNumTdv`,
    Dv.`FkBeIDnDefaultVersion`,
    Be04.`IDName` AS 'DefaultVerion',
    Dv.`FkBeIDnColumnValueType`,
    Be05.`IDName` AS 'ValueType'
FROM `bpmncore`.`bpmfoutdbtablestructure` AS Ts
	LEFT OUTER JOIN `bpmncore`.`bpmfoutdbdefaultvalues` AS Dv ON 
		Ts.`IDNumTs` = Dv.`FkBeIDnTableStructure`
	LEFT OUTER JOIN `bpmncore`.`bpmfoutbaseelement` AS Be01 ON 
		Ts.`FkBeIDnTable` = Be01.`IDNum`
	LEFT OUTER JOIN `bpmncore`.`bpmfoutbaseelement` AS Be02 ON 
		Ts.`FkBeIDnColumn` = Be02.`IDNum`
	LEFT OUTER JOIN `bpmncore`.`bpmfoutbaseelement` AS Be03 ON 
		Dv.`FkBeIDnColumnValueDefault` = Be03.`IDNum`
	LEFT OUTER JOIN `bpmncore`.`bpmfoutbaseelement` AS Be04 ON 
		Dv.`FkBeIDnDefaultVersion` = Be04.`IDNum`
	LEFT OUTER JOIN `bpmncore`.`bpmfoutbaseelement` AS Be05 ON 
		Dv.`FkBeIDnColumnValueType` = Be05.`IDNum`        
ORDER BY Be01.`IDCode`, Be02.`IDCode`	-- Table, Column
;