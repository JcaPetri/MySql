CREATE TABLE IF NOT EXISTS `BpmnCore`.`BpmfouTBaseElementLanguage` (
  `FkBeIDNum` INT NOT NULL,
  `FkBeIDnScope` INT NOT NULL,
  `FkBeIDnLanguage` INT NOT NULL,
  `IDNameLanguage` NVARCHAR(250) NOT NULL,
  `DateBaseElement` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `TzName` VARCHAR(5) NOT NULL,
  `TzOffset` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`FkBeIDNum`, `FkBeIDnScope`, `FkBeIDnLanguage`, `IDNameLanguage`),
  INDEX `FkBeIDNum_idx` (`FkBeIDNum` ASC) INVISIBLE,
  INDEX `FkBeIDnScope_idx` (`FkBeIDnScope` ASC) INVISIBLE,
  INDEX `FkBeIDnLanguage_idx` (`FkBeIDnLanguage` ASC) INVISIBLE,
  CONSTRAINT `FkBeIDNum`
    FOREIGN KEY (`FkBeIDNum`)
    REFERENCES `BpmnCore`.`BpmfouTBaseElement` (`IDNum`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `FkBeIDnScope`
    FOREIGN KEY (`FkBeIDnScope`)
    REFERENCES `BpmnCore`.`BpmfouTBaseElement` (`IDNum`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `FkBeIDnLanguage`
    FOREIGN KEY (`FkBeIDnLanguage`)
    REFERENCES `BpmnCore`.`BpmfouTBaseElement` (`IDNum`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
COMMENT = 'contiene la mayoría de los elementos del sistema. Los mismos tienen un unico ID, unico Numero, Scope, su item definition, el estado y la ultima fecha de actualizacion. El resto de las tablas tienen un vinculo a esta tabla para identificar que tipo de elemento es.'
