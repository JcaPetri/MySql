select now(), SYSDATE();	--  SLEEP(5),

SELECT @@global.time_zone, @@session.time_zone;

SELECT UTC_TIMESTAMP,UTC_TIMESTAMP();

SELECT @@time_zone;
SELECT @@global.time_zone, @@session.time_zone;

SELECT UUID();


LOAD DATA INFILE 'c:/tmp/discounts_2.csv'
INTO TABLE discounts
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(title,@expired_date,amount)
SET expired_date = STR_TO_DATE(@expired_date, '%m/%d/%Y');
SHOW VARIABLES LIKE "secure_file_priv";


SET GLOBAL local_infile=1;

LOAD DATA LOCAL INFILE 'C:/Users/Admin/Documents/MySql/MySqlFiles/TablasDelSistema.csv'
INTO TABLE `bpmncore`.`bpmfoutbaseelement`
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
	(`ID`,
	`IDName`,
	`FkBeIDnScope`,
	`FkBeIDnLanguage`,
	`FkBeIDnDefinition`,
	`FkBeIDnInformationType`,
	`FkBeIDnState`,
	`DateBaseElement`,
	`TzName`,
	`TzOffset`)
SET `ID` = UUID(),
	`FkBeIDnScope` = 0,
    `FkBeIDnLanguage` = 0,
    `FkBeIDnDefinition` = 0,
    `FkBeIDnInformationType` = 0,
    `FkBeIDnState` = 0,
    `DateBaseElement` = UTC_TIMESTAMP,
    `TzName` = 0,
	`TzOffset` = '-03:00';

SELECT * FROM `bpmncore`.`bpmfoutbaseelement`;


        
GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE,
  @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
  
DROP TABLE IF EXISTS test.no_such_table;
SET @x = @@x;

SHOW WARNINGS;        

GET DIAGNOSTICS CONDITION 1 @p = MESSAGE_TEXT;
select @p;
SHOW WARNINGS;

GET DIAGNOSTICS @p1 = NUMBER, @p2 = ROW_COUNT;
select @p1, @p2;

GET DIAGNOSTICS @num_conditions = NUMBER;
SELECT @num_conditions;

SHOW COUNT(*) ERRORS;
SELECT @@error_count;


SELECT f();
SHOW COUNT(*) ERRORS;
SHOW ERRORS;


INSERT INTO `bpmncore`.`bpmtimpfile` (`DataImport`) VALUES ('Prueba4');

DELETE FROM `bpmncore`.`bpmtimpfile` WHERE id > 0;


