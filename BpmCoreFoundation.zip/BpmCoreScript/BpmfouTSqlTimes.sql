CREATE TABLE IF NOT EXISTS `BpmnCore`.`BpmfouTSqlTimes` (
  `IDProEta` INT NOT NULL AUTO_INCREMENT,
  `ProcesoTabla` NVARCHAR(100) NOT NULL,
  `Etapa` NVARCHAR(100) NOT NULL,
  `Comentarios` NVARCHAR(250) NOT NULL,
  `DateTime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`IDProEta`))
ENGINE = InnoDB
COMMENT = 'Registra los tiempos de los Procesos y sus Etapas. Sirve para analizar el funcionamiento del sistema.'
