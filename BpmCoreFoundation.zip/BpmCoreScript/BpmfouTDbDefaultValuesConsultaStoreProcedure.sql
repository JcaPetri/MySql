-- Setea los Default Values
SET @IdnDefinition = 0;
	SELECT @IdnDefinition = IdnDefinition
    FROM (SELECT Dv.`FkBeIDnDefaultVersion`,
				SUM(IF(@IdnDefinition = 0 AND Ts.`FkBeIDnColumn` = 4345, Dv.`FkBeIDnColumnValueDefault`, @IdnDefinition)) AS IdnDefinition	
			FROM `bpmncore`.`bpmfoutdbtablestructure` AS Ts
				LEFT OUTER JOIN `bpmncore`.`bpmfoutdbdefaultvalues` AS Dv ON 
					Ts.`IDNumTs` = Dv.`FkBeIDnTableStructure`
				WHERE Dv.`FkBeIDnDefaultVersion` = 1640		-- @IDnDefaultValueVersion	-- Parametro enviado por el usuario	ISNULL(@IDnDefaultValueVersion, 0)
					AND Ts.`FkBeIDnTable` = 2	-- @IDnTable de la Tabla BpmfouTBaseElement
					AND Dv.`FkBeIDnStateDefaultValue` = 906	-- Estado habilitado
			GROUP BY Dv.`FkBeIDnDefaultVersion`
		) AS TDefaultValues;
        