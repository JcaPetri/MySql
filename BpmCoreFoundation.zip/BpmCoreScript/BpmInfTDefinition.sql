CREATE TABLE IF NOT EXISTS `BpmnCore`.`BpmInfTDefinition` (
  `FkBeIDnDefinition` INT NOT NULL,
  `TargetNamespace` TEXT NULL DEFAULT NULL,
  `ExpressionLanguage` NVARCHAR(250) NOT NULL,
  `FkBeIDnTypeLanguage` INT NOT NULL,
  `Exporter` NVARCHAR(250) NOT NULL,
  `ExporterVersion` NVARCHAR(250) NOT NULL,
  `FkBeIDnStateDefinition` INT NOT NULL,
  `DateDefinition` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `TzName` VARCHAR(5) NOT NULL,
  `TzOffset` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`FkBeIDnDefinition`),
  INDEX `FkBeIDnDefinition_idx` (`FkBeIDnDefinition` ASC) INVISIBLE,
  CONSTRAINT `FkBeIDnDefinition`
    FOREIGN KEY (`FkBeIDnDefinition`)
    REFERENCES `BpmnCore`.`BpmfouTBaseElement` (`IDNum`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
COMMENT = 'define el espacio de nombre, el lenguaje en que esta escrito (XML, UML, XSD) y como se forma. Todo intercambio de archivos entre distintos sistemas BPMN pasa a traves de una o más definiciones. Esto es como especificar el idioma en que se habla, tipo de acentuación, y otras características generales de los elementos. Por lo tanto, una definición puede estar en uno o más RootElement, BaseElement, BPMNDiagram, Import, Ralationship, y Extension.'
