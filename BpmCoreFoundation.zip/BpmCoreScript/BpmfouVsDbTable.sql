SELECT Ts.`IDNumTs`,
    Ts.`FkBeIDnTable`,
    Be01.`IDName` AS 'IDNameTable',
    Ts.`FkBeIDnColumn`,
    Be02.`IDName` AS 'IDNameColumn',
    Ts.`IDTs`,
    Ts.`FkBeIDnStateDbTableStructure`
--    `bpmfoutdbtablestructure`.`DateDbTableStructure`,
--    `bpmfoutdbtablestructure`.`TzName`,
--    `bpmfoutdbtablestructure`.`TzOffset`
FROM `bpmncore`.`bpmfoutdbtablestructure` AS Ts
	INNER JOIN `bpmncore`.`bpmfoutbaseelement` AS Be01
		ON Ts.`FkBeIDnTable` = Be01.`IDNum`
	INNER JOIN `bpmncore`.`bpmfoutbaseelement` AS Be02
		ON Ts.`FkBeIDnColumn` = Be02.`IDNum`;
