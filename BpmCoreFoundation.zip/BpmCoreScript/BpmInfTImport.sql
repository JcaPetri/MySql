CREATE TABLE IF NOT EXISTS `BpmnCore`.`BpmInfTImport` (
  `FkBeIDnImport` INT NOT NULL,
  `FkBeIDnImportType` INT NOT NULL,
  `Location` NVARCHAR(250) NOT NULL,
  `Namespace` NVARCHAR(250) NOT NULL,
  `FkBeIDnStateImport` INT NOT NULL,
  `DateImport` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `TzName` VARCHAR(5) NOT NULL,
  `TzOffset` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`FkBeIDnImport`),
  INDEX `FkBeIDnImport_idx` (`FkBeIDnImport` ASC) INVISIBLE,
  INDEX `FkBeIDnImportType_idx` (`FkBeIDnImportType` ASC) INVISIBLE,
  CONSTRAINT `FkBeIDnImport`
    FOREIGN KEY (`FkBeIDnImport`)
    REFERENCES `BpmnCore`.`BpmfouTBaseElement` (`IDNum`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `FkBeIDnImportType`
    FOREIGN KEY (`FkBeIDnImportType`)
    REFERENCES `BpmnCore`.`BpmfouTBaseElement` (`IDNum`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
COMMENT = 'la clase Importar se usa cuando se hace referencia a un elemento externo, ya sea elementos BPMN contenidos en otras definiciones BPMN o elementos que no son BPMN.'
