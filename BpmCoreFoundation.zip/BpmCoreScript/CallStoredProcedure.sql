CALL `bpmncore`.`BpmfouPBaseElementCRUD` (
	@Result,
	@ResultNumber,
    @RowAffected,
    @IdNumReturn,
    @ResultMessage,
    1648, 	--	vCRUD,
    1640,	--	vIDnDefaultValueVersion,
    0,		-- vID
    uuid(), 	--	vUniqueId,
    'tBpmTables', 	--	vIdName,
    1, 			--	vIdnScope,
    349,		--	vIdnLang,
    0,		--	vIdnCode,
    0,		--	vIdnDefinition,
    0,		--	vIdnInformationType,
    0,		--	vIdnState,
    0,			--	vTzName,
	'−03:00'	--	vTzOffset
);

SELECT @Result,
	@ResultNumber,
    @RowAffected,
    @IdNumReturn,
    @ResultMessage
    ;
    
    
    
/* SET vCRUD = 1648;
SET vIDnDefaultValueVersion = 1640;
SET vUniqueId = uuid();
SET vIdName = 'Prueba';
SET vIdnScope = 0;
SET vIdnLang = 349;
SET vIdnCode = 1;
SET vIdnDefinition = 1050;
SET vIdnInformationType = 904;
SET vIdnState = 906;
SET vTzOffset = '−03:00';
*/



