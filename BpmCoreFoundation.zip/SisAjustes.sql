SELECT * FROM bpmncore.bpmtfounbaseelement  ORDER BY IDNum
WHERE FkBeIDnScope = 12;


/*
-- Pone a cero los valores no utilizados
UPDATE `bpmncore`.`bpmtfounbaseelement`
	SET IDIsUsed = 0,
		TableHistory = "SetOff"				-- 	"SetNull", "SetOff"
WHERE IDName LIKE '%Free%' AND FkBeIDnScope = 8
*/