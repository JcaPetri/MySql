-- ##############################################################################################################################################################################################
-- BpmnCore Explanation

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Para dar de Alta una Tabla en el Sistema
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Primero:
-- 			Crear la tabla en la base de datos, para ello puede utilizar el modelo de otra tabla, 
--  		que esta en el directorio \MySql\BpmCoreFoundation\Tables

-- Segundo:
-- 			Crear la tabla en el sistema (Entity), para ello debe utilizar el StoredProcedure BpmPEntity 
-- 			que esta en el directorio \MySql\BpmCoreFoundation\Stored Procedure
-- 			Ya hay creadas casi 3000 Entities en el sistema, por lo tanto lo que hay que hacer es utilizar una que este Free
-- 			Hasta que no se cree la Entity en forma completa, no estara disponible para su utilizacion
-- 			Lista las Entity que No Tiene Structure
			SELECT * FROM bpmncore.bpmfouventitynostructure;
-- 			Lista las Entity que SI tienen Structure
			SELECT * FROM bpmncore.bpmfouventity;

-- Tercero:
-- 			Crear las columnas que no existen en el Sistema, para ello debe utilizar el StoredProcedure BpmPEntyField
-- 			que esta en el directorio \MySql\BpmCoreFoundation\Stored Procedure
-- 			Ya hay creadas casi 5000 Field y Column en el sistema, por lo tanto, lo que hay que hacer es utilizar una que este Free
-- 			Lista los Fields utilizados
			SELECT * FROM `bpmncore`.`bpmfoutbaseelement` WHERE ScopeIDn = 2 AND IDIsUsed = 1; --  AND IDNum >= 25585;
-- 			Lista las Columns utilizdas
			SELECT * FROM `bpmncore`.`bpmfoutbaseelement` WHERE ScopeIDn = 4 AND IDIsUsed = 1 AND IDNum >= 25585;        
            
-- Cuerto:
-- 			Crear la estructura en el Sistema, que refleje la Tabla de la base de datos.
--          para ello debe utilizar el StoredProcedure BpmPEntyStructure
-- 			que esta en el directorio \MySql\BpmCoreFoundation\Stored Procedure
-- 			Por ahora lo mas conveniente es utilizar el excel BpmnCoreEntity, importar los datos de la estructura
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- FIN
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

-- ##############################################################################################################################################################################################
-- BpmnFouTField Properties Explanation

-- En esta tabla estan definidas las distintas propiedades de las Fields/Columnas del sistema
-- la clave primaria es:
-- 						FieldIDn: es el IdNum del Field
-- 						FieldPropertyTypeIDn: es el IdNum del tipo de propiedad
-- 						FieldPropertyValueIDn: es el IdNum del valor que tiene la propiedad
-- 						FieldOptionValue: es un String con las opciones que puede tener el campo, eje: un arraylist.alter
-- el resto de los campos son de auditoria



