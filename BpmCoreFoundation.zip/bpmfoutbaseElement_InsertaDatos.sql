DELETE FROM bpmncore.bpmfountbaselementimport WHERE substring(IDName,1,12) = 'BldTCoreFree';
SELECT * FROM bpmncore.bpmfountbaselementimport;

SELECT IDName, COUNT(*) FROM bpmncore.bpmfountbaselementimport GROUP BY IDName HAVING COUNT(*) >1;
-- , replace(IDName,"BldTFree","BldTCoreFree") AS `ids`
SELECT IDName, IDCode FROM bpmncore.bpmfountbaselementimport 
WHERE substring(IDName,1,12) = 'BldTCoreFree';


/*
-- Rangos utilizados por cada Scope, Los valores Free son con el Scope 199
SELECT * FROM `bpmncore`.`bpmfouvscopegroup`;
SELECT * FROM `bpmncore`.`bpmfoutbaseelement` WHERE ScopeIDn = 299 and IDNum = 7540;
*/

-- Inserta un Dato nuevo
INSERT INTO `bpmncore`.`bpmfoutbaseelement`
	(-- `ID`,
	-- `IDNum`,
	`IDName`,
	`ScopeIDn`,
	`LanguageIDn`,
	`IDCode`,
	`DefinitionIDn`,
	`InformationTypeIDn`,
	`IDIsUsed`,
	`StateIDn`,
	`CreatedByIDn`,
	`LastModifiedByIDn`,
	`OwnerIDn`,
	-- `DateCreated`,
	-- `DateTimeStamp`,
	`TzNameIDn`,
	`TzOffset`,
	`TableHistory`)
	SELECT -- `ID`,
		-- `IDNum`,
		`IDName`,
		38 `ScopeIDn`,
		779 `LanguageIDn`,
		`IDCode`,
		533 `DefinitionIDn`,
		524 `InformationTypeIDn`,
		0 `IDIsUsed`,
		514 `StateIDn`,
		0 `CreatedByIDn`,
		0 `LastModifiedByIDn`,
		0 `OwnerIDn`,
		-- `DateCreated`,
		-- `DateTimeStamp`,
		1333 `TzNameIDn`,
		-233 `TzOffset`,
		null `TableHistory`
    FROM `bpmncore`.`bpmfountbaselementimport`
    WHERE substring(IDName,1,12) = 'BldTCoreFree';


    
-- =======================================================================================================================================================================
SELECT * FROM `bpmncore`.`bpmfoutbaseelement` WHERE `ScopeIDn` = 299;

-- Muestra datos importados con IDNum
SELECT * FROM `bpmncore`.`dataimportconidnum`;

SELECT Be01.IDNum,
		Be01.IDName,
		dici.IDName,
        Be01.FkBeIDnScope,
        dici.IDScope,
        Be01.IDCode,
        dici.IDCode
	FROM `bpmncore`.`bpmtfounbaseelement` Be01
		INNER JOIN `bpmncore`.`dataimportconidnum` dici ON 
			Be01.IDnum =  dici.IDNum;

-- Actualiza los datos en forma masiva
UPDATE `bpmncore`.`bpmtfounbaseelement` Be
		INNER JOIN `bpmncore`.`dataimportconidnum` Di ON 
			Be.IDnum =  Di.IDNum
	SET	Be.IDName = Di.IDName,
		Be.FkBeIDnScope = Di.IDScope,
		Be.IDCode = Di.IDCode,
		TableHistory = "SetOff";				-- 	"SetNull", "SetOff"

-- Elimina los datos importados
DELETE FROM `bpmncore`.`dataimportconidnum`