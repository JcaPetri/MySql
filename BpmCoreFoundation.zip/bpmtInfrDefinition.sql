SELECT * FROM bpmncore.bpmtinfrdefinition;

-- 963 = FkBeIDnDefinition
SELECT * FROM `bpmncore`.`bpmtfounbaseelement`;

-- Para agregar un dato, primero se debe generar el valor en la tabla bpmtfounbaseelement, luego en la tabla bpmtinfrdefinition
INSERT INTO bpmncore.bpmtfounbaseelement
	(-- `ID`,
	 -- `IDNum`,
	`IDName`,
	`FkBeIDnScope`,
	`FkBeIDnLanguage`,
	-- `IDCode`,		-- Si no se ingresa es autoincremental, para el mismo scope.
	`FkBeIDnDefinition`,
	`FkBeIDnInformationType`,
	`FkBeIDnState`,
	-- `DateTimeStamp`,
	`FkBeIDnTzName`,
	`TzOffset`,
	`UserIDNum`
	-- `TableHistory`
    )
	SELECT -- `ID`,
		-- `IDNum`,
		"bpmndefaultdefinition" `IDName`,
		383 `FkBeIDnScope`,		-- 1	tBpmTable	383		bpmtinfrdefinition
		2008 `FkBeIDnLanguage`,
		-- 2 `IDCode`,			,		-- Si no se ingresa es autoincremental, para el mismo scope.
		0 `FkBeIDnDefinition`,
		4087 `FkBeIDnInformationType`,
		3885 `FkBeIDnState`,
		-- `DateTimeStamp`,
		2830 `FkBeIDnTzName`,
		-233 `TzOffset`,
		0 `UserIDNum`;
		-- `TableHistory`
        
SELECT * FROM `bpmncore`.`bpmtfounbaseelement` WHERE `IDName` = "bpmndefaultdefinition";

INSERT INTO `bpmncore`.`bpmtinfrdefinition`
	(`FkBeIDnDefinition`,
	`TargetNamespace`,
	`ExpressionLanguage`,
	`FkBeIDnTypeLanguage`,
	`Exporter`,
	`ExporterVersion`,
	`FkBeIDnState`,
	-- `DateTimeStamp`,
	`FkBeIDnTzName`,
	`TzOffset`,
	`UserIDNum`
	-- `TableHistory`
    )
SELECT 	6389 `FkBeIDnDefinition`,		-- 6389	bpmndefaultdefinition
	"http://localhost:8080/" `TargetNamespace`,
	"https://www.w3.org/TR/2017/REC-xpath-31-20170321/" `ExpressionLanguage`,
	3894 `FkBeIDnTypeLanguage`,		-- 3894	TXMLSchema	Scope 8	= tSisTypeLanguage
	"A Definir" `Exporter`,
	"A Definir" `ExporterVersion`,
    3885 `FkBeIDnState`,
	-- `DateTimeStamp`,
	2830 `FkBeIDnTzName`,
	-233 `TzOffset`,
	0 `UserIDNum`
    -- `TableHistory`
    ;

SELECT * FROM `bpmncore`.`bpmtfounbaseelement` WHERE IDNum = 6389;    
SELECT * FROM `bpmncore`.`bpmtinfrdefinition` WHERE `FkBeIDnDefinition` = 6389;

