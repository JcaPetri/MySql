
SELECT * FROM bpmncore.bpmfoutbaseelement WHERE ScopeIDn = 23;

SELECT * FROM bpmncore.bpmfoutbaseelement WHERE ID = 'd7eeb10b-2b7d-11eb-a83a-d9f12c069bf6';


SELECT * FROM `bpmncore`.`bpmfoutbaseelementcondatos` WHERE IDNum = 1333;

-- 2070

UPDATE `bpmncore`.`bpmfoutbaseelement`
SET TzNameIDn = 1206
		, TableHistory = "SetOff"				-- 	"SetNull", "SetOff"
WHERE TzNameIDn = 1333;

SELECT * FROM `bpmncore`.`bpmfoutbaseelementcondatos` WHERE TzNameIDn <> 1333;


/*
`CompanyIDn` = <{CompanyIDn: }>,
`` = <{TzNameIDn: }>,
`TzOffset` = <{TzOffset: }>,

*/

INSERT INTO `bpmncore`.`bpmfoutbaseelement`
		(`ID`,
		`IDName`,
		`ScopeIDn`,
        `CompanyIDn`,
		`LanguageIDn`,
		`IDCode`,
		`DefinitionIDn`,
		`InformationTypeIDn`,
		`IDIsUsed`,
		`StateIDn`,
		`CreatedByIDn`,
		`LastModifiedByIDn`,
 		`OwnerIDn`,
		-- `DateCreated`,
		-- `DateTimeStamp`,
		`TzNameIDn`,
		`TzOffset`)
	SELECT `bpmfoutbaseelementfinal`.`ID`,
		`bpmfoutbaseelementfinal`.`IDName`,
		`bpmfoutbaseelementfinal`.`ScopeIDn`,
        `bpmfoutbaseelementfinal`.`CompanyIDn`,
		`bpmfoutbaseelementfinal`.`LanguageIDn`,
		`bpmfoutbaseelementfinal`.`IDCode`,
		`bpmfoutbaseelementfinal`.`DefinitionIDn`,
		`bpmfoutbaseelementfinal`.`InformationTypeIDn`,
		`bpmfoutbaseelementfinal`.`IDIsUsed`,
		`bpmfoutbaseelementfinal`.`StateIDn`,
		`bpmfoutbaseelementfinal`.`CreatedByIDn`,
		`bpmfoutbaseelementfinal`.`LastModifiedByIDn`,
		`bpmfoutbaseelementfinal`.`OwnerIDn`,
		-- `bpmfoutbaseelementfinal`.`DateCreated`,
		-- `bpmfoutbaseelementfinal`.`DateTimeStamp`,
		`bpmfoutbaseelementfinal`.`TzNameIDn`,
		`bpmfoutbaseelementfinal`.`TzOffset`
	FROM `bpmncore`.`bpmfoutbaseelementfinal`;



-- #######################################################################################################################################################################
-- #######################################################################################################################################################################
INSERT INTO `bpmncore`.`bpmfoutbaseelementfinal`
		(`ID`,
		`IDNum`,
		`IDName`,
		`ScopeIDn`,
        `CompanyIDn`,
		`LanguageIDn`,
		`IDCode`,
		`DefinitionIDn`,
		`InformationTypeIDn`,
		`IDIsUsed`,
		`StateIDn`,
		`CreatedByIDn`,
		`LastModifiedByIDn`,
		`OwnerIDn`,
		-- `DateCreated`,
		-- `DateTimeStamp`,
		`TzNameIDn`,
		`TzOffset`,
		`IDNumOld`)
-- #######################################################################################################################################################################
SELECT `bpmfoutbaseelementcondatos`.`ID`,
    ROW_NUMBER() OVER () + 2196  AS `IDNum`,
    `bpmfoutbaseelementcondatos`.`IDName`,
    -- IF(`bpmfoutbaseelementcondatos`.`IDNum` < 40, `bpmfoutbaseelementcondatos`.`IDName`, CONCAT(SUBSTRING(`bpmfoutbaseelementcondatos`.`IDName`, 1, 14),`bpmfoutbaseelementcondatos`.`IDNum` - 35)) AS `IDName`,
    245 AS 'ScopeIDn',
    -- `bpmfoutbaseelementcondatos`.`ScopeIDn`,
    0 AS `CompanyIDn`,
    `bpmfoutbaseelementcondatos`.`LanguageIDn`,
    `bpmfoutbaseelementcondatos`.`IDCode`,
    `bpmfoutbaseelementcondatos`.`DefinitionIDn`,
    `bpmfoutbaseelementcondatos`.`InformationTypeIDn`,
    `bpmfoutbaseelementcondatos`.`IDIsUsed`,
    `bpmfoutbaseelementcondatos`.`StateIDn`,
    `bpmfoutbaseelementcondatos`.`CreatedByIDn`,
    `bpmfoutbaseelementcondatos`.`LastModifiedByIDn`,
    `bpmfoutbaseelementcondatos`.`OwnerIDn`,
    -- `bpmfoutbaseelementcondatos`.`DateCreated`,
    -- `bpmfoutbaseelementcondatos`.`DateTimeStamp`,
    `bpmfoutbaseelementcondatos`.`TzNameIDn`,
    `bpmfoutbaseelementcondatos`.`TzOffset`,
    -- `bpmfoutbaseelementcondatos`.`TableHistory`,
	`bpmfoutbaseelementcondatos`.`IDNum`
FROM `bpmncore`.`bpmfoutbaseelementcondatos`
WHERE ScopeIDn = 24689 AND IDIsUsed = 1	-- ScopeIDn >= 5 AND ScopeIDn <= 39
;

SELECT MAX(IDNum) AS 'MAXIMO' FROM `bpmncore`.`bpmfoutbaseelementfinal`;
-- 2198

SELECT * FROM `bpmncore`.`bpmfoutbaseelementfinal`;
--  AND IDNum >= 62498 AND IDNum <= 62501

-- SELECT * FROM `bpmncore`.`bpmfoutbaseelementfinal`;

-- Deshabilita los datos ya insertados, y los que se van a eliminar
UPDATE `bpmncore`.`bpmfoutbaseelementcondatos`
SET `DefinitionIDn` = 0
-- WHERE (IDNum >= 1 AND IDNum <= 4 OR IDNum >= 40 AND IDNum <= 45);		-- Los Scopes Usados
WHERE ScopeIDn = 39 AND DefinitionIDn <> 0								-- Los Scopes NO Usuados
;
-- SELECT * FROM `bpmncore`.`bpmfoutbaseelementcondatos` WHERE ScopeIDn = 15 AND IDNum > 3 AND IDIsUsed = 1 Order by IDCode;


-- IDNum, ROW_NUMBER() OVER () + 249 AS 'CONT'
SELECT * FROM `bpmncore`.`bpmfoutbaseelementcondatos` WHERE ScopeIDn >= 5 AND ScopeIDn <= 39 AND IDIsUsed = 1 Order by IDCode;
SELECT * FROM `bpmncore`.`bpmfoutbaseelementfinal` WHERE ScopeIDn = 3;

SELECT * FROM `bpmncore`.`bpmfoutbaseelementcondatos` WHERE ScopeIDn = 24309 AND  IDIsUsed = 1; -- AND IDName LIKE '%Free%'

UPDATE `bpmncore`.`bpmfoutbaseelementcondatos`
SET IDIsUsed = 0
-- WHERE (IDNum >= 1 AND IDNum <= 4 OR IDNum >= 40 AND IDNum <= 45);		-- Los Scopes Usados
WHERE ScopeIDn = 38 AND IDName LIKE '%Free%' AND  IDIsUsed = 1
;

SELECT * FROM `bpmncore`.`bpmfoutbaseelementcondatos` WHERE IDNum = ScopeIDn AND DefinitionIDn <> 0;

SELECT * FROM `bpmncore`.`bpmfoutbaseelementcondatos` 
-- WHERE (IDNum >= 1 AND IDNum <= 4 OR IDNum >= 40 AND IDNum <= 45);		-- Los Scopes Usados
WHERE IDNum = ScopeIDn								-- Los Scopes NO Usuados
;

SELECT * FROM `bpmncore`.`bpmfoutbaseelementfinal` WHERE ScopeIDn = 15;

/*
-- SELECT * FROM bpmncore.bpmfoutbaseelement;
SELECT IF(IDNum < 40, IDNum, IDNum - 35) AS `IDNume`, IDNum FROM `bpmncore`.`bpmfoutbaseelementcondatos`
WHERE IDNum >= 1 AND IDNum <= 4 OR IDNum >= 40 AND IDNum <= 45;
;
*/