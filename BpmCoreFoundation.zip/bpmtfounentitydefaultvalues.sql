-- Lista el detalle de la Tabla donde esta la estructura del sistema
SELECT Ts.FkBeIDnTable "IDnTable", Be01.IDName "Table", Ts.IDNumTs, Ts.FkBeIDnColumn "IDnCol", Be02.IDName "Column", Ts.FkBeIDnColumnType "IDnColType", Be03.IDName "DataType", Ts.TsColumnOrder, Ts.FkBeIDnAdmitDefaultValue "IDnAdmitDefVal", Be04.IDName "AdmitDefVal"
	, Dv01.FkBeIDnDefaultVersion "IDnDefVersion", Dv01.FkBeIDnColumnValueDefault "ColDefVer", Be05.IDName "DefaultValue", Dv01.IDNumTdv
FROM `bpmncore`.`bpmtfoundbtablestructure` Ts 
	INNER JOIN `bpmncore`.`bpmtfounbaseelement` Be01 ON TS.FkBeIDnTable = Be01.IDNum 
	INNER JOIN `bpmncore`.`bpmtfounbaseelement` Be02 ON TS.FkBeIDnColumn = Be02.IDNum 
    INNER JOIN `bpmncore`.`bpmtfounbaseelement` Be03 ON TS.FkBeIDnColumnType = Be03.IDNum 
    INNER JOIN `bpmncore`.`bpmtfounbaseelement` Be04 ON TS.FkBeIDnAdmitDefaultValue = Be04.IDNum
    LEFT OUTER JOIN `bpmncore`.`bpmtfoundbdefaultvalues` Dv01 ON TS.IDNumTs = Dv01.FkBeIDnTableStructure
    LEFT OUTER JOIN `bpmncore`.`bpmtfounbaseelement` Be05 ON Dv01.FkBeIDnColumnValueDefault = Be05.IDNum
-- WHERE FkBeIDnTable = 391			-- 402		-- bpmtFounDbTableStructure
	-- AND Ts.FkBeIDnAdmitDefaultValue = 3880
-- WHERE Ts.FkBeIDnAdmitDefaultValue = 3880		-- True = Admit Default Values
ORDER BY Ts.FkBeIDnTable, Ts.TsColumnOrder;

-- Lista la tabla con los posible Default Version
SELECT * FROM `bpmncore`.`bpmtfounbaseelement` WHERE FkBeIDnScope = 404;
SELECT * FROM `bpmncore`.`bpmtfounbaseelement` WHERE IDNum = 6391;

-- Lista la tabla donde estan los valores por default
SELECT * FROM bpmncore.bpmtfoundbdefaultvalues;

-- Inserta los default values desde la Tabla bpmtfoundbtablestructure
INSERT INTO `bpmncore`.`bpmtfoundbdefaultvalues`
		(
        -- `IDNumTdv`,
		-- `IDTdv`,
		`FkBeIDnDefaultVersion`,
		`FkBeIDnTableStructure`,
		`FkBeIDnColumnValueDefault`,
		`FkBeIDnState`,
		-- `DateTimeStamp`,
		`FkBeIDnTzName`,
		`TzOffset`,
		`UserIDNum`
		-- `TableHistory`
        )
		SELECT 6391 `FkBeIDnDefaultVersion`,		-- 6391	BpmVersion 1.0
			Ts.IDNumTs `FkBeIDnTableStructure`,
			0 `FkBeIDnColumnValueDefault`,
			3885 `FkBeIDnState`,
			-- `DateTimeStamp`,
			2830 `FkBeIDnTzName`,
			-233 `TzOffset`,
			0 `UserIDNum`
		FROM `bpmncore`.`bpmtfoundbtablestructure` Ts 
			INNER JOIN `bpmncore`.`bpmtfounbaseelement` Be01 ON TS.FkBeIDnTable = Be01.IDNum INNER JOIN `bpmncore`.`bpmtfounbaseelement` Be02 ON TS.FkBeIDnColumn = Be02.IDNum 
		WHERE Ts.FkBeIDnAdmitDefaultValue = 3880		-- True = Admit Default Values
				AND Ts.FkBeIDnTable = 397
		ORDER BY Ts.FkBeIDnTable, Ts.TsColumnOrder;


/*
-- Inserta los default values desde la Tabla bpmtfoundbtablestructure
INSERT INTO `bpmncore`.`bpmtfoundbdefaultvalues`
		(
        -- `IDNumTdv`,
		-- `IDTdv`,
		`FkBeIDnDefaultVersion`,
		`FkBeIDnTableStructure`,
		`FkBeIDnColumnValueDefault`,
		`FkBeIDnState`,
		-- `DateTimeStamp`,
		`FkBeIDnTzName`,
		`TzOffset`,
		`UserIDNum`
		-- `TableHistory`
        )
		SELECT di.`FkBeIDnDefaultVersion`,
			di.`FkBeIDnTableStructure`,
			di.`FkBeIDnColumnValueDefault`,
			di.`FkBeIDnState`,
			di.`FkBeIDnTzName`,
			di.`TzOffset`,
			di.`UserIDNum`
		FROM `bpmncore`.`dataimportexportartbldefvalue` di;

*/



-- Lista la tabla donde estan los valores por default
SELECT * FROM bpmncore.bpmtfoundbdefaultvalues;
/* Actualiza el valor por default */

UPDATE `bpmncore`.`bpmtfoundbdefaultvalues`
SET FkBeIDnColumnValueDefault = 3885,
		TableHistory = "SetOff"				-- 	"SetNull", "SetOff"
WHERE `IDNumTdv` = 33;


