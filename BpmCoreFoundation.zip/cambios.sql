
UPDATE `bpmncore`.`bpmfoutbaseelement`
	SET `IDName` = "tBpmTables"
	--	, FkBeIDnScope = 1
     , `TableHistory` = "SetOff"
	WHERE `IDNum` = 1;
SELECT * FROM  `bpmncore`.`bpmfoutbaseelement` WHERE `IDNum` = 1;
    
UPDATE `bpmncore`.`bpmfoutbaseelement`
	SET `TableHistory` = "SetNull"
    -- , `IDName` = "Carga 1"
	WHERE `IDNum` = 1;
SELECT * FROM  `bpmncore`.`bpmfoutbaseelement` WHERE `IDNum` = 1;

