-- ##############################################################################################################################################################################################
-- Crea una Entity en el Sistema

-- Ya hay creadas casi 5000 Field y Column en el sistema, por lo tanto lo que hay que hacer es utilizar una que este Free
/* Los Scopes de estructura del sistema son
	2	tSisEntityField		2500
	4	tSisTableColumn		2499
*/

-- En las siguientes consultas se muestran las Columans y Field que ya estan utilizadas, esto es para ver que numero No Utilizar
-- Tambien permite definir el orden dentro del IDCode
-- Detalle de Java Field Entity
SELECT * FROM `bpmncore`.`bpmfouvscopedet` WHERE ScopeIDCode = 2 order by IDNum;
-- Detalle de Column de las Tablas SQL
SELECT * FROM `bpmncore`.`bpmfouvscopedet` WHERE ScopeIDCode = 4 order by IDNum;

-- Columns y Fields Entity disponibles, para ello debe verificar que el nombre no este ya utilizado
-- Detalle de las Java Entity
SELECT * FROM `bpmncore`.`bpmfoutbaseelement` WHERE ScopeIDn = 2; --  AND IDNum >= 24005;

-- Detalle de Tablas SQL
SELECT * FROM `bpmncore`.`bpmfoutbaseelement` 
WHERE ScopeIDn = 4 					-- Define que trabaja con los tSisTableColumn
	-- AND IDName LIKE '%FieldPropertyIDn%'			-- Nombre de la nueva columna
	-- AND IDIsUsed = 0 
    AND IDNum >= 25585;


-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Ya Elegido el IDNum que se va actualizar, se debe ejecutar el StoredProceduer de actualizacion
UPDATE `bpmncore`.`bpmfoutbaseelement`
	SET IDName = 'FieldPropertyIDn',
		IDIsUsed = 1,
		TableHistory = "SetOff"				-- 	"SetNull", "SetOff"
WHERE IDNum = 25589 AND ScopeIDn = 4 AND IDIsUsed = 0;   -- Se Asegura que no se cambie una Tabla que ya esta utilizada

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^


