-- ##############################################################################################################################################################################################
-- Crea una Entity en el Sistema

-- Ya hay creadas casi 3000 Entities en el sistema, por lo tanto lo que hay que hacer es utilizar una que este Free
/* Los Scopes de estructura del sistema son
	1	tSisEntity	1499
	3	tSisTable	1499
*/

-- En las siguientes consultas se muestran las Tablas y Entity que ya estan utilizadas, esto es para ver que numero No Utilizar
-- Tambien permite definir el orden dentro del IDCode
-- Detalle de Java Entity
SELECT * FROM `bpmncore`.`bpmfouvscopedet` WHERE ScopeIDCode = 1 order by IDNum;
-- Detalle de Tablas SQL
SELECT * FROM `bpmncore`.`bpmfouvscopedet` WHERE ScopeIDCode = 3 order by IDNum;

-- Tablas y Java Entity disponibles
-- Detalle de las Java Entity
SELECT * FROM `bpmncore`.`bpmfoutbaseelement` WHERE ScopeIDn = 1; --  AND IDNum >= 24005;
-- Detalle de Tablas SQL
SELECT * FROM `bpmncore`.`bpmfoutbaseelement` WHERE ScopeIDn = 3 AND IDNum >= 24005;

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Ya Elegido el IDNum que se va actualizar, se debe ejecutar el StoredProceduer de actualizacion
UPDATE `bpmncore`.`bpmfoutbaseelement`
	SET IDName = 'bpmfoutfieldproperties',
		IDIsUsed = 1,
		TableHistory = "SetOff"				-- 	"SetNull", "SetOff"
WHERE IDNum = 24010 AND ScopeIDn = 3 AND IDIsUsed = 0;   -- Se Asegura que no se cambie una Tabla que ya esta utilizada

-- Cuando se crea la Entity, como no tiene Structure, no se ve en la consutla Entity

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Lista las Entity que No Tiene Structure
SELECT * FROM bpmncore.bpmfouventitynostructure;

-- Lista las Entity que SI tienen Structure
SELECT * FROM bpmncore.bpmfouventity;

