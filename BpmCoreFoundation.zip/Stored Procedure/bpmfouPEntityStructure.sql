-- Detalle de Tablas
SELECT * FROM `bpmncore`.`bpmfoutbaseelement` Be where Be.ScopeIDn = 3 AND IDIsUsed = 1 ORDER BY Be.IDNum;
-- Detalle de Columnas
SELECT * FROM `bpmncore`.`bpmfoutbaseelement` Be where Be.ScopeIDn = 4 AND IDIsUsed = 1 ORDER BY Be.IDNum;

-- Detalle de Entity
SELECT * FROM `bpmncore`.`bpmfoutbaseelement` Be where Be.ScopeIDn = 1 AND IDIsUsed = 1 ORDER BY Be.IDNum;
-- Detalle de Field
SELECT * FROM `bpmncore`.`bpmfoutbaseelement` Be where Be.ScopeIDn = 2 AND IDIsUsed = 1 ORDER BY Be.IDNum;


-- ###########################################################################################################################################################################3
-- Inserta los datos en el bpmfoutentitystructure, desde los datos importados
-- Lista los datos que se importaron
SELECT * FROM `bpmncore`.`dataimportetitystructure` `di`;

-- DELETE FROM `bpmncore`.`dataimportetitystructure`;

-- Verifica que no haya datos duplicados
SELECT `di`.`EntityTypeIDn`, `di`.`EntityIDn`, `di`.`FieldIDn`, COUNT(*) AS Q FROM `bpmncore`.`dataimportetitystructure` `di`
	GROUP BY `di`.`EntityTypeIDn`, `di`.`EntityIDn`, `di`.`FieldIDn`
    HAVING  COUNT(*) > 1;

-- Inserta los datos
INSERT INTO `bpmncore`.`bpmfoutentitystructure`
		(-- `ID`,
		-- `IDNum`,
		`EntityTypeIDn`,
		`EntityIDn`,
		`FieldIDn`,
		`FieldTypeIDn`,
		`TsFieldOrder`,
		`AdmitDefaultValueIDn`,
		`StateIDn`,
		`CreatedByIDn`,
		`LastModifiedByIDn`,
		`OwnerIDn`,
		-- `DateCreated`,
		-- `DateTimeStamp`,
		`TzNameIDn`,
		`TzOffset`,
		`TableHistory`)
	SELECT `di`.`EntityTypeIDn`,
			`di`.`EntityIDn`,
			`di`.`FieldIDn`,
			`di`.`FieldTypeIDn`,
			`di`.`TsFieldOrder`,
			`di`.`AdmitDefaultValueIDn`,
			`di`.`StateIDn`,
			`di`.`CreatedByIDn`,
			`di`.`LastModifiedByIDn`,
			`di`.`OwnerIDn`,
			`di`.`TzNameIDn`,
			`di`.`TzOffset`,
			null `TableHistory`
	FROM `bpmncore`.`dataimportetitystructure` `di`;

-- ###########################################################################################################################################################################3
-- Pasos para insertar un nuevo valor entre los ya insertados
SELECT * FROM bpmncore.bpmfouventity;

-- Muestra las Entity Structure
SELECT * FROM bpmncore.bpmfouventitystructure
WHERE EntityIDn = 24010
;

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Primero:
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Actualiza el numero del TsFieldOrder
-- Aclaraciones:
-- 				se debe poner el Codigo de la Entity y el valor real que va a tomar el nuevo valor insertado
UPDATE `bpmncore`.`bpmfoutentitystructure` `es`
SET `es`.`TsFieldOrder` = `es`.`TsFieldOrder` + 1,
	`es`.`TableHistory` = "SetOff"	-- 	"SetNull", "SetOff"
WHERE `es`.`EntityIDn` = 24010 				-- Es la Entidad que contiene los Fields
		AND `es`.`TsFieldOrder` >= 6		-- Es el valor a reemplazar
        -- AND `es`.`IDNum` = 576				-- Es el IDNum del Field
;

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Segundo:
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Inserta el numero Valor
-- Aclaraciones:
-- 				se debe poner el Codigo de la Entity y el valor real que va a tomar el nuevo valor insertado
INSERT INTO `bpmncore`.`bpmfoutentitystructure`
		(-- `ID`,
		-- `IDNum`,
		`EntityTypeIDn`,
		`EntityIDn`,
		`FieldIDn`,
		`FieldTypeIDn`,
		`TsFieldOrder`,
		`AdmitDefaultValueIDn`,
		`StateIDn`,
		`CreatedByIDn`,
		`LastModifiedByIDn`,
		`OwnerIDn`,
		-- `DateCreated`,
		-- `DateTimeStamp`,
		`TzNameIDn`,
		`TzOffset`,
		`TableHistory`)
SELECT DISTINCT 
		-- `es`.`ID`,			-- Valor autogenerado
		-- `es`.`IDNum`,		-- Valor autogenerado
		502 `EntityTypeIDn`,
		24010 `EntityIDn`,
		25590 `FieldIDn`,
		303 `FieldTypeIDn`,
		4 `TsFieldOrder`,
		1 `AdmitDefaultValueIDn`,		-- 1 True, 2 False
		514 `StateIDn`,
		1 `CreatedByIDn`,
		0 `LastModifiedByIDn`,
		0 `OwnerIDn`,
		-- `DateCreated`,		-- Valor autogenerado
		-- `DateTimeStamp`,		-- Valor autogenerado
		1333 `TzNameIDn`,
		-233 `TzOffset`,
		NULL `TableHistory`;

-- Busca el FieldIDn
SELECT * FROM `bpmncore`.`bpmfoutbaseelement` Be WHERE `IDName` LIKE '%FieldPropertyTypeIDn%';
-- Busca el Tipo de Field



-- ###########################################################################################################################################################################3
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Muestra los valores sumados uno, consulta complicada
SELECT `es`.`IDNum`,
	`es`.`EntityIDn`,
    `es`.`FieldIDn`,
    `es`.`TsFieldOrder`,
	`eso`.`TsFieldOrderNuevo`,
	`es`.`TsFieldOrder` - `eso`.`TsFieldOrderNuevo` AS 'Dif'
FROM `bpmncore`.`bpmfoutentitystructure` `es`
	INNER JOIN (
				SELECT  `es`.`EntityIDn`,
					`es`.`IDNum`,
					`es`.`FieldIDn`,
					`es`.`TsFieldOrder` + 1 AS 'TsFieldOrderNuevo'
				FROM `bpmncore`.`bpmfoutentitystructure` `es`
				WHERE `es`.`EntityIDn` = 24010 
					AND `es`.`TsFieldOrder` >= 4		-- Es el valor a reemplazar
                    -- AND `es`.`IDNum` = 576
				) `eso` ON 
					`es`.`IDNum` = `eso`.`IDNum` 
					AND `es`.`EntityIDn` = `eso`.`EntityIDn`
                    
                    
