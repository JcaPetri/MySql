SELECT * FROM `bpmncore`.`bpmfoutdbtablestructure`;

SELECT `bpmfoutdbdefaultvalues`.`IDNumTdv`,
    `bpmfoutdbdefaultvalues`.`IDTdv`,
    `bpmfoutdbdefaultvalues`.`FkBeIDnDefaultVersion`,
    `bpmfoutdbdefaultvalues`.`FkBeIDnTableStructure`,
    `bpmfoutdbdefaultvalues`.`FkBeIDnColumnValueDefault`,
    `bpmfoutdbdefaultvalues`.`FkBeIDnState`,
    `bpmfoutdbdefaultvalues`.`DateTime`,
    `bpmfoutdbdefaultvalues`.`FkBeIDnTzName`,
    `bpmfoutdbdefaultvalues`.`TzOffset`,
    `bpmfoutdbdefaultvalues`.`UserIDNum`
FROM `bpmncore`.`bpmfoutdbdefaultvalues`;

