-- Lista los Scopes y el detalle de los mismos.
-- VIEW `bpmncore`.`bpmfouvsscopedep` AS
	SELECT `ScD`.*
    FROM (
			SELECT 
				`bpmncore`.`be`.`ScopeIDn` AS `ScopeIDCode`,
				`bpmncore`.`be`.`IDName` AS `ScopeIDName`,
				`bpmncore`.`be`.`IDNum` AS `IDNum`,
				`bpmncore`.`be`.`IDName` AS `IDName`,
				`bpmncore`.`be`.`IDCode` AS `IDCode`,
				`bpmncore`.`be`.`ID` AS `ID`,
				IF((`bpmncore`.`be`.`IDNum` = `bpmncore`.`be`.`ScopeIDn`),
					'Scope',
					'Value') AS `Type`
			FROM
				`bpmncore`.`bpmfoutbaseelement` `be`
			WHERE
				(`be`.`IDNum` = `be`.`ScopeIDn`)
			UNION ALL
			SELECT 
				`bpmncore`.`be01`.`ScopeIDn` AS `ScopeIDCode`,
				`bpmncore`.`be01`.`IDName` AS `ScopeIDName`,
				`bpmncore`.`be`.`IDNum` AS `IDNum`,
				`bpmncore`.`be`.`IDName` AS `IDName`,
				`bpmncore`.`be`.`IDCode` AS `IDCode`,
				`bpmncore`.`be`.`ID` AS `ID`,
				IF((`bpmncore`.`be`.`IDNum` = `bpmncore`.`be`.`ScopeIDn`),
					'Scope',
					'Value') AS `Type`
			FROM
				(`bpmncore`.`bpmfoutbaseelement` `be`
				JOIN `bpmncore`.`bpmfoutbaseelement` `be01` ON ((`bpmncore`.`be`.`ScopeIDn` = `bpmncore`.`be01`.`IDNum`)))
			WHERE `be`.`IDIsUsed` = 1 AND (`be`.`IDNum` <> `be`.`ScopeIDn`)
		) `ScD`
    ORDER BY `ScD`.`ScopeIDCode`, `ScD`.`IDCode`