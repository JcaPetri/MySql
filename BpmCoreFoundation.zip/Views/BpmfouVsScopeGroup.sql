-- Vista que lista los Scopes y La Cantidad de Registros que tienen cada uno asignados
-- `bpmncore`.`bpmfouvscopegroup` AS
    SELECT 
        `be`.`IDNum` AS `IDNum`,
        `be`.`ID` AS `ID`,
        `be`.`IDName` AS `IDName`,
        `be`.`ScopeIDn` AS `ScopeIDn`,
		`scg`.`ScopeStart`,
        `scg`.`ScopeEnd`,
        `scg`.`ScopeTotal`
/*
        `be`.`LanguageIDn` AS `FkBeIDnLanguage`,
        `be`.`IDCode` AS `IDCode`,
        `be`.`DefinitionIDn` AS `FkBeIDnDefinition`,
        `be`.`InformationTypeIDn` AS `FkBeIDnInformationType`,
        `be`.`IDIsUsed` AS `IDIsUsed`,
        `be`.`StateIDn` AS `FkBeIDnState`,
		`be`.`CreatedByIDn`,
		`be`.`LastModifiedByIDn`,
        `be`.`OwnerIDn`,
		`be`.`DateCreated` AS `DateCreated`,        
		`be`.`DateTimeStamp` AS `DateTimeStamp`,
        `be`.`TzNameIDn` AS `TzName`,
        `be`.`TzOffset` AS `TzOffset`,
		`be`.`TableHistory`
*/
    FROM `bpmncore`.`bpmfoutbaseelement` `be`
        LEFT OUTER JOIN (SELECT `be`.`ScopeIDn`, MIN(IDNum) `ScopeStart`, MAX(IDNum) `ScopeEnd`, COUNT(*) `ScopeTotal` 
							FROM `bpmncore`.`bpmfoutbaseelement` `be`
						 WHERE (`be`.`IDNum` <> `be`.`ScopeIDn`)
						 GROUP BY `be`.`ScopeIDn`
						) `scg` ON `be`.`ScopeIDn` = `scg`.`ScopeIDn`
    WHERE (`be`.`IDNum` = `be`.`ScopeIDn`)
    ORDER BY `be`.`IDCode`
    
    
    SELECT * FROM `bpmncore`.`bpmfoutbaseelement`