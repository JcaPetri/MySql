-- BpmfouVFieldProperty
-- bpmfouvfieldproperty
SELECT `fp`.`ID`,
		`fp`.`IDNum`,
		`fp`.`FieldIDn`,
        `be01`.`IDName` AS 'Field',
		`fp`.`FieldPropertyTypeIDn`,
        `be02`.`IDName` AS 'PropertyType',
		`fp`.`FieldPropertyValueIDn`,
        `be03`.`IDName` AS 'PropertyValue',
		`fp`.`FieldOptionValue`,
		`fp`.`StateIDn`,
        `be04`.`IDName` AS 'State',
		`fp`.`CreatedByIDn`,
		`fp`.`LastModifiedByIDn`,
		`fp`.`OwnerIDn`,
		`fp`.`DateCreated`,
		`fp`.`DateTimeStamp`,
		`fp`.`TzNameIDn`,
		`fp`.`TzOffset`,
		`fp`.`TableHistory`
FROM `bpmncore`.`bpmfoutfieldproperties` `fp`
	JOIN `bpmncore`.`bpmfoutbaseelement` `be01` ON `fp`.`FieldIDn` = `be01`.`IDNum`
	JOIN `bpmncore`.`bpmfoutbaseelement` `be02` ON `fp`.`FieldPropertyTypeIDn` = `be02`.`IDNum`    
    LEFT JOIN `bpmncore`.`bpmfoutbaseelement` `be03` ON `fp`.`FieldPropertyValueIDn` = `be03`.`IDNum`
    JOIN `bpmncore`.`bpmfoutbaseelement` `be04` ON `fp`.`StateIDn` = `be04`.`IDNum`    
;
