-- Vista que lista los Scopes y La Cantidad de Registros que tienen cada uno asignados
-- `bpmncore`.`bpmfouvscopegroup` AS
SELECT *
FROM (
		SELECT 
			`be`.`IDNum` AS `IDNum`,
			`be`.`ID` AS `ID`,
			`be`.`IDName` AS `IDName`,
			`be`.`ScopeIDn` AS `ScopeIDn`,
			`scg`.`ScopeStart`,
			`scg`.`ScopeEnd`,
			`scg`.`ScopeTotal`,
			`scg`.`ScopeUsed`,
            `scg`.`ScopeTotal` - `scg`.`ScopeUsed` AS `ScopeFree`
		FROM `bpmncore`.`bpmfoutbaseelement` `be`
			LEFT OUTER JOIN (SELECT `be`.`ScopeIDn`, MIN(IDNum) `ScopeStart`, MAX(IDNum) `ScopeEnd`, COUNT(*) `ScopeTotal`, SUM(IF(IDIsUsed = 1,1,0)) `ScopeUsed`
								FROM `bpmncore`.`bpmfoutbaseelement` `be`
							 -- WHERE (`be`.`IDNum` <> `be`.`ScopeIDn`)
							 GROUP BY `be`.`ScopeIDn`
							) `scg` ON `be`.`ScopeIDn` = `scg`.`ScopeIDn`
		WHERE (`be`.`IDNum` = `be`.`ScopeIDn`)
	UNION ALL
		SELECT 
			`be`.`IDNum` AS `IDNum`,
			`be`.`ID` AS `ID`,
			`be`.`IDName` AS `IDName`,
			`be`.`ScopeIDn` AS `ScopeIDn`,
			`scg`.`ScopeStart`,
			`scg`.`ScopeEnd`,
			`scg`.`ScopeTotal`,
			`scg`.`ScopeUsed`,
            `scg`.`ScopeTotal` - `scg`.`ScopeUsed` AS `ScopeFree`
		FROM `bpmncore`.`bpmfoutbaseelement` `be`
			LEFT OUTER JOIN (SELECT `be`.`ScopeIDn`, MIN(IDNum) `ScopeStart`, MAX(IDNum) `ScopeEnd`, COUNT(*) `ScopeTotal`, SUM(IF(IDIsUsed = 1,1,0)) `ScopeUsed`
								FROM `bpmncore`.`bpmfoutbaseelement` `be`
							 -- WHERE (`be`.`IDNum` <> `be`.`ScopeIDn`)
							 -- WHERE (`be`.`ScopeIDn` <> 3)
							 GROUP BY `be`.`ScopeIDn`
							) `scg` ON `be`.`IDNum` = `scg`.`ScopeIDn`
		-- WHERE (`be`.`IDNum` = `be`.`ScopeIDn`)
		WHERE (`be`.`ScopeIDn` = 3 AND `be`.`IDNum` <> 3)
		) AS ScopTabl
ORDER BY `IDNum`;
    
    -- SELECT * FROM `bpmncore`.`bpmfoutbaseelement`
    
    

        -- SELECT * FROM `bpmncore`.`bpmfoutbaseelement` WHERE ScopeIDn = 3 AND IDIsUsed = 1
        
-- Info con datos        
SELECT *
FROM (
		SELECT 
			`be`.`IDNum` AS `IDNum`,
			`be`.`ID` AS `ID`,
			`be`.`IDName` AS `IDName`,
			`be`.`ScopeIDn` AS `ScopeIDn`,
			`scg`.`ScopeStart`,
			`scg`.`ScopeEnd`,
			`scg`.`ScopeTotal`,
			`scg`.`ScopeUsed`,
            `scg`.`ScopeTotal` - `scg`.`ScopeUsed` AS `ScopeFree`
	/*
			`be`.`LanguageIDn` AS `FkBeIDnLanguage`,
			`be`.`IDCode` AS `IDCode`,
			`be`.`DefinitionIDn` AS `FkBeIDnDefinition`,
			`be`.`InformationTypeIDn` AS `FkBeIDnInformationType`,
			`be`.`IDIsUsed` AS `IDIsUsed`,
			`be`.`StateIDn` AS `FkBeIDnState`,
			`be`.`CreatedByIDn`,
			`be`.`LastModifiedByIDn`,
			`be`.`OwnerIDn`,
			`be`.`DateCreated` AS `DateCreated`,        
			`be`.`DateTimeStamp` AS `DateTimeStamp`,
			`be`.`TzNameIDn` AS `TzName`,
			`be`.`TzOffset` AS `TzOffset`,
			`be`.`TableHistory`
	*/
		FROM `bpmncore`.`bpmfoutbaseelementcondatos` `be`
			LEFT OUTER JOIN (SELECT `be`.`ScopeIDn`, MIN(IDNum) `ScopeStart`, MAX(IDNum) `ScopeEnd`, COUNT(*) `ScopeTotal`, SUM(IF(IDIsUsed = 1,1,0)) `ScopeUsed`
								FROM `bpmncore`.`bpmfoutbaseelementcondatos` `be`
							 -- WHERE (`be`.`IDNum` <> `be`.`ScopeIDn`)
							 GROUP BY `be`.`ScopeIDn`
							) `scg` ON `be`.`ScopeIDn` = `scg`.`ScopeIDn`
		WHERE (`be`.`IDNum` = `be`.`ScopeIDn`)
	UNION ALL
		SELECT 
			`be`.`IDNum` AS `IDNum`,
			`be`.`ID` AS `ID`,
			`be`.`IDName` AS `IDName`,
			`be`.`ScopeIDn` AS `ScopeIDn`,
			`scg`.`ScopeStart`,
			`scg`.`ScopeEnd`,
			`scg`.`ScopeTotal`,
			`scg`.`ScopeUsed`,
            `scg`.`ScopeTotal` - `scg`.`ScopeUsed` AS `ScopeFree`
		FROM `bpmncore`.`bpmfoutbaseelementcondatos` `be`
			LEFT OUTER JOIN (SELECT `be`.`ScopeIDn`, MIN(IDNum) `ScopeStart`, MAX(IDNum) `ScopeEnd`, COUNT(*) `ScopeTotal`, SUM(IF(IDIsUsed = 1,1,0)) `ScopeUsed`
								FROM `bpmncore`.`bpmfoutbaseelementcondatos` `be`
							 -- WHERE (`be`.`IDNum` <> `be`.`ScopeIDn`)
							 -- WHERE (`be`.`ScopeIDn` <> 3)
							 GROUP BY `be`.`ScopeIDn`
							) `scg` ON `be`.`IDNum` = `scg`.`ScopeIDn`
		-- WHERE (`be`.`IDNum` = `be`.`ScopeIDn`)
		WHERE (`be`.`ScopeIDn` = 3 AND `be`.`IDNum` <> 3)
		) AS ScopTabl
ORDER BY `IDNum`       
        
        