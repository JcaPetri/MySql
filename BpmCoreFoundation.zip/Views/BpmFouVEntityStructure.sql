-- BpmFouVEntityStructure
SELECT `es`.`ID`,
		`es`.`IDNum`,
		`es`.`EntityTypeIDn`,
        `be01`.`IDName` AS 'EntityType',
		`es`.`EntityIDn`,
        `be02`.`IDName` AS 'Entity',
		`es`.`FieldIDn`,
        `be03`.`IDName` AS 'ield',
		`es`.`FieldTypeIDn`,
        `be04`.`IDName` AS 'FieldTyp',
		`es`.`TsFieldOrder`,
		`es`.`AdmitDefaultValueIDn`,
		`es`.`StateIDn`,
        `be05`.`IDName` AS 'State',
		`es`.`CreatedByIDn`,
		`es`.`LastModifiedByIDn`,
		`es`.`OwnerIDn`,
		`es`.`DateCreated`,
		`es`.`DateTimeStamp`,
		`es`.`TzNameIDn`,
		`es`.`TzOffset`,
		`es`.`TableHistory`
FROM `bpmncore`.`bpmfoutentitystructure` `es`
	INNER JOIN `bpmncore`.`bpmfoutbaseelement` `be01` ON `es`.`EntityTypeIDn` = `be01`.`IDNum`
    INNER JOIN `bpmncore`.`bpmfoutbaseelement` `be02` ON `es`.`EntityIDn` = `be02`.`IDNum`
    INNER JOIN `bpmncore`.`bpmfoutbaseelement` `be03` ON `es`.`FieldIDn` = `be03`.`IDNum`
    INNER JOIN `bpmncore`.`bpmfoutbaseelement` `be04` ON `es`.`FieldTypeIDn` = `be04`.`IDNum`
    INNER JOIN `bpmncore`.`bpmfoutbaseelement` `be05` ON `es`.`StateIDn` = `be05`.`IDNum`
;
