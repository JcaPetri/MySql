-- Lista exclusivamente las Tablas y Entidades del Sistema que estan en Uso (IDIsUsed y Tengan bpmfoutentitystructure)
-- se busca los valores de la Estructure, ya que la tabla/entidad que esta en uso es la que tiene estructura definida
SELECT `be`.`ID`,
		`be`.`IDNum`,
		`be`.`IDName`,
		`be`.`ScopeIDn`,
		`be`.`LanguageIDn`,
        CASE WHEN `be`.`ScopeIDn` = 1 THEN 500 WHEN 3 THEN 502 ELSE 0 END `EntityTypeIDn`,
		`be`.`StateIDn`
FROM `bpmncore`.`bpmfoutbaseelement` `be`
	INNER JOIN (SELECT DISTINCT `ts`.`EntityIDn` 
					FROM `bpmncore`.`bpmfoutentitystructure` `ts` 
					WHERE (`ts`.`EntityTypeIDn` = 500 	  		-- Selecciona las Entity
							OR `ts`.`EntityTypeIDn` = 502) 		-- Selecciona las Tablas
							AND `ts`.`StateIDn` = 514			-- Que este habilitado
				) AS `es` ON `be`.`IDNum` = `es`.`EntityIDn`
ORDER BY `be`.`ScopeIDn`, `be`.`IDCode`;

-- Esto funciona nada mas para las Tablas, ya que las Entity pueden o no tener estructura.

/*
-- Lista las EntityTipes
	SELECT * FROM `bpmncore`.`bpmfoutbaseelement` WHERE ScopeIDn = 16;
    
    16	tSisObjectType
	500	Entity
	501	EntityField
	502	Table
	503	TableColumn
	504	tSisObjectTypeFree 6
*/

/*
	SELECT * FROM bpmncore.bpmfouventity;		-- Consulta con la Tablas/Entity utilizadas en el sistema
	SELECT * FROM usercore.bpmfoutentity;		-- Contiene las Tablas/Entity en la base de UserCore
*/


        