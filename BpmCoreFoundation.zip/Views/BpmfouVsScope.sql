-- Vista que lista los Scopes
-- `bpmncore`.`bpmfouvscope` AS
    SELECT 
        `be`.`IDNum` AS `IDNum`,
        `be`.`ID` AS `ID`,
        `be`.`IDName` AS `IDName`,
        `be`.`ScopeIDn` AS `FkBeIDnScope`,
        `be`.`LanguageIDn` AS `FkBeIDnLanguage`,
        `be`.`IDCode` AS `IDCode`,
        `be`.`DefinitionIDn` AS `FkBeIDnDefinition`,
        `be`.`InformationTypeIDn` AS `FkBeIDnInformationType`,
        `be`.`IDIsUsed` AS `IDIsUsed`,
        `be`.`StateIDn` AS `FkBeIDnState`,
		`be`.`CreatedByIDn`,
		`be`.`LastModifiedByIDn`,
        `be`.`OwnerIDn`,
		`be`.`DateCreated` AS `DateCreated`,        
		`be`.`DateTimeStamp` AS `DateTimeStamp`,
        `be`.`TzNameIDn` AS `TzName`,
        `be`.`TzOffset` AS `TzOffset`,
		`be`.`TableHistory`
    FROM
        `bpmncore`.`bpmfoutbaseelement` `be`
    WHERE
        (`be`.`IDNum` = `be`.`ScopeIDn`)
    ORDER BY `be`.`IDCode`