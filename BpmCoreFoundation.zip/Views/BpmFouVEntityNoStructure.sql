-- Lista exclusivamente las Tablas y Entidades del Sistema que NO estan en Uso (IDIsUsed y NO Tengan bpmfoutentitystructure)
SELECT `be`.`ID`,
		`be`.`IDNum`,
		`be`.`IDName`,
		`be`.`ScopeIDn`,
		`be`.`LanguageIDn`,
        CASE WHEN `be`.`ScopeIDn` = 1 THEN 500 
			  WHEN `be`.`ScopeIDn` = 2 THEN 501 
			  WHEN `be`.`ScopeIDn` = 3 THEN 502
              WHEN `be`.`ScopeIDn` = 4 THEN 503
              ELSE 0 END `EntityTypeIDn`,
		`be`.`StateIDn`
FROM `bpmncore`.`bpmfoutbaseelement` `be`
	LEFT OUTER JOIN  (SELECT DISTINCT `ts`.`EntityIDn` 
							FROM `bpmncore`.`bpmfoutentitystructure` `ts` 
							WHERE (`ts`.`EntityTypeIDn` = 500 	  		-- Selecciona las Entity
									OR `ts`.`EntityTypeIDn` = 502) 		-- Selecciona las Tablas
									AND `ts`.`StateIDn` = 514			-- Que este habilitado
						) AS `es` ON `be`.`IDNum` = `es`.`EntityIDn`
WHERE (`be`.`ScopeIDn` = 1 OR `be`.`ScopeIDn` = 2 OR `be`.`ScopeIDn` = 3 OR `be`.`ScopeIDn` = 4) 	-- Trae solo los Scope especificos
		AND (`be`.`IDNum` > 4)			-- No trae el Scope 1, 2, 3, 4, ya que no es un valor utilizable
		AND `be`.`IDIsUsed` = 1			-- Que este en Uso, no trae los IDName Free
		AND `be`.`StateIDn` = 514		-- Que este habilitado
		AND `es`.`EntityIDn` IS NULL	-- No tenga estructura en EntityStructure
ORDER BY `be`.`ScopeIDn`, `be`.`IDCode`;


/*
-- Lista las EntityTipes
	SELECT * FROM `bpmncore`.`bpmfoutbaseelement` WHERE ScopeIDn = 16;
    
    16	tSisObjectType
	500	Entity
	501	EntityField
	502	Table
	503	TableColumn
	504	tSisObjectTypeFree 6
*/

/*
	SELECT * FROM bpmncore.bpmfouventity;		-- Consulta con la Tablas/Entity utilizadas en el sistema
	SELECT * FROM usercore.bpmfoutentity;		-- Contiene las Tablas/Entity en la base de UserCore
*/
