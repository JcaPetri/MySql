USE bpmncore;
CREATE TABLE `bpmfoutfieldproperties` (
  `ID` char(38) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `IDNum` int NOT NULL AUTO_INCREMENT,
  `FieldIDn` int NOT NULL,
  `FieldPropertyIDn` int NOT NULL,
  `StateIDn` smallint NOT NULL,
  `CreatedByIDn` mediumint NOT NULL,
  `LastModifiedByIDn` mediumint NOT NULL,
  `OwnerIDn` mediumint NOT NULL,
  `DateCreated` datetime NOT NULL,
  `DateTimeStamp` timestamp NOT NULL,
  `TzNameIDn` smallint NOT NULL,
  `TzOffset` smallint NOT NULL,
  `TableHistory` text COLLATE utf8_bin,
  PRIMARY KEY (`IDNum`),
  UNIQUE KEY `IDNum_UNIQUE` (`IDNum`),
  UNIQUE KEY `ID_UNIQUE` (`ID`),
  UNIQUE KEY `FieldProperty_UNIQUE` (`FieldIDn`,`FieldPropertyIDn`) /*!80000 INVISIBLE */,
  KEY `FieldIDn_idx` (`FieldIDn`) /*!80000 INVISIBLE */,
  KEY `FieldPropertyIDn_idx` (`FieldPropertyIDn`) /*!80000 INVISIBLE */,
  CONSTRAINT `FieldIDn2` FOREIGN KEY (`FieldIDn`) REFERENCES `bpmfoutbaseelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FieldPropertyIDn` FOREIGN KEY (`FieldPropertyIDn`) REFERENCES `bpmfoutbaseelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='contiene las propiedades de los Fields (campos y tablas) del sistema.';
