use usercore;
CREATE TABLE `usertuserrole` (
	`IDru` char(38) COLLATE utf8_bin NOT NULL,
	`IDNumrU` int NOT NULL AUTO_INCREMENT,
	`FkBeIDnUser` int NOT NULL,
    `RecordID` text NOT NULL,
    `HasAllAccess` boolean NOT NULL,
	`HasDeleteAccess` boolean NOT NULL,
	`HasTransferAccess` boolean NOT NULL,
	`HasReadAccess` boolean NOT NULL,    
    `MaxAccessLevel` datetime NOT NULL,    
	`FkBeIDnState` smallint NOT NULL,
	`DateTimeStamp` timestamp NOT NULL,
	`FkBeIDnTzName` smallint NOT NULL,
	`TzOffset` smallint NOT NULL,
	`UserIDNum` mediumint NOT NULL,
	`TableHistory` text COLLATE utf8_bin NOT NULL,
	PRIMARY KEY (`IDNumrU`,`IDru`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Represents a user role in your organization.'
;


CREATE TABLE `usertuser` (
  `IDu` char(38) COLLATE utf8_bin NOT NULL,
  `IDNumU` int NOT NULL AUTO_INCREMENT,
  `EmployeeNumber` int NOT NULL,
  `EmployeeSufix` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `FirstName` varchar(100) COLLATE utf8_bin NOT NULL,
  `LastName` varchar(100) COLLATE utf8_bin NOT NULL,
  `Alias` varchar(45) COLLATE utf8_bin NOT NULL,
  `CommunityNickname` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `FkBeIDnState` smallint NOT NULL,
  `DateTimeStamp` timestamp NOT NULL,
  `FkBeIDnTzName` smallint NOT NULL,
  `TzOffset` smallint NOT NULL,
  `UserIDNum` mediumint NOT NULL,
  `TableHistory` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`IDNumU`,`IDu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Represents a user in your organization.';
