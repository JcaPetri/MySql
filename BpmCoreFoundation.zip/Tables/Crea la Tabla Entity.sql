/*
USE bpmncore;
SELECT * FROM bpmncore.bpmtfoundbtablestructure;
*/

USE bpmncore;
CREATE TABLE `bpmtfoundbentitystructure` (
  `IDEs` char(38) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `IDNumEs` int NOT NULL,
  `FkBeIDnEntity` int NOT NULL,
  `FkBeIDnField` int NOT NULL,
  `FkBeIDnFieldType` int NOT NULL,
  `TsFieldOrder` int NOT NULL,
  `FkBeIDnState` smallint NOT NULL,
  PRIMARY KEY (`IDNumEs`),
  UNIQUE KEY `TableField_UNIQUE` (`FkBeIDnEntity`,`FkBeIDnField`),
  UNIQUE KEY `IDNumEs_UNIQUE` (`IDNumEs`),
  UNIQUE KEY `IDEs_UNIQUE` (`IDEs`),
  KEY `FkBeIDnEntity_idx` (`FkBeIDnEntity`) /*!80000 INVISIBLE */,
  KEY `FkBeIDnField_idx` (`FkBeIDnField`) /*!80000 INVISIBLE */,
  CONSTRAINT `FkBeIDnField` FOREIGN KEY (`FkBeIDnField`) REFERENCES `bpmtfounbaseelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FkBeIDnEntity` FOREIGN KEY (`FkBeIDnEntity`) REFERENCES `bpmtfounbaseelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='contiene las entidades del sistema.';

