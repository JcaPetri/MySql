-- ##############################################################################################################################################################################################
-- ApplCore Explanation
-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- CREATE TABLES:
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- List the Appl Tables, from the bpmcore data base.
-- Los IDCode de la base ApplCore estan dentro del rango 1200 a 1300
SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 3 AND IDCode >= 1200 AND IDCode <= 1300;

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- CONCEPTO GENERAL:
-- 		Todos los valores se crean en las tablas:
-- 			Informacion/Registros creados por el usuario (no funcionamiento del sistema)
-- 				`ApplCore`.`ApplTDataElement`, contiene que significa cada codigo generado por el usuario en el idioma predeterminado
-- 				`ApplCore`.`appltdatadocumentation`, contiene una o más descriptiones del elemento de la tabla ApplTDataElement.
-- 	 					Opcional: `ApplCore`.`ApplTDataElementlanguage`, contiene el IDNameLanguage para otro idioma distinto al predeterminado
-- 			Estas tablas funcionan como un diccionario, pero estos codigos generados se deben insertar en las tablas correspodientes
-- 			y es aqui donde toman entidad, si solo se crean en el diccionario, es como si no existiera
-- 			para las que los fueron creados y de ahi se las vincula a las otras tablas. Si no sucede esto, la informacion queda en el diccionario
-- 			Eje: Un articulo es creado en estas dos tablas e insertado en la tabla `ApplCore`.`appllogtarticles` donde se le agregan o no mas propiedades en las columnas opcionales
-- 				 Un Deposito es creado en estas dos tablas e insertado en la tabla `ApplCore`.`appllogtwarehouses` donde se le agregan o no mas propiedades en las columnas opcionales
-- 				 Cuando relaciono Articulos con Depositos, lo hago a traves de estas dos tablas y no el diccionario
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

/*
Los IDNum son los Scope de cada registro en la tabla `bpmcore`.`bpmfoutbaseelement`
	IDNum	IDName								  ScopeIDn
	2199	ApplTDataElement						1200		
	2200	ApplTDataElementLanguage				1201
	2201	ApplTDataDocumentation					1202
	2203	ApplLogTArticlesGeneral					1203
	2204	ApplLogTArticlesGeneralProperties		1204
	2205	ApplArtTArticles						1205
	2206	ApplTTableFieldsValues					1206
	2208	ApplArtTStock							1207

*/

-- 		The order must be:
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- 						  1.- Appl Table 010 - ApplTDataElement.sql 	
-- 								IDNum	IDCode	IDName
-- 								2199	1200	ApplTDataElement
-- 								SELECT * FROM `ApplCore`.`ApplTDataElement`;
-- 									referenced by: ScopeIDnDe = `bpmcore`.`bpmfoutbaseelement`
-- 												   CompanyIDnDe = `bpmcore`.`bpmfoutbaseelement`
-- 												   LanguageIDnDe = `bpmcore`.`bpmfoutbaseelement`
-- 									referenced to: DataElementLanguageIDnDl = `ApplCore`.`bldtdataelementlanguage`
-- 												   DocumentationIDnDc = `ApplCore`.`bldtdatadocumentation`
-- 												* if you want to delete this Table, first you must delete the referenced to, in each table.
-- 								ACLARACIONES: 
									-- contiene la informacion generada por los usuario del sistema (Registros del Usuario), 
                                    -- todos los codigos que se utilizaran en las distintas tablas, excepto los comentarios que no se cargan aqui
									-- a cada codigo ingresado se le genera un ID (uniqueidentifier) y un valor unico autonumerico,
                                    -- esta es la tabla diccionario para los registros del usuario
									-- es unico para un:
									-- 					Name 		(es el codigo legible por el usuario). 
																	-- Para cambiar este valor, debe ser realizado por el administrador, Lo optimo es no cambiarlo nunca
                                                                    -- Si le cambio el codigo que representa la palabra Factura y es un comprobante afip. Y lo pongo comida, en todos los lugares que este el codigo empezara a aparecer comida.
                                                                    -- Si se desea cambiar el codigo y esta en muchos lugares el sistema debe generar otro codigo para nuevo valor
																	-- Si se puede cambiar si hay un error de ortografia eje fatura y era factura.
									-- 					Scope		(el Name debe ser unico para el ambito de aplicacion, usualmente una Tabla), vinculo con la tabla bpmcore.bpmfoutbaseelement unica para todas las bases de datos
									-- 					Company		(el Name debe ser unico para la Company), vinculo con la tabla bpmcore.bpmfoutbaseelement unica para todas las bases de datos
									-- 					Language	(el Name debe ser unico para el idioma predeterminado), vinculo con la tabla bpmcore.bpmfoutbaseelement unica para todas las bases de datos
									-- de esta manera nos aseguramos de no duplicar informacion, 
                                    -- El Name es unico para una Company, Scope (Tabla), Idioma = El CompanyScope puede ser el ID para kafka
									-- El resto de las tablas tienen un vinculo a esta tabla para identificar que tipo de elemento es.
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- 						  2.- Appl Table 012.- ApplTDataElementLanguage.sql	
-- 								IDNum	IDCode	IDName
-- 								2200	1201	ApplTDataElementLanguage
-- 								SELECT * FROM `ApplCore`.`ApplTDataElementLanguage`;
-- 									referenced by: DataElementLanguageIDnDl = `ApplCore`.`bldtdataelement`
-- 												   ScopeIDnDl = `bpmcore`.`bpmfoutbaseelement`
-- 												   CompanyIDnDl = `bpmcore`.`bpmfoutbaseelement`
-- 												   LanguageIDnDl = `bpmcore`.`bpmfoutbaseelement`
-- 									referenced to: 
-- 								ACLARACIONES: 
 									-- contiene el IDNameLanguage para otro idioma distinto al predeterminado
 									-- Aclaracion: los valores Num, Scope, Company = siempre son iguales a la tabla ApplTDataElement  (solo se cambian si se hace en la tabla principal), 
 									-- 				se ponen en esta tabla solo para asegurar la integridad y que no haya duplicados
 									-- es unico para un:
 									-- 					DataElementLanguageIDn		(es el NumIDn unico)
 									-- 					IDNameLanguage 	(es el codigo legible por el usuario). Este no se debe cambiar, ya que cambiara el significado en todos los lugares que este involucrado
																		-- Si se desea cambiar el codigo y esta en muchos lugares el sistema debe generar otro codigo para nuevo valor
                                                                        -- Si se puede cambiar si hay un error de ortografia eje fatura y era factura.
 									-- 					Scope			(el Name debe ser unico para el ambito de aplicacion, usualmente una Tabla), vinculo con la tabla bpmcore.bpmfoutbaseelement unica para todas las bases de datos
 									-- 					Company			(el Name debe ser unico para la Company), vinculo con la tabla bpmcore.bpmfoutbaseelement unica para todas las bases de datos
 									-- 					Language		(el Name debe ser unico para el idioma que se ingresa), vinculo con la tabla bpmcore.bpmfoutbaseelement unica para todas las bases de datos
 									-- Los valores Num, Scope, Company = siempre son iguales a la tabla ApplTDataElement, 
 									-- 				se ponen en esta tabla solo para asegurar la integridad y que no haya duplicados
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- 						  3.- Appl Table 014 - ApplTDataDocumentation.sql	
-- 								IDNum	IDCode	IDName
-- 								2201	1202	ApplTDataDocumentation
-- 								SELECT * FROM `ApplCore`.`ApplTDataDocumentation`;
-- 									referenced by: DocumentationIDnDc = `ApplCore`.`bldtdataelement`
-- 												   LanguageIDnDc = `bpmcore`.`bpmfoutbaseelement`
-- 									referenced to: 
-- 								ACLARACIONES: 
										-- contiene una o más descriptiones del elemento de la tabla ApplTDataElement. 
										-- La misma tiene definido un idioma, un orden cuando hay más de una descripcion y un tipo de texto
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- 						  4.- Appl Table 020 - ApplLogTArticlesGeneral.sql	
-- 								IDNum	IDCode	IDName
-- 								2203	1203	ApplLogTArticlesGeneral
-- 								SELECT * FROM `ApplCore`.`ApplLogTArticlesGeneral`;
-- 									referenced by: 
-- 		 										CONSTRAINT `ArticlesGeneralIDnGar` FOREIGN KEY (`ArticlesGeneralIDn`) REFERENCES `ApplCore`.`ApplTDataElement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE,
-- 		 										CONSTRAINT `CompanyIDnGar` FOREIGN KEY (`CompanyIDn`) REFERENCES `bpmcore`.`systcompanies` (`CompanyIDn`) ON DELETE CASCADE ON UPDATE CASCADE
-- 									referenced to: A Def
-- 												ALTER TABLE `bpmcore`.`appllogtarticlesgeneralproperties` DROP FOREIGN KEY `ArticlesGeneralIDnGpt`;
-- 												ALTER TABLE `bpmcore`.`appllogtarticles` DROP FOREIGN KEY `GeneralIDnArt`;    
-- 												* if you want to delete this Table, first you must delete the referenced to, in each table.
-- 								ACLARACIONES: 
										-- Contiene la informacion general de los articulos
										-- Las propiedades de los articulos vienen dadas:
										-- 		1.- primero por los parametros generales, 
										-- 		2.- segundo por los parametros individuales de la tabla articulos
										-- Si hay un parametro individual (tabla articulos), este sobreescribe los parametros generales
										-- Para Crear un articulo, primero debemos crear el parametro general y 
										-- luego crear el articulo y asociarle si o si un parametro general en el 
										-- campo GeneralParameterIDn de la tabla appllogtarticles
                                        -- la clave primaria, es el GeneralIDn (Tabla) + CompanyIDn
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- 						  5.- Appl Table 022 - ApplLogTArticlesGeneralProperties.sql	
-- 								IDNum	IDCode	IDName
-- 								2204	1204	ApplLogTArticlesGeneralOptionalFields
-- 								SELECT * FROM `ApplCore`.`ApplLogTArticlesGeneralOptionalFields`;
-- 									referenced by: A Def
-- 												 CONSTRAINT `ArticlesGeneralArticlesPropertyIDnGpt` FOREIGN KEY (`ArticlesGeneralPropertyIDn`) REFERENCES `bpmcore`.`systtablefields` (`TableFieldIDn`) ON DELETE CASCADE ON UPDATE CASCADE,
-- 												 CONSTRAINT `ArticlesGeneralArticlesIDnGpt` FOREIGN KEY (`ArticlesGeneralIDn`) REFERENCES `ApplCore`.`appllogtgeneral` (`ArticlesGeneralIDn`) ON DELETE CASCADE ON UPDATE CASCADE, 
-- 												 CONSTRAINT `CompanyIDnGpt` FOREIGN KEY (`CompanyIDn`) REFERENCES `bpmcore`.`systcompanies` (`CompanyIDn`) ON DELETE CASCADE ON UPDATE CASCADEE
-- 									referenced to:  A Def
-- 												No tiene referencias
-- 												* if you want to delete this Table, first you must delete the referenced to, in each table.
-- 								ACLARACIONES: 
										-- Contiene las columnas/fields/propiedades de la Tabla appllogtgeneral que son opcionales
										-- la clave primaria, es la propiedad (columna) GeneralPropertyIDn + el GeneralIDn (Tabla) + CompanyIDn
										-- los valores de la propiedad pueden ser un Valor ID o un Texto
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- 						  6.- Appl Table 030 - ApplLogTArticles.sql	
-- 								IDNum	IDCode	IDName
-- 								2205	1205	ApplArtTArticles
-- 								SELECT * FROM `ApplCore`.`ApplArtTArticles`;
-- 									referenced by: 
-- 												 CONSTRAINT `ArticleIDnArt` FOREIGN KEY (`ArticleIDn`) REFERENCES `ApplCore`.`ApplTDataElement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE,
-- 												 CONSTRAINT `ArticleGeneralIDnArt` FOREIGN KEY (`ArticleGeneralIDn`) REFERENCES `ApplCore`.`appllogtarticlesgeneral` (`ArticleGeneralIDn`) ON DELETE CASCADE ON UPDATE CASCADE,
-- 												 CONSTRAINT `CompanyIDnArt` FOREIGN KEY (`CompanyIDn`) REFERENCES `bpmcore`.`systcompanies` (`CompanyIDn`) ON DELETE CASCADE ON UPDATE CASCADE
-- 									referenced to:  
-- 												ALTER TABLE `bpmcore`.`appllogtserie` DROP FOREIGN KEY `ArticleIDnSer`;
-- 												ALTER TABLE `bpmcore`.`appllogtfoldersarticles` DROP FOREIGN KEY `ArticleIDnFla`;
-- 												* if you want to delete this Table, first you must delete the referenced to, in each table.
-- 								ACLARACIONES: 
										-- contiene la informacion de los articulos
										-- la clave primaria, es el ArticleIDn + CompanyIDn, solo puede estar el articulo una vez en la compania
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- 						  7.- Appl Table 032 - ApplLogTArticlesOptionalFields.sql	
-- 								IDNum	IDCode	IDName
-- 								2206	1206	ApplArtTArticlesOptionalFields
-- 								SELECT * FROM `ApplCore`.`ApplArtTArticlesOptionalFields`;
-- 									referenced by: 
-- 												 CONSTRAINT `ArticlePropertyIDnArp` FOREIGN KEY (`ArticlePropertyIDn`) REFERENCES `bpmcore`.`bpmfoutbaseelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE,
-- 												 CONSTRAINT `ArticleIDnArp` FOREIGN KEY (`ArticleIDn`) REFERENCES `ApplCore`.`appllogtfolders` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE,
-- 												 CONSTRAINT `CompanyIDnArp` FOREIGN KEY (`CompanyIDn`) REFERENCES `bpmcore`.`systcompanies` (`CompanyIDn`) ON DELETE CASCADE ON UPDATE CASCADE-- 									referenced to:  
-- 									referenced to:  
-- 												* if you want to delete this Table, first you must delete the referenced to, in each table.
-- 								ACLARACIONES: 
										-- Contiene las Columnas/Field opcionales de los Articulos
										-- en cada registro se especifica la Propiedad y el valor que asume para cada articulo
										-- la clave primaria, es la propiedad (columna) TableFieldIDn + el ArticleIDn (Tabla) + CompanyIDn
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@



-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- CARGA DE DATOS INICIALES:
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
/*
	=============================================================================================================================================================================================
	Primero:
			Crear la Empresa, todos los registros se asignan a una empresa
				Esta creada en la base `bpmcore`.`bpmfoutbaseelement` dentro del scope 25 tSysCompany (Diccionario), 
                pero para que pueda utilizarse se debe agregar en la tabla `bpmcore`.`systcompanies`, 
                desde aqui se vincula con las otras tablas
					SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 25;
						IDNum	IDName				ScopeIDn	  IDCode
						25		SysTCompanies			3			16
                
                SELECT * FROM `bpmcore`.`SysTCompanies`;
					IDNum	IDName				ScopeIDn	  IDCode
                    2207	System					25			 2
					2142	Peperina				25			 3
					2143	Tagle					25			 4
					2144	UniversalBuildCompany	25			 5

				View que muestra las Companias
				
				System es la compania del sistema que tiene como funcion:
					1.- Su funcion es contener todos los registros del sistema y que le dan vida al mismo (no los registros de usuario)
					1.- Todos los elementos creados son accesibles por todos

				Stored Procedures utilizados
					Los Stored Procedures del sistema estan creados en la base `bpmcore`.`bpmfoutbaseelement` dentro del scope 6 tSysTStoredProcedures para la Company System
						Sys StProc 025 - SysPCompaniesCreate.sql		-- Crea la compania
						Sys StProc 025 - SysPCompanies Calls.sql		-- Llama al Stored Procedure
						-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------------
						Bpm StProc 01 - BpmfouPBaseElementCreate.sql	-- Crea la compania en la tabla BaseElement
						Bpm StProc 01 - BpmfouPBaseElement Calls.sql	-- Llama al Stored Procedure
                    
	=============================================================================================================================================================================================
	
	=============================================================================================================================================================================================
	Etapa 1.- Paso 1:
			Crear los ApplLogTArticlesGeneral, que contiene la informacion general de las propiedades de los articulos
			Se crea en la base `ApplCore`.`ApplTDataElement` (Diccionario), dentro del scope 2203 ApplLogTArticlesGeneral y la empresa definida, 
			pero para que pueda utilizarse se debe agregar en la tabla `ApplCore`.`ApplLogTArticlesGeneral`, 
            donde se le definen las distintas propiedades y desde aqui se vincula con las otras tablas
            La clave primaria: ArticleGeneralIDn + CompanyIDn
				SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE IDNum = 2203;
					IDNum	IDName								ScopeIDn	CompanyIDn		IDCode
					2203	ApplLogTArticlesGeneral					3			2207		1203
		^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		1.2- Paso 2: (Opcional)
			Crear los ApplLogTArticlesGeneralOptionalFields, que contiene las columnas/fields/propiedades de la Tabla ApplLogTGeneral que son opcionales
				Se crea en la base `ApplCore`.`ApplTDataElement` (Diccionario), dentro del scope de cada Field/Column y la empresa definida, 
                esto es para que una misma descripcion puede estar en mas de una columna y puede representar cosas distintas, 
                Ej Autor como marca de resma y Autor como Opcion
				pero para que pueda utilizarse se debe agregar en la tabla `ApplCore`.`ApplLogTArticlesGeneralProperties`, 
				donde se le definen las distintas propiedades y desde aqui se vincula con las otras tablas
                La clave primaria: es la propiedad TableFieldIDn (Columnas) + ArticleGeneralIDn (Tabla) + CompanyIDn
					SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 2203;
					IDNum	IDName									ScopeIDn	CompanyIDn		IDCode
					2204	ApplLogTArticlesGeneralOptionalFields		3			2207		1204

	=============================================================================================================================================================================================
	Etapa 2.- Paso 1:
            Crear los ApplLogTArticles, que Contiene la informacion general de los articulos
            como ya se creo el ArticlesGeneral se le debe asignar uno a cada articulos
			Se crea en la base `ApplCore`.`ApplTDataElement` (Diccionario), dentro del scope 2205 ApplArtTArticles y la empresa definida, 
			pero para que pueda utilizarse se debe agregar en la tabla `ApplCore`.`ApplArtTArticles`, 
            donde se le definen las distintas propiedades y desde aqui se vincula con las otras tablas
            La clave primaria: ArticleIDn + CompanyIDn
-                SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 3 and IDNum >= 2199;
					IDNum	IDName								ScopeIDn	CompanyIDn		IDCode
					2205	ApplArtTArticles						3			2207		1205
			
            -- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				SELECT * FROM `ApplCore`.`ApplTDataElement` WHERE `ScopeIDn` = 2205;
                SELECT * FROM `ApplCore`.`ApplLogTArticles`;
                SELECT * FROM `Applcore`.`AppllogTArticlesSuppliersArticles`;
                SELECT * FROM `ApplCore`.`ApplImpTArticles`;
            -- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            
            Articles - Creacion individual de Articulos:
				Consulta: Appl StProc 030 - ApplLogPArticles Calls.sql
				Tablas afectadas: 	`ApplCore`.`ApplTDataElement`						// El Diccionario
									`ApplCore`.`ApplLogTArticles`						// Base General de Articulos

			Articles - Importacion Masiva de Articulos:
				Consulta: Appl StProc 030 - ApplLogPArticles ImportMasive.sql
				Tablas afectadas: 	`ApplCore`.`ApplTDataElement`						// El Diccionario
									`ApplCore`.`ApplLogTArticles`						// Base General de Articulos

            Articles - Importacion Masiva de Articulos Asociados a un Proveedor:
				Appl StProc 030 - ApplLogPArticles ImportMasive SupplierAsociation.sql
                Tabla Origen: `ApplCore`.`ApplImpTArticles`
				Tablas afectadas: 	`ApplCore`.`ApplTDataElement`						// El Diccionario
									`ApplCore`.`ApplLogTArticles`						// Base General de Articulos
									`Applcore`.`AppllogTArticlesSuppliersArticles`		// Relacion entre los Articulos y sus Proveedores
					-- Aclaracion: puede dar error la ultima consulta si es que en la tabla del proveedor no esta el articulo
            
		^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		1.2- Paso 2: (Opcional)
			Crear los ApplLogTArticlesOptionalFields, que contiene las columnas/fields/propiedades de la Tabla ApplLogTArticles que son opcionales
				Las columnas se crean en la tabla `bpmcore`.`BpmfouTBaseElement` ya que son estructura del sistema, cada columna es una propiedad del articulo
                estas se crean en el Scope 4 y para la empresa 2207 System
					Para ello hay que ejcutar el StoredProcedure:
						Sys StProc 004 - SysPTableFields Calls.sql que llama al Sys StProc 004 - SysPTableFieldsCreate.sql

				Los datos de las empresas se crea en la base `ApplCore`.`ApplTDataElement` (Diccionario), 
                dentro del scope de cada Field/Column y la empresa definida, esto es para que una misma descripcion 
                puede estar en mas de una columna y puede representar cosas distintas, 
                Ej Autor como marca de resma y Autor como Opcion
				pero para que pueda utilizarse se debe agregar en la tabla `ApplCore`.`ApplArtTArticlesOptionalFields`, 
				donde se le definen las distintas propiedades y desde aqui se vincula con las otras tablas
                La clave primaria: es la propiedad ArticlePropertyIDn (columna) + el ArticleIDn (Tabla) + CompanyIDn
					SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 3 and IDNum >= 2199;
						IDNum	IDName								ScopeIDn	CompanyIDn		IDCode
						2206	ApplArtTArticlesOptionalFields			3			2207		1206
                -- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                IMPORTANTE:
					En esta tabla se cargan los IDn que vinculan la TableFieldIDn, el ArticleIDn, y la CompanyIDn 
                    al que se le define el FieldValueIDn, FieldNumValue, FieldTextValue
                    Como los FieldValueIDn es un elemento IDn, se debe crear primero en la tabla DataElement
						primero ejecutar el 1.2.1- Creacion del Valor FieldValueIDn y luego agregar los OptionalFields
                -- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                
			-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			ACLARACION:
				Las propiedades de los articulos vienen dadas:
						1.- primero por los parametros generales, 
						2.- segundo por los parametros individuales de la tabla articulos
				 Si hay un parametro individual (tabla articulos), este sobreescribe los parametros generales
				 Para Crear un articulo, primero debemos crear el parametro general y 
				 luego crear el articulo y asociarle si o si un parametro general en el 
				 campo GeneralParameterIDn de la tabla appllogtarticles
				 la clave primaria, es el GeneralIDn (Tabla) + CompanyIDn

            -- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				SELECT * FROM `ApplCore`.`ApplLogTArticlesOptionalFields`;
                SELECT * FROM `ApplCore`.`ApplImpTArticlesOpcVal`;
            -- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

            Articles Optional Field - Creacion individual de Articulos:
				Consulta: Appl StProc 032 - ApplLogPArticlesOptionalFields Calls.sql
				Tablas afectadas: 	`ApplCore`.`ApplLogTArticlesOptionalFields`			// Base General de Articulos

			Articles Optional Field - Importacion Masiva de Articulos:
				Consulta: Appl StProc 032 - ApplLogPArticlesOptionalFields InsertDatosMasivos.sql
                Tabla Origen: `ApplCore`.`ApplImpTArticlesOpcVal`
				Tablas afectadas: 	`ApplCore`.`ApplTDataElement`						// El Diccionario
									`ApplCore`.`ApplLogTArticles`						// Base General de Articulos

				^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
				^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
				1.2.1- Creacion del Field Opcionales
				/*-- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
					Los Fields o Columnas opcionales se crean en la base BpmCore y en la tabla BpmfouPBaseElement
                    ya que son parte estructural del sistema. Primero se crean en el Diccionario y luego en la tabla que le
                    da entidas, ya que se asigna el campo a la empresa.
					El ScopeIDn es 4 SysTTableFields. 

					-- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
						SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE `ScopeIDn` = 4;
                        SELECT * FROM `bpmcore`.`systtablefields` order by TableFieldIDn desc;
                    -- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

				Table Fields - Creacion de TableFields:
						Consulta: Sys StProc 004 - SysPTableFields Calls.sql
                        Tablas afectadas: 	`bpmcore`.`BpmfouTBaseElement`				// Diccionario Base del Sistema
											`bpmcore`.`systtablefields`					// Base con las columnas para cada empresa
				=============================================================================================================================================================================================
				*/
                
				-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
				-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
				-- 1.2.1- Creacion del Valor FieldValueIDn 
				/* -- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
					-- Los valores que forman la lista de opciones de cada Field/Columna, se cargan en el ScopeIDn del Field/Columna indicada
					-- esto es ya que la clave primaria es TableFieldValueIDn + TableFieldIDn + CompanyIDn
					-- Por lo tanto, si se cargara en la tabla ApplTTableFieldsValues ScopeIDn 2206, una determina descripcion, no podria cargarse dentro de varias columnas
					-- ya que infringiria la clave de duplicidad. Ej, la palabra Autor, puede ser una marca o puede ser una opcion para otra columna y representan cosas distintas en cada una
					-- IMPORTANTE: Conclusion, los valores opcionales de cada columna se cargan en el ScopeIDn de la columna a donde pertenece el valor

                    -- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
						SELECT * FROM `ApplCore`.`ApplTTableFieldsValues`;
                        SELECT * FROM `ApplCore`.`ApplImpTTableFieldsValues`;
					-- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

					Table Fields Values - Creacion individual de los valores que puede tener Field:
						Consulta: Appl StProc 016 - ApplLogPTableFieldsValues Calls.sql
							Ejecuta: 2231 ApplLogPTableFieldsValuesCreate
						Tablas afectadas: 	`ApplCore`.`ApplTDataElement`				// El Diccionario
											`ApplCore`.`ApplTTableFieldsValues`			// Base con los valores posibles que puede tener un Field/Columna
                                                                                        
					Table Fields Values - Importacion Masiva de Articulos:
						Consulta: Appl StProc 016 - ApplLogPTableFieldsValues ImportMasive.sql
                        Tabla Origen: `ApplCore`.`ApplImpTTableFieldsValues`
						Tablas afectadas: 	`ApplCore`.`ApplTDataElement`				// El Diccionario
											`ApplCore`.`ApplLogTArticles`				// Base con los valores posibles que puede tener un Field/Columna
				=============================================================================================================================================================================================
				*/

-- 	=============================================================================================================================================================================================
-- 	Etapa 3.- Paso 1:
/*
            Crear los ApplArtTStock, que Contiene la informacion del stock de cada articulos
            como no todos los articulos llevan stock (eje servicios, bienes de uso, etc), se debe cargar la informacion en una tabla aparte
			La clave primaria: ArticleIDn + CompanyIDn (valores ya creado en sus tablas respectivas)
                SELECT * FROM `ApplCore`.`ApplLogTStock`;
					IDNum	IDName								ScopeIDn	CompanyIDn		IDCode
					2208	ApplLogTStock							3			2207		1207

	=============================================================================================================================================================================================
	Etapa 4.-:
		Paso 4.1: Importacion desde un Supplier
            Crear los ApplSaleTPriceList, contiene la informacion de las listas de precios de la Company
            una compania puede tener varias listas de precios, Ej: minorista, mayorista, cliente VIP, etc.
			La lista de precios se crea en la base `ApplCore`.`ApplTDataElement` (Diccionario), 
			dentro del scope 2246 para la empresa definida,	pero para que pueda utilizarse se debe 
            agregar en la tabla `ApplCore`.`ApplSaleTPriceList`, donde se le definen las distintas propiedades 
            y desde aqui se vincula con las otras tablas
            La clave primaria: PriceListIDn + CompanyIDn
-                SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 3 and IDNum >= 2199;
					IDNum	IDName								ScopeIDn	CompanyIDn		IDCode
					2246	ApplSaleTPriceList						3			2207		1262
                    2247	ApplSaleTPriceListArticles				3			2207		1263

			-- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				SELECT * FROM `ApplCore`.`ApplTDataElement` WHERE `ScopeIDn` = 2246;
                SELECT * FROM `ApplCore`.`ApplSaleTPriceList`;
			-- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

			Sale Price List - Creacion individual una Lista de Precios:
				Consulta: Appl StProc 080 - ApplSupPSalePriceList Calls.sql
					Ejecuta:  ApplSupPSuppliersPriceListCreate
				Tablas afectadas: 	`ApplCore`.`ApplTDataElement`				// El Diccionario
									`ApplCore`.`ApplSaleTPriceList`				// Lista de Precios con sus propiedades
	-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------																			
	Etapa 4.- 
		Paso 2.1: Importacion desde un Supplier
            Crear los ApplSaleTPriceListArticles, contiene la informacion de los precios de los articulos
            para una lista de precios y compania especifica. 
            Esto quiere decir que un articulo puede estar en multiples listas de precios
			La clave primaria: ArticleIDn + PriceListIDn + CompanyIDn (valores ya creado en sus tablas respectivas)

			-- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                SELECT * FROM `ApplCore`.`ApplSaleTPriceListArticles`;
			-- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

			Sale Price List Articles - Importacion Masiva de Articulos en base a un Proveedor
				Para realizar esto se deben definir los siguientes parametro:
					0.- CompanyIDn - codigo IDn de la empresa dueña de la Lista de Precios
                    1.- PriceListIDn - codigo IDn de la lista de precios a actualizar
                    2.- SupplierIDn - codigo IDn del Supplier
                    2.- SupplierPriceListIDn - codigo IDn de la lista de precios del Supplier
				Consulta: Appl StProc 082 - ApplSupPSalePriceListArticlesInsertFromSupplier.sql
					Ejecuta:  
                        Tabla Origen: `ApplCore`.`ApplLogTArticles`
									  `ApplCore`.`ApplSaleTPriceListArticles`
									  `ApplCore`.`ApplLogTArticlesSuppliersArticles`
									  `ApplCore`.`ApplSupTSuppliersPriceListArticles`
						Tablas afectadas: 	`ApplCore`.`ApplSaleTPriceListArticles`				// Base con los articulos, su lista de precios 

		Paso 2.2: Inserta Articulos Sin Supplier
			Como los articulos no tiene un Supplier, se agregan todos los que 
				Si estan en la Tabla ApplLogTArticles y NO estan en la tabla ApplSaleTPriceListArticles
			Como no hay precio de referencia, el precio es $1, luego por listado se deberia actualizar el precio

			Sale Price List Articles - Importacion Masiva de Articulos SIN Supplier
				Para realizar esto se deben definir los siguientes parametro:
				Consulta: Appl StProc 082 - ApplSupPSalePriceListArticlesInsertWithoutSupplier.sql
					Ejecuta:  
                        Tabla Origen: `ApplCore`.`ApplLogTArticles`
						Tablas afectadas: 	`ApplCore`.`ApplSaleTPriceListArticles`				// Base con los articulos, su lista de precios 

	=============================================================================================================================================================================================
	Etapa 5:
            Actualizacion de la Lista de Precios de los Supplier/Proveedores
			lo que implica actualizar la su lista de precios y el historico que solo se actualiza el precio nuevo vario respecto del actual
            Se debe ejecutar la consulta segun sea:
				Automatica: Appl StProc 076 - ApplImpPSuppliersPriceListArticlesImport Calls.sql
                Manual: Appl StProc 076 - ApplImpPSuppliersPriceListArticlesImport Ejecucion Manual.sql
            
            Pasos para su realizacion:
				1.- Realizar el archivo en Excel para su importacion, debe tener el formato segun la tabla siguiente
					SELECT * FROM `applcore`.`applimptsupplierspricelistarticles`;
				2.- Importar el archivo en Excel en la tabla `ApplCore`.`ApplImpTSuppliersPriceListArticles` 
                3.- Ejecutar la depuracion de los datos llamando al Stored Procedure CALL `ApplCore`.`ApplImpPSuppliersPriceListArticlesDebug`
                4.- Desactiva los articulos que no estan mas en la base importada, estan en la tabla applsup y no en la tabla applimp
				5.- Actualiza articulos que ya estan incorporado, ya que estan en las dos tablas
					5.1- Inserta en la tabla los Articulos que tuvieron cambio de precios, ya que estan en las dos tablas
                    5.1- Actualiza articulos que ya estan incorporado, ya que estan en las dos tablas
				6.- Inserta articulos nuevos, estan en la tabla applimp y no en la tabla applsup
					6.1- Inserta articulos nuevos, estan en la tabla applsuptsupplierspricelisthistory
                    6.2- Inserta articulos nuevos, estan en la tabla applimp y no en la tabla applsup

			-- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                SELECT * FROM `ApplCore`.`ApplSupTSuppliersPriceListArticles`;
                SELECT * FROM `ApplCore`.`ApplSupTSuppliersPriceListHistory`;
			-- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

			Supplier Price List Articles - Importacion Masiva de Articulos del Supplier
					Ejecuta:  
                        Tabla Origen: `ApplCore`.`ApplImpTSuppliersPriceListArticles`
						Tablas afectadas: 	`ApplCore`.`ApplSupTSuppliersPriceListArticles`				// Base con los articulos, su lista de precios 
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

	=============================================================================================================================================================================================
	Etapa 6:
		Paso 2.1: Actualizacion desde un Supplier
            Actualizacion de la Lista de Precios segun los precios de los Supplier/Proveedores
			-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
            PENDIENTE: Esta actualizacion se hace en funcion a ciertos parametros que se debe definir
			-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
			-- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                SELECT * FROM `ApplCore`.`ApplSaleTPriceListArticles`;
                SELECT * FROM `ApplCore`.`ApplImpTSuppliersPriceListArticles`;
			-- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

			Sale Price List Articles - Actualizacion Masiva de la Lista de Precios
				Consulta: Appl StProc 082 - ApplSupPSalePriceListArticlesUpdateFromSupplier.sql
					Ejecuta:  
                        Tabla Origen: `ApplCore`.`ApplImpTSuppliersPriceListArticles`
						Tablas afectadas: 	`ApplCore`.`ApplSaleTPriceListArticles`				// Base con los articulos, su lista de precios 

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

		Paso 2.2: Actualizacion desde un Excel
			-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
            REVISARLO - HACERLO
            -- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
            Actualizacion de la Lista de Precios segun parametros no asociados a un proveedor
			-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
            PENDIENTE: Esta actualizacion se hace en funcion a ciertos parametros que se debe definir
			-- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5

			-- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                SELECT * FROM `ApplCore`.`ApplSaleTPriceListArticles`;
			-- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

			Sale Price List Articles - Actualizacion Masiva de la Lista de Precios
				Consulta: Appl StProc 082 - ApplSupPSalePriceListArticlesUpdateWithoutSupplier.sql
					Ejecuta:  
                        Tabla Origen: A Definir
						Tablas afectadas: 	`ApplCore`.`ApplSaleTPriceListArticles`				// Base con los articulos, su lista de precios 

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^



			
*/

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@




-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- RESUMEN DE CONCEPTOS:
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- BUSCADOR - ARTICLES - SUPPLIER - PRICES
/* Pasos:
		1.- Crear los Articulos
				Appl StProc 030 - ApplLogPArticles ImportMasive.sql
				Appl StProc 030 - ApplLogPArticles ImportMasive SupplierAsociation.sql		-- Se crea el articulo y se lo asocia a un Proveedor/Supplier
					IMPORTANTE: Antes de ejecutar el procedimiento, deben crear los Supplier / 
								sus Prices List / Agregar los Articulos de su lista de precios
                                
		2.- Crear los Articulos Optional Fields
				Appl StProc 016 - ApplLogPTableFieldsValues ImportMasive.sql
				Appl StProc 032 - ApplLogPArticlesOptionalFields InsertDatosMasivos.sql

		3.- Crea los Articulos en la Lista de Precios
				Los crea desde un Supplier/Proveedor
					Appl StProc 082 - ApplSupPSalePriceListArticlesInsertFromSupplier.sql
				Los crea sin un Supplier/Proveedor
					Appl StProc 082 - ApplSupPSalePriceListArticlesInsertWithoutSupplier.sql
			
	Aclaracion: Para que la consulta de los articulos con sus precios se pueda actualizar
			Todo esto es porque:
				el articulo debe estar creado y asociado al proveedor 
                el mismo debe estar tipificado, (antes debo crear en el diccionario y en los tablafield values)
                debo cargar los precios de cada articulo

-- Consultas de control
	SELECT * FROM applcore.appllogvarticles WHERE LOWER(Article) LIKE '%espiral%' ;
	SELECT * FROM applcore.appllogvarticlesoptionalfields WHERE LOWER(Article) LIKE '%pizzi%' ORDER BY ArticleIDn;

*/

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Actualizacion de Precios
/* Pasos:
		4.- Actualiza la Lista de Precios de los Suppliers
				Automatica: Appl StProc 076 - ApplImpPSuppliersPriceListArticlesImport Calls.sql
                Manual: Appl StProc 076 - ApplImpPSuppliersPriceListArticlesImport Ejecucion Manual.sql
                
		5.- Actualiza la Lista de Precios desde la Lista de Precios de los Suppliers
				Appl StProc 084 - ApplSupPSalePriceListArticlesUpdateFromSupplier.sql
					Ver los resultados SELECT * FROM applcore.applsalevpricelist;
                Appl StProc 084 - ApplSupPSalePriceListArticlesUpdateWithoutSupplier.sql

*/

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- CREACION DE SUPPLIER - SUPPLIER PRICE LIST - SUPPLIER ARTICLES
/* Pasos:
			1.- Crear Supplier/Proveedor en la tabla Persons
				Tabla Afectada: `ApplCore`.`ApplTPersons`
				Query: Appl StProc 018 - ApplPPersons Calls.sql
                SELECT PersonIDn, TradeName FROM applcore.appltpersons WHERE CompanyIDn = 2142 ORDER BY PersonIDn;
					PersonIDn	TradeName
					49			Estela Montenegro s.a.
					868			Mar-Plast s.a.
					869			Popeye LMG s.r.l.
					870			El Auditor s.a.
					871			Papelera Cumbre s.a.
					1754		Wow
					1755		Tienda Foko
					1756		Matemundo

			2.- Crear la Lista de Precios para ese proveedor
				Tabla Afectada: `ApplCore`.`ApplSupTSuppliersPriceList`				
                Query: Appl StProc 070 - ApplSupPSuppliersPriceList Calls.sql
                SELECT SupplierPriceListIDn, SupplierIDn FROM applcore.applsuptsupplierspricelist;
                    SupplierPriceListIDn	SupplierIDn
						51						49			LP Montenegro
						52						869			LP Popeye
						872						868			LP MarPlast
						1788					1754		LP	Wow
						1789					1755		LP Tienda Foko
						1792					1756		LP Matemundo

			3.- Insertar / Actualizar los Articulos asociados a la Lista de Precios del Supplier
				Tabla afectada: `ApplCore`.`ApplSupTSuppliersPriceListArticles`
                Query: 
				Proceso a Ejecutar:
					Automatica: Appl StProc 076 - ApplImpPSuppliersPriceListArticlesImport Calls.sql
					Manual: Appl StProc 076 - ApplImpPSuppliersPriceListArticlesImport Ejecucion Manual.sql
	
*/
-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- CREATE STORED PROCEDURES:
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 6; --  AND IDCode >= 1200 AND IDCode <= 1300;
