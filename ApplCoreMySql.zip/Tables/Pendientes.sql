SELECT * FROM applcore.applsuptsupplierspricelist;


/*
Debo registrar los movimiento realizados de importacion y la lista de precios
donde se destaque 
	Fecha de importacion
    
    Fecha de lista de precios
    CodigoListaPrecios
	Tiempos de importacion
    
    Puede haber otra tabla donde se dejen registrados el detalle de los errores de importacion

*/