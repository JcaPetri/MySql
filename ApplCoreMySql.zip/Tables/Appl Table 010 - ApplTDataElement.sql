-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplTDataElement
-- contiene la informacion generada por los usuario del sistema, todos los codigos que se utilizaran en las distintas tablas, 
-- EXCEPTO los comentarios que no se cargan aqui
-- a cada codigo ingresado se le genera un ID (uniqueidentifier) y un valor unico autonumerico.
-- es unico para un:
-- 					Name 		(es el codigo legible por el usuario)
-- 					Scope		(el Name debe ser unico para el ambito de aplicacion, usualmente una Tabla), vinculo con la tabla bpmcore.bpmfoutbaseelement unica para todas las bases de datos
-- 					BusinessUnit	(el Name debe ser unico para la BusinessUnit), vinculo con la tabla bpmcore.bpmfoutbaseelement unica para todas las bases de datos
-- 					Language		(el Name debe ser unico para el idioma predeterminado), vinculo con la tabla bpmcore.bpmfoutbaseelement unica para todas las bases de datos
-- de esta manera nos aseguramos de no duplicar informacion, Resumen el Name es unico para una BusinessUnit, Scope (Tabla), Idioma
-- El resto de las tablas tienen un vinculo a esta tabla para identificar que tipo de elemento es.

-- Delete the table ApplTDataElement if Exits, but First Altere the tables that have a referenced foreign key
USE applcore;
-- First you must to delete the Foreing Key Constraint;
-- The referenced ApplTDataElement Tables:
	ALTER TABLE `applcore`.`appltdataelementlanguage`  DROP FOREIGN KEY `DataElementLanguageIDnDl`;
	ALTER TABLE `applcore`.`appltdatadocumentation`  DROP FOREIGN KEY `DocumentationIDnDc`;
	ALTER TABLE `applcore`.`appllogtarticlesgeneral`  DROP FOREIGN KEY `ArticleGeneralIDnGar`;

	ALTER TABLE `applcore`.`applarttarticles`  DROP FOREIGN KEY `ArticlesIDnArt`;
	ALTER TABLE `applcore`.`applmkttcampaign`  DROP FOREIGN KEY `CampaignIDnCmp`;
	ALTER TABLE `applcore`.`appllogtrelations`  DROP FOREIGN KEY `RelationIDnRel`;



-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `applcore`.`appltdataelement`;

CREATE TABLE `applcore`.`appltdataelement` (
		`ID` char(38) COLLATE utf8mb4_bin NOT NULL,		-- Es el uniqueIdentifier
		`IDNum` int NOT NULL AUTO_INCREMENT,		-- Es el valor autonumerico
		`IDName` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,		-- Es el codigo legible por el usuario para el idioma
        		`IDNameStructureIDn` int NOT NULL,			-- Es el IDNum de la estructura del IDName, si es multivaluado, aqui referecia a la estructura
		`ScopeIDn` int NOT NULL,				-- Es el IdNum del Scope, el Name debe ser unico para el ambito de aplicacion, usualmente una Tabla
		`BusinessUnitIDn` int NOT NULL,			-- Es el IdNum de la BusinessUnit al que esta asignado el IDName
		`LanguageIDn` int NOT NULL,			-- Es el IdNum del idioma en que esta definido el Name
		`IDCode` int NOT NULL,				-- Es el codigo unico del registro, este codigo es para un ambito de aplicacion
		`DefinitionIDn` smallint NOT NULL,			-- Es el IdNum del tipo de definicion del elemento
		`InformationTypeIDn` smallint NOT NULL,		-- Es el IdNum del tipo de informacion que representa el registro
		`IDIsUsed` tinyint NOT NULL,			-- Determina si el registro es usado o  no
		`StateIDn` smallint NOT NULL,			-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,		-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,		-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,			-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,			-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 		-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 			-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 			-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		PRIMARY KEY (`IDNum`),
		UNIQUE KEY `ID_UNIQUE` (`ID`) /*!80000 INVISIBLE */,
		UNIQUE KEY `IDNum_UNIQUE` (`IDNum`),
		UNIQUE KEY `IDNameScopeCompLang_UNIQUE` (`IDName`,`ScopeIDn`,`BusinessUnitIDn`,`LanguageIDn`),
		UNIQUE KEY `IDScopeIDCode_UNIQUE` (`BusinessUnitIDn`,`ScopeIDn`,`IDCode`),
		KEY `ID_idx` (`ID`) /*!80000 INVISIBLE */,
        		KEY `IDNum_idx` (`IDNum`) /*!80000 INVISIBLE */,
		KEY `IDCode_idx` (`IDCode`),
		KEY `BusinessUnitIDn_idx` (`BusinessUnitIDn`),
		KEY `IDIsUsed_idx` (`IDIsUsed`),
		CONSTRAINT `ScopeIDnDe` FOREIGN KEY (`ScopeIDn`) REFERENCES `bpmcore`.`bpmfoutbaseelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE,
		CONSTRAINT `BusinessUnitIDnDe` FOREIGN KEY (`BusinessUnitIDn`) REFERENCES `bpmcore`.`systcompanies` (`BusinessUnitIDn`) ON DELETE CASCADE ON UPDATE CASCADE,
		CONSTRAINT `LanguageIDnDe` FOREIGN KEY (`LanguageIDn`) REFERENCES `bpmcore`.`systlanguages` (`LanguageIDn`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
		AUTO_INCREMENT=0 
		DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin 
		COMMENT='
Es el diccionario del modulo Articulos. Este diccionario tiene definido un idioma por defecto.
De esta manera mantenemos la integridad y no duplicidad de infomacion.
Cada codigo ingresado se le genera un ID (uniqueidentifier) y un IDNum valor unico autonumerico.
El resto de las tablas solo tienen el IDNum. Para determinar que significa un codigo, se debe consultar en esta tabla.
Con el objetivo de que una misma palabra IDName pueda tener distintos significados segun su uso es que se define para un Scope.
Para respetar todas las reglas el valor unico debe ser la combinacion de: Name/Scope/BusinessUnit/Language
es unico para un:
  Name     -> (es el codigo legible por el usuario) 
  Scope     -> (el Name debe ser unico para el ambito de aplicacion, usualmente una Tabla), vinculo con la tabla bpmfoutbaseelement unica para todas las bases de datos
  BusinessUnit -> (la BusinessUnit), vinculo con la tabla bpmcore.bpmfoutbaseelement unica para todas las bases de datos
  Language -> (el idioma predeterminado), vinculo con la tabla bpmfoutbaseelement unica para todas las bases de datos
Importante: el objeto exite cuando es creado en la tabla respectiva, que este creado en el diccionario no afecta al sistema.
Ej: se crea el articulo resma en el diccionario, pero no existe hasta que el mismo no es creado en la tabla Articles.

';

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - appltdataelement
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appltdataelement_BEFORE_INSERT`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appltdataelement_BEFORE_INSERT` BEFORE INSERT ON `appltdataelement` FOR EACH ROW BEGIN
	IF new.ID IS NULL OR new.ID = '' THEN
		SET new.ID = uuid();
	END IF;
    IF new.IDCode IS NULL OR new.IDCode = 0 OR new.IDCode = '' THEN
		SET new.IDCode = (SELECT ifnull(MAX(IDCode),0) + 1 FROM `applcore`.`appltdataelement` WHERE ScopeIDn = new.ScopeIDn);
	END IF;
    SET new.DateCreated = ifnull(new.DateCreated,current_timestamp);
    SET new.DateTimeStamp = ifnull(new.DateTimeStamp,current_timestamp);
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - appltdataelement
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appltdataelement_BEFORE_UPDATE`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appltdataelement_BEFORE_UPDATE` BEFORE UPDATE ON `appltdataelement` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = ifnull(new.DateTimeStamp,current_timestamp);
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(old.IDNum,"†",
					IF(new.IDName = old.IDName,"",new.IDName),"†",
                    IF(new.IDNameStructureIDn = old.IDNameStructureIDn,"",new.IDNameStructureIDn),"†",
					IF(new.ScopeIDn = old.ScopeIDn,"",new.ScopeIDn),"†",
					IF(new.BusinessUnitIDn = old.BusinessUnitIDn,"",new.BusinessUnitIDn),"†",
					IF(new.LanguageIDn = old.LanguageIDn,"",new.LanguageIDn),"†",
                    IF(new.IDCode = old.IDCode,"",new.IDCode),"†",
                    IF(new.DefinitionIDn = old.DefinitionIDn,"",new.DefinitionIDn),"†",
                    IF(new.InformationTypeIDn = old.InformationTypeIDn,"",new.InformationTypeIDn),"†",
                    IF(new.IDIsUsed = old.IDIsUsed,"",new.IDIsUsed),"†",
                    IF(new.StateIDn = old.StateIDn,"",new.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",new.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",new.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",new.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",new.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",new.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",new.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `applcore`.`appltdataelement`;

