-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplLogTArticles table
-- contiene la informacion de los articulos
-- la clave primaria: es el ArticleIDn + CompanyIDn, solo puede estar el articulo una vez en la compania
USE ApplCore;

-- #########################################################################################################################################################################################
-- 1.- First you must to delete the Foreing Key Constraint childs;
-- The referenced ApplSaleTPriceList Tables:
	ALTER TABLE `ApplCore`.`ApplSaleTPriceListArticles` DROP FOREIGN KEY `ArticleIDnPla`;
    	ALTER TABLE `ApplCore`.`ApplSaleTPriceListArticlesHistory` DROP FOREIGN KEY `ArticleIDnPlaH`;
/*	ALTER TABLE `bpmcore`.`appllogtstock` DROP FOREIGN KEY `ArticleIDnStk`;
	ALTER TABLE `bpmcore`.`appllogtserie` DROP FOREIGN KEY `ArticleIDnSer`;
	ALTER TABLE `bpmcore`.`appllogtfoldersarticles` DROP FOREIGN KEY `ArticleIDnFla`;
*/

-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `ApplCore`.`ApplLogTArticles`;

-- #########################################################################################################################################################################################
-- 2.- Seconde you create the Table
CREATE TABLE `ApplCore`.`ApplLogTArticles` (
	`ArticleIDn` int NOT NULL,			-- Es el IdNum del Articulo en el DataElement
        	`CompanyIDn` int NOT NULL,		-- Es el IdNum de la Company al que esta asignado el IDName
		-- la clave primaria, es el ArticleIDn + CompanyIDn, solo puede estar el articulo una vez en la compania
        	`ArticleGeneralIDn` int NOT NULL,						-- Es el IdNum de los parametros generales del articulo, Si se modifica los parametros generales, hay que tener en cuenta que modifica todos los articulos asociados. Por lo tanto, para hacer un cambio, de un grupo nuevo, se deberia crear un parametro general nuevo y asociarles los articulos que se desean.
        	`BarCode` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,		-- Es el codigo de barra
        	`StockEnable` tinyint NOT NULL,					-- True = 1 / False = 0, Habilita si se lleva stock del artículo
	`StateIDn` smallint NOT NULL,					-- Es el estado del registro
	`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
	`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
	`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
	`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
	`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
	`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
	`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
	`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
	 PRIMARY KEY (`ArticleIDn`,`CompanyIDn`),
		 UNIQUE KEY `ArticleCompanyIDn_UNIQUE` (`ArticleIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
		 UNIQUE KEY `BarCodeCompanyIDn_UNIQUE` (`BarCode`,`CompanyIDn`),
		 KEY `ArticleCompanyIDn_idx` (`ArticleIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
         KEY `CompanyIDn_idx` (`CompanyIDn`) /*!80000 INVISIBLE */,
		 CONSTRAINT `ArticleIDnArt` FOREIGN KEY (`ArticleIDn`) REFERENCES `ApplCore`.`appltdataelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `ArticleGeneralIDnArt` FOREIGN KEY (`ArticleGeneralIDn`) REFERENCES `ApplCore`.`ApplLogTArticlesgeneral` (`ArticleGeneralIDn`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `CompanyIDnArt` FOREIGN KEY (`CompanyIDn`) REFERENCES `bpmcore`.`systcompanies` (`CompanyIDn`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
		DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='contiene la informacion de los articulos y sus propiedades
				';

-- #########################################################################################################################################################################################
-- 3.- Then you must to Re-Create the Foreing Key Constraint, because in the step 1 you delete;
-- The referenced ApplSaleTPriceListArticles Tables:
	ALTER TABLE `ApplCore`.`ApplSaleTPriceListArticles` ADD CONSTRAINT `ArticleIDnPla` FOREIGN KEY (`ArticleIDn`) REFERENCES `ApplCore`.`ApplLogTArticles` (`ArticleIDn`) ON DELETE CASCADE ON UPDATE CASCADE;
	ALTER TABLE `ApplCore`.`ApplSaleTPriceListArticlesHistory` ADD CONSTRAINT `ArticleIDnPlaH` FOREIGN KEY (`ArticleIDn`) REFERENCES `ApplCore`.`ApplLogTArticles` (`ArticleIDn`) ON DELETE CASCADE ON UPDATE CASCADE;


-- #########################################################################################################################################################################################
-- 4.- Create the Trigger Before Insert - ApplLogTArticles
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE ApplCore;
DROP TRIGGER IF EXISTS `ApplCore`.`ApplLogTArticles_BEFORE_INSERT`;
DELIMITER $$
USE `ApplCore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `ApplLogTArticles_BEFORE_INSERT` BEFORE INSERT ON `ApplLogTArticles` FOR EACH ROW BEGIN
    SET new.DateCreated = ifnull(new.DateCreated,current_timestamp);
    SET new.DateTimeStamp = ifnull(new.DateTimeStamp,current_timestamp);
END$$
DELIMITER ;

-- #########################################################################################################################################################################################
-- 5.- Create the Trigger Before Update - ApplLogTArticles
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE ApplCore;
DROP TRIGGER IF EXISTS `ApplCore`.`ApplLogTArticles_BEFORE_UPDATE`;
DELIMITER $$
USE `ApplCore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `ApplLogTArticles_BEFORE_UPDATE` BEFORE UPDATE ON `ApplLogTArticles` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = ifnull(new.DateTimeStamp,current_timestamp);
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(
					IF(new.ArticleIDn = old.ArticleIDn,"",old.ArticleIDn),"†",
                    IF(new.CompanyIDn = old.CompanyIDn,"",old.CompanyIDn),"†",
                    -- la clave primaria, es el ArticleIDn + CompanyIDn, solo puede estar el articulo una vez en la compania
                    IF(new.ArticleGeneralIDn = old.ArticleGeneralIDn,"",old.ArticleGeneralIDn),"†",
					IF(new.BarCode = old.BarCode,"",old.BarCode),"†",
					IF(new.StockEnable = old.StockEnable,"",old.StockEnable),"†",
                    IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `ApplCore`.`ApplLogTArticles`;