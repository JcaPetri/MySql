-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the appltdatadocumentation table
-- contiene una o más descriptiones del elemento de la tabla appltdataelement. 
-- La misma tiene definido un idioma, un orden cuando hay más de una descripcion y un tipo de texto
USE applcore;

-- First you must to delete the Foreing Key Constraint;
-- The referenced appltdatadocumentation Tables:
-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `applcore`.`appltdatadocumentation`;

CREATE TABLE `applcore`.`appltdatadocumentation` (
		`ID` char(38) COLLATE utf8mb4_bin NOT NULL,		-- Es el uniqueIdentifier
		`IDNum` int NOT NULL AUTO_INCREMENT,			-- Es el valor autonumerico
		`DocumentationIDn` int NOT NULL,				-- Es el IdNum del DataElement
		`LanguageIDn` int NOT NULL,						-- Es el IdNum del idioma en que esta definido el Name
		`DescriptionOrder` tinyint NOT NULL,			-- Es el orden en que van las distintas descripciones, esto sirve cuando hay mas de una descripcion para un DataElment
		`DocDescription` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,	-- Es la descripcion
		`TextFormatIDn` smallint NOT NULL,				-- Es el IdNum del tipo de formato de Texto
		`StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`IDNum`),
		 UNIQUE KEY `ID_UNIQUE` (`ID`) /*!80000 INVISIBLE */,
		 UNIQUE KEY `IDNum_UNIQUE` (`IDNum`),
		 KEY `ID_idx` (`ID`) /*!80000 INVISIBLE */,
         KEY `IDNum_idx` (`IDNum`) /*!80000 INVISIBLE */,
         KEY `DocLangIDn_idx` (`DocumentationIDn`,`LanguageIDn`) /*!80000 INVISIBLE */,
		 CONSTRAINT `DocumentationIDnDc` FOREIGN KEY (`DocumentationIDn`) REFERENCES `applcore`.`appltdataelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE,
		 CONSTRAINT `LanguageIDnDc` FOREIGN KEY (`LanguageIDn`) REFERENCES `bpmncore`.`bpmfoutbaseelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
		AUTO_INCREMENT=0 
		DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='contiene una o más descriptiones del elemento de la tabla appltdataelement. 
				La misma tiene definido un idioma, un orden cuando hay más de una descripcion y un tipo de texto.
				';


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - appltdatadocumentation
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appltdatadocumentation_BEFORE_INSERT`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appltdatadocumentation_BEFORE_INSERT` BEFORE INSERT ON `appltdatadocumentation` FOR EACH ROW BEGIN
	IF new.ID IS NULL OR new.ID = '' THEN
		SET new.ID = uuid();
	END IF;
    SET new.DateCreated = CURRENT_TIMESTAMP;
    SET new.DateTimeStamp = CURRENT_TIMESTAMP;
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - appltdatadocumentation
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appltdatadocumentation_BEFORE_UPDATE`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appltdatadocumentation_BEFORE_UPDATE` BEFORE UPDATE ON `appltdatadocumentation` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = CURRENT_TIMESTAMP;
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(old.IDNum,"†",
					IF(new.DocumentationIDn = old.DocumentationIDn,"",old.DocumentationIDn),"†",
					IF(new.LanguageIDn = old.LanguageIDn,"",old.LanguageIDn),"†",
					IF(new.DescriptionOrder = old.DescriptionOrder,"",old.DescriptionOrder),"†",
					IF(new.DocDescription = old.DocDescription,"",old.DocDescription),"†",
                    IF(new.TextFormatIDn = old.TextFormatIDn,"",old.TextFormatIDn),"†",
                    IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `applcore`.`appltdatadocumentation`;