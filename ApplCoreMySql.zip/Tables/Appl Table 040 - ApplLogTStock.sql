-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplLogTStock table
-- Contiene la informacion del stock de cada articulos
-- como no todos los articulos llevan stock (eje servicios, bienes de uso, etc), se debe cargar la informacion en una tabla aparte
-- la clave primaria, es el ArticleIDn + CompanyIDn, el articulo solo puede tener un valor de stock para la compania
USE applcore;

-- First you must to delete the Foreing Key Constraint;
-- The referenced appllogtstock Tables:
-- 	ALTER TABLE `bpmcore`.`appllogtserie` DROP FOREIGN KEY `ArticleIDnSer`;

-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `applcore`.`appllogtstock`;

CREATE TABLE `applcore`.`appllogtstock` (
		`ArticleIDn` int NOT NULL,						-- Es el IdNum del Articulo en el DataElement
        `CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName
					-- la clave primaria, es el ArticleIDn + CompanyIDn, solo puede estar el articulo una vez en la compania
        `Stock` double NOT NULL,						-- Cantidad de Stock
        `StockMinimun` double NOT NULL,					-- Cantidad de Stock mínimo
        `StockMaximun` double NOT NULL,					-- Cantidad de Stock máximo
        `StockEnableNegative` tinyint NOT NULL,			-- Habilita la posibilidad de tener Stock negativo
        `StockPointOrder` double NOT NULL,				-- Cantidad de Stock para realizar el púnto de pedido
        `ScrapTolerancePurchase` double NOT NULL,		-- Porcentaje de desvío en la cantidad de unidades para considerar la mercadería recibida
														-- es utilizado por el modulo compras para dar por cumplida la recepcion de mercaderia, 
                                                        -- si la diferencia entre lo pendiente y lo recibido esta dentro de este valor, en forma automatica 
                                                        -- cierra la orden de compra del articulo. Si el valor esta en cero, esta desactivado.
        `MeasureStockUnitIDn` tinyint NOT NULL,			-- Es el IdNum de la Unidad de medida de Stock, Scope = ,
        `MeasureIPurchasekUnitDn` tinyint NOT NULL,		-- Es el IdNum de la Unidad de medida de compras, Scope = ,
		`MeasureSaleskUnitIDn` tinyint NOT NULL,		-- Es el IdNum de la Unidad de medida de ventas, Scope = ,
        `WarehouseDefaultIDn` tinyint NOT NULL,			-- Es el IdNum del Deposito predefinido, Scope =  depositos
		`StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`ArticleIDn`,`CompanyIDn`),
		 UNIQUE KEY `ArticleCompanyIDn_UNIQUE` (`ArticleIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
		 KEY `ArticleCompanyIDn_idx` (`ArticleIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
         KEY `CompanyIDn_idx` (`CompanyIDn`) /*!80000 INVISIBLE */,
		 CONSTRAINT `ArticleIDnStk` FOREIGN KEY (`ArticleIDn`) REFERENCES `applcore`.`appllogtarticles` (`ArticleIDn`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `CompanyIDnStk` FOREIGN KEY (`CompanyIDn`) REFERENCES `bpmcore`.`systcompanies` (`CompanyIDn`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
		DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='Contiene la informacion del stock de cada articulos
				 como no todos los articulos llevan stock (eje servicios, bienes de uso, etc), se debe cargar la informacion en una tabla aparte
				 la clave primaria, es el ArticleIDn + CompanyIDn, el articulo solo puede tener un valor de stock para la compania
				';


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - appllogtstock
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appllogtstock_BEFORE_INSERT`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appllogtstock_BEFORE_INSERT` BEFORE INSERT ON `appllogtstock` FOR EACH ROW BEGIN
	IF new.ID IS NULL OR new.ID = '' THEN
		SET new.ID = uuid();
	END IF;
    SET new.DateCreated = CURRENT_TIMESTAMP;
    SET new.DateTimeStamp = CURRENT_TIMESTAMP;
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - appllogtstock
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appllogtstock_BEFORE_UPDATE`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appllogtstock_BEFORE_UPDATE` BEFORE UPDATE ON `appllogtstock` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = CURRENT_TIMESTAMP;
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(old.ArticleIDn,"†",old.CompanyIDn,"†",
					-- la clave primaria, es el ArticleIDn + CompanyIDn, solo puede estar el articulo una vez en la compania
                    IF(new.Stock = old.Stock,"",old.Stock),"†",
                    IF(new.StockMinimun = old.StockMinimun,"",old.StockMinimun),"†",
                    IF(new.StockMaximun = old.StockMaximun,"",old.StockMaximun),"†",
                    IF(new.StockEnableNegative = old.StockEnableNegative,"",old.StockEnableNegative),"†",
                    IF(new.StockPointOrder = old.StockPointOrder,"",old.StockPointOrder),"†",
                    IF(new.ScrapTolerancePurchase = old.ScrapTolerancePurchase,"",old.ScrapTolerancePurchase),"†",
                    IF(new.MeasureStockUnitIDn = old.MeasureStockUnitIDn,"",old.MeasureStockUnitIDn),"†",
                    IF(new.MeasureIPurchasekUnitDn = old.MeasureIPurchasekUnitDn,"",old.MeasureIPurchasekUnitDn),"†",
                    IF(new.MeasureSaleskUnitIDn = old.MeasureSaleskUnitIDn,"",old.MeasureSaleskUnitIDn),"†",
                    IF(new.WarehouseDefaultIDn = old.WarehouseDefaultIDn,"",old.WarehouseDefaultIDn),"†",
                    IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `applcore`.`appllogtstock`;