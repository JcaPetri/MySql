-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplSupTSuppliersPriceListHistory table
-- contiene la informacion Historica de los Precios de los Articulos de los Suppliers/Proveedores
-- la clave primaria: es el ArticleSupplierID + SupplierIDn + CompanyIDn
USE ApplCore;

-- #########################################################################################################################################################################################
-- 1.- First you must to delete the Foreing Key Constraint childs;
-- The referenced ApplSupTSuppliersPriceListHistory Tables:
-- 	ALTER TABLE `ApplCore`.`ApplLogTArticlesSuppliersArticles` DROP FOREIGN KEY `ArticleSupplierAsA`;
	-- After deleted the referenced, you can delete the table
	DROP TABLE IF EXISTS `ApplCore`.`ApplSupTSuppliersPriceListHistory`;

-- #########################################################################################################################################################################################
-- 2.- Seconde you create the Table
CREATE TABLE `ApplCore`.`ApplSupTSuppliersPriceListHistory` (
		`ArticleSupplierID` varchar(38) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,		-- Es Codigo Unico de identificacion del articulo para ese Supplier/Proveedor
        `SupplierIDn` int NOT NULL,						-- Es el IdNum del Supplier/Proveedor, esta en la tabla ApplTPersons
		`CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName
				-- la clave primaria: es el ArticleSupplierID + SupplierIDn + CompanyIDn
        `DatePriceList` datetime NOT NULL,				-- Es la fecha de la Lista de Precio
        `Price` decimal(16,6) NOT NULL,					-- Es el precio del articulo
        `DatePriceListBefore` datetime,					-- Es la fecha del precio anterior que tenia
        `PriceBefore` decimal(16,6),					-- Es el precio anterior que tenia
		`StateIDn` smallint NOT NULL,					-- Es el estado del registro
		 PRIMARY KEY (`DatePriceList`, `ArticleSupplierID`, `SupplierIDn`, `CompanyIDn`),
		 UNIQUE KEY `ArtSupplierCompanyIDn_UNIQUE` (`DatePriceList`, `ArticleSupplierID`,`SupplierIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
		 KEY `ArtSupplierCompanyIDn_idx` (`ArticleSupplierID`,`SupplierIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
         KEY `DatePriceListSupplierIDn_idx` (`DatePriceList`,`SupplierIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
         KEY `SupplierCompanyIDn_idx` (`SupplierIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
         CONSTRAINT `SupplierIDnSpH` FOREIGN KEY (`SupplierIDn`) REFERENCES `ApplCore`.`ApplTPersons` (`PersonIDn`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `CompanyIDnSpH` FOREIGN KEY (`CompanyIDn`) REFERENCES `BpmCore`.`systcompanies` (`CompanyIDn`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
		DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='contiene la informacion Historica de los Precios de los Articulos de los Suppliers/Proveedores
				 la clave primaria: es el ArticleSupplierID + SupplierIDn + CompanyIDn
				';

-- #########################################################################################################################################################################################
-- 3.- Then you must to Re-Create the Foreing Key Constraint, because in the step 1 you delete;
-- The referenced ApplSupTSuppliersPriceListArticles Tables:
/*
	ALTER TABLE `ApplCore`.`appllogtarticlessuppliersarticles` ADD CONSTRAINT `ArticleSupplierIDAsA` FOREIGN KEY (`ArticleSupplierID`) 
		REFERENCES `ApplCore`.`ApplSupTSuppliersPriceListArticles` (`ArticleSupplierID`) ON DELETE CASCADE ON UPDATE CASCADE;
*/

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Lista los datos de la tabla
SELECT * FROM `ApplCore`.`ApplSupTSuppliersPriceListHistory`;