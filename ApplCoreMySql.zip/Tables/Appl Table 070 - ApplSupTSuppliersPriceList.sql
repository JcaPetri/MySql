-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplSupTSuppliersPriceList table
-- contiene la informacion de las Listas de Precios de los Suppliers/Proveedores
-- las propiedades especificas de las listas de precios, estan en la tabla ApplSupTSuppliersPriceListOptionalFiels
-- la clave primaria: es el SupplierPriceListIDn + SupplierIDn + CompanyIDn
USE ApplCore;

-- #########################################################################################################################################################################################
-- 1.- First you must to delete the Foreing Key Constraint childs;
-- The referenced ApplSupTSuppliersPriceList Tables:
	ALTER TABLE `ApplCore`.`ApplSupTSuppliersPriceListArticles` DROP FOREIGN KEY `SupplierPriceListIDnSpA`;		-- Field: SupplierPriceListIDn
	-- After deleted the referenced, you can delete the table
	DROP TABLE IF EXISTS `ApplCore`.`ApplSupTSuppliersPriceList`;

-- #########################################################################################################################################################################################
-- 2.- Seconde you create the Table
CREATE TABLE `ApplCore`.`ApplSupTSuppliersPriceList` (
        `SupplierPriceListIDn` int NOT NULL,			-- Es el IdNum de la Lista de Precios del Supplier/Proveedor, esta en la tabla DataElement
				-- El IDName y el Documentation estan en sus tablas respectivas
        `SupplierIDn` int NOT NULL,						-- Es el IdNum del Supplier/Proveedor, esta en la tabla ApplTPersons
		`CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName
				-- la clave primaria: es el SupplierPriceListIDn + SupplierIDn + CompanyIDn
        `PriceListDecimal` tinyint NOT NULL,			-- Es la cantidad de decimales que lleva la lista de precios
        `DateFrom` datetime NOT NULL,					-- Es la fecha desde que toma vigencia la lista de precios
        `DateTo` datetime NOT NULL,						-- Es la fecha hasta que tiene vigencia la lista de precios
															-- Un proveedor puede pasar una lista que entre en vigencia un dia especifico que dure un tiempo determinado
		`CurrencyIDn` int NOT NULL,						-- Es el IdNum de la moneda de la lista de precios
		`PriceTaxTypeIDn` int NOT NULL,					-- Es el IdNum del tipo precio con relacion a los impuestos
															-- Eje, PrecioFinal/PrecioNetoImpuesto
		`StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`SupplierPriceListIDn`,`SupplierIDn`,`CompanyIDn`),
		 UNIQUE KEY `SupPrListSupplierCompanyIDn_UNIQUE` (`SupplierPriceListIDn`,`SupplierIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
		 KEY `SupPrListSupplierCompanyIDn_idx` (`SupplierPriceListIDn`,`SupplierIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
         KEY `SupplierCompanyIDn_idx` (`SupplierIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
         KEY `CompanyIDn_idx` (`CompanyIDn`) /*!80000 INVISIBLE */,
         CONSTRAINT `SupplierPriceListIDnSup` FOREIGN KEY (`SupplierPriceListIDn`) REFERENCES `ApplCore`.`ApplTDataElement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `SupplierIDnSup` FOREIGN KEY (`SupplierIDn`) REFERENCES `ApplCore`.`ApplTPersons` (`PersonIDn`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `CompanyIDnSup` FOREIGN KEY (`CompanyIDn`) REFERENCES `BpmCore`.`systcompanies` (`CompanyIDn`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
		DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='contiene la informacion de las Listas de Precios de los Suppliers/Proveedores
				 las propiedades especificas de las listas de precios, estan en la tabla ApplSupTSuppliersPriceListOptionalFiels
				 la clave primaria: es el SupplierPriceListIDn + SupplierIDn + CompanyIDn
				';

-- #########################################################################################################################################################################################
-- 3.- Then you must to Re-Create the Foreing Key Constraint, because in the step 1 you delete;
-- The referenced ApplSupTSuppliersPriceListArticles Tables:
	ALTER TABLE `ApplCore`.`ApplSupTSuppliersPriceListArticles` ADD CONSTRAINT `SupplierPriceListIDnSpA` FOREIGN KEY (`SupplierPriceListIDn`) 
		REFERENCES `ApplCore`.`ApplSupTSuppliersPriceList` (`SupplierPriceListIDn`) ON DELETE CASCADE ON UPDATE CASCADE;

-- #########################################################################################################################################################################################
-- 4.- Create the Trigger Before Insert - ApplSupTSuppliersPriceList
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE ApplCore;
DROP TRIGGER IF EXISTS `ApplCore`.`ApplSupTSuppliersPriceList_BEFORE_INSERT`;
DELIMITER $$
USE `ApplCore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `ApplSupTSuppliersPriceList_BEFORE_INSERT` BEFORE INSERT ON `ApplSupTSuppliersPriceList` FOR EACH ROW BEGIN
    SET new.DateCreated = ifnull(new.DateCreated,current_timestamp);
    SET new.DateTimeStamp = ifnull(new.DateTimeStamp,current_timestamp);
END$$
DELIMITER ;

-- #########################################################################################################################################################################################
-- 5.- Create the Trigger Before Update - ApplSupTSuppliersPriceList
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE ApplCore;
DROP TRIGGER IF EXISTS `ApplCore`.`ApplSupTSuppliersPriceList_BEFORE_UPDATE`;
DELIMITER $$
USE `ApplCore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `ApplSupTSuppliersPriceList_BEFORE_UPDATE` BEFORE UPDATE ON `ApplSupTSuppliersPriceList` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = ifnull(new.DateTimeStamp,current_timestamp);
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(
					IF(new.SupplierPriceListIDn = old.SupplierPriceListIDn,"",old.SupplierPriceListIDn),"†",
                    IF(new.SupplierIDn = old.SupplierIDn,"",old.SupplierIDn),"†",
                    IF(new.CompanyIDn = old.CompanyIDn,"",old.CompanyIDn),"†",
						-- la clave primaria: es el SupplierPriceListIDn + SupplierIDn + CompanyIDn
                    IF(new.PriceListDecimal = old.PriceListDecimal,"",old.PriceListDecimal),"†",
					IF(new.DateFrom = old.DateFrom,"",old.DateFrom),"†",
                    IF(new.DateTo = old.DateTo,"",old.DateTo),"†",
                    IF(new.CurrencyIDn = old.CurrencyIDn,"",old.CurrencyIDn),"†",
                    IF(new.PriceTaxTypeIDn = old.PriceTaxTypeIDn,"",old.PriceTaxTypeIDn),"†",
                    IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Lista los datos de la tabla
SELECT * FROM `ApplCore`.`ApplSupTSuppliersPriceList`;