-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplImpTSuppliersPriceListArticles table
-- contiene la estructura para importar las distintas listas de precios
-- El IDNum es un valor autoincremental que sirve como indice para las depuraciones
-- luego de las mismas la clave primaria es el ArticleSupplierID + SupplierIDn + CompanyIDn
-- Si hay algun valor duplicado se debe informar para que el usuario lo elimine y vea cual es el indicado
-- El resto de los valores se utilizan para actualizar la lista de precios
USE ApplCore;

-- #########################################################################################################################################################################################
-- 1.- First you must to delete the Foreing Key Constraint childs;
-- The referenced ApplSupTSuppliersPriceList Tables:
	-- ALTER TABLE `ApplCore`.`ApplSupTSuppliersPriceListArticles` DROP FOREIGN KEY `SupplierPriceListIDnSpA`;		-- Field: SupplierPriceListIDn
	-- After deleted the referenced, you can delete the table
	DROP TABLE IF EXISTS `ApplCore`.`ApplImpTSuppliersPriceListArticles`;

-- #########################################################################################################################################################################################
-- 2.- Seconde you create the Table
CREATE TABLE `ApplCore`.`ApplImpTSuppliersPriceListArticles` (
		`IDNum` int NOT NULL AUTO_INCREMENT,			-- Es el valor autonumerico
		`ArticleSupplierID` VARCHAR(250),				-- Es el ID del Articulo unico en el sistema del Supplier/Proveedor
		`SupplierIDn` VARCHAR(250),						-- Es el IDNum del Supplier/Proveedor
		`CompanyIDn` VARCHAR(250),						-- Es la Company a la cual esta asociado el Supplier/Proveedor
		`ArticleSupplierDescription` VARCHAR(1000),		-- Es la descripcion del Article
		`SupplierPriceListIDn` VARCHAR(1000),			-- Es el IDNum del Supplier/Proveedor
		`Price` VARCHAR(1000),							-- Es el Precio de Lista
		`DatePriceList` VARCHAR(1000),					-- Es la fecha de la lista de precios
        `PriceListCode` VARCHAR(1000),					-- Es el codigo de la lista de precios, si el proveedor cada vez que pasa la lista de precios tiene un codigo especial este se carga aqui
																-- de esa manera se deja aclarado que ese precio se actualizo con esa lista de precios
        `ResultIDn` int,								-- El el IDNum del resultado de la importacion, esto permite proveedor la informacion en cualquier idioma
        `ResultDescription` VARCHAR(250),				-- Es la descripcion del resultado
		PRIMARY KEY (`IDNum`),
        KEY `IDNum_idx` (`IDNum`) /*!80000 INVISIBLE */,
        KEY `ArtSuppCompanyIDn_idx` (`ArticleSupplierID`,`SupplierIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
        KEY `ResultIDn_idx` (`ResultIDn`) /*!80000 INVISIBLE */
) ENGINE=InnoDB
	AUTO_INCREMENT=0 
	DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin 
	COMMENT='contiene la estructura para importar las distintas listas de precios
			 El IDNum es un valor autoincremntal que sirve como indice para las depuraciones
			 luego de las mismas la clave primaria es el ArticleSupplierID + SupplierIDn + CompanyIDn
			 Si hay algun valor duplicado se debe informar para que el usuario lo elimine y vea cual es el indicado
			 El resto de los valores se utilizan para actualizar la lista de precios
			';

-- #########################################################################################################################################################################################
-- 3.- Then you must to Re-Create the Foreing Key Constraint, because in the step 1 you delete;
-- The referenced ApplSupTSuppliersPriceListArticles Tables:
/*
	ALTER TABLE `ApplCore`.`ApplSupTSuppliersPriceListArticles` ADD CONSTRAINT `SupplierPriceListIDnSpA` FOREIGN KEY (`SupplierPriceListIDn`) 
		REFERENCES `ApplCore`.`ApplSupTSuppliersPriceList` (`SupplierPriceListIDn`) ON DELETE CASCADE ON UPDATE CASCADE;
*/


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Lista los datos de la tabla
SELECT * FROM `ApplCore`.`ApplImpTSuppliersPriceListArticles`;
