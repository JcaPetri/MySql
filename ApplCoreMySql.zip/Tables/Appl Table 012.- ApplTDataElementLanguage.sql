-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplTDataElementLanguage table
-- contiene el IDNameLanguage para otro idioma distinto al predeterminado
-- Aclaracion: los valores Num, Scope, Company = siempre son iguales a la tabla appltdataelement  (solo se cambian si se hace en la tabla principal), 
-- 				se ponen en esta tabla solo para asegurar la integridad y que no haya duplicados
-- es unico para un:
-- 					DataElementLanguageIDn		(es el NumIDn unico)
-- 					IDNameLanguage 	(es el codigo legible por el usuario)
-- 					Scope			(el Name debe ser unico para el ambito de aplicacion, usualmente una Tabla), vinculo con la tabla bpmcore.bpmfoutbaseelement unica para todas las bases de datos
-- 					Company			(el Name debe ser unico para la Company), vinculo con la tabla bpmcore.bpmfoutbaseelement unica para todas las bases de datos
-- 					Language		(el Name debe ser unico para el idioma que se ingresa), vinculo con la tabla bpmcore.bpmfoutbaseelement unica para todas las bases de datos
-- Aclaracion: los valores Num, Scope, Company = siempre son iguales a la tabla appltdataelement, 
-- 				se ponen en esta tabla solo para asegurar la integridad y que no haya duplicados

USE applcore;
-- First you must to delete the Foreing Key Constraint;
-- The referenced appltdataelementlanguage Tables:
-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `applcore`.`appltdataelementlanguage`;

CREATE TABLE `appltdataelementlanguage` (
		`DataElementLanguageIDn` int NOT NULL,		-- Es el IdNum del DataElement
		`IDName` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,	-- Es el codigo legible por el usuario para el idioma
		`ScopeIDn` int NOT NULL,					-- Es el IdNum del Scope, el Name debe ser unico para el ambito de aplicacion, usualmente una Tabla
		`CompanyIDn` int NOT NULL,					-- Es el IdNum de la Compania
		`LanguageIDn` int NOT NULL,					-- Es el IdNum del idioma
		`StateIDn` smallint NOT NULL,				-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,			-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,		-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,				-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,			-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 		-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 				-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 				-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`DataElementLanguageIDn`,`IDName`,`ScopeIDn`,`CompanyIDn`,`LanguageIDn`),		
		 UNIQUE KEY `IDNumNameScopeCompLang_UNIQUE` (`DataElementLanguageIDn`,`IDName`,`ScopeIDn`,`CompanyIDn`,`LanguageIDn`),
		 KEY `IDNumNameScopeCompLang_idx` (`DataElementLanguageIDn`,`IDName`,`ScopeIDn`,`CompanyIDn`,`LanguageIDn`) /*!80000 INVISIBLE */,
		 CONSTRAINT `DataElementLanguageIDnDl` FOREIGN KEY (`DataElementLanguageIDn`) REFERENCES `applcore`.`appltdataelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE,
		 CONSTRAINT `ScopeIDnDl` FOREIGN KEY (`ScopeIDn`) REFERENCES `bpmcore`.`bpmfoutbaseelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE,
		 CONSTRAINT `CompanyIDnDl` FOREIGN KEY (`CompanyIDn`) REFERENCES `bpmcore`.`bpmfoutbaseelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE,
		 CONSTRAINT `LanguageIDnDl` FOREIGN KEY (`LanguageIDn`) REFERENCES `bpmcore`.`bpmfoutbaseelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
	DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin
    COMMENT='contiene el IDNameLanguage para otro idioma distinto al predeterminado 
			 es unico para un:
 					DataElementLanguage		(es el NumIDn unico)
 					IDName	 			(es el codigo legible por el usuario, para el idioma elegido)
 					Scope				(el Name debe ser unico para el ambito de aplicacion), vinculo con la tabla bpmcore.bpmfoutbaseelement unica para todas las bases de datos
 					Company				(el Name debe ser unico para la Company), vinculo con la tabla bpmcore.bpmfoutbaseelement unica para todas las bases de datos
 					Language			(el Name debe ser unico para el idioma que se ingresa), vinculo con la tabla bpmcore.bpmfoutbaseelement unica para todas las bases de datos
			 Los valores Num, Scope, Company = siempre son iguales a la tabla appltdataelement (solo se cambian si se hace en la tabla principal), 
						  se ponen en esta tabla solo para asegurar la integridad y que no haya duplicados
                    ';

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - appltdataelementlanguage
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appltdataelementlanguage_BEFORE_INSERT`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appltdataelementlanguage_BEFORE_INSERT` BEFORE INSERT ON `appltdataelementlanguage` FOR EACH ROW BEGIN
    SET new.DateCreated = ifnull(new.DateCreated,CURRENT_TIMESTAMP);
    SET new.DateTimeStamp = ifnull(new.DateTimeStamp,CURRENT_TIMESTAMP);
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - appltdataelementlanguage
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appltdataelementlanguage_BEFORE_UPDATE`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appltdataelementlanguage_BEFORE_UPDATE` BEFORE UPDATE ON `appltdataelementlanguage` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = ifnull(new.DateTimeStamp,CURRENT_TIMESTAMP);
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(old.DataElementLanguageIDn,"†",
                    IF(new.IDName = old.IDName,"",new.IDName),"†",
					IF(new.ScopeIDn = old.ScopeIDn,"",new.ScopeIDn),"†",
                    IF(new.CompanyIDn = old.CompanyIDn,"",new.CompanyIDn),"†",
					IF(new.LanguageIDn = old.LanguageIDn,"",new.LanguageIDn),"†",
                    IF(new.StateIDn = old.StateIDn,"",new.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",new.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",new.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",new.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",new.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",new.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",new.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `applcore`.`appltdataelementlanguage`;

