-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplLogTArticlesOptionalFields table
-- Contiene las columnas/fields/propiedades de la Tabla ApplLogTArticles que son opcionales
-- la clave primaria: es la propiedad (columna) TableFieldIDn + el ArticleIDn (Tabla) + CompanyIDn

/*
		-- Lista los Campos/Fields disponibles, estan en el ScopeIDn = 4 SysTTableFields
		SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 4 order by IDNum desc, ScopeIDn;
        -- Campos opcionales de los articulos
		2229	Unit			4	652	2207	2507
		2228	Quantity		4	652	2207	2506
		2227	Color			4	652	2207	2505
		2226	Weight			4	652	2207	2504
		2225	Size			4	652	2207	2503
		2224	Product			4	652	2207	2502
		2223	Brand			4	652	2207	2501
        
*/
USE ApplCore;

-- First you must to delete the Foreing Key Constraint;
-- The referenced appllogtarticlesproperty Tables:
-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `ApplCore`.`ApplLogTArticlesOptionalFields`;

CREATE TABLE `ApplCore`.`ApplLogTArticlesOptionalFields` (
        `TableFieldIDn` int NOT NULL,					-- Es el IdNum de la propiedad del Articulo (Columna de la Tabla), se crea en la tabla bpmfoutbaseelement
        `ArticleIDn` int NOT NULL,						-- Es el IdNum del Articulo en el DataElement
        `CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName, esta en la tabla BpmfounTCompany y se crea en la tabla BaseElement
			-- la clave primaria: es la propiedad (columna) TableFieldIDn + el ArticleIDn (Tabla) + CompanyIDn
        `FieldValueIDn` int,							-- Es el IDNum del valor de esa Propiedad, este valor se carga en el DataElement
		`FieldNumValue` double,							-- Es un valor numerico definido por el usuario
		`FieldTextValue` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,	-- Es un valor texto definido por el usuario
		`StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`TableFieldIDn`,`ArticleIDn`,`CompanyIDn`),
		 UNIQUE KEY `TableFieldArticleCompanyIDn_UNIQUE` (`TableFieldIDn`,`ArticleIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
		 KEY `TableFieldArticleCompanyIDn_idx` (`TableFieldIDn`,`ArticleIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
         KEY `ArticleCompanyIDn_idx` (`ArticleIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
         KEY `CompanyIDn_idx` (`CompanyIDn`) /*!80000 INVISIBLE */,
		 CONSTRAINT `TableFieldIDnAfo` FOREIGN KEY (`TableFieldIDn`) REFERENCES `bpmcore`.`systtablefields` (`TableFieldIDn`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `ArticleIDnAfo` FOREIGN KEY (`ArticleIDn`) REFERENCES `applcore`.`appllogtarticles` (`ArticleIDn`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `CompanyIDnAfo` FOREIGN KEY (`CompanyIDn`) REFERENCES `bpmcore`.`systcompanies` (`CompanyIDn`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
        DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='Contiene las columnas/fields/propiedades de la Tabla ApplLogTArticles que son opcionales
				 la clave primaria: es la propiedad (columna) TableFieldIDn + el ArticleIDn (Tabla) + CompanyIDn
				';


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - ApplLogTArticlesOptionalFields
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE ApplCore;
DROP TRIGGER IF EXISTS `ApplCore`.`ApplLogTArticlesOptionalFields_BEFORE_INSERT`;
DELIMITER $$
USE `ApplCore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `ApplLogTArticlesOptionalFields_INSERT` BEFORE INSERT ON `ApplLogTArticlesOptionalFields` FOR EACH ROW BEGIN
    SET new.DateCreated = ifnull(new.DateCreated,current_timestamp);
    SET new.DateTimeStamp = ifnull(new.DateTimeStamp,current_timestamp);
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - appllogtarticlesproperties
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE ApplCore;
DROP TRIGGER IF EXISTS `ApplCore`.`ApplLogTArticlesOptionalFields_BEFORE_UPDATE`;
DELIMITER $$
USE `ApplCore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `ApplLogTArticlesOptionalFields_BEFORE_UPDATE` BEFORE UPDATE ON `ApplLogTArticlesOptionalFields` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = ifnull(new.DateTimeStamp,current_timestamp);
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(
					IF(new.TableFieldIDn = old.TableFieldIDn,"",old.TableFieldIDn),"†",
                    IF(new.ArticleIDn = old.ArticleIDn,"",old.ArticleIDn),"†",
                    IF(new.CompanyIDn = old.CompanyIDn,"",old.CompanyIDn),"†",
                    -- Aqui van siempre la clave primaria que no cambia
					IF(new.FieldValueIDn = old.FieldValueIDn,"",old.FieldValueIDn),"†",
                    IF(new.FieldNumValue = old.FieldNumValue,"",old.FieldNumValue),"†",
					IF(new.FieldTextValue = old.FieldTextValue,"",old.FieldTextValue),"†",
                    IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `ApplCore`.`ApplLogTArticlesOptionalFields`;