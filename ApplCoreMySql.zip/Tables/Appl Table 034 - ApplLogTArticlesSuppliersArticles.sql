-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplLogTApplLogTArticlesSuppliersArticles table
-- contiene la relacion entre los Articulos de la Empresa y los Articulos de los Suppliers/Proveedores
-- Por lo tanto, si asociamos el articulo de la Company con el proveedor, este articulo estara repetido tantas veces como proveedores vendan ese articulo. 
-- la clave primaria: es el ArticleIDn + ArticleSupplierID + SupplierIDn + CompanyIDn
-- --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Esto se resuelve con una Consulta
-- Lo que hay que hacer para relacionar los distintos proveedores de un articulo, es hacer una consulta tipo tabla dinamica, 
-- donde en la primer columna este el articulo, y en las otras columnas esten los distintos proveedores de ese articulo
-- como el vinculo es nuestro articulo y la asociacion del articulo del proveedor a nuestro articulo esta hecha manualmente, es que luego la comparacion es precisa
-- --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
USE ApplCore;

-- First you must to delete the Foreing Key Constraint;
-- The referenced ApplLogTArticlesSuppliersArticles Tables:
-- 	ALTER TABLE `BpmCore`.`appllogtstock` DROP FOREIGN KEY `ArticleIDnStk`;

-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `ApplCore`.`ApplLogTArticlesSuppliersArticles`;

CREATE TABLE `ApplCore`.`ApplLogTArticlesSuppliersArticles` (
		`ArticleIDn` int NOT NULL,						-- Es el IdNum del Articulo en el DataElement
		`ArticleSupplierID` varchar(38) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,		-- Es Codigo Unico de identificacion del articulo para ese Supplier/Proveedor
        `SupplierIDn` int NOT NULL,						-- Es el IdNum del Supplier/Proveedor, esta en la tabla ApplTPersons
		`CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName
				-- la clave primaria: es el ArticleIDn + ArticleSupplier + SupplierIDn + CompanyIDn
		`StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`ArticleIDn`,`ArticleSupplierID`,`SupplierIDn`,`CompanyIDn`),
		 UNIQUE KEY `ArtSuppArtCompanyIDn_UNIQUE` (`ArticleIDn`,`ArticleSupplierID`,`SupplierIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
		 KEY `ArtSuppArtCompanyIDn_idx` (`ArticleIDn`,`ArticleSupplierID`,`SupplierIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
         KEY `SupplierCompanyIDn_idx` (`SupplierIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
         CONSTRAINT `ArticleIDnAsA` FOREIGN KEY (`ArticleIDn`) REFERENCES `ApplCore`.`ApplLogTArticles` (`ArticleIDn`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `ArticleSupplierIDAsA` FOREIGN KEY (`ArticleSupplierID`) REFERENCES `ApplCore`.`ApplSupTSuppliersPriceListArticles` (`ArticleSupplierID`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `SupplierIDnAsA` FOREIGN KEY (`SupplierIDn`) REFERENCES `ApplCore`.`ApplTPersons` (`PersonIDn`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `CompanyIDnAsA` FOREIGN KEY (`CompanyIDn`) REFERENCES `BpmCore`.`systcompanies` (`CompanyIDn`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
		DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='contiene la relacion entre los Articulos de la Empresa y los Articulos de los Suppliers/Proveedores
				 la clave primaria: es el ArticleIDn + ArticleSupplier + SupplierIDn + CompanyIDn
				';


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - ApplLogTArticlesSuppliersArticles
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE ApplCore;
DROP TRIGGER IF EXISTS `ApplCore`.`ApplLogTArticlesSuppliersArticles_BEFORE_INSERT`;
DELIMITER $$
USE `ApplCore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `ApplLogTArticlesSuppliersArticles_BEFORE_INSERT` BEFORE INSERT ON `ApplLogTArticlesSuppliersArticles` FOR EACH ROW BEGIN
    SET new.DateCreated = ifnull(new.DateCreated,current_timestamp);
    SET new.DateTimeStamp = ifnull(new.DateTimeStamp,current_timestamp);
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - ApplLogTArticlesSuppliersArticles
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE ApplCore;
DROP TRIGGER IF EXISTS `ApplCore`.`ApplLogTArticlesSuppliersArticles_BEFORE_UPDATE`;
DELIMITER $$
USE `ApplCore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `ApplLogTArticlesSuppliersArticles_BEFORE_UPDATE` BEFORE UPDATE ON `ApplLogTArticlesSuppliersArticles` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = ifnull(new.DateTimeStamp,current_timestamp);
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(
					IF(new.ArticleIDn = old.ArticleIDn,"",old.ArticleIDn),"†",
                    IF(new.ArticleSupplierID = old.ArticleSupplierID,"",old.ArticleSupplierID),"†",
                    IF(new.SupplierIDn = old.SupplierIDn,"",old.SupplierIDn),"†",
                    IF(new.CompanyIDn = old.CompanyIDn,"",old.CompanyIDn),"†",
                    -- la clave primaria: es el ArticleIDn + ArticleSupplier + SupplierIDn + CompanyIDn
                    IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `ApplCore`.`ApplLogTArticlesSuppliersArticles`;