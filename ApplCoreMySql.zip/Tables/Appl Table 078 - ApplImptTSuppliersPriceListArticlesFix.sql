-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplImpTSuppliersPriceListArticlesFix table
-- contiene la informacion para solucionar errores en los datos de importacion de la Lista de Precios de Supplier/Proveedor
-- la clave primaria es el ArticleSupplierID + SupplierIDn + CompanyIDn
-- Una vez que se importan los datos, se reemplaza con la informacion que esta en esta tabla
USE ApplCore;

-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `ApplCore`.`ApplImpTSuppliersPriceListArticlesFix`;

CREATE TABLE `ApplCore`.`ApplImpTSuppliersPriceListArticlesFix` (
		`ArticleSupplierID` VARCHAR(38) not null,		-- Es el ID del Articulo unico en el sistema del Supplier/Proveedor
		`SupplierIDn` int not null,						-- Es el IDNum del Supplier/Proveedor
		`CompanyIDn` int not null,						-- Es la Company a la cual esta asociado el Supplier/Proveedor
		`ArticleSupplierDescription` VARCHAR(1000),		-- Es la descripcion del Article
		`StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		PRIMARY KEY (`ArticleSupplierID`,`SupplierIDn`,`CompanyIDn`),
        UNIQUE KEY `ArticleSupplierCompanyIDn_UNIQUE` (`ArticleSupplierID`,`SupplierIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
        KEY `IDNum_idx` (`ArticleSupplierID`,`SupplierIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
        KEY `CompanyIDn_idx` (`CompanyIDn`) /*!80000 INVISIBLE */,
		CONSTRAINT `SupplierIDnFsa` FOREIGN KEY (`SupplierIDn`) REFERENCES `ApplCore`.`ApplTPersons` (`PersonIDn`) ON DELETE CASCADE ON UPDATE CASCADE,
        CONSTRAINT `CompanyIDnFsa` FOREIGN KEY (`CompanyIDn`) REFERENCES `BpmCore`.`systcompanies` (`CompanyIDn`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB
	DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin 
	COMMENT='contiene la informacion para solucionar errores en los datos de importacion de la Lista de Precios de Supplier/Proveedor
			 la clave primaria es el ArticleSupplierID + SupplierIDn + CompanyIDn
			 Una vez que se importan los datos, se reemplaza con la informacion que esta en esta tabla
			';

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - ApplImpTSuppliersPriceListArticlesFix
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE ApplCore;
DROP TRIGGER IF EXISTS `ApplCore`.`ApplImpTSuppliersPriceListArticlesFix_BEFORE_INSERT`;
DELIMITER $$
USE `ApplCore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `ApplImpTSuppliersPriceListArticlesFix_BEFORE_INSERT` BEFORE INSERT ON `ApplImpTSuppliersPriceListArticlesFix` FOR EACH ROW BEGIN
    SET new.DateCreated = ifnull(new.DateCreated,current_timestamp);
    SET new.DateTimeStamp = ifnull(new.DateTimeStamp,current_timestamp);
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - ApplImpTSuppliersPriceListArticlesFix
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE ApplCore;
DROP TRIGGER IF EXISTS `ApplCore`.`ApplImpTSuppliersPriceListArticlesFix_BEFORE_UPDATE`;
DELIMITER $$
USE `ApplCore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `ApplImpTSuppliersPriceListArticlesFix_BEFORE_UPDATE` BEFORE UPDATE ON `ApplImpTSuppliersPriceListArticlesFix` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = ifnull(new.DateTimeStamp,current_timestamp);
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(
					IF(new.ArticleSupplierID = old.ArticleSupplierID,"",old.ArticleSupplierID),"†",
                    IF(new.SupplierIDn = old.SupplierIDn,"",old.SupplierIDn),"†",
                    IF(new.CompanyIDn = old.CompanyIDn,"",old.CompanyIDn),"†",
						-- la clave primaria: es el ArticleSupplier + SupplierIDn + CompanyIDn
                    IF(new.ArticleSupplierDescription = old.ArticleSupplierDescription,"",old.ArticleSupplierDescription),"†",
                    IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `ApplCore`.`ApplImpTSuppliersPriceListArticlesFix`;
