SELECT * FROM applcore.applsuptsupplierspricelisthistory
WHERE StateIDn = 372 AND ArticleSupplierID = 300358
ORDER BY ArticleSupplierID, DateLastUpdate;

DELETE FROM applcore.applsuptsupplierspricelisthistory;

-- Obtiene el ultimo precio de la lista
-- guarda lo puedo sacar de la tabla general antes de actualizar los precios. es buena
SELECT * FROM `applcore`.`applsuptsupplierspricelisthistory` `sph1`
	INNER JOIN (
				SELECT `ArticleSupplierID`,
						`SupplierIDn`,
						`CompanyIDn`,
						max(`DateLastUpdate`) `DateLastUpdate`
				FROM `applcore`.`applsuptsupplierspricelisthistory` `sph`
				-- WHERE ArticleSupplierID = 300358
				GROUP BY `ArticleSupplierID`,
						`SupplierIDn`,
						`CompanyIDn`
				) `gph`
					on `sph1`.`ArticleSupplierID` = `gph`.`ArticleSupplierID`
						and `sph1`.`SupplierIDn` = `gph`.`SupplierIDn`
						and `sph1`.`CompanyIDn` = `gph`.`CompanyIDn`
                        and `sph1`.`DateLastUpdate` = `gph`.`DateLastUpdate`

