-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplTPersons table
-- contiene la informacion de los Clientes y Proveedores
-- estos se cargan en la misma tabla y pueden tener el perfil de Cliente/Proovedor o Ambos
-- la clave primaria: es el PersonIDn + CompanyIDn, solo puede estar un Cliente/Proveedor una vez en la compania
USE ApplCore;

-- First you must to delete the Foreing Key Constraint;
-- The referenced ApplTPersons Tables:
-- 	ALTER TABLE `BpmCore`.`appllogtstock` DROP FOREIGN KEY `ArticleIDnStk`;


-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `ApplCore`.`ApplTPersons`;

CREATE TABLE `ApplCore`.`ApplTPersons` (
        `PersonIDn` int NOT NULL,		-- Es el IdNum de Cliente/Proveedor en el DataElement
        `CompanyIDn` int NOT NULL,		-- Es el IdNum de la Company al que esta asignado el IDName
	-- la clave primaria: es el PersonIDn + CompanyIDn, solo puede estar un Cliente/Proveedor una vez en la compania
        `PersonTypeIDn` int NOT NULL,		-- Es el IdNum del Tipo de Person, Client/Supplier or Both
        `TradeName` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,		-- Es el Nombre Comercial del Cliente/Proveedor
        `CountryIDn` int NOT NULL,						-- Es el IdNum del Pais
        `Address` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,		-- La Direccion
        `SalesUsualCurrencyIDn` int NOT NULL,		-- Es el IdNum de la moneda usual de Ventas del Cliente
        `SalesPriceListIDn` int NOT NULL,		-- Es el IdNum de la listade precios
		`StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`PersonIDn`,`CompanyIDn`),
		 UNIQUE KEY `PersonCompanyIDn_UNIQUE` (`PersonIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
		 KEY `PersonCompanyIDn_idx` (`PersonIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
         KEY `CompanyIDn_idx` (`CompanyIDn`) /*!80000 INVISIBLE */,
		 CONSTRAINT `PersonIDnPer` FOREIGN KEY (`PersonIDn`) REFERENCES `ApplCore`.`ApplTDataElement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `CompanyIDnPer` FOREIGN KEY (`CompanyIDn`) REFERENCES `BpmCore`.`systcompanies` (`CompanyIDn`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
		DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='contiene la informacion de los Clientes y Proveedores
				 estos se cargan en la misma tabla y pueden tener el perfil de Cliente/Proovedor o Ambos
				 la clave primaria: es el PersonIDn + CompanyIDn, solo puede estar un Cliente/Proveedor una vez en la compania
				';


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - ApplTPersons
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE ApplCore;
DROP TRIGGER IF EXISTS `ApplCore`.`ApplTPersons_BEFORE_INSERT`;
DELIMITER $$
USE `ApplCore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `ApplTPersons_BEFORE_INSERT` BEFORE INSERT ON `ApplTPersons` FOR EACH ROW BEGIN
    SET new.DateCreated = ifnull(new.DateCreated,current_timestamp);
    SET new.DateTimeStamp = ifnull(new.DateTimeStamp,current_timestamp);
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - ApplTPersons
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE ApplCore;
DROP TRIGGER IF EXISTS `ApplCore`.`ApplTPersons_BEFORE_UPDATE`;
DELIMITER $$
USE `ApplCore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `ApplTPersons_BEFORE_UPDATE` BEFORE UPDATE ON `ApplTPersons` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = ifnull(new.DateTimeStamp,current_timestamp);
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(
					IF(new.PersonIDn = old.PersonIDn,"",old.PersonIDn),"†",
                    IF(new.CompanyIDn = old.CompanyIDn,"",old.CompanyIDn),"†",
                    -- la clave primaria: es el PersonIDn + CompanyIDn, solo puede estar un Cliente/Proveedor una vez en la compania
                    IF(new.PersonTypeIDn = old.PersonTypeIDn,"",old.PersonTypeIDn),"†",
					IF(new.TradeName = old.TradeName,"",old.TradeName),"†",
                    IF(new.CountryIDn = old.CountryIDn,"",old.CountryIDn),"†",
                    IF(new.Address = old.Address,"",old.Address),"†",
                    IF(new.SalesUsualCurrencyIDn = old.SalesUsualCurrencyIDn,"",old.SalesUsualCurrencyIDn),"†",
                    IF(new.SalesPriceListIDn = old.SalesPriceListIDn,"",old.SalesPriceListIDn),"†",
                    IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `ApplCore`.`ApplTPersons`;