-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ApplLogTArticlesGeneral
-- -----------------------------

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplLogTArticlesGeneral table
-- Contiene la informacion general de las propiedades de los articulos
-- Las propiedades de los articulos vienen dadas:
-- 		1.- primero por los parametros generales, 
-- 		2.- segundo por los parametros individuales de la tabla articulos
-- Si hay un parametro individual (tabla articulos), este sobreescribe los parametros generales
-- Para Crear un articulo, primero debemos crear el parametro general y 
-- luego crear el articulo y asociarle si o si un parametro general en el 
-- campo GeneralParameterIDn de la tabla appllogtarticles
-- la clave primaria, es el GeneralIDn (Tabla) + CompanyIDn



USE applcore;

-- First you must to delete the Foreing Key Constraint;
-- The referenced appllogtarticlesgeneral Tables:
 	ALTER TABLE `bpmcore`.`appllogtarticlesgeneralproperties` DROP FOREIGN KEY `ArticleGeneralIDnGpt`;
 	ALTER TABLE `bpmcore`.`appllogtarticles` DROP FOREIGN KEY `GeneralIDnArt`;    

-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `applcore`.`appllogtarticlesgeneral`;

CREATE TABLE `applcore`.`appllogtarticlesgeneral` (
		`ArticleGeneralIDn` int NOT NULL,				-- Es el IdNum del General Articulo en el DataElement
														-- ya que es un registro del usuario, no asociado al funcionamiento del System
				-- El name y la descripcion estan dentro de las tablas DataElement y DataDocumentation
        `CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName
				-- la clave primaria, es el GeneralIDn (Tabla) + CompanyIDn
        `ScalesUse` tinyint NOT NULL,					-- True = 1 / False = 0, Habilita el uso de escalas para el artículo
        `StockEnable` tinyint NOT NULL,					-- True = 1 / False = 0, Habilita si se lleva stock del artículo
        `GroupUse` tinyint NOT NULL,					-- True = 1 / False = 0, Habilita la utilización de las Groups/partidas por el artículo
        `GroupAutomaticNumbering` tinyint NOT NULL,		-- True = 1 / False = 0, Habilita la utilización de la numeracion automatica de Groups/Partidas lo da el sistema
        `GroupAutoDownloadByAge` tinyint NOT NULL,		-- True = 1 / False = 0, Habilita la descarga automática de Groups/partida por antigüedad
        `SeriesUse` tinyint NOT NULL,					-- True = 1 / False = 0, Habilita el uso de series
        `SeriesUseMandatory` tinyint NOT NULL,			-- True = 1 / False = 0, Establece como obligatorio el uso de las series
        `SeriesUseReentry` tinyint NOT NULL,			-- True = 1 / False = 0, Admite reingreso de series, activa la comprobación de que no haya series duplicadas (actuales o ya vendidas).
        `SeriesUseValidate` tinyint NOT NULL,			-- True = 1 / False = 0, Valida el número de serie de egreso, que exista en el sistema. Cuando se carga un comprobante de egreso valida que los números de series disponibles existan.
		`StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`ArticleGeneralIDn`,`CompanyIDn`),
		 UNIQUE KEY `ArticleCompanyIDn_UNIQUE` (`ArticleGeneralIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
		 KEY `GeneralCompanyIDn_idx` (`ArticleGeneralIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
         KEY `CompanyIDn_idx` (`CompanyIDn`) /*!80000 INVISIBLE */,
		 CONSTRAINT `ArticleGeneralIDnGar` FOREIGN KEY (`ArticleGeneralIDn`) REFERENCES `applcore`.`appltdataelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE,
		 CONSTRAINT `CompanyIDnGar` FOREIGN KEY (`CompanyIDn`) REFERENCES `bpmcore`.`systcompanies` (`CompanyIDn`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
		DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='contiene la informacion general de las propiedades de los articulos
				 Las propiedades de los articulos vienen dadas:
				 		1.- primero por los parametros generales, 
				 		2.- segundo por los parametros individuales de la tabla articulos
					Si hay un parametro individual (tabla articulos), este sobreescribe los parametros generales
				 Para Crear un articulo, primero debemos crear el parametro general y 
				 luego crear el articulo y asociarle si o si un parametro general en el 
                 campo GeneralParameterIDn de la tabla appllogtarticles
				';


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - appllogtarticlesgeneral
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appllogtarticlesgeneral_BEFORE_INSERT`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appllogtarticlesgeneral_BEFORE_INSERT` BEFORE INSERT ON `appllogtarticlesgeneral` FOR EACH ROW BEGIN
    SET new.DateCreated = ifnull(new.DateCreated,current_timestamp);
    SET new.DateTimeStamp = ifnull(new.DateTimeStamp,current_timestamp);
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - appllogtarticlesgeneral
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appllogtarticlesgeneral_BEFORE_UPDATE`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appllogtarticlesgeneral_BEFORE_UPDATE` BEFORE UPDATE ON `appllogtarticlesgeneral` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = ifnull(new.DateTimeStamp,current_timestamp);
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(
					IF(new.ArticleGeneralIDn = old.ArticleGeneralIDn,"",old.ArticleGeneralIDn),"†",
                    IF(new.CompanyIDn = old.CompanyIDn,"",old.CompanyIDn),"†",
                    -- Con estos dos campos, se generan tantas especificaciones generales.
					IF(new.ScalesUse = old.ScalesUse,"",old.ScalesUse),"†",
                    IF(new.StockEnable = old.StockEnable,"",old.StockEnable),"†",
                    IF(new.GroupUse = old.GroupUse,"",old.GroupUse),"†",
					IF(new.GroupAutomaticNumbering = old.GroupAutomaticNumbering,"",old.GroupAutomaticNumbering),"†",
                    IF(new.GroupAutoDownloadByAge = old.GroupAutoDownloadByAge,"",old.GroupAutoDownloadByAge),"†",
                    IF(new.SeriesUse = old.SeriesUse,"",old.SeriesUse),"†",
                    IF(new.SeriesUseMandatory = old.SeriesUseMandatory,"",old.SeriesUseMandatory),"†",
                    IF(new.SeriesUseReentry = old.SeriesUseReentry,"",old.SeriesUseReentry),"†",
                    IF(new.SeriesUseValidate = old.SeriesUseValidate,"",old.SeriesUseValidate),"†",
                    IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `applcore`.`appllogtarticlesgeneral`;