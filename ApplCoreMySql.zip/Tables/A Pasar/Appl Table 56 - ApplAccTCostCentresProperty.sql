-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplAccTCostCentresProperty table
-- Contiene las propiedades de los Centro de Costos que son opcionales
-- en esta tabla se cargan las columna opcionales
-- la clave primaria, es la propiedad (columna) CostCentrePropertyIDn + el CostCentreIDn (Tabla) + CompanyIDn

/*
        -- Campos opcionales
		A Definir

*/
USE applcore;

-- First you must to delete the Foreing Key Constraint;
-- The referenced applacctcostcentresproperty Tables:
-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `applcore`.`applacctcostcentresproperty`;

CREATE TABLE `applcore`.`applacctcostcentresproperty` (
        `CostCentrePropertyIDn` int NOT NULL,			-- Es el IdNum de la propiedad del Centro de Costos (Columna de la Tabla), se crea en la tabla bpmfoutbaseelement
        `CostCentreIDn` int NOT NULL,					-- Es el IdNum del Centro de Costos, se crea en la tabla bpmfoutbaseelement
        `CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName, esta en la tabla BpmfounTCompany y se crea en la tabla BaseElement
		`PropertyValueIDn` int NOT NULL,				-- Es el IDNum del valor de esa Propiedad, este valor se carga en el DataElement
		`OptionValue` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,	-- Es un valor opcional para la propiedad
		`StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`AccountPropertyIDn`,`AccountIDn`,`CompanyIDn`),
		 UNIQUE KEY `AccountPropertyCompanyIDn_UNIQUE` (`AccountPropertyIDn`,`AccountIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
		 KEY `AccountPropertyCompanyIDn_idx` (`AccountPropertyIDn`,`AccountIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
         KEY `CompanyIDn_idx` (`CompanyIDn`) /*!80000 INVISIBLE */,
		 CONSTRAINT `AccountPropertyIDnAcp` FOREIGN KEY (`AccountPropertyIDn`) REFERENCES `bpmcore`.`bpmfoutbaseelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `AccountIDnAcp` FOREIGN KEY (`AccountIDn`) REFERENCES `applcore`.`appllogtfolders` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
        DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='Contiene las propiedades de los Centro de Costos que son opcionales
				 en esta tabla se cargan las columna opcionales
				 la clave primaria, es la propiedad (columna) CostCentrePropertyIDn + el CostCentreIDn (Tabla) + CompanyIDn
				';


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - applacctcostcentresproperty
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`applacctcostcentresproperty_BEFORE_INSERT`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `applacctcostcentresproperty_INSERT` BEFORE INSERT ON `applacctcostcentresproperty` FOR EACH ROW BEGIN
    SET new.DateCreated = CURRENT_TIMESTAMP;
    SET new.DateTimeStamp = CURRENT_TIMESTAMP;
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - applacctcostcentresproperty
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`applacctcostcentresproperty_BEFORE_UPDATE`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `applacctcostcentresproperty_BEFORE_UPDATE` BEFORE UPDATE ON `applacctcostcentresproperty` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = CURRENT_TIMESTAMP;
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(old.CostCentrePropertyIDn,"†",old.CostCentreIDn,"†",old.CompanyIDn,"†",
				-- Aqui van siempre la clave primaria que no cambia
					IF(new.PropertyValueIDn = old.PropertyValueIDn,"",old.PropertyValueIDn),"†",
					IF(new.OptionValue = old.OptionValue,"",old.OptionValue),"†",
                    IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `applcore`.`applacctcostcentresproperty`;