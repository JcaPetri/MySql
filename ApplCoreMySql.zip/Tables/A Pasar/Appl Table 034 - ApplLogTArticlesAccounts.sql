-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplLogTArticlesAccounts table
-- Contiene para cada articulo la cuenta contable asociada segun el tipo de operacion
-- la clave primaria, es la ArticuloIDn, AccountIDn + OperationTypeIDn + CompanyIDn
USE applcore;

-- First you must to delete the Foreing Key Constraint;
-- The referenced appllogtarticlesaccounts Tables:
-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `applcore`.`appllogtarticlesaccounts`;

CREATE TABLE `applcore`.`appllogtarticlesaccounts` (
        `ArticleIDn` int NOT NULL,						-- Es el IdNum del Articulo en el DataElement
        `AccountIDn` int NOT NULL,						-- Es el IdNum del Account/Cuenta, se crea en la tabla bpmfoutbaseelement
        `OpetationTypeIDn` int NOT NULL,				-- Es el IdNum del Tipo de Operacion, se crea en la tabla bpmfoutbaseelement
        `CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName, esta en la tabla BpmfounTCompany y se crea en la tabla BaseElement
		`StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`ArticleIDn`,`AccountIDn`,`OpetationTypeIDn`,`CompanyIDn`),
		 UNIQUE KEY `ArtAccOperTypeCompanyIDn_UNIQUE` (`ArticleIDn`,`AccountIDn`,`OpetationTypeIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
		 KEY `ArtAccOperTypeCompanyIDn_idx` (`ArticleIDn`,`AccountIDn`,`OpetationTypeIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
         KEY `CompanyIDn_idx` (`CompanyIDn`) /*!80000 INVISIBLE */,
		 CONSTRAINT `ArticleIDnAao` FOREIGN KEY (`ArticleIDn`) REFERENCES `applcore`.`appllogtarticles` (`ArticleIDn`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `AccountIDnAao` FOREIGN KEY (`AccountIDn`) REFERENCES `applcore`.`applacctaccounts` (`AccountIDn`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `OpetationTypeIDnAao` FOREIGN KEY (`OpetationTypeIDn`) REFERENCES `bpmncore`.`bpmfoutbaseelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE,
		 CONSTRAINT `CompanyIDnAao` FOREIGN KEY (`CompanyIDn`) REFERENCES `bpmncore`.`bpmfoutbaseelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
        DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='Contiene para cada articulo la cuenta contable asociada segun el tipo de operacion
				 la clave primaria, es la ArticuloIDn, AccountIDn + OperationTypeIDn + CompanyIDn
				';


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - appllogtarticlesaccounts
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appllogtarticlesaccounts_BEFORE_INSERT`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appllogtarticlesaccounts_INSERT` BEFORE INSERT ON `appllogtarticlesaccounts` FOR EACH ROW BEGIN
    SET new.DateCreated = CURRENT_TIMESTAMP;
    SET new.DateTimeStamp = CURRENT_TIMESTAMP;
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - appllogtarticlesaccounts
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appllogtarticlesaccounts_BEFORE_UPDATE`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appllogtarticlesaccounts_BEFORE_UPDATE` BEFORE UPDATE ON `appllogtarticlesaccounts` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = CURRENT_TIMESTAMP;
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(old.ArticleIDn,"†",old.AccountIDn,"†",old.OpetationTypeIDn,"†",old.CompanyIDn,"†",
                -- Aqui van siempre la clave primaria que no cambia
                    IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `applcore`.`appllogtarticlesaccounts`;