-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplLogTFolders table
-- contiene los Folders/Carpetas donde se clasifican los articulos
-- Puede haber varios tipos de Folders, segun la clasificacion que se le quiera dar a los articulos
-- Eje, Folder de Marketing, Folder Tecnico, etc
-- La clave primaria es Folder + Company

-- La Clave primaria, es el numero de Serie, 
USE applcore;

-- First you must to delete the Foreing Key Constraint;
-- The referenced appllogtfolders Tables:
ALTER TABLE `bpmcore`.`appllogtfoldersstructure`  DROP FOREIGN KEY `FolderIDnFld`;
ALTER TABLE `bpmcore`.`appllogtfoldersarticles`  DROP FOREIGN KEY `FolderIDnFla`;

-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `applcore`.`appllogtfolders`;

CREATE TABLE `applcore`.`appllogtfolders` (
        `FolderIDn` int NOT NULL,						-- Es el IdNum del Folder, se crea en la tabla applcore.dataelement
        `CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName, esta en la tabla BpmfounTCompany y se crea en la tabla BaseElement
        `FolderTypeIDn` int NOT NULL,					-- Es el IdNum del Tipo de Folder, esta en la tabla BpmfounTCompany y se crea en la tabla BaseElement
        `StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`FolderIDn`,`CompanyIDn`),
		 UNIQUE KEY `FolderCompanyID_UNIQUE` (`FolderIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
		 KEY `FolderCompanyID_idx` (`FolderIDn`,`CompanyIDn`),
         KEY `CompanyID_idx` (`CompanyIDn`),
		 CONSTRAINT `FolderIDnWah` FOREIGN KEY (`FolderIDn`) REFERENCES `applcore`.`dataelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
        DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='contiene los Folders/Carpetas donde se clasifican los articulos
				 Puede haber varios tipos de Folders, segun la clasificacion que se le quiera dar a los articulos
				 Eje, Folder de Marketing, Folder Tecnico, etc
				 La clave primaria es Folder + Company
				';


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - appllogtfolders
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appllogtfolders_BEFORE_INSERT`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appllogtfolders_INSERT` BEFORE INSERT ON `appllogtfolders` FOR EACH ROW BEGIN
    SET new.DateCreated = CURRENT_TIMESTAMP;
    SET new.DateTimeStamp = CURRENT_TIMESTAMP;
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - appllogtfolders
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appllogtfolders_BEFORE_UPDATE`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appllogtfolders_BEFORE_UPDATE` BEFORE UPDATE ON `appllogtfolders` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = CURRENT_TIMESTAMP;
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(old.FolderIDn,"†",old.CompanyIDn,"†",
					IF(new.FolderTypeIDn = old.FolderTypeIDn,"",old.FolderTypeIDn),"†",
					IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `applcore`.`appllogtfolders`;