-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the AppltAccTCostCentresRulesStructure table
-- contiene las Estructuras de las Reglas de Apropiacion de los Centros de Costos de cada compania, 
-- Esta regla de Apropiacion debe dar el 100% entro los distintos centro de costos elegidos
-- la Clave primaria es: CostCentreIDn + CostCentreRuleIDn + CompanyIDn
-- Esta informacion esa asociada al DataElement
USE applcore;

-- First you must to delete the Foreing Key Constraint;
-- The referenced applacctcostcentrerulesstructure Tables:
-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `applcore`.`applacctcostcentresrulesstructurestructure`;

CREATE TABLE `applcore`.`applacctcostcentrerulesstructure` (
        `CostCentreIDn` int NOT NULL,					-- Es el IdNum del Centro de Costos, se crea en la tabla DataElement
        `CostCentreRuleIDn` int NOT NULL,				-- Es el IdNum de la Regla de Apropiacion/CostCentreRule, se crea en la tabla BaseElement
        `CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName
		`CCRulePercentage` double NOT NULL,				-- Es el % del Centro de Costos para esa regla de apropiacion
														-- cada regla de apropiacion debe tener el 100% sumando todas las reglas de apropiacion
        `StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`CostCentreRuleIDn`,`CompanyIDn`),
		 UNIQUE KEY `CostCentreRuleCompanyIDn_UNIQUE` (`CostCentreRuleIDn`,`CompanyIDn`),
		 KEY `CostCentreRuleCompanyIDn_idx` (`CostCentreRuleIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
         KEY `CompanyIDn_idx` (`CompanyIDn`) /*!80000 INVISIBLE */,
		 CONSTRAINT `CostCentreRuleIDnCcr` FOREIGN KEY (`CostCentreRuleIDn`) REFERENCES `applcore`.`appltdataelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE,
		 CONSTRAINT `CompanyIDnCcr` FOREIGN KEY (`CompanyIDn`) REFERENCES `bpmncore`.`bpmfoutbaseelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
		DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='contiene las Estructuras de las Reglas de Apropiacion de los Centros de Costos de cada compania, 
				 Esta regla de Apropiacion debe dar el 100% entro los distintos centro de costos elegidos
				 la Clave primaria es: CostCentreIDn + CostCentreRuleIDn + CompanyIDn
				';


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - appltdatadocumentation
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`applacctcostcentrerulesstructure_BEFORE_INSERT`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `applacctcostcentrerulesstructure_BEFORE_INSERT` BEFORE INSERT ON `applacctcostcentrerulesstructure` FOR EACH ROW BEGIN
    SET new.DateCreated = CURRENT_TIMESTAMP;
    SET new.DateTimeStamp = CURRENT_TIMESTAMP;
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - applacctcostcentrerulesstructure
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`applacctcostcentrerulesstructure_BEFORE_UPDATE`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `applacctcostcentrerulesstructure_BEFORE_UPDATE` BEFORE UPDATE ON `applacctcostcentrerulesstructure` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = CURRENT_TIMESTAMP;
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(old.CostCentreIDn,"†",old.CostCentreRuleIDn,"†",old.CompanyIDn,"†",
					IF(new.CCRulePercentage = old.CCRulePercentage,"",old.CCRulePercentage),"†",
                    IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `applcore`.`applacctcostcentrerulesstructure`;