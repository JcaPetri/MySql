-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplLogTRelations table
-- contiene las relaciones posibles que puede haber entre dos registros
-- como puede ser entre carpetas, articulos, etc
-- Estas relaciones se clasifican  en tipos, Marketing, Repuestos, Comercial, etc.alter
-- Eje, Marketing = Sustitutos, Complementarios
-- Eje, Repuestos = GrupoComponente, ProductoAlternativo
-- De esta manera se puede armar una estructura de relaciones y cuando se elige un articulo, 
-- se pueden ver todos los productos que son sustitutos/Complementarios, o a que grupo de componente pertenece, etc
-- La clave primaria es Relation + Company

-- La Clave primaria, es el numero de Serie, 
USE applcore;

-- First you must to delete the Foreing Key Constraint;
-- The referenced appllogtrelations Tables:
-- ALTER TABLE `bpmcore`.`appllogtrelationsstructure`  DROP FOREIGN KEY `FolderIDnFld`;
-- ALTER TABLE `bpmcore`.`appllogtrelationsarticles`  DROP FOREIGN KEY `FolderIDnFla`;

-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `applcore`.`appllogtrelations`;

CREATE TABLE `applcore`.`appllogtrelations` (
        `RelationIDn` int NOT NULL,						-- Es el IdNum de la Relacion, se crea en la tabla applcore.dataelement
        `CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName, esta en la tabla BpmfounTCompany y se crea en la tabla BaseElement
        `RelationTypeIDn` int NOT NULL,					-- Es el IdNum del Tipo de Relacion, se crea en la tabla BaseElement
        `RelationShow` tinyint NOT NULL,				-- True = 1 se muestra, False = 0 no se muestra por defecto
        `StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`RelationIDn`,`CompanyIDn`),
		 UNIQUE KEY `RelationCompanyID_UNIQUE` (`RelationIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
		 KEY `RelationCompanyID_idx` (`RelationIDn`,`CompanyIDn`),
         KEY `CompanyID_idx` (`CompanyIDn`),
		 CONSTRAINT `RelationIDnRel` FOREIGN KEY (`RelationIDn`) REFERENCES `applcore`.`dataelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
        DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='contiene las relaciones posibles que puede haber entre dos registros
				 como puede ser entre carpetas, articulos, etc
				 Estas relaciones se clasifican  en tipos, Marketing, Repuestos, Comercial, etc.alter
				 Eje, Marketing = Sustitutos, Complementarios
				 Eje, Repuestos = GrupoComponente, ProductoAlternativo
				 De esta manera se puede armar una estructura de relaciones y cuando se elige un articulo, 
				 se pueden ver todos los productos que son sustitutos/Complementarios, o a que grupo de componente pertenece, etc
				 La clave primaria es Relation + Company
				';


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - appllogtrelations
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appllogtrelations_BEFORE_INSERT`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appllogtrelations_INSERT` BEFORE INSERT ON `appllogtrelations` FOR EACH ROW BEGIN
    SET new.DateCreated = CURRENT_TIMESTAMP;
    SET new.DateTimeStamp = CURRENT_TIMESTAMP;
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - appllogtrelations
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appllogtrelations_BEFORE_UPDATE`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appllogtrelations_BEFORE_UPDATE` BEFORE UPDATE ON `appllogtrelations` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = CURRENT_TIMESTAMP;
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(old.RelationIDn,"†",old.CompanyIDn,"†",
					IF(new.RelationTypeIDn = old.RelationTypeIDn,"",old.RelationTypeIDn),"†",
                    IF(new.RelationShow = old.RelationShow,"",old.RelationShow),"†",
					IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `applcore`.`appllogtrelations`;