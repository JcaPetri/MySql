-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplLogTFoldersArticles table
-- Contiene los articulos de cada Folders/Carpetas
-- la clave primaria, son los ArticlesIDn + el folderIDn (Tabla) + Company
-- tambien hay una restriccion del PatherRestrictionIDn para definir si dentro 
-- de la estructura del padre se pueden duplicar los articulos, Por defecto si se pueden duplicar
USE applcore;

-- First you must to delete the Foreing Key Constraint;
-- The referenced applstktserieType Tables:
-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `applcore`.`appllogtfoldersarticles`;

CREATE TABLE `applcore`.`appllogtfoldersarticles` (
        `ArticleIDn` int NOT NULL,						-- Es el IdNum del Articulo, se crea en la tabla `applcore`.`appllogtarticles`
        `FolderIDn` int NOT NULL,						-- Es el IdNum del Folder/Carpeta, se crea en la tabla `applcore`.`appllogtfolders`
        `CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName, esta en la tabla BpmfounTCompany y se crea en la tabla BaseElement
			-- La Clave primaria es Articulo + Folder + Company
		`ArticleOrder` int NOT NULL,						-- Es el Orden del articulo dentro del Folder
	    `PatherRestrictionIDn` int NOT NULL,			-- Es el IDNum del Folder/Carpeta, que genera la restriccion de duplicidad del Folder Padre 
														-- Por defecto el articulo solo esta una vez dentro de la carpeta y puede estar varias veces dentro de la carpeta Padre
                                                        -- Para evitar esto en PatherRestrictionIDn se pone el IDNum de la carpeta Padre/Abuelo/BizAbuelo, etc y de esta manera
                                                        -- El articulo solo puede estar una unica vez dentro de la estructura del Padre y todos sus hijos.
		`StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`ArticleIDn`,`FolderIDn`,`CompanyIDn`),
		 UNIQUE KEY `ArticleFolderCompanyIDn_UNIQUE` (`ArticleIDn`,`FolderIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
		 KEY `ArticleFolderCompanyIDn_idx` (`ArticleIDn`,`FolderIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
         KEY `CompanyIDn_idx` (`CompanyIDn`) /*!80000 INVISIBLE */,
		 CONSTRAINT `ArticleIDnFla` FOREIGN KEY (`ArticleIDn`) REFERENCES `applcore`.`appllogtarticles` (`ArticleIDn`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `FolderIDnFla` FOREIGN KEY (`FolderIDn`) REFERENCES `applcore`.`appllogtfolders` (`FolderIDn`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
        DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='Contiene los articulos de cada Folders/Carpetas
				 la clave primaria, son los ArticlesIDn + el folderIDn (Tabla) + Company
				 tambien hay una restriccion del PatherRestrictionIDn para definir si dentro 
				 de la estructura del padre se pueden duplicar los articulos, Por defecto si se pueden duplicar
				';


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - appllogtfoldersarticles
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appllogtfoldersarticles_BEFORE_INSERT`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appllogtfoldersarticles_INSERT` BEFORE INSERT ON `appllogtfoldersarticles` FOR EACH ROW BEGIN
    IF new.ArticleOrder IS NULL OR new.ArticleOrder = 0 OR new.ArticleOrder = '' THEN
		SET new.ArticleOrder = (SELECT ifnull(MAX(ArticleOrder),0) + 1 FROM `applcore`.`appllogtfoldersarticles` WHERE CompanyIDn = new.CompanyIDn AND FolderIDn = new.FolderIDn);
        -- Asigna el valor del ArticleOrder en forma incremental para esa Company y Folder
	END IF;
    SET new.DateCreated = CURRENT_TIMESTAMP;
    SET new.DateTimeStamp = CURRENT_TIMESTAMP;
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - appllogtfoldersarticles
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appllogtfoldersarticles_BEFORE_UPDATE`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appllogtfoldersarticles_BEFORE_UPDATE` BEFORE UPDATE ON `appllogtfoldersarticles` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = CURRENT_TIMESTAMP;
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(old.ArticleIDn,"†",old.FolderIDn,"†",old.CompanyIDn,"†",
				-- Aqui van siempre la clave primaria que no cambia
					IF(new.ArticleOrder = old.ArticleOrder,"",old.ArticleOrder),"†",
					IF(new.PatherRestrictionIDn = old.PatherRestrictionIDn,"",old.PatherRestrictionIDn),"†",
                    IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `applcore`.`appllogtfoldersarticles`;