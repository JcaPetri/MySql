-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the bldtcompcomp table
-- contiene como se forman los component, que pueden estar formados por otros Elements o Components
-- 			(Los Elements no pueden contener otros elements, son la unidad minima)
-- Como no hay registros unicos derivados de la combinacion de campos se crea un uniqueId

USE buildcore;

-- Delete the BldTCompComp Table
-- First you must to delete the Foreing Key Constraint;
-- table 'bldtcomponent' referenced by a foreign key constraint 'ComponentPIDn' on table 'bldtpricelistdetail'.
ALTER TABLE `buildcore`.`bldtpricelistdetail` DROP FOREIGN KEY `ComponentPIDn`;

DROP TABLE IF EXISTS `buildcore`.`bldtcompcomp`;

-- Create the table BldTCompComp
USE buildcore;
CREATE TABLE `bldtcompcomp` (
		`ID` char(38) COLLATE utf8mb4_bin NOT NULL,		-- Es el uniqueIdentifier
		`IDNum` int NOT NULL AUTO_INCREMENT,			-- Es un valor autonumerico
	    `ComponentPatherIDn` int NOT NULL,				-- Es el IdNum del Component Padre
	    `ComponentSonIDn` int NOT NULL,					-- Es el IdNum del Component Hijo
        `VariableComp` smallint NOT NULL,				-- Define si el Component o Element varia cuando cambia la cantidad del padre
        `CompLevel` smallint NOT NULL,					-- El nivel del Component
        `CompOrder` smallint NOT NULL,					-- El orden del Component hijo dentro dentro del component padre
-- Como varia el elemento segun la variacion del valor del padre
-- Eje: Columna, 2 metros de alto
--  			el hormigon varia por metro 3
-- 				el hierro de las columnas varian por metro lineal
-- 				los hierros de encastre no varian cuando varia el padre
	    `Quantity` decimal(4) NOT NULL DEFAULT '0',	-- Es la cantidad del elemento o componente que forma al padre
	    `UnitIDn` int NOT NULL,						-- Es el IdNum de la unidad de medida de la cantidad
		`StateIDn` smallint NOT NULL,				-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,			-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,		-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,				-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,			-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 		-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 				-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 				-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`IDNum`),
		 UNIQUE KEY `ID_UNIQUE` (`ID`) /*!80000 INVISIBLE */,
		 UNIQUE KEY `IDNum_UNIQUE` (`IDNum`),
		 KEY `ID_idx` (`ID`) /*!80000 INVISIBLE */,
         KEY `CompPather_idx` (`ComponentPatherIDn`) /*!80000 INVISIBLE */,
         KEY `CompPatherSon_idx` (`ComponentPatherIDn`,`ComponentSonIDn`) /*!80000 INVISIBLE */,
		 CONSTRAINT `ComponentPatherIDnCc` FOREIGN KEY (`ComponentPatherIDn`) REFERENCES `bldtcomponent` (`ComponentIDn`) ON DELETE CASCADE ON UPDATE CASCADE,
		 CONSTRAINT `ComponentSonIDnCc` FOREIGN KEY (`ComponentSonIDn`) REFERENCES `bldtcomponent` (`ComponentIDn`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
	AUTO_INCREMENT=0 
	DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin 
    COMMENT='contiene como se forman los component, que pueden estar formados por otros Elements o Components
			(Los Elements no pueden contener otros elements, son la unidad minima)
			Como no hay registros unicos derivados de la combinacion de campos se crea un uniqueId
			';


-- Faltan hacer los Triggers, de la tabla. Luego hacer las Tablas y empezar a Probar cargando los elementos. 
-- se pueden generar las pruebas en excel primero.

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - bldtcompcomp
-- en caso que no se ingrese desde java, establece el valor del DateCreated y el DateTimeStamp
USE buildcore;
DROP TRIGGER IF EXISTS `buildcore`.`bldtcompcomp_BEFORE_INSERT`;
DELIMITER $$
USE `buildcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `bldtcompcomp_BEFORE_INSERT` BEFORE INSERT ON `bldtcompcomp` FOR EACH ROW BEGIN
    SET new.DateCreated = ifnull(new.DateCreated,CURRENT_TIMESTAMP);
    SET new.DateTimeStamp = ifnull(new.DateTimeStamp,CURRENT_TIMESTAMP);
END$$
DELIMITER ;


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - bldtcompcomp
-- en caso que no se ingrese desde java, establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE buildcore;
DROP TRIGGER IF EXISTS `buildcore`.`bldtcompcomp_BEFORE_UPDATE`;
DELIMITER $$
USE `buildcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `bldtcompcomp_BEFORE_UPDATE` BEFORE UPDATE ON `bldtcompcomp` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = ifnull(new.DateTimeStamp,CURRENT_TIMESTAMP);
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(old.IDNum,"†",
					IF(new.ComponentPatherIDn = old.ComponentPatherIDn,"",new.ComponentPatherIDn),"†",
                    IF(new.ComponentSonIDn = old.ComponentSonIDn,"",new.ComponentSonIDn),"†",
                    IF(new.VariableComp = old.VariableComp,"",new.VariableComp),"†",
                    IF(new.CompLevel = old.CompLevel,"",new.CompLevel),"†",
                    IF(new.CompOrder = old.CompOrder,"",new.CompOrder),"†",
                    IF(new.Quantity = old.Quantity,"",new.Quantity),"†",
                    IF(new.UnitIDn = old.UnitIDn,"",new.UnitIDn),"†",
                    IF(new.StateIDn = old.StateIDn,"",new.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",new.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",new.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",new.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",new.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",new.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",new.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- List the Build Tables, from the bpmncore data base.
SELECT * FROM `buildcore`.`bldtcompcomp`;

