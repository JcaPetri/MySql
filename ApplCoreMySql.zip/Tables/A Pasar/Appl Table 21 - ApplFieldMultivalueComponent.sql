-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the AppltFieldMultivalueComponent table
-- contiene la composicion del campo multivaluado, como esta formado el mismo.
-- Ej: tres componentes (cuerpo+Escala1+Escala2) Articulos + Escala1 + Escala 2 -- 8 caracteres generales (remeras) + 4 talles (xl) + 3 color (roj)
USE applcore;

-- First you must to delete the Foreing Key Constraint;
-- The referenced appltfieldmultivalue Tables:
-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `applcore`.`appltfieldmultivaluecomponent`;

CREATE TABLE `applcore`.`appltfieldmultivaluecomponent` (
        `FieldMultivalueComponentIDn` int NOT NULL,		-- Es el IdNum del FieldMultivalueComponent, se crea en la tabla DataElement
        `FieldMultivalueIDn` int NOT NULL,				-- Es el IdNum del FieldMultivalue, se crea en la tabla DataElement
        `CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName
		`PositionOrder` tinyint NOT NULL,				-- Es el orden dentro de la estructura
		`PositionInit` tinyint NOT NULL,				-- Posicion Inicial desde donde comienza el campo. Inicialmente es 1, a medida que se agregan componentes a la estructura, va incrementando este campo
		`PositionLongChar` tinyint NOT NULL,			-- Es la cantidad de caracteres del componente
		`TextFormatIDn` int NOT NULL,					-- Es el IdNum del tipo de formato de Texto
		`FillChar` varchar(10) NOT NULL,				-- Es el caracter de relleno cuando sobran espacios en blanco
		`ComponentAutomatic` tinyint NOT NULL,			-- Determina si el sistema sugiere el valor automatico para el componente. Para realizar esto, sugiere un valor ascendente, Eje si el tipo de caracter es numerico, incrementa de 1 en 1, si es alfanumerico, sugiere una combinacion de letras, A, B, C, si fueran dos campos, seria AA, AB, AC, etc
		`FieldMultivalueComponentOpcionsIDn` int NULL,	-- Es el IDNum de las opciones para el componente. Esto se utiliza si el componente puede tener una valores predefinidos y no elegidos por el usuario. Esto se aplica si el componente es una escala, Eje escala de talles xs, x, l, xl. 
		`StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`FieldMultivalueComponentIDn`,`FieldMultivalueIDn`,`CompanyIDn`),
		 UNIQUE KEY `FieldMultivalueComponentCompanyIDn_UNIQUE` (`FieldMultivalueComponentIDn`,`FieldMultivalueIDn`,`CompanyIDn`),
		 KEY `FieldMultivalueCompanyIDn_idx` (`FieldMultivalueComponentIDn`,`FieldMultivalueIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
         CONSTRAINT `FieldMultivalueComponentIDnFmc` FOREIGN KEY (`FieldMultivalueComponentIDn`) REFERENCES `applcore`.`appltdataelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE,
		 CONSTRAINT `FieldMultivalueIDnFmc` FOREIGN KEY (`FieldMultivalueIDn`) REFERENCES `applcore`.`appltdataelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE,
		 CONSTRAINT `CompanyIDnFmc` FOREIGN KEY (`CompanyIDn`) REFERENCES `bpmncore`.`bpmfoutbaseelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
		DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='contiene la composicion del campo multivaluado, como esta formado el mismo.
				 El componente puede ser el codigo base, o Talles, o Colores, etc
				';


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - appltfieldmultivaluecomponent
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appltfieldmultivaluecomponent_BEFORE_INSERT`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appltfieldmultivaluecomponent_BEFORE_INSERT` BEFORE INSERT ON `appltfieldmultivaluecomponent` FOR EACH ROW BEGIN
    SET new.DateCreated = CURRENT_TIMESTAMP;
    SET new.DateTimeStamp = CURRENT_TIMESTAMP;
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - appltfieldmultivaluecomponent
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appltfieldmultivaluecomponent_BEFORE_UPDATE`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appltfieldmultivaluecomponent_BEFORE_UPDATE` BEFORE UPDATE ON `appltfieldmultivaluecomponent` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = CURRENT_TIMESTAMP;
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(old.FieldMultivalueComponentIDn,"†",
					old.FieldMultivalueIDn,"†",
					old.CompanyIDn,"†",
					IF(new.PositionOrder = old.PositionOrder,"",old.PositionOrder),"†",
                    IF(new.PositionInit = old.PositionInit,"",old.PositionInit),"†",
                    IF(new.PositionLongChar = old.PositionLongChar,"",old.PositionLongChar),"†",
                    IF(new.TextFormatIDn = old.TextFormatIDn,"",old.TextFormatIDn),"†",
                    IF(new.FillChar = old.FillChar,"",old.FillChar),"†",
                    IF(new.ComponentAutomatic = old.ComponentAutomatic,"",old.ComponentAutomatic),"†",
                    IF(new.FieldMultivalueComponentOpcionsIDn = old.FieldMultivalueComponentOpcionsIDn,"",old.FieldMultivalueComponentOpcionsIDn),"†",
                    IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `applcore`.`appltfieldmultivaluecomponent`;