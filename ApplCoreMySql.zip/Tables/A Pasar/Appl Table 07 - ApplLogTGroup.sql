-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplLogTGroup table
-- contiene las Groups/Partidas permiten llevar el stock del articulo por grupos segun un criterio definido, 
-- Ej por unidad de compra (es util para las importaciones), por lotes de vecimientos (Ej los medicamentos), o el criterio definido.
-- La partida puede tener distintas propiedades, por lo tanto, puede haber una tabla con las propiedades de cada partida.  

-- La Clave primaria, es el numero de Serie, 
USE applcore;

-- First you must to delete the Foreing Key Constraint;
-- The referenced appllogtgroup Tables:
ALTER TABLE `bpmcore`.`appllogtgroupproperty`  DROP FOREIGN KEY `GroupIDnPop`;

-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `applcore`.`appllogtgroup`;

CREATE TABLE `applcore`.`appllogtgroup` (
        `ID` char(38) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,					-- Es el ID UniqueIdentifier, valor unico del registro
		`IDNum` int NOT NULL AUTO_INCREMENT,												-- Es el IDNum valor numerico incremental, valor unico del registro
        `GroupIDn` int NOT NULL,						-- Es el IdNum del Group/Partida, se crea en la tabla bpmfoutbaseelement, ya que es una Tabla estructura del Sistema
        `GroupName` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,			-- Código en letras del ID
        `CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName, esta en la tabla BpmfounTCompany y se crea en la tabla BaseElement
        `GroupBarCode` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,			-- Código en letras del ID
		`GroupStateIDn` smallint NOT NULL,				-- Es el estado del Group/Partida, HabIng=Habilitado para el Ingreso solamente / HabEgr=Habilitado para el Egreso solamente / HabIyE=Habilitado para el Ingreso y Egreso / NoHabi=No Habilitada, partida cerrada
        `DateExpiration` datetime NOT NULL,				-- Es la fecha de vencimiento de la partida
        `StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`IDNum`),
		 UNIQUE KEY `ID_UNIQUE` (`ID`) /*!80000 INVISIBLE */,
		 UNIQUE KEY `IDNum_UNIQUE` (`IDNum`),
		 UNIQUE KEY `GroupNameCompanyIDn_UNIQUE` (`GroupIDn`,`GroupName`,`CompanyIDn`),
		 CONSTRAINT `GroupIDnGrp` FOREIGN KEY (`GroupIDn`) REFERENCES `applcore`.`bpmfoutbaseelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
		AUTO_INCREMENT=0 
        DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='contiene las Groups/Partidas permiten llevar el stock del articulo por grupos segun un criterio definido, 
				 Ej por unidad de compra (es util para las importaciones), por lotes de vecimientos (Ej los medicamentos), o el criterio definido.
				 La partida puede tener distintas propiedades, por lo tanto, puede haber una tabla con las propiedades de cada partida.  
				';


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - appllogtgroup
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appllogtgroup_BEFORE_INSERT`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appllogtgroup_INSERT` BEFORE INSERT ON `appllogtgroup` FOR EACH ROW BEGIN
    SET new.DateCreated = CURRENT_TIMESTAMP;
    SET new.DateTimeStamp = CURRENT_TIMESTAMP;
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - appllogtgroup
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appllogtgroup_BEFORE_UPDATE`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appllogtgroup_BEFORE_UPDATE` BEFORE UPDATE ON `appllogtgroup` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = CURRENT_TIMESTAMP;
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(old.GroupIDn,"†",
					IF(new.GroupName = old.GroupName,"",old.GroupName),"†",
					IF(new.CompanyIDn = old.CompanyIDn,"",old.CompanyIDn),"†",
                    IF(new.GroupBarCode = old.GroupBarCode,"",old.GroupBarCode),"†",
					IF(new.GroupStateIDn = old.GroupStateIDn,"",old.GroupStateIDn),"†",
                    IF(new.DateExpiration = old.DateExpiration,"",old.DateExpiration),"†",
                    IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `applcore`.`appllogtgroup`;