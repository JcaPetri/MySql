-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplLogTFoldersStructure table
-- contiene la estructura de los Folders/Carpetas dentro de la empresa
-- Esta estructura esta organizada en un esquema Padre/hijo
-- Las columnas FolderSonIDn y FolderPatherIDn se cargan con los IDNum de esta misma tabla
-- Cuando es el Primer Nivel, el Padre = Hijo, como el padre es Autonumerico, luego que se define el valor se lo carga al hijo
-- Puede haber un Folder General, que a su vez tenga otros SubFolder
-- De esta manera se puede obtener distintos informes
-- La clave primaria es IDNum, que esta tiene la combinacion Padre/Hijo inicial

-- La Clave primaria, es el numero de Serie, 
USE applcore;

-- First you must to delete the Foreing Key Constraint;
-- The referenced appllogtfoldersstructure Tables:
-- ALTER TABLE `bpmcore`.`appllogtfoldersstructurestructure`  DROP FOREIGN KEY `WarehouseIDnWhp`;

-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `applcore`.`appllogtfoldersstructure`;

CREATE TABLE `applcore`.`appllogtfoldersstructure` (
		`FolderSonIDn` int NOT NULL AUTO_INCREMENT,		-- Es un valor autonumerico, es el valor del FolderSon
        `FolderPatherIDn` int NOT NULL,					-- Es el IdNum del WarehousePatherIDn, viene del FolderSonIDn
        -- Cuando es el Primer Nivel, el Padre = Hijo, como el padre es Autonumerico, luego que se define el valor se lo carga al hijo
        `FolderIDn` int NOT NULL,						-- Es el IdNum del Folder que esta asociada a la estructura
	    `CompLevel` smallint NOT NULL,					-- El nivel del Folder
        `CompOrder` smallint NOT NULL,					-- El orden del Folder hijo dentro dentro del Folder padre
        `FolderRestriction` tinyint NOT NULL,			-- Si el Valor es True = 1, el Valor del FolderPatherIDn se carga en todos los hijos
														-- de esta manera, se hace la segunda restriccion
                                                        -- Si el Valor es False = 0, el Valor del FolderSonIDn se carga y no hay doble restriccion
        `PatherRestrictionIDn` int NOT NULL,			-- Si el valor es igual a FolderSonIDn, quiere decir que la unica restriccion es solo de esta carpeta
                                                        -- si es tiene el valor del Padre/Abuelo/BizAbuelo, quiere decir que el articulo solo puede estar en un solo hijo dentro de esta estructura
                                                        -- y los hijos tiene el IDNum en el campo FolderRestrictionIDn, por lo tanto hay una doble restriccion
                                                        -- la primera no puede estar duplicado el articulo dentro del folder y luego no puede estar duplicado dentro del padre
        `CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName, esta en la tabla BpmfounTCompany y se crea en la tabla BaseElement
        `StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`FolderSonIDn`),
		 UNIQUE KEY `FolderSonIDn` (`FolderSonIDn`) /*!80000 INVISIBLE */,
		 UNIQUE KEY `FolderPatherSonIDn_UNIQUE` (`FolderSonIDn`,`FolderPatherIDn`),
		 KEY `FolderSonIDn_idx` (`FolderSonIDn`) /*!80000 INVISIBLE */,
		 KEY `FolderPatherSonIDn_idx` (`FolderSonIDn`,`FolderPatherIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
		 KEY `CompanyIDn_idx` (`CompanyIDn`),
		 CONSTRAINT `FolderPatherIDnFld` FOREIGN KEY (`FolderPatherIDn`) REFERENCES `applcore`.`appllogtfoldersstructure` (`WarehouseSonIDn`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `FolderIDnFld` FOREIGN KEY (`FolderIDn`) REFERENCES `applcore`.`appllogtfolders` (`FolderIDn`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
		AUTO_INCREMENT=0
        DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='contiene la estructura de los Folders/Carpetas dentro de la empresa
				 Esta estructura esta organizada en un esquema Padre/hijo
				 Las columnas FolderSonIDn y FolderPatherIDn se cargan con los IDNum de esta misma tabla
				 Cuando es el Primer Nivel, el Padre = Hijo, como el padre es Autonumerico, luego que se define el valor se lo carga al hijo
				 Puede haber un Folder General, que a su vez tenga otros SubFolder
				 De esta manera se puede obtener distintos informes
				 La clave primaria es IDNum, que esta tiene la combinacion Padre/Hijo inicial
				';


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - appllogtfoldersstructure
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appllogtfoldersstructure_BEFORE_INSERT`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appllogtfoldersstructure_INSERT` BEFORE INSERT ON `appllogtfoldersstructure` FOR EACH ROW BEGIN
    SET new.DateCreated = CURRENT_TIMESTAMP;
    SET new.DateTimeStamp = CURRENT_TIMESTAMP;
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - appllogtfoldersstructure
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appllogtfoldersstructure_BEFORE_UPDATE`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appllogtfoldersstructure_BEFORE_UPDATE` BEFORE UPDATE ON `appllogtfoldersstructure` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = CURRENT_TIMESTAMP;
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(old.FolderSonIDn,"†",
					IF(new.FolderPatherIDn = old.FolderPatherIDn,"",old.FolderPatherIDn),"†",
					IF(new.FolderIDn = old.FolderIDn,"",old.FolderIDn),"†",
                    IF(new.CompLevel = old.CompLevel,"",old.CompLevel),"†",
                    IF(new.CompOrder = old.CompOrder,"",old.CompOrder),"†",
                    IF(new.FolderRestriction = old.FolderRestriction,"",old.FolderRestriction),"†",
                    IF(new.PatherRestrictionIDn = old.PatherRestrictionIDn,"",old.PatherRestrictionIDn),"†",
                    IF(new.CompanyIDn = old.CompanyIDn,"",old.CompanyIDn),"†",
					IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `applcore`.`appllogtfoldersstructure`;