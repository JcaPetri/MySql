-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the AppltFieldMultivalue table
-- contiene el nombre de la estructura del campo multivaluado, 
-- esta estructura en la tabla FieldMultivalueComponent esta la informacion de como se debe leer este informacion que se guarda en el campo
-- Ej: Articulos + Escala1 + Escala 2 -- 8 caracteres generales (remeras) + 4 talles (xl) + 3 color (roj)
-- Como esta informacion esa asociada al DataElement, quiere decir que para un IDName + Scope + Company + Language puede tener un valor distinto
USE applcore;

-- First you must to delete the Foreing Key Constraint;
-- The referenced appltfieldmultivalue Tables:
-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `applcore`.`appltfieldmultivalue`;

CREATE TABLE `applcore`.`appltfieldmultivalue` (
        `FieldMultivalueIDn` int NOT NULL,				-- Es el IdNum del FieldMultivalue, se crea en la tabla DataElement
        `CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName
		`FieldMultivalueTypeIDn` int NOT NULL,			-- Es el IdNum del tipo de campo multivaluado, Ej: texto liso, Compuesto, etc
		`FieldLong` smallint NOT NULL,					-- Longitud en caracteres del campo multivaluado Este es el largo total del articulo incluyendo las escalas
		`StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`FieldMultivalueIDn`,`CompanyIDn`),
		 UNIQUE KEY `FieldMultivalueCompanyIDn_UNIQUE` (`FieldMultivalueIDn`,`CompanyIDn`),
		 KEY `FieldMultivalueCompanyIDn_idx` (`FieldMultivalueIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
		 CONSTRAINT `FieldMultivalueIDnFm` FOREIGN KEY (`FieldMultivalueIDn`) REFERENCES `applcore`.`appltdataelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE,
		 CONSTRAINT `CompanyIDnDc` FOREIGN KEY (`CompanyIDn`) REFERENCES `bpmncore`.`bpmfoutbaseelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
		DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='contiene el nombre de la estructura del campo multivaluado. 
				 Esto permite que dentro de un Field (campo), pueda guardarse informacion que se puede estructurar y separar.
				';


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - appltdatadocumentation
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appltfieldmultivalue_BEFORE_INSERT`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appltfieldmultivalue_BEFORE_INSERT` BEFORE INSERT ON `appltfieldmultivalue` FOR EACH ROW BEGIN
    SET new.DateCreated = CURRENT_TIMESTAMP;
    SET new.DateTimeStamp = CURRENT_TIMESTAMP;
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - appltfieldmultivalue
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appltfieldmultivalue_BEFORE_UPDATE`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appltfieldmultivalue_BEFORE_UPDATE` BEFORE UPDATE ON `appltfieldmultivalue` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = CURRENT_TIMESTAMP;
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(old.FieldMultivalueIDn,"†",
					old.CompanyIDn,"†",
					IF(new.FieldMultivalueTypeIDn = old.FieldMultivalueTypeIDn,"",old.FieldMultivalueTypeIDn),"†",
					IF(new.FieldLong = old.FieldLong,"",old.FieldLong),"†",
                    IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `applcore`.`appltfieldmultivalue`;