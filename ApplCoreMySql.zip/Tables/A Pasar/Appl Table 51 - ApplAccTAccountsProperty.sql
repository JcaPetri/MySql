-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplAccTAccountsProperty table
-- Contiene las propiedades de las Accounts/Cuentas que son opcionales
-- en esta tabla se cargan las columna opcionales
-- la clave primaria, es la propiedad (columna) AccountPropertyIDn + el AccountIDn (Tabla) + CompanyIDn

/*
        -- Campos opcionales
		`CostCentre`,			True = 1, False = 0, lleva o no centro de costos
        `CostCentreRuleIDn`,	el IdNum de la regla de apropiacion del centro de costos para la cuenta, 
								Las reglas de apropiación son criterios predefinidos que manejan porcentajes para los distintos centros de costo
                                Si no tiene regla de apropiacion, esta se carga al momento de cargar el asiento
					ACLARACION: Si la cuenta lleva centro de costos, y no se cargan por una regla de apropiacion, los asientos quedan pendientes
								Por lo tanto, es importante si lleva Centro de Costos, tener si o si una regla de Apropiacion CostCenterRule
		`TradableAccount`,	True = 1, False = 0, la cuenta sólo podrá ser cotizable en asientos si el campo se activa este parámetro.
		`TradableIndexIDn`,		el IdNum del Indice por el que cotiza la cuenta, El índice estará previamente definido en la opción de Indices.

		`CommentAccount`, el IdNum de los comentarios habituales de los asientos ingresados
						-- la cuenta puede tener varios comentarios, esto se puede hacer a travez de la tabla DataDocumentation

*/
USE applcore;

-- First you must to delete the Foreing Key Constraint;
-- The referenced ApplAccTAccountsProperty Tables:
-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `applcore`.`applacctaccountsproperty`;

CREATE TABLE `applcore`.`applacctaccountsproperty` (
        `AccountPropertyIDn` int NOT NULL,				-- Es el IdNum de la propiedad de la Account/Cuenta (Columna de la Tabla), se crea en la tabla bpmfoutbaseelement
        `AccountIDn` int NOT NULL,						-- Es el IdNum del Account/Cuenta, se crea en la tabla bpmfoutbaseelement
        `CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName, esta en la tabla BpmfounTCompany y se crea en la tabla BaseElement
		`PropertyValueIDn` int NOT NULL,				-- Es el IDNum del valor de esa Propiedad, este valor se carga en el DataElement
		`OptionValue` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,	-- Es un valor opcional para la propiedad
		`StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`AccountPropertyIDn`,`AccountIDn`,`CompanyIDn`),
		 UNIQUE KEY `AccountPropertyCompanyIDn_UNIQUE` (`AccountPropertyIDn`,`AccountIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
		 KEY `AccountPropertyCompanyIDn_idx` (`AccountPropertyIDn`,`AccountIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
         KEY `CompanyIDn_idx` (`CompanyIDn`) /*!80000 INVISIBLE */,
		 CONSTRAINT `AccountPropertyIDnAcp` FOREIGN KEY (`AccountPropertyIDn`) REFERENCES `bpmcore`.`bpmfoutbaseelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `AccountIDnAcp` FOREIGN KEY (`AccountIDn`) REFERENCES `applcore`.`appllogtfolders` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
        DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='Contiene las propiedades de las Accounts/Cuentas que son opcionales
				 en esta tabla se cargan las columna opcionales
				 la clave primaria, es la propiedad (columna) AccountPropertyIDn + el AccountIDn (Tabla) + CompanyIDn
				';


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - applacctaccountsproperty
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`applacctaccountsproperty_BEFORE_INSERT`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `applacctaccountsproperty_INSERT` BEFORE INSERT ON `applacctaccountsproperty` FOR EACH ROW BEGIN
    SET new.DateCreated = CURRENT_TIMESTAMP;
    SET new.DateTimeStamp = CURRENT_TIMESTAMP;
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - applacctaccountsproperty
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`applacctaccountsproperty_BEFORE_UPDATE`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `applacctaccountsproperty_BEFORE_UPDATE` BEFORE UPDATE ON `applacctaccountsproperty` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = CURRENT_TIMESTAMP;
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(old.AccountPropertyIDn,"†",old.AccountIDn,"†",old.CompanyIDn,"†",
				-- Aqui van siempre la clave primaria que no cambia
					IF(new.PropertyValueIDn = old.PropertyValueIDn,"",old.PropertyValueIDn),"†",
					IF(new.OptionValue = old.OptionValue,"",old.OptionValue),"†",
                    IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `applcore`.`applacctaccountsproperty`;