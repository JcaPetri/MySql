-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the applmkttcampaignarticlegroupGroup table
-- Contiene los articulos asociados a las distintas Campaign de Marketing
-- la clave primaria, es el Articulo + el campaignIDn (Tabla) + Company
USE applcore;

-- First you must to delete the Foreing Key Constraint;
-- The referenced applstktserieType Tables:
-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `applcore`.`applmkttcampaignarticlegroup`;

CREATE TABLE `applcore`.`applmkttcampaignarticlegroup` (
        `ArticleGroupIDn` int NOT NULL,					-- Es el IdNum del Grupo de Articulo, se crea en la tabla `applcore`.`appllogtarticles`
        `CampaignIDn` int NOT NULL,						-- Es el IdNum de la Tabla Campaign, se crea en la tabla `applcore`.`applmkttcampaign`
        `CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName, esta en la tabla BpmfounTCompany y se crea en la tabla `bpmcore`.`bpmfoutbaseelement`
		`StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`ArticleGroupIDn`,`CampaignIDn`,`CompanyIDn`),
		 UNIQUE KEY `ArticleCampaignCompanyIDn_UNIQUE` (`ArticleGroupIDn`,`CampaignIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
		 KEY `ArticleCampaignCompanyIDn_idx` (`ArticleGroupIDn`,`CampaignIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
		 CONSTRAINT `ArticleGroupIDnCmg` FOREIGN KEY (`ArticleIDn`) REFERENCES `applcore`.`appllogtarticles` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `CampaignIDnCmg` FOREIGN KEY (`CampaignIDn`) REFERENCES `applcore`.`applmkttcampaign` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
        DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='Contiene los articulos asociados a las distintas Campaign de Marketing
				 la clave primaria, es el Articulo + el campaignIDn (Tabla) + Company
				';


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - applmkttcampaignarticlegroup
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`applmkttcampaignarticlegroup_BEFORE_INSERT`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `applmkttcampaignarticlegroup_INSERT` BEFORE INSERT ON `applmkttcampaignarticlegroup` FOR EACH ROW BEGIN
    SET new.DateCreated = CURRENT_TIMESTAMP;
    SET new.DateTimeStamp = CURRENT_TIMESTAMP;
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - applmkttcampaignarticlegroup
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`applmkttcampaignarticlegroup_BEFORE_UPDATE`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `applmkttcampaignarticlegroup_BEFORE_UPDATE` BEFORE UPDATE ON `applmkttcampaignarticlegroup` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = CURRENT_TIMESTAMP;
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(old.ArticleGroupIDn,"†",old.CampaignIDn,"†",old.CompanyIDn,"†",
				-- Aqui van siempre la clave primaria que no cambia
                    IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `applcore`.`applmkttcampaignarticlegroup`;