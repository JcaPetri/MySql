-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplLogTArticlesSupplierEquivalents table
-- contiene las equivalencias entre los articulos de los distintos Suppliers/Proveedores
-- en la tabla appllogtarticlessuppliersarticles, esta asociado cada articulo con un cada Supplier/Proveedor, un mismo articulo esta repetido multiples veces
-- aqui esta la informacion de cuantos proveedores venden el mismo articulo, esta realacion se hace manualmente, lo que nos asegura que la comparacion sea precisa
-- En esta tabla se guarda la relacion de un mismo articulo para cada porveedor, sobre los articulosLo que hay que hacer para relacionar los distintos proveedores de un articulo, es hacer una consulta tipo tabla dinamica, 
-- donde en la primer columna este el articulo, y en las otras columnas esten los distintos proveedores de ese articulo
-- como el vinculo es nuestro articulo y la asociacion del articulo del proveedor a nuestro articulo esta hecha manualmente, es que luego la comparacion es precisa

-- la clave primaria: es el ArticleSupplierFrom + SupplierFromIDn + ArticleSupplierTo + SupplierToIDn + CompanyIDn
USE ApplCore;

-- First you must to delete the Foreing Key Constraint;
-- The referenced ApplLogTArticlesSupplierEquivalents Tables:
-- 	ALTER TABLE `BpmCore`.`appllogtstock` DROP FOREIGN KEY `ArticleIDnStk`;

-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `ApplCore`.`ApplLogTArticlesSupplierEquivalents`;

CREATE TABLE `ApplCore`.`ApplLogTArticlesSupplierEquivalents` (
		`ArticleSupplierFrom` varchar(38) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,		-- Es Codigo Unico de identificacion del articulo para ese Supplier/Proveedor
        `SupplierFromIDn` int NOT NULL,																-- Es el IdNum del Supplier/Proveedor, esta en la tabla ApplTPersons
		`ArticleSupplierTo` varchar(38) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,			-- Es Codigo Unico de identificacion del articulo para ese Supplier/Proveedor
        `SupplierToIDn` int NOT NULL,																-- Es el IdNum del Supplier/Proveedor, esta en la tabla ApplTPersons
		`CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName
				-- la clave primaria: es el ArticleSupplierFrom + SupplierFromIDn + ArticleSupplierTo + SupplierToIDn + CompanyIDn
		`StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`ArticleSupplierFrom`,`SupplierFromIDn`,`ArticleSupplierTo`,`SupplierToIDn`,`CompanyIDn`),
		 UNIQUE KEY `ArtSuppFromArtSuppToCompanyIDn_UNIQUE` (`ArticleSupplierFrom`,`SupplierFromIDn`,`ArticleSupplierTo`,`SupplierToIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
		 KEY `ArtSuppFromArtSuppToCompanyIDn_idx` (`ArticleSupplierFrom`,`SupplierFromIDn`,`ArticleSupplierTo`,`SupplierToIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
         KEY `StateCompanyIDn_idx` (`StateIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
         CONSTRAINT `SupplierIDnSpA` FOREIGN KEY (`ArticleSupplierFrom`) REFERENCES `ApplCore`.`ApplTPersons` (`PersonIDn`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `CompanyIDnSpA` FOREIGN KEY (`CompanyIDn`) REFERENCES `BpmCore`.`systcompanies` (`CompanyIDn`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
		DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='contiene las equivalencias entre los articulos de los distintos Suppliers/Proveedores
				 cada Supplier/Proveedor puede vender el mismo producto, pero en su sistema tiene un codigo distinto
				 en esta tabla se realizan las equivalencias de los mismos
				 la clave primaria: es el ArticleSupplierFrom + SupplierIDnFrom + ArticleSupplierTo + SupplierIDnTo + CompanyIDn
				';


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - ApplLogTArticlesSupplierEquivalents
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE ApplCore;
DROP TRIGGER IF EXISTS `ApplCore`.`ApplLogTArticlesSupplierEquivalents_BEFORE_INSERT`;
DELIMITER $$
USE `ApplCore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `ApplLogTArticlesSupplierEquivalents_BEFORE_INSERT` BEFORE INSERT ON `ApplLogTArticlesSupplierEquivalents` FOR EACH ROW BEGIN
    SET new.DateCreated = ifnull(new.DateCreated,current_timestamp);
    SET new.DateTimeStamp = ifnull(new.DateTimeStamp,current_timestamp);
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - ApplLogTArticlesSupplierEquivalents
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE ApplCore;
DROP TRIGGER IF EXISTS `ApplCore`.`ApplLogTArticlesSupplierEquivalents_BEFORE_UPDATE`;
DELIMITER $$
USE `ApplCore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `ApplLogTArticlesSupplierEquivalents_BEFORE_UPDATE` BEFORE UPDATE ON `ApplLogTArticlesSupplierEquivalents` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = ifnull(new.DateTimeStamp,current_timestamp);
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(old.ArticleSupplierFrom,"†",
									  old.SupplierFromIDn,"†",
									  old.ArticleSupplierTo,"†",
                                      old.SupplierToIDn,"†",
                                      old.CompanyIDn,"†",
						-- la clave primaria: es el ArticleSupplierFrom + SupplierFromIDn + ArticleSupplierTo + SupplierToIDn + CompanyIDn
                    IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `ApplCore`.`ApplLogTArticlesSupplierEquivalents`;