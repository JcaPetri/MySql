-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplLogTSerie table
-- contiene las series de los articulos del stock 
-- Cuando se maneja Series se lleva el stock por unidad, o sea cada item es un valor de stock. 
-- A su vez la cantidad de series habilitadas de un articulo, deben ser igual a la cantidad de stock del mismo.
-- Las series deshabilitadas son las que se han vendido
-- Ej: El ejemplo tipico es llevar el stock de los autos, cada auto tiene un numero de serie 
-- La Clave primaria, es el numero de Serie, 
USE applcore;

-- First you must to delete the Foreing Key Constraint;
-- The referenced appllogtserie Tables:
-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `applcore`.`appllogtserie`;

CREATE TABLE `applcore`.`appllogtserie` (
        `ID` char(38) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,					-- Es el ID UniqueIdentifier, valor unico del registro
		`IDNum` int NOT NULL AUTO_INCREMENT,												-- Es el IDNum valor numerico incremental, valor unico del registro
        `ArticleIDn` int NOT NULL,						-- Es el IdNum del Articulo, se crea en la tabla DataElement
        `CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName, esta en la tabla BpmfounTCompany y se crea en la tabla BaseElement
        `SerieStateIDn` int NOT NULL,					-- Es el IdNum del estado de la Serie, Ej: en stock, comprometida, pedida, vendida, etc
		`PartidaIDn` smallint NOT NULL,					-- Es el IdNum de la Partida a la que pertenece la Serie, esta en la tabla ApplTPartida y se crea en la tabla DataElement
		`StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`IDNum`),
		 UNIQUE KEY `ID_UNIQUE` (`ID`) /*!80000 INVISIBLE */,
		 UNIQUE KEY `IDNum_UNIQUE` (`IDNum`),
		 UNIQUE KEY `FieldMultivalueCompanyIDn_UNIQUE` (`FieldMultivalueIDn`,`CompanyIDn`),
		 CONSTRAINT `ArticleIDnSer` FOREIGN KEY (`ArticleIDn`) REFERENCES `applcore`.`applstktarticles` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
		AUTO_INCREMENT=0 
        DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='Contiene las series de los articulos del stock 
				 Cuando se maneja Series se lleva el stock por unidad, o sea cada item es un valor de stock. 
				 A su vez la cantidad de series habilitadas de un articulo, deben ser igual a la cantidad de stock del mismo.
				 Las series deshabilitadas son las que se han vendido
				 Ej: El ejemplo tipico es llevar el stock de los autos, cada auto tiene un numero de serie 
				 La Clave primaria, es el numero de Serie,
				';


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - appllogtserie
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appllogtserie_BEFORE_INSERT`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appllogtserie_INSERT` BEFORE INSERT ON `appllogtserie` FOR EACH ROW BEGIN
    SET new.DateCreated = CURRENT_TIMESTAMP;
    SET new.DateTimeStamp = CURRENT_TIMESTAMP;
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - appllogtserie
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appllogtserie_BEFORE_UPDATE`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appllogtserie_BEFORE_UPDATE` BEFORE UPDATE ON `appllogtserie` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = CURRENT_TIMESTAMP;
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(old.IDNum,"†",
					IF(new.ArticleIDn = old.ArticleIDn,"",old.ArticleIDn),"†",
					IF(new.CompanyIDn = old.CompanyIDn,"",old.CompanyIDn),"†",
                    IF(new.SerieStateIDn = old.SerieStateIDn,"",old.SerieStateIDn),"†",
					IF(new.PartidaIDn = old.PartidaIDn,"",old.PartidaIDn),"†",
                    IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `applcore`.`appllogtserie`;