-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplLogTGroupProperty table
-- Contiene las columnas/fields/propiedades de la Tabla appllogtgroup (Partida/Group) que son opcionales
-- en esta tabla se cargan las columna opcionales
-- la clave primaria, es la propiedad (columna) + el groupIDn (Tabla) + Company
USE applcore;

-- First you must to delete the Foreing Key Constraint;
-- The referenced applstktserieType Tables:
-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `applcore`.`appllogtgroupproperty`;

CREATE TABLE `applcore`.`appllogtgroupproperty` (
        `GroupPropertyIDn` int NOT NULL,				-- Es el IdNum de la propiedad del Group/Partida (Columna de la Tabla), se crea en la tabla bpmfoutbaseelement
        `GroupIDn` int NOT NULL,						-- Es el IdNum del Group/Partida, se crea en la tabla bpmfoutbaseelement
        `CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName, esta en la tabla BpmfounTCompany y se crea en la tabla BaseElement
		`PropertyValueIDn` int NOT NULL,			-- Es el IDNum del valor de esa Propiedad, 0 = false, 1 = true, el resto se vincula con la tabla BaseElement
		`OptionValue` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,	-- Es un valor opcional para la propiedad
		`StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`GroupPropertyIDn`,`GroupIDn`,`CompanyIDn`),
		 UNIQUE KEY `GroupPropertyCompanyIDn_UNIQUE` (`GroupPropertyIDn`,`GroupIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
		 KEY `GroupPropertyCompanyIDn_idx` (`GroupPropertyIDn`,`GroupIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
		 CONSTRAINT `GroupPropertyIDnPop` FOREIGN KEY (`GroupPropertyIDn`) REFERENCES `bpmcore`.`bpmfoutbaseelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `GroupIDnPop` FOREIGN KEY (`GroupIDn`) REFERENCES `applcore`.`applstktgroup` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
        DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='Contiene las columnas/fields/propiedades de la Tabla appllogtgroup (Partida/Group) que son opcionales
				 en esta tabla se cargan las columna opcionales
				 la clave primaria, es la propiedad (columna) + el groupIDn (Tabla) + Company
                 los valores de la propiedad pueden ser un Valor ID o un Texto
				';


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - appllogtgroupproperty
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appllogtgroupproperty_BEFORE_INSERT`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appllogtgroupproperty_INSERT` BEFORE INSERT ON `appllogtgroupproperty` FOR EACH ROW BEGIN
    SET new.DateCreated = CURRENT_TIMESTAMP;
    SET new.DateTimeStamp = CURRENT_TIMESTAMP;
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - appllogtgroupproperty
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appllogtgroupproperty_BEFORE_UPDATE`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appllogtgroupproperty_BEFORE_UPDATE` BEFORE UPDATE ON `appllogtgroupproperty` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = CURRENT_TIMESTAMP;
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(old.GroupPropertyIDn,"†",old.GroupIDn,"†",old.CompanyIDn,"†",
				-- Aqui van siempre la clave primaria que no cambia
					IF(new.PropertyValueIDn = old.PropertyValueIDn,"",old.PropertyValueIDn),"†",
					IF(new.OptionValue = old.OptionValue,"",old.OptionValue),"†",
                    IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `applcore`.`appllogtgroupproperty`;