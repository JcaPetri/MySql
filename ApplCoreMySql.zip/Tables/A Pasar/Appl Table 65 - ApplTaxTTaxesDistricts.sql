-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the AppltTaxTTaxesDistricts table
-- contiene los vinculos entres los Taxes/Impuestos y los Districts/Regiones de cada compania, 
-- la Clave primaria es: TaxIDn + TaxDistrictIDn + CompanyIDn
-- la tabla TaxesDistricts, ya que:
--      Un Tax/Impuesto se puede aplicar a multiples areas (el Iva puede estar en dos regiones distinas)
--      Un District/Region puede tener multiples impuestos (el area Cordoba puede tener multiples impuestos)
USE applcore;

-- First you must to delete the Foreing Key Constraint;
-- The referenced appltaxttaxesdistricts Tables:
-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `applcore`.`appltaxttaxesdistricts`;

CREATE TABLE `applcore`.`appltaxttaxesdistricts` (
        `TaxIDn` int NOT NULL,							-- Es el IdNum del Impuesto/Tax, se crea en la tabla DataElement
        `TaxDistrictIDn` int NOT NULL,					-- Es el IdNum del District, se crea en la tabla BaseElement
        `CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName
		`StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`TaxIDn`,`TaxDistrictIDn`,`CompanyIDn`),
		 UNIQUE KEY `TaxDistrictCompanyIDn_UNIQUE` (`TaxIDn`,`TaxDistrictIDn`,`CompanyIDn`),
		 KEY `TaxDistrictCompanyIDn_idx` (`TaxIDn`,`TaxDistrictIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
         KEY `CompanyIDn_idx` (`CompanyIDn`) /*!80000 INVISIBLE */,
		 CONSTRAINT `TaxIDnTdt` FOREIGN KEY (`TaxIDn`) REFERENCES `applcore`.`appltaxttaxes` (`TaxIDn`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `TaxDistrictIDnTdt` FOREIGN KEY (`TaxDistrictIDn`) REFERENCES `applcore`.`appltaxtdistricts` (`TaxDistrictIDn`) ON DELETE CASCADE ON UPDATE CASCADE,
		 CONSTRAINT `CompanyIDnTdt` FOREIGN KEY (`CompanyIDn`) REFERENCES `bpmncore`.`bpmfoutbaseelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
		DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='contiene los vinculos entres los Taxes/Impuestos y los Districts/Regiones de cada compania, 
				 la Clave primaria es: TaxIDn + TaxDistrictIDn + CompanyIDn
				 la tabla TaxesDistricts, ya que:
				      Un Tax/Impuesto se puede aplicar a multiples areas (el Iva puede estar en dos regiones distinas)
				      Un District/Region puede tener multiples impuestos (el area Cordoba puede tener multiples impuestos)
				';


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - appltdatadocumentation
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appltaxttaxesdistricts_BEFORE_INSERT`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appltaxttaxesdistricts_BEFORE_INSERT` BEFORE INSERT ON `appltaxttaxesdistricts` FOR EACH ROW BEGIN
    SET new.DateCreated = CURRENT_TIMESTAMP;
    SET new.DateTimeStamp = CURRENT_TIMESTAMP;
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - appltaxttaxesdistricts
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appltaxttaxesdistricts_BEFORE_UPDATE`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appltaxttaxesdistricts_BEFORE_UPDATE` BEFORE UPDATE ON `appltaxttaxesdistricts` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = CURRENT_TIMESTAMP;
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(old.TaxIDn,"†",old.TaxDistrictIDn,"†",old.CompanyIDn,"†",
                    IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `applcore`.`appltaxttaxesdistricts`;