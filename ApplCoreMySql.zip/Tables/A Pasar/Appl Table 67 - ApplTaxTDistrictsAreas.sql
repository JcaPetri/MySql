-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplTaxTDistrictsAreas table
-- contiene la estructura de los Distritos Impositivos/Tax Districts dentro de la empresa
-- Esta estructura se organiza asociando a un District/Region una lista de Areas que 
-- estan definidas en la base BpmCore segun norma ISO
-- Los Paises, Provincia, Regiones, Ciudades, Municipios, Comunas o el esquema que se desee
-- lo importante es que se detalle que lugares pertenece a un determinado distrito
-- la Clave primaria es: TaxDistrictIDn + TaxAreaIDn + CompanyIDn

-- La Clave primaria, es el numero de Serie, 
USE applcore;

-- First you must to delete the Foreing Key Constraint;
-- The referenced appltaxtdistrictsareas Tables:
-- ALTER TABLE `bpmcore`.`appltaxtdistrictsareasstructure`  DROP FOREIGN KEY `WarehouseIDnWhp`;

-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `applcore`.`appltaxtdistrictsareas`;

CREATE TABLE `applcore`.`appltaxtdistrictsareas` (
		`TaxDistrictIDn` int NOT NULL,					-- Es el IdNum del District, se crea en la tabla BaseElement
        `TaxAreaIDn` int NOT NULL,						-- Es el IdNum del Area, se crea en la tabla BaseElement en base a la norma ISO
        `CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName
        `StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 UNIQUE KEY `TaxDistrictAreaCompanyIDn` (`TaxDistrictIDn`,`TaxAreaIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
		 KEY `CompanyIDn_idx` (`CompanyIDn`),
		 CONSTRAINT `TaxDistrictIDnTda` FOREIGN KEY (`TaxDistrictIDn`) REFERENCES `applcore`.`appltaxtdistricts` (`TaxDistrictIDn`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `TaxAreaIDnTda` FOREIGN KEY (`TaxAreaIDn`) REFERENCES `bpmcore`.`bpmfoutbaseelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
		AUTO_INCREMENT=0
        DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='contiene la estructura de los Distritos Impositivos/Tax Districts dentro de la empresa
				 Esta estructura se organiza asociando a un District/Region una lista de Areas que 
				 estan definidas en la base BpmCore segun norma ISO
				 Los Paises, Provincia, Regiones, Ciudades, Municipios, Comunas o el esquema que se desee
				 lo importante es que se detalle que lugares pertenece a un determinado distrito
				 la Clave primaria es: TaxDistrictIDn + TaxAreaIDn + CompanyIDn
				';


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - appltaxtdistrictsareas
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appltaxtdistrictsareas_BEFORE_INSERT`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appltaxtdistrictsareas_INSERT` BEFORE INSERT ON `appltaxtdistrictsareas` FOR EACH ROW BEGIN
    SET new.DateCreated = CURRENT_TIMESTAMP;
    SET new.DateTimeStamp = CURRENT_TIMESTAMP;
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - appltaxtdistrictsareas
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appltaxtdistrictsareas_BEFORE_UPDATE`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appltaxtdistrictsareas_BEFORE_UPDATE` BEFORE UPDATE ON `appltaxtdistrictsareas` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = CURRENT_TIMESTAMP;
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(old.TaxDistrictIDn,"†",old.TaxAreaIDn,"†",old.CompanyIDn,"†",
					IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `applcore`.`appltaxtdistrictsareas`;