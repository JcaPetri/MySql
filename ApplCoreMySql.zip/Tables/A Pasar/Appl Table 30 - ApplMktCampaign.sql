-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplMktTCampaign table
-- contiene las campañas de Marketing
-- los valores obligatorios son el tipo de campaña, y el periodo de aplicacion fecha desde, hasta y duracion.
-- La clave primaria es Marketing + Company

USE applcore;

-- First you must to delete the Foreing Key Constraint;
-- The referenced applmkttcampaign Tables:
-- ALTER TABLE `bpmcore`.`applmkttcampaignproperty`  DROP FOREIGN KEY `SerieIDnSet`;

-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `applcore`.`applmkttcampaign`;

CREATE TABLE `applcore`.`applmkttcampaign` (
        `CampaignIDn` int NOT NULL,						-- Es el IdNum de la campaña de Marketing, se crea en la tabla `bpmcore`.`bpmfoutbaseelement`
        `CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName, esta en la tabla BpmfounTCompany y se crea en la tabla `bpmcore`.`bpmfoutbaseelement`
        `CampaignTypeIDn` smallint NOT NULL,			-- Es el IdNum del tipo de campaña de Marketing, se crea en la tabla `applcore`.`appltdataelement`
		`CampaignTzNameIDn` smallint NOT NULL, 			-- Es el IdNum de la Time Zone del la fecha que inicia la campaña de Marketing
		`CampaignTzOffset` smallint NOT NULL, 			-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
        `CampaignDateStart` datetime NOT NULL,			-- Es la fecha de inicio de la campaña de Marketing
        `CampaignDateEnd` datetime NOT NULL,			-- Es la fecha de final de la campaña de Marketing
        `CampaignTimeDuration` int NOT NULL,			-- Es la cantidad de dias, horas y mimutos de duracion de la campaña de Marketing, se pasa todo a segundos
        `StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`CampaignIDn`,`CompanyIDn`),
		 UNIQUE KEY `CampaignCompanyID_UNIQUE` (`CampaignIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
		 KEY (`CampaignIDn`,`CompanyIDn`),
		 CONSTRAINT `CampaignIDnCmp` FOREIGN KEY (`CampaignIDn`) REFERENCES `applcore`.`appltdataelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
		DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='contiene las campañas de Marketing
				 los valores obligatorios son el tipo de campaña, y el periodo de aplicacion fecha desde, hasta y duracion.
				 La clave primaria es Marketing + Company
				';


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - applmkttcampaign
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`applmkttcampaign_BEFORE_INSERT`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `applmkttcampaign_INSERT` BEFORE INSERT ON `applmkttcampaign` FOR EACH ROW BEGIN
    SET new.DateCreated = CURRENT_TIMESTAMP;
    SET new.DateTimeStamp = CURRENT_TIMESTAMP;
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - applmkttcampaign
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`applmkttcampaign_BEFORE_UPDATE`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `applmkttcampaign_BEFORE_UPDATE` BEFORE UPDATE ON `applmkttcampaign` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = CURRENT_TIMESTAMP;
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(old.CampaignIDn,"†",old.CompanyIDn,"†",
					IF(new.CampaignTypeIDn = old.CampaignTypeIDn,"",old.CampaignTypeIDn),"†",
                    IF(new.CampaignTzNameIDn = old.CampaignTzNameIDn,"",old.CampaignTzNameIDn),"†",
                    IF(new.CampaignTzOffset = old.CampaignTzOffset,"",old.CampaignTzOffset),"†",
                    IF(new.CampaignDateStart = old.CampaignDateStart,"",old.CampaignDateStart),"†",
					IF(new.CampaignDateEnd = old.CampaignDateEnd,"",old.CampaignDateEnd),"†",
                    IF(new.CampaignTimeDuration = old.CampaignTimeDuration,"",old.CampaignTimeDuration),"†",
                    IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `applcore`.`applmkttcampaign`;