-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplLogTRelationsFoldersArticles table
-- Contiene las relaciones entre Folders/Carpetas/Articulos
-- aqui podemos dar relacion entre articulos, folders, articulos y folders
-- y definir el tipo de relacion que tienen
-- La clave primaria es RelationFromIDn + RelationToIDn + RelationTypeIDn + CompanyIDn
USE applcore;

-- First you must to delete the Foreing Key Constraint;
-- The referenced applstktserieType Tables:
-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `applcore`.`appllogtrelationsfoldersarticles`;

CREATE TABLE `applcore`.`appllogtrelationsfoldersarticles` (
        `RelationFromIDn` int NOT NULL,					-- Es el IdNum del Articulo/Folder origen de la relacion, se crea en la tabla `applcore`.`appllogtarticles` o `applcore`.`appllogtfolders`
        `RelationToIDn` int NOT NULL,					-- Es el IdNum del Articulo/Folder destino de la relacion, se crea en la tabla `applcore`.`appllogtarticles` o `applcore`.`appllogtfolders`
        `RelationTypeIDn` int NOT NULL,					-- Es el IdNum del Tipo de Relacion, se crea en la tabla `applcore`.`appllogtrelationstypes`
        `CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName, esta en la tabla BpmfounTCompany y se crea en la tabla BaseElement
			-- La Clave primaria es RelationFromIDn + RelationToIDn + RelationTypeIDn + CompanyIDn
		`StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`RelationFromIDn`,`FolderIDn`,`CompanyIDn`),
		 UNIQUE KEY `RelationFromToTypeCompanyIDn_UNIQUE` (`RelationFromIDn`,`RelationToIDn`,`RelationTypeIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
		 KEY `RelationFromToTypeCompanyIDn_idx` (`RelationFromIDn`,`RelationToIDn`,`RelationTypeIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
         KEY `CompanyIDn_idx` (`CompanyIDn`) /*!80000 INVISIBLE */ -- ,
		 -- CONSTRAINT `RelationTypeIDnRfa` FOREIGN KEY (`RelationTypeIDn`) REFERENCES `applcore`.`appllogtarticles` (`ArticleIDn`) ON DELETE CASCADE ON UPDATE CASCADE,
         -- CONSTRAINT `FolderIDnFla` FOREIGN KEY (`FolderIDn`) REFERENCES `applcore`.`appllogtfolders` (`FolderIDn`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
        DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='Contiene las relaciones entre Folders/Carpetas/Articulos
				 aqui podemos dar relacion entre articulos, folders, articulos y folders
				 y definir el tipo de relacion que tienen
				 La clave primaria es RelationFromIDn + RelationToIDn + RelationTypeIDn + CompanyIDn
				';


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - appllogtrelationsfoldersarticles
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appllogtrelationsfoldersarticles_BEFORE_INSERT`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appllogtrelationsfoldersarticles_INSERT` BEFORE INSERT ON `appllogtrelationsfoldersarticles` FOR EACH ROW BEGIN
    IF new.ArticleOrder IS NULL OR new.ArticleOrder = 0 OR new.ArticleOrder = '' THEN
		SET new.ArticleOrder = (SELECT ifnull(MAX(ArticleOrder),0) + 1 FROM `applcore`.`appllogtrelationsfoldersarticles` WHERE CompanyIDn = new.CompanyIDn AND FolderIDn = new.FolderIDn);
        -- Asigna el valor del ArticleOrder en forma incremental para esa Company y Folder
	END IF;
    SET new.DateCreated = CURRENT_TIMESTAMP;
    SET new.DateTimeStamp = CURRENT_TIMESTAMP;
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - appllogtrelationsfoldersarticles
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appllogtrelationsfoldersarticles_BEFORE_UPDATE`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appllogtrelationsfoldersarticles_BEFORE_UPDATE` BEFORE UPDATE ON `appllogtrelationsfoldersarticles` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = CURRENT_TIMESTAMP;
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(old.RelationFromIDn,"†",old.RelationToIDn,"†",old.CompanyIDn,"†",
					IF(new.RelationTypeIDn = old.RelationTypeIDn,"",old.RelationTypeIDn),"†",
                    IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `applcore`.`appllogtrelationsfoldersarticles`;