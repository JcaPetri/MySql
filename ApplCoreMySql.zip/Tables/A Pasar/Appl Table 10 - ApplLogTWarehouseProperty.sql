-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplLogTWarehouseProperty table
-- Contiene las propiedades de los Warehouse/Depositos que son opcionales
-- en esta tabla se cargan las columna opcionales
-- la clave primaria, es la propiedad (columna) + el WarehouseIDn (Tabla) + CompanyIDn
USE applcore;

-- First you must to delete the Foreing Key Constraint;
-- The referenced applstktserieType Tables:
-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `applcore`.`appllogtwarehouseproperty`;

CREATE TABLE `applcore`.`appllogtwarehouseproperty` (
        `WarehousePropertyIDn` int NOT NULL,			-- Es el IdNum de la propiedad del Warehouse/Deposito (Columna de la Tabla), se crea en la tabla bpmfoutbaseelement
        `WarehouseIDn` int NOT NULL,					-- Es el IdNum del Warehouse/Deposito, se crea en la tabla `applcore`.`appllogtwarehouse`
        `CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName, esta en la tabla BpmfounTCompany y se crea en la tabla BaseElement
		`PropertyValueIDn` int NOT NULL,				-- Es el IDNum del valor de esa Propiedad, 0 = false, 1 = true, el resto se vincula con la tabla BaseElement
		`OptionValue` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,	-- Es un valor opcional para la propiedad
		`StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`WarehousePropertyIDn`,`GroupIDn`,`CompanyIDn`),
		 UNIQUE KEY `WarehousePropertyCompanyIDn_UNIQUE` (`WarehousePropertyIDn`,`WarehouseIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
		 KEY `WarehousePropertyCompanyIDn_idx` (`WarehousePropertyIDn`,`WarehouseIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
		 CONSTRAINT `WarehousePropertyIDnWhp` FOREIGN KEY (`WarehousePropertyIDn`) REFERENCES `bpmcore`.`bpmfoutbaseelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `WarehouseIDnWhp` FOREIGN KEY (`WarehouseIDn`) REFERENCES `applcore`.`appllogtwarehouse` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
        DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='Contiene las propiedades de los Warehouse/Depositos que son opcionales
				 en esta tabla se cargan las columna opcionales
				 la clave primaria, es la propiedad (columna) + el WarehouseIDn (Tabla) + CompanyIDn
				';


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - appllogtwarehouseproperty
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appllogtwarehouseproperty_BEFORE_INSERT`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appllogtwarehouseproperty_INSERT` BEFORE INSERT ON `appllogtwarehouseproperty` FOR EACH ROW BEGIN
    SET new.DateCreated = CURRENT_TIMESTAMP;
    SET new.DateTimeStamp = CURRENT_TIMESTAMP;
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - appllogtwarehouseproperty
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appllogtwarehouseproperty_BEFORE_UPDATE`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appllogtwarehouseproperty_BEFORE_UPDATE` BEFORE UPDATE ON `appllogtwarehouseproperty` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = CURRENT_TIMESTAMP;
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(old.WarehousePropertyIDn,"†",old.WarehouseIDn,"†",old.CompanyIDn,"†",
				-- Aqui van siempre la clave primaria que no cambia
                    IF(new.PropertyValueIDn = old.PropertyValueIDn,"",old.PropertyValueIDn),"†",
					IF(new.OptionValue = old.OptionValue,"",old.OptionValue),"†",
                    IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `applcore`.`appllogtwarehouseproperty`;