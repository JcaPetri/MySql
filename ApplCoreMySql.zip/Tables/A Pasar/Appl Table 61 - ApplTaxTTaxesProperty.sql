-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplTaxTTaxesProperty table
-- Contiene las propiedades de los Taxes/Impuestos que son opcionales
-- en esta tabla se cargan las columna opcionales
-- Ej, se define el IVA del 21%, a ese impuesto se le agrega el parametro del Tipo de Alicuota IVA, y que es percepcion impositiva. Tambien se puede definir la region que puede ser un pais o una localidad.
-- la clave primaria, es la propiedad (columna) TaxPropertyIDn + el TaxIDn (Tabla) + CompanyIDn

/*
        -- Campos opcionales (cada uno es una columna de la tabla)
		`TaxIncome`,			True = 1 tiene impacto en ganancias, False = 0 No tiene impacto en ganancias
        `TaxPerception`,		True = 1 es un impuesto de percepcion, False = 0 no genera percepcion
        `TaxRegionIDn`,			Es el IdNum del codigo de region donde se aplica el impuesto

*/
USE applcore;

-- First you must to delete the Foreing Key Constraint;
-- The referenced appltaxttaxesproperty Tables:
-- After deleted the referenced, you can delete the table
DROP TABLE IF EXISTS `applcore`.`appltaxttaxesproperty`;

CREATE TABLE `applcore`.`appltaxttaxesproperty` (
        `TaxPropertyIDn` int NOT NULL,					-- Es el IdNum de la propiedad de los Taxes/Impuestos (Columna de la Tabla), se crea en la tabla bpmfoutbaseelement
        `TaxIDn` int NOT NULL,							-- Es el IdNum del Tax/Impuesto, se crea en la tabla bpmfoutbaseelement
        `CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName, esta en la tabla BpmfounTCompany y se crea en la tabla BaseElement
		`PropertyValueIDn` int NOT NULL,				-- Es el IDNum del valor de esa Propiedad, este valor se carga en el DataElement
		`OptionValue` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,	-- Es un valor opcional para la propiedad
		`StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`TaxPropertyIDn`,`TaxIDn`,`CompanyIDn`),
		 UNIQUE KEY `TaxPropertyCompanyIDn_UNIQUE` (`TaxPropertyIDn`,`TaxIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
		 KEY `TaxPropertyCompanyIDn_idx` (`TaxPropertyIDn`,`TaxIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
         KEY `CompanyIDn_idx` (`CompanyIDn`) /*!80000 INVISIBLE */,
		 CONSTRAINT `TaxPropertyIDnAcp` FOREIGN KEY (`TaxPropertyIDn`) REFERENCES `bpmcore`.`bpmfoutbaseelement` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `TaxIDnAcp` FOREIGN KEY (`TaxIDn`) REFERENCES `applcore`.`appltaxttaxes` (`IDNum`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
        DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='Contiene las propiedades de los Taxes/Impuestos que son opcionales
				 en esta tabla se cargan las columna opcionales
				 la clave primaria, es la propiedad (columna) TaxPropertyIDn + el TaxIDn (Tabla) + CompanyIDn
				';


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Insert - appltaxttaxesproperty
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appltaxttaxesproperty_BEFORE_INSERT`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appltaxttaxesproperty_INSERT` BEFORE INSERT ON `appltaxttaxesproperty` FOR EACH ROW BEGIN
    SET new.DateCreated = CURRENT_TIMESTAMP;
    SET new.DateTimeStamp = CURRENT_TIMESTAMP;
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the Trigger Before Update - appltaxttaxesproperty
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE applcore;
DROP TRIGGER IF EXISTS `applcore`.`appltaxttaxesproperty_BEFORE_UPDATE`;
DELIMITER $$
USE `applcore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `appltaxttaxesproperty_BEFORE_UPDATE` BEFORE UPDATE ON `appltaxttaxesproperty` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = CURRENT_TIMESTAMP;
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(old.TaxPropertyIDn,"†",old.TaxIDn,"†",old.CompanyIDn,"†",
				-- Aqui van siempre la clave primaria que no cambia
					IF(new.PropertyValueIDn = old.PropertyValueIDn,"",old.PropertyValueIDn),"†",
					IF(new.OptionValue = old.OptionValue,"",old.OptionValue),"†",
                    IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- Lista los datos de la tabla
SELECT * FROM `applcore`.`appltaxttaxesproperty`;