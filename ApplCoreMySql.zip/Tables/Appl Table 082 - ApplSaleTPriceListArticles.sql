-- ##############################################################################################################################################################################################-- Lista los datos de la tabla
-- ##############################################################################################################################################################################################-- Lista los datos de la tabla
-- Create the ApplSaleTPriceListArticles table
-- contiene la informacion de los articulos de cada Listas de Precios
-- como cada articulo puede estar en varias listas de precios, aqui es donde se asignan a ellas
-- la clave primaria: es el ArticleIDn + PriceListIDn + CompanyIDn
USE ApplCore;

-- #########################################################################################################################################################################################
-- 1.- First you must to delete the Foreing Key Constraint childs;
-- The referenced ApplSaleTPriceListArticles Tables:
--    ALTER TABLE `ApplCore`.`appllogtarticlessuppliersarticles` DROP FOREIGN KEY `ArticleSupplierIDAsA`;
	-- After deleted the referenced, you can delete the table
	DROP TABLE IF EXISTS `ApplCore`.`ApplSaleTPriceListArticles`;

-- #########################################################################################################################################################################################
-- 2.- Seconde you create the Table
CREATE TABLE `ApplCore`.`ApplSaleTPriceListArticles` (
		`ArticleIDn` int NOT NULL,						-- Es el IdNum del Articulo
        `PriceListIDn` int NOT NULL,					-- Es el IdNum de la lista de Precios
		`CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName
				-- la clave primaria: es el ArticleIDn + PriceListIDn + CompanyIDn
		`Price` decimal(16,6) NOT NULL,					-- Es el precio del articulo
        `PriceDate` datetime NOT NULL,					-- Es la fecha de la Lista de Precio, puede no coincidir con la fecha actual
														-- ya que el proceso de actualizacion puede diferir de la fecha de la lista de precios que se actualiza
		`PriceListCode` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,		-- Es el codigo de la lista de precios, este es un codigo que se genera cada vez que se actualiza la Lista de Precios
																									-- Es el Codigo de la LP + Año + Valor autonumerico ascendente
		`StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`ArticleIDn`, `PriceListIDn`, `CompanyIDn`),
		 UNIQUE KEY `ArtPriceListCompanyIDn_UNIQUE` (`ArticleIDn`, `PriceListIDn`, `CompanyIDn`) /*!80000 INVISIBLE */,
		 KEY `ArtPriceListCompanyIDn_idx` (`ArticleIDn`, `PriceListIDn`, `CompanyIDn`) /*!80000 INVISIBLE */,
         KEY `SupplierCompanyIDn_idx` (`PriceListIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
         KEY `StateIDn_idx` (`StateIDn`) /*!80000 INVISIBLE */,
         CONSTRAINT `ArticleIDnPla` FOREIGN KEY (`ArticleIDn`) REFERENCES `ApplCore`.`ApplLogTArticles` (`ArticleIDn`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `PriceListIDnPla` FOREIGN KEY (`PriceListIDn`) REFERENCES `ApplCore`.`ApplSaleTPriceList` (`PriceListIDn`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `CompanyIDnPla` FOREIGN KEY (`CompanyIDn`) REFERENCES `BpmCore`.`systcompanies` (`CompanyIDn`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
		DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='contiene la informacion de los articulos de cada Listas de Precios
				 como cada articulo puede estar en varias listas de precios, aqui es donde se asignan a ellas
				 la clave primaria: es el ArticleIDn + PriceListIDn + CompanyIDn
				';

-- #########################################################################################################################################################################################
-- 3.- Then you must to Re-Create the Foreing Key Constraint, because in the step 1 you delete;
-- The referenced ApplSaleTPriceListArticles Tables:
-- 	ALTER TABLE `ApplCore`.`appllogtarticlessuppliersarticles` ADD CONSTRAINT `ArticleSupplierIDAsA` FOREIGN KEY (`ArticleSupplierID`) 
-- 		REFERENCES `ApplCore`.`ApplSaleTPriceListArticles` (`ArticleSupplierID`) ON DELETE CASCADE ON UPDATE CASCADE;

-- #########################################################################################################################################################################################
-- 4.- Create the Trigger Before Insert - ApplSaleTPriceListArticles
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE ApplCore;
DROP TRIGGER IF EXISTS `ApplCore`.`ApplSaleTPriceListArticles_BEFORE_INSERT`;
DELIMITER $$
USE `ApplCore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `ApplSaleTPriceListArticles_BEFORE_INSERT` BEFORE INSERT ON `ApplSaleTPriceListArticles` FOR EACH ROW BEGIN
    SET new.DateCreated = ifnull(new.DateCreated,current_timestamp);
    SET new.DateTimeStamp = ifnull(new.DateTimeStamp,current_timestamp);
END$$
DELIMITER ;

-- #########################################################################################################################################################################################
-- 5.- Create the Trigger Before Update - ApplSaleTPriceListArticles
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE ApplCore;
DROP TRIGGER IF EXISTS `ApplCore`.`ApplSaleTPriceListArticles_BEFORE_UPDATE`;
DELIMITER $$
USE `ApplCore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `ApplSaleTPriceListArticles_BEFORE_UPDATE` BEFORE UPDATE ON `ApplSaleTPriceListArticles` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = ifnull(new.DateTimeStamp,current_timestamp);
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(
					IF(new.ArticleIDn = old.ArticleIDn,"",old.ArticleIDn),"†",
                    IF(new.PriceListIDn = old.PriceListIDn,"",old.PriceListIDn),"†",
                    IF(new.CompanyIDn = old.CompanyIDn,"",old.CompanyIDn),"†",
						-- la clave primaria: es el ArticleIDn + PriceListIDn + CompanyIDn
                    IF(new.Price = old.Price,"",old.Price),"†",
					IF(new.PriceDate = old.PriceDate,"",old.PriceDate),"†",
                    IF(new.PriceListCode = old.PriceListCode,"",old.PriceListCode),"†",
                    IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- ##############################################################################################################################################################################################-- Lista los datos de la tabla
-- ##############################################################################################################################################################################################-- Lista los datos de la tabla
-- Lista los datos de la tabla
SELECT * FROM `ApplCore`.`ApplSaleTPriceListArticles`;