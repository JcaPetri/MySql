-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplSupTSuppliersPriceListArticles table
-- contiene la informacion de las Listas de Precios de los Suppliers/Proveedores
-- las propiedades especificas de las listas de precios, estan en la tabla ApplSupTSuppliersPriceList
-- la clave primaria: es el ArticleSupplierID + SupplierIDn + CompanyIDn
USE ApplCore;

-- #########################################################################################################################################################################################
-- 1.- First you must to delete the Foreing Key Constraint childs;
-- The referenced ApplSupTSuppliersPriceListArticles Tables:
    ALTER TABLE `ApplCore`.`appllogtarticlessuppliersarticles` DROP FOREIGN KEY `ArticleSupplierIDAsA`;
	-- After deleted the referenced, you can delete the table
	DROP TABLE IF EXISTS `ApplCore`.`ApplSupTSuppliersPriceListArticles`;

-- #########################################################################################################################################################################################
-- 2.- Seconde you create the Table
CREATE TABLE `ApplCore`.`ApplSupTSuppliersPriceListArticles` (
		`ArticleSupplierID` varchar(38) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,		-- Es Codigo Unico de identificacion del articulo para ese Supplier/Proveedor
        `SupplierIDn` int NOT NULL,						-- Es el IdNum del Supplier/Proveedor, esta en la tabla ApplTPersons
		`CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName
				-- la clave primaria: es el ArticleSupplierID + SupplierIDn + CompanyIDn
		`ArticleSupplierDescription` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,		-- Es la descripcion del articulo realizada por el Supplier/Proveedor
		`SupplierPriceListIDn` int NOT NULL,			-- Es el IdNum de la Lista de Precios del Supplier/Proveedor, esta en la tabla DataElement
        `Price` decimal(16,6) NOT NULL,					-- Es el precio del articulo
        `DatePriceList` datetime NOT NULL,				-- Es la fecha de la Lista de Precio, puede no coincidir con la fecha actual
														-- ya que el proceso de actualizacion puede diferir de la fecha de la lista de precios que se actualiza
		`PriceListCode` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,		-- Es el codigo de la lista de precios
		`StateIDn` smallint NOT NULL,					-- Es el estado del registro
		`CreatedByIDn` mediumint NOT NULL,				-- Es el IdNum del usuario que creo el registro
		`LastModifiedByIDn` mediumint NOT NULL,			-- Es el IdNum del ultimo usuario que modifico el registro
		`OwnerIDn` mediumint NOT NULL,					-- Es el IdNum del dueño del registro
		`DateCreated` datetime NOT NULL,				-- Es la fecha de creacion del registro
		`DateTimeStamp` timestamp NOT NULL, 			-- Es la fecha de la ultima modificacion del registro
		`TzNameIDn` smallint NOT NULL, 					-- Es el IdNum de la Time Zone del la fecha
		`TzOffset` smallint NOT NULL, 					-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
		`TableHistory` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, 	-- Es el historico del registro
		 PRIMARY KEY (`ArticleSupplierID`, `SupplierIDn`, `CompanyIDn`),
		 UNIQUE KEY `ArtSupplierCompanyIDn_UNIQUE` (`ArticleSupplierID`,`SupplierIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
		 KEY `ArtSupplierCompanyIDn_idx` (`ArticleSupplierID`,`SupplierPriceListIDn`,`SupplierIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
         KEY `DatePriceListSupplierIDn_idx` (`DatePriceList`,`SupplierPriceListIDn`,`SupplierIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
         KEY `SupplierCompanyIDn_idx` (`SupplierIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
         CONSTRAINT `SupplierPriceListIDnSpA` FOREIGN KEY (`SupplierPriceListIDn`) REFERENCES `ApplCore`.`ApplSupTSuppliersPriceList` (`SupplierPriceListIDn`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `SupplierIDnSpA` FOREIGN KEY (`SupplierIDn`) REFERENCES `ApplCore`.`ApplTPersons` (`PersonIDn`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `CompanyIDnSpA` FOREIGN KEY (`CompanyIDn`) REFERENCES `BpmCore`.`systcompanies` (`CompanyIDn`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
		DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='contiene la informacion de las Listas de Precios de los Suppliers/Proveedores
				 las propiedades especificas de las listas de precios, estan en la tabla ApplSupTSuppliersPriceList
				 la clave primaria: es el ArticleSupplier + SupplierPriceListIDn + SupplierIDn + CompanyIDn
				';

-- #########################################################################################################################################################################################
-- 3.- Then you must to Re-Create the Foreing Key Constraint, because in the step 1 you delete;
-- The referenced ApplSupTSuppliersPriceListArticles Tables:
	ALTER TABLE `ApplCore`.`appllogtarticlessuppliersarticles` ADD CONSTRAINT `ArticleSupplierIDAsA` FOREIGN KEY (`ArticleSupplierID`) 
		REFERENCES `ApplCore`.`ApplSupTSuppliersPriceListArticles` (`ArticleSupplierID`) ON DELETE CASCADE ON UPDATE CASCADE;

-- #########################################################################################################################################################################################
-- 4.- Create the Trigger Before Insert - ApplSupTSuppliersPriceListArticles
-- establece el valor del ID uniqueidentifier, el IDCode, el DateCreated y el DateTimeStamp
USE ApplCore;
DROP TRIGGER IF EXISTS `ApplCore`.`ApplSupTSuppliersPriceListArticles_BEFORE_INSERT`;
DELIMITER $$
USE `ApplCore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `ApplSupTSuppliersPriceListArticles_BEFORE_INSERT` BEFORE INSERT ON `ApplSupTSuppliersPriceListArticles` FOR EACH ROW BEGIN
    SET new.DateCreated = ifnull(new.DateCreated,current_timestamp);
    SET new.DateTimeStamp = ifnull(new.DateTimeStamp,current_timestamp);
END$$
DELIMITER ;

-- #########################################################################################################################################################################################
-- 5.- Create the Trigger Before Update - ApplSupTSuppliersPriceListArticles
-- establece el valor del DateTimeStamp, TableHistory creando el historico de cada registro
USE ApplCore;
DROP TRIGGER IF EXISTS `ApplCore`.`ApplSupTSuppliersPriceListArticles_BEFORE_UPDATE`;
DELIMITER $$
USE `ApplCore`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `ApplSupTSuppliersPriceListArticles_BEFORE_UPDATE` BEFORE UPDATE ON `ApplSupTSuppliersPriceListArticles` FOR EACH ROW BEGIN
	SET new.DateTimeStamp = ifnull(new.DateTimeStamp,current_timestamp);
    IF new.TableHistory = 'SetNull' THEN
		SET new.TableHistory = null;
    ELSEIF new.TableHistory = 'SetOff' THEN
		SET new.TableHistory = old.TableHistory;
    ELSE
		SET new.TableHistory = concat(
					IF(new.ArticleSupplierID = old.ArticleSupplierID,"",old.ArticleSupplierID),"†",
                    IF(new.SupplierIDn = old.SupplierIDn,"",old.SupplierIDn),"†",
                    IF(new.CompanyIDn = old.CompanyIDn,"",old.CompanyIDn),"†",
						-- la clave primaria: es el ArticleSupplier + SupplierIDn + CompanyIDn
                    IF(new.ArticleSupplierDescription = old.ArticleSupplierDescription,"",old.ArticleSupplierDescription),"†",
                    IF(new.SupplierPriceListIDn = old.SupplierPriceListIDn,"",old.SupplierPriceListIDn),"†",
                    IF(new.Price = old.Price,"",old.Price),"†",
					IF(new.DatePriceList = old.DatePriceList,"",old.DatePriceList),"†",
                    IF(new.PriceListCode = old.PriceListCode,"",old.PriceListCode),"†",
                    IF(new.StateIDn = old.StateIDn,"",old.StateIDn),"†",
                    IF(new.CreatedByIDn = old.CreatedByIDn,"",old.CreatedByIDn),"†",
                    IF(new.LastModifiedByIDn = old.LastModifiedByIDn,"",old.LastModifiedByIDn),"†",
                    IF(new.OwnerIDn = old.OwnerIDn,"",old.OwnerIDn),"†",
                    IF(new.DateCreated = old.DateCreated,"",old.DateCreated),"†",
                    old.DateTimeStamp,"†",
                    IF(new.TzNameIDn = old.TzNameIDn,"",old.TzNameIDn),"†",
                    IF(new.TzOffset = old.TzOffset,"",old.TzOffset),
				IFNULL(concat("‡",old.TableHistory),""));
		END IF;
END$$
DELIMITER ;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Lista los datos de la tabla
SELECT * FROM `ApplCore`.`ApplSupTSuppliersPriceListArticles`;