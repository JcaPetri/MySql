-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Create the ApplSaleTPriceListArticlesHistory table
-- contiene la informacion Historica de los Precios de los Articulos
-- la clave primaria: es el ArticleIDn + PriceListIDn + CompanyIDn
USE ApplCore;

-- #########################################################################################################################################################################################
-- 1.- First you must to delete the Foreing Key Constraint childs;
-- The referenced ApplSaleTPriceListArticlesHistory Tables:
-- 	ALTER TABLE `ApplCore`.`ApplLogTArticlesSuppliersArticles` DROP FOREIGN KEY `ArticleSupplierAsA`;
	-- After deleted the referenced, you can delete the table
	DROP TABLE IF EXISTS `ApplCore`.`ApplSaleTPriceListArticlesHistory`;

-- #########################################################################################################################################################################################
-- 2.- Seconde you create the Table
CREATE TABLE `ApplCore`.`ApplSaleTPriceListArticlesHistory` (
		`ArticleIDn` int NOT NULL,						-- Es el IdNum del Articulo
        `PriceListIDn` int NOT NULL,					-- Es el IdNum de la lista de Precios
		`CompanyIDn` int NOT NULL,						-- Es el IdNum de la Company al que esta asignado el IDName
        `PriceDate` datetime NOT NULL,					-- Es la fecha de la Lista de Precio
				-- la clave primaria: es el PriceDate + ArticleIDn + PriceListIDn + CompanyIDn
        `Price` decimal(16,6) NOT NULL,					-- Es el precio del articulo
        `PriceDateBefore` datetime,						-- Es la fecha del precio anterior que tenia
        `PriceBefore` decimal(16,6),					-- Es el precio anterior que tenia
		`StateIDn` smallint NOT NULL,					-- Es el estado del registro
		 PRIMARY KEY (`PriceDate`, `ArticleIDn`, `PriceListIDn`, `CompanyIDn`),
		 UNIQUE KEY `DateArtPriceCompanyIDn_UNIQUE` (`PriceDate`, `ArticleIDn`, `PriceListIDn`, `CompanyIDn`) /*!80000 INVISIBLE */,
		 KEY `DateArtPriceCompanyIDn_idx` (`PriceDate`, `ArticleIDn`, `PriceListIDn`, `CompanyIDn`) /*!80000 INVISIBLE */,
         KEY `ArticleCompanyIDn_idx` (`ArticleIDn`,`CompanyIDn`) /*!80000 INVISIBLE */,
         KEY `StateIDn_idx` (`StateIDn`) /*!80000 INVISIBLE */,
         CONSTRAINT `ArticleIDnPlaH` FOREIGN KEY (`ArticleIDn`) REFERENCES `ApplCore`.`ApplLogTArticles` (`ArticleIDn`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `PriceListIDnPlaH` FOREIGN KEY (`PriceListIDn`) REFERENCES `ApplCore`.`ApplSaleTPriceList` (`PriceListIDn`) ON DELETE CASCADE ON UPDATE CASCADE,
         CONSTRAINT `CompanyIDnPlaH` FOREIGN KEY (`CompanyIDn`) REFERENCES `BpmCore`.`systcompanies` (`CompanyIDn`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB 
		DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
		COMMENT='contiene la informacion Historica de los Precios de los Articulos de los Suppliers/Proveedores
				 la clave primaria: es el ArticleSupplierID + SupplierIDn + CompanyIDn
				';

-- #########################################################################################################################################################################################
-- 3.- Then you must to Re-Create the Foreing Key Constraint, because in the step 1 you delete;
-- The referenced ApplSupTSuppliersPriceListArticles Tables:
/*
	ALTER TABLE `ApplCore`.`appllogtarticlessuppliersarticles` ADD CONSTRAINT `ArticleSupplierIDAsA` FOREIGN KEY (`ArticleSupplierID`) 
		REFERENCES `ApplCore`.`ApplSupTSuppliersPriceListArticles` (`ArticleSupplierID`) ON DELETE CASCADE ON UPDATE CASCADE;
*/

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Lista los datos de la tabla
SELECT * FROM `ApplCore`.`ApplSaleTPriceListArticlesHistory`;