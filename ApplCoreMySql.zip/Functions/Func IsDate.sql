USE `applcore`;
DROP function IF EXISTS `FncIsDate`;

DELIMITER $$
USE `applcore`$$

CREATE DEFINER=`root`@`localhost` FUNCTION `FncIsDate` (vString VARCHAR(1000))
    RETURNS INTEGER
	DETERMINISTIC
BEGIN
    -- Error Variables
    DECLARE vSP_NumConditions int DEFAULT 0;
    DECLARE vSqlState char(5) DEFAULT 0; 		-- SqlState, This value is a five-character string (for example, '42S02')
    DECLARE vErrorCode int DEFAULT 0;			-- ErrorCode, This value is numeric. It is MySQL-specific and is not portable to other database systems., este se vincula con una descripcion personalizada en la base de datos.
	DECLARE vMsgString TEXT DEFAULT 0;			-- MsgString, This string provides a textual description of the error.
    	-- exit if Errors occurs for sqlexception
    -- declare exit handler for sqlexception
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        BEGIN
			-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
			get stacked diagnostics vSP_NumConditions = number;				-- Take the condition number
			-- Depend of the vSP_NumConditions value, send the result
			if vSP_NumConditions > 0 then
				-- Report the first error
				get stacked diagnostics condition vSP_NumConditions vSqlState = returned_sqlstate, vErrorCode = mysql_errno, vMsgString = message_text;		-- Take the ondition information
				-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
				-- Resultado Erróneo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
				-- Todas estas variables se envian dentro del mensaje vMsgString, concatenandolas.	-- , cast(251 AS CHAR), '†'
				-- SQLState five-character string
			else
				-- Carga la informacion general (de o no error se carga lo mismo)
				set vSqlState = 'HY000';				-- informa el resultado: 'HY000' (general error) is used for client-side errors and if server-side errors hasen't MySQL error numbers
				set vErrorCode = 2200;					-- informa el numero de resultado, este se vincula con una descripcion personalizada en la base de datos.
														-- 2000 to 2999: Client error codes reserved for use by the client library.
                                                        -- 2200 Function Error
				set vMsgString = 'Unknown MySQL Function error';
				-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
				-- Resultado Erróneo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
				-- Todas estas variables se envian dentro del mensaje vMsgString, concatenandolas.	-- , cast(251 AS CHAR), '†'
				-- SQLState five-character string, for Client Error use always 'HY000'
			END IF;
			SET vMsgString = concat(vSqlState, '†', vErrorCode, '†', vMsgString);
			-- RETURN concat("Err = vString: ",vOrignalValue," - vFormat: ",vFormat, '†MsgString ', vMsgString);
            -- RETURN CONCAT(vOrignalValue, '†', vMsgString);
            RETURN 0;
        END;
		-- #####################################################################################################################################################################################################
			IF isnull(DAYNAME(vString)) = TRUE THEN
				RETURN 0;
			ELSE
				RETURN 1;
			END IF;
		-- #####################################################################################################################################################################################################
END$$

DELIMITER ;
