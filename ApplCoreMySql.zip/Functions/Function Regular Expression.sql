/* 
Date format MySQL
select now();		-- MySql yyyy-mm-dd
	'2021-12-28 15:23:09'

*/

/*
	STR_TO_DATE(string, format)
		STR_TO_DATE(string, '')
        
		%d	Day of the month as a numeric value (01 to 31)
		%e	Day of the month as a numeric value (0 to 31)	deberia ser (1 to 31)
        
        %M	Month name in full (January to December)
		%m	Month name as a numeric value (01 to 12)

		%Y	Year as a numeric, 4-digit value
		%y	Year as a numeric, 2-digit value

        %j	Day of the year (001 to 366)
        
*/

SELECT * FROM `ApplCore`.`applimptsupplierspricelistarticles`;

UPDATE `ApplCore`.`applimptsupplierspricelistarticles`
SET `DateLastUpdate` = 'Juan'
WHERE `IDNum` = 8192 ;


UPDATE `ApplCore`.`applimptsupplierspricelistarticles`
SET `DateLastUpdate` = FncConvDate(DateLastUpdate,'dd/mm/yyyy');

SELECT FncConvDate(DateLastUpdate,'dd/mm/yyyy') 'dATE'
FROM `ApplCore`.`applimptsupplierspricelistarticles`;

SELECT FncConvDate('0Juan08/1971','dd/mm/yyyy') 'dATE';
SELECT @vSqlState,
	@vErrorCode,
    @vMsgString,
    @vRowAffected;

SELECT CAST('1971-0D8-03' AS DATE);


SELECT IDNum
		, DateLastUpdate
        , FncConvDate(DateLastUpdate,'dd/mm/yyyy')
FROM `ApplCore`.`applimptsupplierspricelistarticles`;

/*
Ver que nivel de precicion se tiene para determinar el if de la funcion de conversion

		, FncIsDate(DateLastUpdate) `FncIsDate`
		, if('2021-12-21' REGEXP '[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])',1,0) `RegExpFechaOK`
        , if(DateLastUpdate REGEXP '[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])',1,0) `RegExpFechErr`

*/

SELECT REGEXP_SUBSTR('abc def ghi', '[a-z]+');

SELECT replace('jus3/08/1971', "/","-") `Replace`
		, if(replace('jus3/08/1971', "/","-") REGEXP '([1-9]|0[1-9]|[1-2][0-9]|3[0-1])-(0[1-9]|1[0-2])-[0-9]{4}',1,0) `RegExp01`
	-- dd/mm/yyyy	Ej: 08/12/2021 o 8/12/2021 -- dd/mm/yy	Ej: 08/12/21 o 8/12/21
		, REGEXP_SUBSTR(replace('jus03/08/71ds', "/","-"), '([1-9]|0[1-9]|[1-2][0-9]|3[0-1])-([1-9]|0[1-9]|1[0-2])-([0-9]{4}|[0-9]{2})',1,0) `RegExp dd/mm/yyyy`
	--  yyyy/mm/dd	yy/mm/dd		length 10		Ej: 2021/12/08 o 2021/12/8
		, REGEXP_SUBSTR(replace('jus71/08/03ds', "/","-"), '([0-9]{4}|[0-9]{2})-([1-9]|0[1-9]|1[0-2])-([1-9]|0[1-9]|[1-2][0-9]|3[0-1])',1,0) `RegExp yyyy/mm/dd`
;        
