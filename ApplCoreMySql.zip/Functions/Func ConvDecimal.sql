USE `applcore`;
DROP function IF EXISTS `FncConvDecimal`;

DELIMITER $$
USE `applcore`$$

CREATE DEFINER=`root`@`localhost` FUNCTION `FncConvDecimal` (vString VARCHAR(1000))
	-- RETURNS DECIMAL(16,6)
    RETURNS varchar(1000)
	DETERMINISTIC
BEGIN
    IF (vString REGEXP '^[0-9]+\\.?[0-9]*$') THEN
		RETURN CONVERT(vString, DECIMAL(16,6));
    ELSEIF (REPLACE(vString,',','.') REGEXP '^[0-9]+\\.?[0-9]*$') THEN
		RETURN CONVERT(REPLACE(vString,',','.'), DECIMAL(16,6));
    ELSE
		RETURN vString;
    END IF;
END$$

DELIMITER ;
