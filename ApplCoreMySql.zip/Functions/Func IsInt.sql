USE `applcore`;
DROP function IF EXISTS `FncIsInt`;

DELIMITER $$
USE `applcore`$$

CREATE DEFINER=`root`@`localhost` FUNCTION `FncIsInt`(vString VARCHAR(1000)) RETURNS int
    DETERMINISTIC
BEGIN
    IF (vString REGEXP '^[0-9]+$') THEN
      RETURN 1;
    ELSE
      RETURN 0;
    END IF;
END$$

DELIMITER ;
