USE `applcore`;
DROP function IF EXISTS `FncConvPrueba`;

DELIMITER $$
USE `applcore`$$
	CREATE DEFINER=`root`@`localhost` FUNCTION `FncConvPrueba`(vString VARCHAR(1000),vFormat VARCHAR(10)) 
		RETURNS varchar(1000) CHARSET utf8mb4 COLLATE utf8mb4_0900_as_cs
		DETERMINISTIC
	BEGIN
		DECLARE vOrignalValue VARCHAR(1000) DEFAULT "";
        -- Variables de Error
        DECLARE vSP_NumConditions int DEFAULT 0;
		DECLARE vSqlState char(5) DEFAULT ''; 		-- SqlState, This value is a five-character string (for example, '42S02')
		DECLARE vErrorCode int DEFAULT 0;			-- ErrorCode, This value is numeric. It is MySQL-specific and is not portable to other database systems., este se vincula con una descripcion personalizada en la base de datos.
		DECLARE vMsgString TEXT DEFAULT '';			-- MsgString, This string provides a textual description of the error.
		DECLARE vResult TEXT DEFAULT '';
        
        -- declare exit handler for sqlexception
		DECLARE EXIT HANDLER FOR sqlexception		-- CONTINUE
			BEGIN
				-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
				get stacked diagnostics vSP_NumConditions = number;		-- Take the condition number
				-- Depend of the vSP_NumConditions value, send the result
				if vSP_NumConditions > 0 then
					-- Report the first error
					get stacked diagnostics condition vSP_NumConditions vSqlState = returned_sqlstate, vMsgString = message_text;		-- Take the ondition information
                    -- , vErrorCode = mysql_errno
						-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
						-- Resultado Erróneo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
						-- Todas estas variables se envian dentro del mensaje vMsgString, concatenandolas.	-- , cast(251 AS CHAR), '†'
						-- SQLState five-character string
						set vMsgString = concat(vSqlState, '†', vMsgString);
						RETURN concat(vString, '†MsgString ', vMsgString);
					else
						-- Carga la informacion general (de o no error se carga lo mismo)
						set vSqlState = 'HY000';				-- informa el resultado: 'HY000' (general error) is used for client-side errors and if server-side errors hasen't MySQL error numbers
						set vErrorCode = 2000;					-- informa el numero de resultado, este se vincula con una descripcion personalizada en la base de datos.
																-- 2,000 to 2,999: Client error codes reserved for use by the client library.
						-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
						-- Resultado Erróneo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
						-- Todas estas variables se envian dentro del mensaje vMsgString, concatenandolas.	-- , cast(251 AS CHAR), '†'
						-- SQLState five-character string, for Client Error use always 'HY000'
						set vMsgString = concat('HY000', '†', 'Unknown MySQL error');
						-- vRowAffected no depende del vSP_NumConditions, se carga antes del if
						RETURN concat(vString, '†MsgString ', vMsgString);
					END IF;
			END;
          
/*		DECLARE CONTINUE HANDLER FOR SQLWARNING		-- CONTINUE
		  BEGIN
				get  diagnostics condition 1 vSqlState = returned_sqlstate, vErrorCode = mysql_errno, vMsgString = message_text;		-- Take the ondition information
			-- stacked
/*				-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
				get stacked diagnostics vSP_NumConditions = number;		-- Take the condition number
				-- Depend of the vSP_NumConditions value, send the result
				if vSP_NumConditions > 0 then
					-- Report the first error	stacked
					get stacked diagnostics condition vSP_NumConditions vSqlState = returned_sqlstate, vErrorCode = mysql_errno, vMsgString = message_text;		-- Take the ondition information
						-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
						-- Resultado Erróneo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
						-- Todas estas variables se envian dentro del mensaje vMsgString, concatenandolas.	-- , cast(251 AS CHAR), '†'
						-- SQLState five-character string
						set vMsgString = concat(vSqlState, '†', vMsgString);
						-- RETURN concat(vString, '†MsgString ', vMsgString);
					else
						-- Carga la informacion general (de o no error se carga lo mismo)
						set vSqlState = 'HY000';				-- informa el resultado: 'HY000' (general error) is used for client-side errors and if server-side errors hasen't MySQL error numbers
						set vErrorCode = 2000;					-- informa el numero de resultado, este se vincula con una descripcion personalizada en la base de datos.
																-- 2,000 to 2,999: Client error codes reserved for use by the client library.
						-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
						-- Resultado Erróneo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
						-- Todas estas variables se envian dentro del mensaje vMsgString, concatenandolas.	-- , cast(251 AS CHAR), '†'
						-- SQLState five-character string, for Client Error use always 'HY000'
						set vMsgString = concat('HY000', '†', 'Unknown MySQL error');
						-- vRowAffected no depende del vSP_NumConditions, se carga antes del if
						-- RETURN concat(vString, '†MsgString ', vMsgString);
					END IF;

		  END;
          */
		DECLARE CONTINUE HANDLER FOR SQLWARNING -- 1292 -- SQLWARNING
		  BEGIN
			get stacked diagnostics condition 1 vSqlState = returned_sqlstate, vMsgString = message_text;		-- Take the ondition information
		  END;
		-- Ejecuta programa
        -- #####################################################################################################################################################################################################
            SET vOrignalValue = vString;
			SET vString = TRIM(replace(vString, "/","-"));
			-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			/*CASE vFormat
				-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
				WHEN 'mm/dd/yyyy' THEN
			*/
            -- IF vFormat = 'mm/dd/yyyy' THEN
					-- MM/DD/YYYY		Month-Day-Year with leading zeros (02/17/2009)
					-- M/D/YYYY			Month-Day-Year with no leading zeros (2/17/2009)
					-- bM/bD/YYYY		Month-Day-Year with spaces instead of leading zeros	( 2/17/2009)
					SET vString = REGEXP_SUBSTR(vString, '(1[0-2]|[1-9]|0[1-9]| [1-9])-(3[0-1]|[1-2][0-9]|[1-9]|0[1-9]| [1-9])-([0-9]{4})',1,0);
					-- RETURN concat('When 1 - ',vString,' - ',vFormat,' - ',STR_TO_DATE(vString, '%m-%d-%Y'),' yyyy-mm-dd');		-- MM/DD/YY 	Month-Day-Year with leading zeros (02/17/2009)
					-- RETURN STR_TO_DATE(vString, '%m-%d-%Y');

                    -- SET vString = CAST(vString AS DATE);
                    -- SET vString = (SELECT CAST(vString AS DATE));
                    SET vString = (SELECT STR_TO_DATE(vString, '%d-%m-%Y'));
                    SET vResult = concat(' - Error ', vSqlState, ' - ErrorMessage ', vMsgString);
                    RETURN concat('iF 1 mm/dd/yyyy : ', ifnull(vString,' null'), ' Original ', vOrignalValue, vResult);
            /*	ELSE
					RETURN concat('Else: ',vString);
			END IF;
            */
                    /*
				ELSE
					RETURN vString;
			END CASE;*/
	END$$

DELIMITER ;


