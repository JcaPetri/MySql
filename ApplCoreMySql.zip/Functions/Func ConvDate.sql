USE `applcore`;
DROP function IF EXISTS `FncConvDate`;

DELIMITER $$
USE `applcore`$$

CREATE DEFINER=`root`@`localhost` FUNCTION `FncConvDate` (vString VARCHAR(1000),vFormat VARCHAR(10))
    RETURNS varchar(1000)
	DETERMINISTIC
BEGIN
	DECLARE vOrignalValue VARCHAR(1000) DEFAULT "";
	DECLARE vDate DATE;
    DECLARE vYear varchar(4) DEFAULT "";
    DECLARE vMonth varchar(2) DEFAULT "";
    DECLARE vDay varchar(2) DEFAULT "";
	DECLARE vStart tinyint default 0;
    DECLARE vEnd tinyint default 0;
    DECLARE vSP_NumConditions int DEFAULT 0;
    DECLARE vSqlState char(5) DEFAULT 0; 		-- SqlState, This value is a five-character string (for example, '42S02')
    DECLARE vErrorCode int DEFAULT 0;			-- ErrorCode, This value is numeric. It is MySQL-specific and is not portable to other database systems., este se vincula con una descripcion personalizada en la base de datos.
	DECLARE vMsgString TEXT DEFAULT 0;			-- MsgString, This string provides a textual description of the error.
    	-- exit if Errors occurs for sqlexception
    -- declare exit handler for sqlexception
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        BEGIN
			-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
			get stacked diagnostics vSP_NumConditions = number;				-- Take the condition number
			-- Depend of the vSP_NumConditions value, send the result
			if vSP_NumConditions > 0 then
				-- Report the first error
				get stacked diagnostics condition vSP_NumConditions vSqlState = returned_sqlstate, vErrorCode = mysql_errno, vMsgString = message_text;		-- Take the ondition information
				-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
				-- Resultado Erróneo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
				-- Todas estas variables se envian dentro del mensaje vMsgString, concatenandolas.	-- , cast(251 AS CHAR), '†'
				-- SQLState five-character string
			else
				-- Carga la informacion general (de o no error se carga lo mismo)
				set vSqlState = 'HY000';				-- informa el resultado: 'HY000' (general error) is used for client-side errors and if server-side errors hasen't MySQL error numbers
				set vErrorCode = 2200;					-- informa el numero de resultado, este se vincula con una descripcion personalizada en la base de datos.
														-- 2000 to 2999: Client error codes reserved for use by the client library.
                                                        -- 2200 Function Error
				set vMsgString = 'Unknown MySQL Function error';
				-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
				-- Resultado Erróneo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
				-- Todas estas variables se envian dentro del mensaje vMsgString, concatenandolas.	-- , cast(251 AS CHAR), '†'
				-- SQLState five-character string, for Client Error use always 'HY000'
			END IF;
			SET vMsgString = concat(vSqlState, '†', vErrorCode, '†', vMsgString);
			-- RETURN concat("Err = vString: ",vOrignalValue," - vFormat: ",vFormat, '†MsgString ', vMsgString);
            -- RETURN CONCAT(vOrignalValue, '†', vMsgString);
            RETURN vOrignalValue;
        END;
			-- #####################################################################################################################################################################################################
            SET vOrignalValue = vString;
			SET vString = TRIM(replace(vString, "/","-"));	-- Cambia la barra por el - y elimina espacios
            SET vFormat = TRIM(replace(vFormat, "/","-"));	-- Cambia la barra por el / y elimina espacios

			-- Aclaraciones
					-- vMonth ([1-9][0-9]|1[0-2]|[1-9]|0[1-9]| [1-9])
							-- [1-9][0-9] =  valores entre 13 y 99 - esto es para buscar errores
                            -- 1[0-2] = 10 a 12
                            -- [1-9] = 1 a 9	Esto genera el error de que si el numero es mayor de 12 toma solo el primer caracter
                            -- 0[1-9] = 01 a 09
                            --  [1-9] = b1 a b9 donde b es el espacio
                    -- vDay (3[0-1]|[1-2][0-9]|[1-9]|0[1-9]| [1-9]), toma los valores entre:
							--  [3-9][0-9] = valores entre 32 y 99 - esto es para buscar errores
							--  3[0-1] = 30 a 31
                            --  [1-2][0-9] = 10 a 20 o 20 a 29
                            --  [1-9] = 1 a 9	Esto genera el error de que si el numero es mayor que 31 toma solo el primer caracter
                            --  0[1-9] = 01 a 09
                            --  b[1-9] = b1 a b9 donde b es el espacio
			CASE vFormat
				-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
				WHEN 'mm-dd-yyyy' THEN		-- 1(2)-4(2)-7(4)
					-- MM-DD-YYYY		Month-Day-Year with leading zeros (02/17/2009)
					-- M-D-YYYY			Month-Day-Year with no leading zeros (2/17/2009)
					-- bM-bD-YYYY		Month-Day-Year with spaces instead of leading zeros	( 2/17/2009)
					SET vString = REGEXP_SUBSTR(vString, '([1-9][0-9]|1[0-2]|[1-9]|0[1-9]| [1-9])-([3-9][0-9]|3[0-1]|[1-2][0-9]|[1-9]|0[1-9]| [1-9])-([0-9]{4}|[0-9]{2})',1,0);
					-- vMonth
						SET vStart = 1;
                        SET vEnd = locate("-",vString,1);						-- Se le resta 1 para eliminar el guion
						SET vMonth = SUBSTRING(vString,vStart,(vEnd-vStart));	-- Como son cantidad de espacio se resta el final menos el inicio
					-- vDay
						SET vStart = vEnd + 1;									-- Se le suma 1 por el guion
                        SET vEnd = locate("-",vString,vStart);					-- Se le resta 1 para eliminar el guion
						SET vDay = SUBSTRING(vString,vStart,(vEnd-vStart));		-- Como son cantidad de espacio se resta el final menos el inicio
					-- vYear
						SET vStart = vEnd + 1;									-- Se le suma 1 por el guion
                        SET vEnd = length(vString) + 1;							-- Se suma 1 tomar el ultimo caracter
						SET vYear = SUBSTRING(vString,vStart,(vEnd-vStart));	-- Como son cantidad de espacio se resta el final menos el inicio
				-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
				WHEN 'mm-dd-yy' THEN		-- 1(2)-4(2)-7(2)
					-- Desde el 0 al 69 pone 20 dos mil xx, luego del 70 pone 19 mi novesciento xx
					-- MM/DD/YY		Month-Day-Year with leading zeros (02/17/09) = 2009
					-- M/D/YY			Month-Day-Year with no leading zeros (2/17/09) = 2009
					-- bM/bD/YY		Month-Day-Year with spaces instead of leading zeros	( 2/17/09) = 2009
					SET vString = REGEXP_SUBSTR(vString, '([1-9][0-9]|1[0-2]|[1-9]|0[1-9]| [1-9])-([3-9][0-9]|3[0-1]|[1-2][0-9]|[1-9]|0[1-9]| [1-9])-([0-9]{4}|[0-9]{2})',1,0);
					-- vMonth
						SET vStart = 1;
                        SET vEnd = locate("-",vString,1);						-- Se le resta 1 para eliminar el guion
						SET vMonth = SUBSTRING(vString,vStart,(vEnd-vStart));	-- Como son cantidad de espacio se resta el final menos el inicio
					-- vDay
						SET vStart = vEnd + 1;									-- Se le suma 1 por el guion
                        SET vEnd = locate("-",vString,vStart);					-- Se le resta 1 para eliminar el guion
						SET vDay = SUBSTRING(vString,vStart,(vEnd-vStart));		-- Como son cantidad de espacio se resta el final menos el inicio
					-- vYear
						SET vStart = vEnd + 1;									-- Se le suma 1 por el guion
                        SET vEnd = length(vString) + 1;							-- Se suma 1 tomar el ultimo caracter
						SET vYear = SUBSTRING(vString,vStart,(vEnd-vStart));	-- Como son cantidad de espacio se resta el final menos el inicio
				-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
				WHEN 'dd-mm-yyyy' THEN		-- 1(2)-4(2)-7(4)
					-- DD/MM/YYYY		Day-Month-Year with leading zeros (17/02/2009)
					-- D/M/YYYY			Day-Month-Year with no leading zeros (17/2/2009)
					-- bD/bM/YYYY		Day-Month-Year with spaces instead of leading zeros	(17/ 2/2009)
					SET vString = REGEXP_SUBSTR(vString, '([3-9][0-9]|3[0-1]|[1-2][0-9]|[1-9]|0[1-9]| [1-9])-([1-9][0-9]|1[0-2]|[1-9]|0[1-9]| [1-9])-([0-9]{4}|[0-9]{2})',1,0);
					SET vYear = SUBSTRING(vString,7,4);
					SET vMonth = SUBSTRING(vString,4,2);
					SET vDay = SUBSTRING(vString,1,2);
					-- vDay
						SET vStart = 1;
                        SET vEnd = locate("-",vString,1);						-- Se le resta 1 para eliminar el guion
						SET vDay = SUBSTRING(vString,vStart,(vEnd-vStart));	-- Como son cantidad de espacio se resta el final menos el inicio
					-- vMonth
						SET vStart = vEnd + 1;									-- Se le suma 1 por el guion
                        SET vEnd = locate("-",vString,vStart);					-- Se le resta 1 para eliminar el guion
						SET vMonth = SUBSTRING(vString,vStart,(vEnd-vStart));		-- Como son cantidad de espacio se resta el final menos el inicio
					-- vYear
						SET vStart = vEnd + 1;									-- Se le suma 1 por el guion
                        SET vEnd = length(vString) + 1;							-- Se suma 1 tomar el ultimo caracter
						SET vYear = SUBSTRING(vString,vStart,(vEnd-vStart));	-- Como son cantidad de espacio se resta el final menos el inicio
				-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
				WHEN 'dd-mm-yy' THEN		-- 1(2)-4(2)-7(2)
					-- Desde el 0 al 69 pone 20 dos mil xx, luego del 70 pone 19 mi novesciento xx
					-- DD/MM/YY			Day-Month-Year with leading zeros (17/02/09) = 2009
					-- D/M/YY			Day-Month-Year with no leading zeros (17/2/09) = 2009
					-- bD/bM/YY			Day-Month-Year with spaces instead of leading zeros	(17/ 2/09) = 2009
					SET vString = REGEXP_SUBSTR(vString, '([3-9][0-9]|3[0-1]|[1-2][0-9]|[1-9]|0[1-9]| [1-9])-([1-9][0-9]|1[0-2]|[1-9]|0[1-9]| [1-9])-([0-9]{4}|[0-9]{2})',1,0);
					-- vDay
						SET vStart = 1;
                        SET vEnd = locate("-",vString,1);						-- Se le resta 1 para eliminar el guion
						SET vDay = SUBSTRING(vString,vStart,(vEnd-vStart));	-- Como son cantidad de espacio se resta el final menos el inicio
					-- vMonth
						SET vStart = vEnd + 1;									-- Se le suma 1 por el guion
                        SET vEnd = locate("-",vString,vStart);					-- Se le resta 1 para eliminar el guion
						SET vMonth = SUBSTRING(vString,vStart,(vEnd-vStart));		-- Como son cantidad de espacio se resta el final menos el inicio
					-- vYear
						SET vStart = vEnd + 1;									-- Se le suma 1 por el guion
                        SET vEnd = length(vString) + 1;							-- Se suma 1 tomar el ultimo caracter
						SET vYear = SUBSTRING(vString,vStart,(vEnd-vStart));	-- Como son cantidad de espacio se resta el final menos el inicio
				-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
				WHEN 'yyyy-mm-dd' THEN		-- 1(4)-6(2)-9(2)
					-- YYYY/MM/DD		Year-Month-Day with leading zeros (2009/02/17)
					-- YYYY/M/D			Year-Month-Day with no leading zeros (2009/2/17)
					-- YYYY/bM/bD		Year-Month-Day with spaces instead of leading zeros (2009/ 2/17)
					SET vString = REGEXP_SUBSTR(vString, '([0-9]{4}|[0-9]{2})-([1-9][0-9]|1[0-2]|[1-9]|0[1-9]| [1-9])-([3-9][0-9]|3[0-1]|[1-2][0-9]|[1-9]|0[1-9]| [1-9])',1,0);
					-- vYear
						SET vStart = 1;
                        SET vEnd = locate("-",vString,1);						-- Se le resta 1 para eliminar el guion
						SET vYear = SUBSTRING(vString,vStart,(vEnd-vStart));	-- Como son cantidad de espacio se resta el final menos el inicio
					-- vMonth
						SET vStart = vEnd + 1;									-- Se le suma 1 por el guion
                        SET vEnd = locate("-",vString,vStart);					-- Se le resta 1 para eliminar el guion
						SET vMonth = SUBSTRING(vString,vStart,(vEnd-vStart));	-- Como son cantidad de espacio se resta el final menos el inicio
					-- vDay
						SET vStart = vEnd + 1;									-- Se le suma 1 por el guion
                        SET vEnd = length(vString) + 1;							-- Se suma 1 tomar el ultimo caracter
						SET vDay = SUBSTRING(vString,vStart,(vEnd-vStart));		-- Como son cantidad de espacio se resta el final menos el inicio
				-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
				WHEN 'yy-mm-dd' THEN		-- 1(2)-4(2)-7(2)
					-- Desde el 0 al 69 pone 20 dos mil xx, luego del 70 pone 19 mi novesciento xx
					-- YY/MM/DD			Year-Month-Day with leading zeros (09/02/17) = 2009
					-- YY/M/D			Year-Month-Day with no leading zeros (09/2/17) = 2009
					-- YY/bM/bD			Year-Month-Day with spaces instead of leading zeros (09/ 2/17) = 2009
					SET vString = REGEXP_SUBSTR(vString, '([0-9]{4}|[0-9]{2})-([1-9][0-9]|1[0-2]|[1-9]|0[1-9]| [1-9])-([3-9][0-9]|3[0-1]|[1-2][0-9]|[1-9]|0[1-9]| [1-9])',1,0);
					-- vYear
						SET vStart = 1;
                        SET vEnd = locate("-",vString,1);						-- Se le resta 1 para eliminar el guion
						SET vYear = SUBSTRING(vString,vStart,(vEnd-vStart));	-- Como son cantidad de espacio se resta el final menos el inicio
					-- vMonth
						SET vStart = vEnd + 1;									-- Se le suma 1 por el guion
                        SET vEnd = locate("-",vString,vStart);					-- Se le resta 1 para eliminar el guion
						SET vMonth = SUBSTRING(vString,vStart,(vEnd-vStart));	-- Como son cantidad de espacio se resta el final menos el inicio
					-- vDay
						SET vStart = vEnd + 1;									-- Se le suma 1 por el guion
                        SET vEnd = length(vString) + 1;							-- Se suma 1 tomar el ultimo caracter
						SET vDay = SUBSTRING(vString,vStart,(vEnd-vStart));		-- Como son cantidad de espacio se resta el final menos el inicio
				-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
				WHEN 'mmddyyyy' THEN		-- 1(2)-3(2)-5(4)
					-- MMDDYYYY			Month-Day-Year with leading zeros (02172009)
					SET vString = REGEXP_SUBSTR(vString, '([1-9][0-9]|1[0-2]|[1-9]|0[1-9]| [1-9])([3-9][0-9]|3[0-1]|[1-2][0-9]|[1-9]|0[1-9]| [1-9])([0-9]{4})',1,0);
                    if length(vString) = 8 then
						SET vYear = SUBSTRING(vString,5,4);
						SET vMonth = SUBSTRING(vString,1,2);
						SET vDay = SUBSTRING(vString,3,2);
                    else
						SET vYear = null;
						SET vMonth = null;
						SET vDay = null;
                    end if;
				-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
				WHEN 'ddmmyyyy' THEN		-- 1(2)-3(2)-5(4)
					-- DDMMYYYY			Day-Month-Year with leading zeros (02172009)
					SET vString = REGEXP_SUBSTR(vString, '([3-9][0-9]|3[0-1]|[1-2][0-9]|[1-9]|0[1-9]| [1-9])([1-9][0-9]|1[0-2]|[1-9]|0[1-9]| [1-9])([0-9]{4})',1,0);
                    if length(vString) = 8 then
						SET vYear = SUBSTRING(vString,5,4);
						SET vMonth = SUBSTRING(vString,3,2);
						SET vDay = SUBSTRING(vString,1,2);
                    else
						SET vYear = null;
						SET vMonth = null;
						SET vDay = null;
                    end if;
				-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
				WHEN 'yyyymmdd' THEN		-- 1(4)-5(2)-7(2)
					-- DDMMYYYY			Day-Month-Year with leading zeros (02172009)
					SET vString = REGEXP_SUBSTR(vString, '([0-9]{4})([1-9][0-9]|1[0-2]|[1-9]|0[1-9]| [1-9])([3-9][0-9]|3[0-1]|[1-2][0-9]|[1-9]|0[1-9]| [1-9])',1,0);
                    if length(vString) = 8 then
						SET vYear = SUBSTRING(vString,1,4);
						SET vMonth = SUBSTRING(vString,5,2);
						SET vDay = SUBSTRING(vString,7,2);		
                    else
						SET vYear = null;
						SET vMonth = null;
						SET vDay = null;
                    end if;
				-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
				ELSE
					-- Genera el Error
                    -- Cuando se genera el else, los valores de vYear, vMonth, vDay son null, por ende el concat da --
                    SET vFormat = "Else";
			END CASE;
			-- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			-- RETURN concat(vFormat," = ",vYear,"†",vMonth,"†",vDay);
            -- Convierte los elementos obtenidos en una fecha, si es error, da null, y si da null devuelve el valor original
			SET vDate = CAST(concat(vYear,"-",vMonth,"-",vDay) AS DATE);		-- MySql yyyy-mm-dd
            -- Cuando se genera el else, los valores de vYear, vMonth, vDay son null, por ende el concat da --
            IF (CAST(vMonth AS SIGNED) < 1 or CAST(vMonth AS SIGNED) > 12) then set vMonth = null; end if;
            IF (CAST(vDay AS SIGNED) < 1 or CAST(vDay AS SIGNED) > 31) then set vDay = null; end if;
			RETURN IFNULL(vDate,vOrignalValue);
            -- #####################################################################################################################################################################################################
END$$

DELIMITER ;


