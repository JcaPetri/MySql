USE applcore;
-- #################################################################################################################################################################################################
-- Pasos: (Para asociar el rastro de los registros, primero le asigna un valor UniqueID a los datos importados)
	-- `ApplCore`.`ApplTDataElement`						// El Diccionario
			-- Inserta datos Masivos desde la tabla ApplImpTArticlesOpcionalField, creando los registros en la tabla ApplTDataElement
    -- `ApplCore`.`ApplTTableFieldsValues`					// Opciones disponibles para las distintas columna/fields
			-- Inserta datos Masivos en la tabla ApplTTableFieldsValues
-- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Crea los valores posibles para cada columna en la tabla ApplTDataElement
-- Aclaraciones:
	-- Los valores que forman la lista de opciones de cada Field/Columna, se cargan en el ScopeIDn del Field/Columna indicada
	-- esto es ya que la clave primaria es TableFieldValueIDn + TableFieldIDn + CompanyIDn
	-- Por lo tanto, si se cargara en la tabla ApplTTableFieldsValues ScopeIDn 2206, una determina descripcion, no podria cargarse dentro de varias columnas
	-- ya que infringiria la clave de duplicidad. Ej, la palabra Autor, puede ser una marca o puede ser una opcion para otra columna y representan cosas distintas en cada una
	-- IMPORTANTE: Conclusion, los valores opcionales de cada columna se cargan en el ScopeIDn de la columna a donde pertenece el valor
-- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

-- #################################################################################################################################################################################################
-- Controles
-- -----------------------------------------------------------------------------------------------------------------------------------------
/*
SELECT * FROM applcore.applimpttablefieldsvalues;
DELETE FROM applcore.applimpttablefieldsvalues;

SELECT * FROM  ApplCore.ApplImpTTableFieldsValues WHERE LOWER(IDName) LIKE '%Keyroad%';

-- Busca Duplicados
SELECT CompanyIDn, TableFieldIDn, FieldValue, COUNT(*) 'Q' FROM applcore.applimpttablefieldsvalues GROUP BY CompanyIDn, TableFieldIDn, FieldValue HAVING COUNT(*) > 1;


-- Verifica que los FieldValueIDn no esten ya creados para esa CompanyIDn y el ScopeIDn que es el TableFieldIDn
-- Esto es porque la Clave Primaria para cargar un nuevo registro es: IDName + ScopeIDn + CompanyIDn
SELECT * FROM `applcore`.`applimpttablefieldsvalues` `itf` 
	INNER JOIN `ApplCore`.`ApplTDataElement` `de` 
		ON `itf`.`CompanyIDn` = `de`.`CompanyIDn`
			AND `itf`.`TableFieldIDn` = `de`.`ScopeIDn`
			AND `itf`.`FieldValue` = `de`.`IDName`
            ;

SELECT * FROM `ApplCore`.`ApplTDataElement` `de` 
	WHERE IDName LIKE "%Talonarios de Facturas%"
;

DELETE FROM `applcore`.`applimpttablefieldsvalues` 
	WHERE FieldValue = "Notas Autoadhesivas 75x75mm 80h Fluo " AND TableFieldIDn = 2224
    ;

UPDATE `applcore`.`applimpttablefieldsvalues`
SET `FieldValue` = REPLACE(`FieldValue`, ";", ",");

SELECT `FieldValue`, REPLACE(`FieldValue`, ";", ",") `Value` FROM `applcore`.`applimpttablefieldsvalues`;

SELECT * FROM applcore.applimpttablefieldsvalues;
*/

-- #################################################################################################################################################################################################
-- Setea las variables
set @vIDNameStructureIDn = 1;		-- Es el IDNum de la estructura del IDName - si es multivaluado - aqui esta la estructura
set @vLanguageIDn = 734;			-- Español
set @vCompanyIDn = 2142; 			-- 2142 Peperina / 2143 Tagle / 2144 UniversalBuildCompany
set @vIDCode = 0;					-- 0 = Codigo incrementalmente autogenerado - Codigo numerico establecido por el usuario, permite organizar los contenidos de la tabla por rangos
set @vDefinitionIDn = 2070;			-- bpmndefaultdefinition
set @vInformationTypeIDn = 381;		-- 381 Data / 382 Software
set @vIDIsUsed = 1;					-- True
set @vStateIDn = 372;				-- 372 Enable Habilitado / 373 Disable Deshabilitado
set @vCreatedByIDn = 1;				-- Usuario
set @vLastModifiedByIDn = 1;		-- Usuario
set @vOwnerIDn = 1;					-- Usuario
set @vDateCreated = current_timestamp;			-- Es la fecha de creacion del registro, es la fecha y hora actual segun el posicionamiento actual
set @vDateTimeStamp = current_timestamp;			-- Es la fecha de la ultima modificacion del registro, es la fecha y hora actual segun el posicionamiento actual
set @vTzNameIDn = 1206;				-- America/Buenos_Aires
set @vTzOffset = timestampdiff(minute, utc_timestamp(), current_timestamp());	-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro 
set @vTableHistory = null;			-- Es el historico del registro
-- Variables para insertar los registros en la tabla ApplLogArticles
set @ArticleGeneralIDn = 2;					-- Es el IDNum de las caracteristicas Generales del Articulo, esta en la tabla appllogtarticlesgeneral
set @BarCode = null;						-- Es el codigo de barra
set @StockEnable = 1;						-- True = 1 / False = 0

-- #################################################################################################################################################################################################
-- 1.- Le Asigna un ID uniqueidentifier a todos los registros de la tabla ApplCore.ApplimpTArticles
-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
UPDATE `applcore`.`applimpttablefieldsvalues`
SET `ID` = uuid()
WHERE ID is null;

-- #################################################################################################################################################################################################
-- 1.- Inserta todos los registros en la tabla `ApplCore`.`ApplTDataElement` que estan en la tabla ApplCore.ApplImpTArticlesOpcionalField
-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	INSERT INTO `ApplCore`.`ApplTDataElement`
			(`ID`,
			-- `IDNum`,
			`IDName`,
			`IDNameStructureIDn`,
			`ScopeIDn`,
			`CompanyIDn`,
			`LanguageIDn`,
			`IDCode`,
			`DefinitionIDn`,
			`InformationTypeIDn`,
			`IDIsUsed`,
			`StateIDn`,
			`CreatedByIDn`,
			`LastModifiedByIDn`,
			`OwnerIDn`,
			`DateCreated`,
			`DateTimeStamp`,
			`TzNameIDn`,
			`TzOffset`,
			`TableHistory`)
		SELECT 	`itf`.`ID`,						-- UniqueIdentifier, es autogenerado en la consulta anterior
				-- `ia`.ArticleSupplierID, 		-- Es el codigo del articulo para ese proveedor
				`itf`.`FieldValue`,					-- Es la descripcion del articulo
				@vIDNameStructureIDn `IDNameStructureIDn`,	-- Es el IDNum de la estructura del IDName, si es multivaluado, aqui esta la estructura
				`itf`.`TableFieldIDn` `ScopeIDn`,				-- Es el IDNum del Ambito de Aplicación / Tabla a la que pertenece el registro, numeros variales
				@vCompanyIDn `CompanyIDn`,			-- Es el IDNum de la Compania dueña del Registro, Scope = 25, 2207 System, 7566 Tagle, 7565 Peperina
				@vLanguageIDn `LanguageIDn`, 		-- Es el IDNum del Idioma del Registro, Scope = 11 TSysLanguage, 652 English -- Codigo del idioma por defecto elegido. Este es el mismo durante todo el sistema.
				@vIDCode `IDCode`,					-- Codigo numerico establecido por el usuario, permite organizar los contenidos de la tabla por rangos, se carga automaticamente si no se especifica
				@vDefinitionIDn `DefinitionIDn`,		-- Es el IDNum del tipo de definicion del elemento, Scope = 23 tSysDefinition, 2070 bpmndefaultdefinition
				@vInformationTypeIDn `InformationTypeIDn`,	-- Es el IDNum del tipo de Registro, Scope = 18 tSisInfoType, 381 Data, 382 Software = definición del código, bajo que estandar esta escrito. Define el tipo de dato que es el BaseElement, puede ser: Data (son los elementos reales que forman el sistema, los procesos, etc.), Software (es la estructura BMPN, XML, XSD).	
				@vIDIsUsed `IDIsUsed`,						-- 1 = true, 0 = false
				@vStateIDn `StateIDn`,						-- Es el IDNum del estado del registro, Scope = 21 tSisState, 372 Ena, 373 Dis
				@vCreatedByIDn `CreatedByIDn`,					-- Es el IdNum del usuario que creo el registro, Scope = 231 UserTUser, numeros variales
				@vLastModifiedByIDn `LastModifiedByIDn`,				-- Es el IdNum del ultimo usuario que modifico el registro, Scope = 231 UserTUser, numeros variales
				@vOwnerIDn `OwnerIDn`,						-- Es el IdNum del usuario dueño del registro, Scope = 231 UserTUser, numeros variales
				@vDateCreated `DateCreated`,		-- Es la fecha de creacion del registro, es la fecha y hora actual segun el posicionamiento actual
				@vDateTimeStamp `DateTimeStamp`,	-- Es la fecha de la ultima modificacion del registro, es la fecha y hora actual segun el posicionamiento actual
													-- Cuando se crea el registro, el DateCreated y DateTimeStamp son iguales
				@vTzNameIDn, 						-- Es el IdNum de la Time Zone del la fecha
				@vTzOffset `TzOffset`, 				-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
									-- como es en horas y minutos, aqui se registra la diferencia real en horas y minutos
				@vTableHistory `TableHistory`	-- Es el historico del registro
			FROM applcore.applimpttablefieldsvalues `itf`;

-- #################################################################################################################################################################################################
-- 2.- Inserta todos los registros en la tabla `ApplCore`.`ApplTTableFieldsValues`
-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	INSERT INTO `Applcore`.`ApplTTableFieldsValues`
			(`TableFieldValueIDn`,
			`TableFieldIDn`,
			`CompanyIDn`,
			`StateIDn`,
			`CreatedByIDn`,
			`LastModifiedByIDn`,
			`OwnerIDn`,
			`DateCreated`,
			`DateTimeStamp`,
			`TzNameIDn`,
			`TzOffset`,
			`TableHistory`)
		SELECT
				`de`.`IDNum` `TableFieldValueIDn`,						-- Es el IdNum de la TableFieldValueIDn se crea en el DataElement
				`de`.`ScopeIDn` `TableFieldIDn`,						-- Es el IdNum de la TableFieldIDn que es la columna que recibira la lista de opciones disponibles, (que son los Campos/Fields disponibles, estan en el ScopeIDn = 4 SysTTableFields)
				@vCompanyIDn `CompanyIDn`,			-- Es el IDNum de la Compania dueña del Registro, Scope = 25, 2207 System, 7566 Tagle, 7565 Peperina
																				-- la clave primaria, es la PropertyValueOption + el PropertyValue + CompanyIDn
				@vStateIDn `StateIDn`,						-- Es el IDNum del estado del registro, Scope = 21 tSisState, 372 Ena, 373 Dis
				@vCreatedByIDn `CreatedByIDn`,					-- Es el IdNum del usuario que creo el registro, Scope = 231 UserTUser, numeros variales
				@vLastModifiedByIDn `LastModifiedByIDn`,				-- Es el IdNum del ultimo usuario que modifico el registro, Scope = 231 UserTUser, numeros variales
				@vOwnerIDn `OwnerIDn`,						-- Es el IdNum del usuario dueño del registro, Scope = 231 UserTUser, numeros variales
				@vDateCreated `DateCreated`,		-- Es la fecha de creacion del registro, es la fecha y hora actual segun el posicionamiento actual
				@vDateTimeStamp `DateTimeStamp`,	-- Es la fecha de la ultima modificacion del registro, es la fecha y hora actual segun el posicionamiento actual
													-- Cuando se crea el registro, el DateCreated y DateTimeStamp son iguales
				@vTzNameIDn, 						-- Es el IdNum de la Time Zone del la fecha
				@vTzOffset `TzOffset`, 				-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
									-- como es en horas y minutos, aqui se registra la diferencia real en horas y minutos
				@vTableHistory `TableHistory`	-- Es el historico del registro
			FROM `applcore`.`applimpttablefieldsvalues` `itf`
				INNER JOIN `applcore`.`appltdataelement` `de`
					ON `itf`.`ID` = `de`.`ID`;

/*
-- #################################################################################################################################################################################################
-- CONTROLES
-- Lista los Scopes donde se insertaron los datos
SELECT * FROM `ApplCore`.`ApplTDataElement` `de`
	INNER JOIN (
				SELECT `TableFieldIDn` 
					FROM `applcore`.`applimpttablefieldsvalues`
                    GROUP BY `TableFieldIDn`
				) `itf`
		ON `de`.`ScopeIDn` = `itf`.`TableFieldIDn`
ORDER BY `ScopeIDn`, `IDCode` Desc;

SELECT `tfv`.`CompanyIDn`, `tfv`.`TableFieldIDn`, `tfv`.`TableFieldValueIDn` 
FROM `Applcore`.`ApplTTableFieldsValues` `tfv`
	INNER JOIN (
				SELECT `TableFieldIDn` 
					FROM `applcore`.`applimpttablefieldsvalues`
                    GROUP BY `TableFieldIDn`
				) `itf`
		ON `tfv`.`TableFieldIDn` = `itf`.`TableFieldIDn`
ORDER BY `TableFieldValueIDn`
;
-- #################################################################################################################################################################################################
*/

-- #################################################################################################################################################################################################
-- 3.- Elimina los registros Ya Procesados de la Tabla `ApplCore`.`ApplImpTArticlesOpcionalField`
-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
DELETE FROM `applcore`.`applimpttablefieldsvalues`;

-- ######################################################################################################################################################################################################
-- ######################################################################################################################################################################################################
-- ######################################################################################################################################################################################################

-- SELECT * FROM applcore.appllogvtablefieldsvalues;

SELECT CompanyIDn, ScopeIDn, IDNum, CONCAT(`Field Scope`,'-',`Field Value`) 'ColFieldValue' FROM applcore.applvdataelementoptionfieldvalue;





