USE applcore;
-- #################################################################################################################################################################################################
/*
			Crear los ApplLogTArticlesOptionalFields, que contiene las columnas/fields/propiedades de la Tabla ApplLogTArticles que son opcionales
				Las columnas se crean en la tabla `bpmcore`.`BpmfouTBaseElement` ya que son estructura del sistema, cada columna es una propiedad del articulo
                estas se crean en el Scope 4 y para la empresa 2207 System
					Para ello hay que ejcutar el StoredProcedure:
						Sys StProc 004 - SysPTableFields Calls.sql que llama al Sys StProc 004 - SysPTableFieldsCreate.sql

				Los datos de las empresas se crea en la base `ApplCore`.`ApplTDataElement` (Diccionario), 
                dentro del scope de cada Field/Column y la empresa definida, esto es para que una misma descripcion 
                puede estar en mas de una columna y puede representar cosas distintas, 
                Ej Autor como marca de resma y Autor como Opcion
				pero para que pueda utilizarse se debe agregar en la tabla `ApplCore`.`ApplArtTArticlesOptionalFields`, 
				donde se le definen las distintas propiedades y desde aqui se vincula con las otras tablas
                La clave primaria: es la propiedad ArticlePropertyIDn (columna) + el ArticleIDn (Tabla) + CompanyIDn
					SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 3 and IDNum >= 2199;
						IDNum	IDName								ScopeIDn	CompanyIDn		IDCode
						2206	ApplArtTArticlesOptionalFields			3			2207		1206
                -- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                IMPORTANTE:
					En esta tabla se cargan los IDn que vinculan la TableFieldIDn, el ArticleIDn, y la CompanyIDn 
                    al que se le define el FieldValueIDn, FieldNumValue, FieldTextValue
                    Como los FieldValueIDn es un elemento IDn, se debe crear primero en la tabla DataElement
						primero ejecutar el 1.2.1- Creacion del Valor FieldValueIDn y luego agregar los OptionalFields
                -- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                
			-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			ACLARACION:
				Las propiedades de los articulos vienen dadas:
						1.- primero por los parametros generales, 
						2.- segundo por los parametros individuales de la tabla articulos
				 Si hay un parametro individual (tabla articulos), este sobreescribe los parametros generales
				 Para Crear un articulo, primero debemos crear el parametro general y 
				 luego crear el articulo y asociarle si o si un parametro general en el 
				 campo GeneralParameterIDn de la tabla appllogtarticles
				 la clave primaria, es el GeneralIDn (Tabla) + CompanyIDn

            -- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				SELECT * FROM `ApplCore`.`ApplLogTArticlesOptionalFields`;
                SELECT * FROM `ApplCore`.`ApplImpTArticlesOpcVal`;
            -- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
*/
-- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


-- #################################################################################################################################################################################################
-- Controles
-- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
/*
SELECT * FROM `applcore`.`applimptarticlesopcval` `iaov`
ORDER BY CompanyIDn, ArticleIDn, TableFieldIDn, FieldValueIDn;

-- DELETE  FROM `applcore`.`applimptarticlesopcval`;

-- Inserta los Valores con TablaField
-- Determina si hay duplicados con TableFieldIDn
SELECT CompanyIDn, ArticleIDn, TableFieldIDn, COUNT(*) Q 
FROM applcore.applimptarticlesopcval 
GROUP BY CompanyIDn, ArticleIDn, TableFieldIDn 
HAVING COUNT(*) > 1
ORDER BY COUNT(*) DESC;

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Determina si los registros importados ya estan cargados
SELECT  * FROM `applcore`.`applimptarticlesopcval` `iaov`
	INNER JOIN `applcore`.`appllogtarticlesoptionalfields` `aof`
		ON `iaov`.`CompanyIDn` = `aof`.`CompanyIDn`
			AND `iaov`.`ArticleIDn` = `aof`.`ArticleIDn`
			AND `iaov`.`TableFieldIDn` = `aof`.`TableFieldIDn`
ORDER BY `iaov`.`CompanyIDn`, `iaov`.`ArticleIDn`, `iaov`.`TableFieldIDn`;

-- Verifica que no haya duplicados en la tabla appllogtarticlesoptionalfields
SELECT `aof`.`CompanyIDn`, `aof`.`ArticleIDn`, `aof`.`TableFieldIDn`, COUNT(*) 'Q' 
	FROM `applcore`.`appllogtarticlesoptionalfields` `aof`
GROUP BY `aof`.`CompanyIDn`, `aof`.`ArticleIDn`, `aof`.`TableFieldIDn`
HAVING COUNT(*) > 1;

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
*/

-- #################################################################################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Paso 1: Actualiza los Registros que ya estan incorporados
-- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Etapa 1.1: Primero depura los registros importados
	UPDATE `applcore`.`applimptarticlesopcval`
	SET `FieldValueIDn` = IF(TRIM(`FieldValueIDn`) IS NULL OR TRIM(`FieldValueIDn`) = '', NULL, `FieldValueIDn`),
	`FieldNumValue` = IF(TRIM(`FieldNumValue`) IS NULL OR TRIM(`FieldNumValue`) = '', NULL, `FieldNumValue`),
	`FieldTextValue` = IF(TRIM(`FieldTextValue`) IS NULL OR TRIM(`FieldTextValue`) = '', NULL, `FieldTextValue`);
	-- SELECT * FROM `applcore`.`applimptarticlesopcval`;

	-- SELECT IF(TRIM(`FieldValueIDn`) IS NULL, NULL, `FieldValueIDn`) AS `FieldValueIDn`, IF(TRIM(`FieldNumValue`) = '', NULL, `FieldNumValue`) AS `FieldNumValue`, IF(TRIM(`FieldTextValue`) = '', NULL, `FieldTextValue`) AS `FieldTextValue` FROM `applcore`.`applimptarticlesopcval`;
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Etapa 1.2: Luego hacerlo en la consulta de actualizacion masiva
	UPDATE `Applcore`.`ApplLogTArticlesOptionalFields` `aof`
		INNER JOIN `applcore`.`applimptarticlesopcval` `iaov`
			ON `aof`.`CompanyIDn` = `iaov`.`CompanyIDn`
				AND `aof`.`ArticleIDn` = `iaov`.`ArticleIDn`
				AND `aof`.`TableFieldIDn` = `iaov`.`TableFieldIDn`
	SET
			`aof`.`FieldValueIDn` = `iaov`.`FieldValueIDn`,
			`aof`.`FieldNumValue` = `iaov`.`FieldNumValue`,
			`aof`.`FieldTextValue` = `iaov`.`FieldTextValue`,
			`TableHistory` = "SetOff"				-- 	"SetNull", "SetOff"
	;


-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Etapa 1.3: Borra los Registros que ya estan incorporados
UPDATE `applcore`.`applimptarticlesopcval` `iaov` 
	INNER JOIN `applcore`.`appllogtarticlesoptionalfields` `aof`
		ON `iaov`.`CompanyIDn` = `aof`.`CompanyIDn`
			AND `iaov`.`ArticleIDn` = `aof`.`ArticleIDn`
			AND `iaov`.`TableFieldIDn` = `aof`.`TableFieldIDn`
            AND `iaov`.`FieldValueIDn` = `aof`.`FieldValueIDn`
SET `iaov`.`FieldTextValue` = 'Borrar'; 
DELETE FROM `applcore`.`applimptarticlesopcval` WHERE `FieldTextValue` = 'Borrar'; 
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
/* Verifica la consulta de eliminacion
SELECT * FROM `applcore`.`applimptarticlesopcval` `iaov` 
	INNER JOIN `applcore`.`appllogtarticlesoptionalfields` `aof`
		ON `iaov`.`CompanyIDn` = `aof`.`CompanyIDn`
			AND `iaov`.`ArticleIDn` = `aof`.`ArticleIDn`
			AND `iaov`.`TableFieldIDn` = `aof`.`TableFieldIDn`
            AND `iaov`.`FieldValueIDn` = `aof`.`FieldValueIDn`
*/
-- #################################################################################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Paso 2: Inserta los registros que queda
-- -----------------------------------------------------------------------------------------------------------------------------------------------

-- Muestra los datos que quedan
-- SELECT * FROM `applcore`.`applimptarticlesopcval`;

-- -----------------------------------------------------------------------------------------------------------------------------------------------
-- Inserta los datos Importados que faltan
			INSERT INTO `applcore`.`appllogtarticlesoptionalfields`
					(`TableFieldIDn`,
					`ArticleIDn`,
					`CompanyIDn`,
					`FieldValueIDn`,
					`FieldNumValue`,
					`FieldTextValue`,
					`StateIDn`,
					`CreatedByIDn`,
					`LastModifiedByIDn`,
					`OwnerIDn`,
					`DateCreated`,
					`DateTimeStamp`,
					`TzNameIDn`,
					`TzOffset`,
					`TableHistory`)
			SELECT  `iaov`.`TableFieldIDn`,			-- Es el IdNum de la propiedad del Articulo (Columna de la Tabla), se crea en la tabla bpmfoutbaseelement
					`iaov`.`ArticleIDn`,				-- Es el IdNum del Articulo en el DataElement
					`iaov`.`CompanyIDn`,					-- Es el IdNum de la Company al que esta asignado el IDName
															-- Es el IdNum de la Company: 2142 Peperina / 2143 Tagle / 2144 UniversalBuildCompany
					IF(`iaov`.`FieldValueIDn` = '', NULL, CAST(TRIM(SUBSTRING(`iaov`.`FieldValueIDn`, 1, 250)) AS UNSIGNED)) 'FieldValueIDn',		-- Es el IDNum del valor de esa Propiedad, este valor se carga en el DataElement
					IF(`iaov`.`FieldNumValue` = '', NULL, TRIM(SUBSTRING(`iaov`.`FieldNumValue`, 1, 250))) 'FieldNumValue',						-- Es un valor numerico definido por el usuario
                    IF(`iaov`.`FieldTextValue` = '', NULL, TRIM(SUBSTRING(`iaov`.`FieldTextValue`, 1, 250))) 'FieldTextValue',						-- Es un valor texto definido por el usuario
                    372 `StateIDn`,							-- Es el IDNum del estado del registro, Scope = 21 tSisState, 372 Ena, 373 Dis
					1 `CreatedByIDn`,						-- Es el IdNum del usuario que creo el registro, Scope = 231 UserTUser, numeros variales
					1 `LastModifiedByIDn`,					-- Es el IdNum del ultimo usuario que modifico el registro, Scope = 231 UserTUser, numeros variales
					1 `OwnerIDn`,							-- Es el IdNum del usuario dueño del registro, Scope = 231 UserTUser, numeros variales
					current_timestamp `DateCreated`,		-- Es la fecha de creacion del registro, es la fecha y hora actual segun el posicionamiento actual
					current_timestamp `DateTimeStamp`,		-- Es la fecha de la ultima modificacion del registro, es la fecha y hora actual segun el posicionamiento actual
					1206, 									-- Es el IdNum de la Time Zone del la fecha		 America/Buenos_Aires
					timestampdiff(minute, utc_timestamp(), current_timestamp()) `TzOffset`, 
										-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
										-- como es en horas y minutos, aqui se registra la diferencia real en horas y minutos
					null `TableHistory`						-- Es el historico del registro
            FROM `applcore`.`applimptarticlesopcval` `iaov` 
			ORDER BY `iaov`.`CompanyIDn`,
					 `iaov`.`ArticleIDn`,
                     `iaov`.`TableFieldIDn`,
                     `iaov`.`FieldValueIDn`
					;

-- #################################################################################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Paso 3: Elimina los datos
-- -----------------------------------------------------------------------------------------------------------------------------------------------
DELETE FROM `applcore`.`applimptarticlesopcval` `iaov`;


SELECT * FROM `applcore`.`appllogvarticlesoptionalfields`;
SELECT * FROM `applcore`.`applimptarticlesopcval` `iaov`;

