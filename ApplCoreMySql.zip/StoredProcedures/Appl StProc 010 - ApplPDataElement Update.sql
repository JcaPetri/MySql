UPDATE `applcore`.`appltdataelement`
	SET ScopeIDn = 2223,	-- IDCode = IDCode + 1,
		TableHistory = "SetOff"				-- 	"SetNull", "SetOff"
WHERE ScopeIDn = 2206;

SELECT * FROM applcore.appltdataelement WHERE ScopeIDn = 2223;