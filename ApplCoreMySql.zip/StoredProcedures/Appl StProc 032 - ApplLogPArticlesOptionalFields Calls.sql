-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Appl StProc 032 - ApplLogPArticlesOptionalFields Calls.sql
-- IDNum	IDName/Table							ScopeIDn	IDCode
-- 2230		ApplLogPArticlesOptionalFieldsCreate		6		  403
-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

/* Lista los Articles de la Company
	SELECT * FROM applcore.appllogvarticles;
			Company				Article
			2142	Peperina	7	Pampa Resma A4 70gr x 500h
			2142	Peperina	8	Boreal Resma A4 70gr x 500h
			2142	Peperina	9	Boreal Resma A4 80gr x 500h
			2142	Peperina	10	Boreal Resma color A4 75gr x 500h
			2142	Peperina	11	Triunfante Resma color A4 70gr x 100h
			2142	Peperina	12	Husares Resma A4 120gr x 100h
			2142	Peperina	13	Husares Resma A4 150gr x 100h
			2142	Peperina	14	Boreal Resma T/O 70gr x 500h
			2142	Peperina	15	Autor Resma A3 80grs x 500h
*/
-- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
/*	Lista las Option Properties Values, para cada TableField y Company, estos son valores como si fueran de una lista de opciones, 
		SELECT * FROM ApplCore.appllogvtablefieldsvalues;
				Company				TableField			TableFieldValue
				2142	Peperina	2223	Brand		22	Pampa
				2142	Peperina	2223	Brand		23	Boreal
				2142	Peperina	2223	Brand		24	Triunfante
				2142	Peperina	2223	Brand		25	Sabonis
				2142	Peperina	2223	Brand		26	Grap
				2142	Peperina	2223	Brand		27	Mit
				2142	Peperina	2223	Brand		28	Katana
				2142	Peperina	2223	Brand		29	Maped
				2142	Peperina	2223	Brand		30	Olami
				2142	Peperina	2223	Brand		31	Husares
				2142	Peperina	2223	Brand		32	Autor
                --------------------------------------------------
				2142	Peperina	2225	Size		33	A4
				2142	Peperina	2225	Size		34	TO
				2142	Peperina	2225	Size		35	A3
        
*/
-- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
/*
Los Field/Columnas: FieldNumValue, FieldTextValue, son libres y no estandarizadas, el usuario puede cargar cualquier valor
se sugiere tratar de no utilizarlo, ya que no fomenta la estandarizacion y posteriormente las busquedas y/o generacion de informes
*/

-- Call Stored Procedures to create a new record
-- Parametros para la tabla `ApplCore`.`ApplLogTArticlesOptionalFields`
set @traceability = 0;
		-- Art 7 Brand 2223 Val 22 
		-- Art 7 PrdTy 2232 Val 48
set @vArticleIDn = 7;				-- Es el IdNum del Articulo en el DataElement
set @vTableFieldIDn = 2232;			-- Es el IdNum de la propiedad del Articulo (Columna de la Tabla), se crea en la tabla bpmfoutbaseelement
set @vFieldValueIDn = 48;			-- Es el IDNum del valor de esa Propiedad, este valor se carga en el DataElement
set @vFieldNumValue = null;			-- Es un valor numerico definido por el usuario
set @vFieldTextValue = null;		-- Es un valor texto definido por el usuario

set @vCompanyIDn = 2142; 			-- Es el IdNum de la Company: 2142 Peperina / 2143 Tagle / 2144 UniversalBuildCompany
										-- la clave primaria es la propiedad (columna) vTableFieldIDn + el ArticleIDn (Tabla) + CompanyIDn
set @vStateIDn = 372;				-- 372 Enable Habilitado / 373 Disable Deshabilitado
set @vCreatedByIDn = 1;				-- Usuario
set @vLastModifiedByIDn = 0;		-- Usuario
set @vOwnerIDn = 0;					-- Usuario
set @vTzNameIDn = 1206;				-- America/Buenos_Aires
-- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Ejecuta el Procedimiento Almacenado
CALL `ApplCore`.`ApplLogPArticlesOptionalFieldsCreate`(
	@vSqlState,
	@vErrorCode,
	@vMsgString,
	@vRowAffected,
	@traceability,						-- Activate the traceability of the stored procedure: True = 1 / False = 0
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Parametros para insertar nuevo registro
	@vTableFieldIDn,		-- Es el IdNum de la propiedad del Articulo (Columna de la Tabla), se crea en la tabla bpmfoutbaseelement
	@vArticleIDn,			-- Es el IdNum del Articulo en el DataElement
    @vCompanyIDn, 			-- Es el IdNum de la Company: 2142 Peperina / 2143 Tagle / 2144 UniversalBuildCompany
										-- la clave primaria es la propiedad (columna) vTableFieldIDn + el ArticleIDn (Tabla) + CompanyIDn
	@vFieldValueIDn,		-- Es el IDNum del valor de esa Propiedad, este valor se carga en el DataElement
	@vFieldNumValue,		-- Es un valor numerico definido por el usuario
	@vFieldTextValue,		-- Es un valor texto definido por el usuario
	@vStateIDn,				-- vStateIDn, Es el IdNum del estado del registro, (Habilitado / Deshabilitado / Eliminado / etc), Scope = 21 tSisState, 372 Ena, 373 Dis
	@vCreatedByIDn, 		-- vCreatedByIDn, Es el IdNum del usuario que creo el registro, Scope = 231 UserTUser, numeros variales
	@vLastModifiedByIDn, 	-- vLastModifiedByIDn, Es el IdNum del ultimo usuario que modifico el registro, Scope = 231 UserTUser, numeros variales
	@vOwnerIDn, 			-- vOwnerIDn, Es el IdNum del usuario dueño del registro, Scope = 231 UserTUser, numeros variales
	current_timestamp,		-- vDateCreated, Es la fecha de creacion del registro, es la fecha y hora actual segun el posicionamiento actual
	current_timestamp,		-- vDateTimeStamp, Es la fecha de la ultima modificacion del registro, es la fecha y hora actual segun el posicionamiento actual
									-- Cuando se crea el registro, el DateCreated y DateTimeStamp son iguales
	@vTzNameIDn,			-- vTzNameIDn, Es el IdNum de la Time Zone del la fecha
	timestampdiff(minute, utc_timestamp(), current_timestamp()),	-- vTzOffset, Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
																	-- como es en horas y minutos, aqui se registra la diferencia real en horas y minutos
	null					-- vTableHistory, Es el historico del registro
);

SELECT @vSqlState,
	@vErrorCode,
    @vMsgString,
    @vRowAffected
    ;

-- Lista las tablas donde se insertaron los datos
SELECT * FROM `ApplCore`.`ApplLogVArticlesOptionalFields`;
-- SELECT * FROM `ApplCore`.`ApplLogTArticlesOptionalFields`;

-- Lista la tabla SysTSqlTimes
-- 2230		ApplLogPArticlesOptionalFieldsCreate
-- SELECT * FROM `bpmcore`.`systsqltimes` WHERE ProcessIDn = 2230 ORDER BY ProcessIDn, ProcessNumber desc, ProcessOrder, Stage desc;

/*
	DELETE FROM `bpmcore`.`systsqltimes` WHERE ProcessIDn = 2230;
*/


