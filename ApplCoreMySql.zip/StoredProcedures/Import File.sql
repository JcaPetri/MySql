-- SELECT VERSION();		-- Version Instalada de Mysql
-- Muestra el directorio seguro para importar datos a MySQl
-- 		SHOW VARIABLES LIKE "secure_file_priv";
-- 		SELECT @@GLOBAL.secure_file_priv;			-- Muestra lo mismo
-- Activa la Variable Local para permitir importar datos
-- 		SET GLOBAL local_infile=1;
-- 		SHOW GLOBAL VARIABLES LIKE 'local_infile';

/*
	IN vFileSource varchar(250),		-- Es el lugar desde donde se importan los archivos, ruta de acceso
	IN vFileImport varchar(250),		-- Es el archivo a Importar
*/
USE `ApplCore`;
DELETE FROM `ApplCore`.`ApplImpTSuppliersPriceListArticles` ;

-- Al Inicio Pone a Cero el contador de la Tabla
ALTER TABLE `applcore`.`applimptsupplierspricelistarticles` AUTO_INCREMENT = 0 ;

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Import Data
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
LOAD DATA INFILE 'C:\\ProgramData\\MySQL\\MySQL Server 8.0\\Uploads\\LP Estela Montenegro - Imp_ApplSupTSuppliersPriceListArticles_20201228.csv' 	-- Imp_ApplSupTSuppliersPriceListArticles_20201228
		-- Para que funcione se debe poner doble \\ ya que es un caracter especial
INTO TABLE `ApplCore`.`ApplImpTSuppliersPriceListArticles` 
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(ArticleSupplierID, SupplierIDn, CompanyIDn, ArticleSupplierDescription, SupplierPriceListIDn, Price, DatePriceList, PriceListCode);

-- #################################################################################################################################################################################################
-- DEPURACION DE DATOS
-- 		ACLARACION:
-- 					Luego de cada depuracion si el registro no es apto para su utilizacion se pone el ResultIDn y ResultDescription
-- 					de esta manera no se utiliza y se evitan errores, tambien se lo informan al Cliente que no se actualizo
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Elimina los espacios en blanco
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
UPDATE `ApplCore`.`ApplImpTSuppliersPriceListArticles` 
SET
	`ArticleSupplierID` = TRIM(ArticleSupplierID),
	`SupplierIDn` = TRIM(SupplierIDn),
	`CompanyIDn` = TRIM(CompanyIDn),
	`ArticleSupplierDescription` = TRIM(ArticleSupplierDescription),
	`SupplierPriceListIDn` = TRIM(SupplierPriceListIDn),
	`Price` = TRIM(Price),
	`DatePriceList` = TRIM(DatePriceList),
    `PriceListCode` = TRIM(PriceListCode)
    ;

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Verifica que las columnas tengan el tipo de dato correcto
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
UPDATE `ApplCore`.`applimptsupplierspricelistarticles`
SET `ResultIDn` = 1,
	`ResultDescription` = 'The value of SupplierIDn, or CompanyIDn or SupplierPriceListIDn are not Int'
WHERE FncIsInt(`SupplierIDn`) = 0 
		OR FncIsInt(`CompanyIDn`) = 0
        OR FncIsInt(`SupplierPriceListIDn`) = 0;

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Verifica que la Company este dado de alta en la tabla SuppliersPriceList 
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
UPDATE `ApplCore`.`applimptsupplierspricelistarticles` `ISpl`
		left outer join `ApplCore`.`ApplSupTSuppliersPriceList` `Spl` 
			on `ISpl`.`CompanyIDn`= `Spl`.`CompanyIDn`
SET `ResultIDn` = 1,
	`ResultDescription` = 'The value of CompanyIDn doesn`t exist'
WHERE `Spl`.`CompanyIDn` is null;

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Verifica que el Supplier para esa Company este dado de alta en la tabla SuppliersPriceList
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
UPDATE `ApplCore`.`applimptsupplierspricelistarticles` `ISpl`
		left outer join `ApplCore`.`ApplSupTSuppliersPriceList` `Spl` 
			on `ISpl`.`SupplierIDn`= `Spl`.`SupplierIDn`
				and `ISpl`.`CompanyIDn`= `Spl`.`CompanyIDn`
SET `ResultIDn` = 1,
	`ResultDescription` = 'The value of SupplierIDn doesn`t exist'
WHERE `Spl`.`SupplierIDn` is null;

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Verifica que la Lista de Precios para ese Supplier y esa Company este dado de alta
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
UPDATE `ApplCore`.`applimptsupplierspricelistarticles` `ISpl`
		left outer join `ApplCore`.`ApplSupTSuppliersPriceList` `Spl` 
			on `ISpl`.`SupplierPriceListIDn`= `Spl`.`SupplierPriceListIDn`
				and`ISpl`.`SupplierIDn`= `Spl`.`SupplierIDn`
				and `ISpl`.`CompanyIDn`= `Spl`.`CompanyIDn`
SET `ResultIDn` = 1,
	`ResultDescription` = 'The value of SupplierPriceListIDn doesn`t exist'
WHERE `Spl`.`SupplierPriceListIDn` is null;

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Actualiza informacion que viene erronea del Supplier/Proveedor y que nunca lo resuelve
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Esto se asocia a la tabla ApplImpTSuppliersPriceListArticlesFix, y se vincula con la clave primaria es el ArticleSupplierID + SupplierIDn + CompanyIDn
-- Ej, 302044, este articulo en la descripcion contiene el ID 302044CANOPLA INTERVEN TUBO FANTASIA 1201
UPDATE `applcore`.`applimptsupplierspricelistarticles` `Spl`
	INNER JOIN `applcore`.`applimptsupplierspricelistarticlesfix` `SplF`
		ON `Spl`.`ArticleSupplierID` = `SplF`.`ArticleSupplierID`
			AND `Spl`.`SupplierIDn` = `SplF`.`SupplierIDn`
            AND `Spl`.`CompanyIDn` = `SplF`.`CompanyIDn`
SET `Spl`.`ArticleSupplierDescription` = `SplF`.`ArticleSupplierDescription`
	, `Spl`.`ResultIDn` = 0
	, `Spl`.`ResultDescription` = 'Fix the ArticleSupplierDescription';

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Verifica que el Precio sea un numero
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Actualiza el campo Price ajustando al formato MySql
UPDATE `ApplCore`.`applimptsupplierspricelistarticles`
SET `Price` = FncConvDecimal(`Price`);

-- Establece los registros en 1 que no son decimales transformables
UPDATE `ApplCore`.`applimptsupplierspricelistarticles`
SET `ResultIDn` = 1,
	`ResultDescription` = 'The value of Price are not number'
WHERE FncIsDecimal(`Price`) = 0;


-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Verifica que la Fecha tenga formato correcto
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Actualiza el campo DateLastUpdate ajustando la fecha al formato MySql
UPDATE `ApplCore`.`applimptsupplierspricelistarticles`
SET `DatePriceList` = FncConvDate(DatePriceList,'dd/mm/yyyy');

-- Establece los registros en 1 que no son fecha transformable
UPDATE `ApplCore`.`applimptsupplierspricelistarticles`
SET `ResultIDn` = 1,
	`ResultDescription` = 'The value of DateLastUpdate are not valid Date'
WHERE FncIsDate(`DatePriceList`) = 0;

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Verifica que no haya duplicados y que infrinjan la clave ID
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
UPDATE `ApplCore`.`applimptsupplierspricelistarticles` `isa`
	INNER JOIN (
				SELECT `ArticleSupplierID`,
						`SupplierIDn`,
						`CompanyIDn`,
						COUNT(*) 'Q'
				FROM `applcore`.`applimptsupplierspricelistarticles`
				GROUP BY `ArticleSupplierID`,
						`SupplierIDn`,
						`CompanyIDn`
				HAVING COUNT(*) > 1
				) `isad`
					on `isa`.`ArticleSupplierID` = `isad`.`ArticleSupplierID`
						and `isa`.`SupplierIDn` = `isad`.`SupplierIDn`
						and `isa`.`CompanyIDn` = `isad`.`CompanyIDn`
SET `ResultIDn` = 1,
	`ResultDescription` = 'The record is duplicated'
;

-- #################################################################################################################################################################################################
-- Importa los Datos a Tabla applsuptsupplierspricelistarticles
-- Para ello sigue los siguientes pasos:
-- 		1.- Desactiva los articulos que no estan mas en la base importada, estan en la tabla applsup y no en la tabla applimp
-- 		2.- Actualiza articulos que ya estan incorporado, ya que estan en las dos tablas
-- 		3.- Inserta articulos nuevos, estan en la tabla applimp y no en la tabla applsup
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

-- #################################################################################################################################################################################################
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- 		1.- Desactiva los articulos que no estan mas en la base importada, estan en la tabla applsup y no en la tabla applimp
UPDATE `applcore`.`applsuptsupplierspricelistarticles` `sar`
	LEFT JOIN (
				SELECT `IDNum`,
						`ArticleSupplierID`,
						`SupplierIDn`,
						`CompanyIDn`,
						`ArticleSupplierDescription`,
						`SupplierPriceListIDn`,
						`Price`,
						`DatePriceList`,
                        `PriceListCode`,
						`ResultIDn`,
						`ResultDescription`
				FROM `applcore`.`applimptsupplierspricelistarticles`
				) `isa`
					on `sar`.`ArticleSupplierID` = `isa`.`ArticleSupplierID`
						and `sar`.`SupplierIDn` = `isa`.`SupplierIDn`
						and `sar`.`CompanyIDn` = `isa`.`CompanyIDn`
SET
		`sar`.`StateIDn` = 373,									-- 372 Enable Habilitado / 373 Disable Deshabilitado
		-- `sar`.`CreatedByIDn` = 0,								-- Usuario
		`sar`.`LastModifiedByIDn` = 1,							-- Usuario
		-- `sar`.`OwnerIDn` = 0,									-- Usuario
		-- `sar`.`DateLastUpdate` = current_timestamp,				-- Es la fecha de actualizacion del archivo
		`sar`.`DateTimeStamp` = current_timestamp,				-- Es la fecha que se ejecuta el procedimiento
		`sar`.`TzNameIDn` = 1206,								-- America/Buenos_Aires
		`sar`.`TzOffset` = timestampdiff(minute, utc_timestamp(), current_timestamp())
WHERE (`isa`.`ResultIDn` = 0 OR `isa`.`ResultIDn` is null)
		AND `isa`.`IDNum` is null;

-- Muestra los datos 
/*SELECT `sar`.ArticleSupplierID, `isa`.`IDNum` FROM `applcore`.`applsuptsupplierspricelistarticles` `sar`
			LEFT JOIN `applcore`.`applimptsupplierspricelistarticles` `isa`
					on `sar`.`ArticleSupplierID` = `isa`.`ArticleSupplierID`
						and `sar`.`SupplierIDn` = `isa`.`SupplierIDn`
						and `sar`.`CompanyIDn` = `isa`.`CompanyIDn`
WHERE (`isa`.`ResultIDn` = 0 OR `isa`.`ResultIDn` is null)
		AND `isa`.`IDNum` is null;
*/
-- No se eliminan de la tabla applimptsupplierspricelistarticles ya que no estan, el proveedor no los trabaja mas

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- 1.2- Desactiva los articulos que no estan mas en la base importada, estan en la tabla applsup y no en la tabla applimp
-- 		de la tabla `ApplCore`.`ApplSupTSuppliersPriceListHistory`
UPDATE `applcore`.`ApplSupTSuppliersPriceListHistory` `sph`
	LEFT JOIN `applcore`.`applimptsupplierspricelistarticles` `isa`
			on `sph`.`ArticleSupplierID` = `isa`.`ArticleSupplierID`
				and `sph`.`SupplierIDn` = `isa`.`SupplierIDn`
				and `sph`.`CompanyIDn` = `isa`.`CompanyIDn`
SET
		`sph`.`StateIDn` = 373									-- 372 Enable Habilitado / 373 Disable Deshabilitado
WHERE (`isa`.`ResultIDn` = 0 OR `isa`.`ResultIDn` is null)
		AND `isa`.`IDNum` is null;

/*
SELECT `sph`.ArticleSupplierID, `isa`.`IDNum` FROM `applcore`.`ApplSupTSuppliersPriceListHistory` `sph`
			LEFT JOIN `applcore`.`applimptsupplierspricelistarticles` `isa`
					on `sph`.`ArticleSupplierID` = `isa`.`ArticleSupplierID`
						and `sph`.`SupplierIDn` = `isa`.`SupplierIDn`
						and `sph`.`CompanyIDn` = `isa`.`CompanyIDn`
WHERE (`isa`.`ResultIDn` = 0 OR `isa`.`ResultIDn` is null)
		AND `isa`.`IDNum` is null;
*/
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

			-- #################################################################################################################################################################################################
			-- 2.- Actualiza articulos que ya estan incorporado, ya que estan en las dos tablas
			-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			-- 2.1- Inserta en la tabla los Articulos que tuvieron cambio de precios, ya que estan en las dos tablas
            -- Primero se ejecuta esta consulta para que impacte en el Historico, ya que la base de la consulta es la diferencia entre los datos importados y los de la base
			INSERT INTO `applcore`.`applsuptsupplierspricelisthistory`
					(`ArticleSupplierID`,
					`SupplierIDn`,
					`CompanyIDn`,
					`DatePriceList`,
					`Price`,
					`DatePriceListBefore`,
					`PriceBefore`,
					`StateIDn`
					)
						SELECT `isa`.`ArticleSupplierID`,
								`isa`.`SupplierIDn`,
								`isa`.`CompanyIDn`,
								`isa`.`DatePriceList`,
								`isa`.`Price`,
								`sar`.`DatePriceList`,
								`sar`.`Price`,
								 372 `StateIDn`						-- 372 Enable Habilitado / 373 Disable Deshabilitado
							FROM `applcore`.`applimptsupplierspricelistarticles` `isa`
								INNER JOIN `applcore`.`applsuptsupplierspricelistarticles` `sar`
									on `isa`.`ArticleSupplierID` = `sar`.`ArticleSupplierID`
										and `isa`.`SupplierIDn` = `sar`.`SupplierIDn`
										and `isa`.`CompanyIDn` = `sar`.`CompanyIDn`
						WHERE (`isa`.`ResultIDn` = 0 OR `isa`.`ResultIDn` is null)
							AND (`isa`.`Price` <> `sar`.`Price`);

			-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
            -- 	2.2- Actualiza articulos que ya estan incorporado, ya que estan en las dos tablas
			UPDATE `applcore`.`applsuptsupplierspricelistarticles` `sar`
				INNER JOIN `applcore`.`applimptsupplierspricelistarticles` `isa`
						on `sar`.`ArticleSupplierID` = `isa`.`ArticleSupplierID`
							and `sar`.`SupplierIDn` = `isa`.`SupplierIDn`
							and `sar`.`CompanyIDn` = `isa`.`CompanyIDn`
			SET
					`sar`.`ArticleSupplierDescription` = `isa`.`ArticleSupplierDescription`,
					`sar`.`SupplierPriceListIDn` = `isa`.`SupplierPriceListIDn`,
					`sar`.`Price` = `isa`.`Price`,
					`sar`.`DatePriceList` = `isa`.`DatePriceList`,
                    `sar`.`PriceListCode` = `isa`.`PriceListCode`,
					`sar`.`StateIDn` = 372,									-- 372 Enable Habilitado / 373 Disable Deshabilitado
					-- `sar`.`CreatedByIDn` = 1,							-- Usuario que creo el registro
					`sar`.`LastModifiedByIDn` = 1,							-- Usuario que modifico el registro
					-- `sar`.`OwnerIDn` = 0,								-- Usuario dueño del registro
					-- `sar`.`DateCreated` = current_timestamp,				-- Es la fecha de creacion del registro
					`sar`.`DateTimeStamp` = current_timestamp,				-- Es la fecha que se ejecuta el procedimiento
					`sar`.`TzNameIDn` = 1206,								-- America/Buenos_Aires
					`sar`.`TzOffset` = timestampdiff(minute, utc_timestamp(), current_timestamp())
			WHERE (`isa`.`ResultIDn` = 0 OR `isa`.`ResultIDn` is null)
					AND (`isa`.`Price` <> `sar`.`Price` 
									OR `isa`.`ArticleSupplierDescription` <> `sar`.`ArticleSupplierDescription`
                                    OR `isa`.`SupplierPriceListIDn` <> `sar`.`SupplierPriceListIDn`);
	
			-- Elimina los datos YA actualizados, estan en las dos tablas
			DELETE `applcore`.`applimptsupplierspricelistarticles`
			FROM `applcore`.`applimptsupplierspricelistarticles`
					INNER JOIN `applcore`.`applsuptsupplierspricelistarticles` `sar`
						on `applcore`.`applimptsupplierspricelistarticles`.`ArticleSupplierID` = `sar`.`ArticleSupplierID`
							and `applcore`.`applimptsupplierspricelistarticles`.`SupplierIDn` = `sar`.`SupplierIDn`
							and `applcore`.`applimptsupplierspricelistarticles`.`CompanyIDn` = `sar`.`CompanyIDn`;
			-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

			-- #################################################################################################################################################################################################
			-- 	3.- Inserta articulos nuevos, estan en la tabla applsuptsupplierspricelisthistory
			-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			-- 	3.1- Inserta articulos nuevos, estan en la tabla applsuptsupplierspricelisthistory
			INSERT INTO `applcore`.`applsuptsupplierspricelisthistory`
					(`ArticleSupplierID`,
					`SupplierIDn`,
					`CompanyIDn`,
					`DatePriceList`,
					`Price`,
                    `DatePriceListBefore`,
                    `PriceBefore`,
					`StateIDn`
					)
					SELECT `isa`.`ArticleSupplierID`,
							`isa`.`SupplierIDn`,
							`isa`.`CompanyIDn`,
							`isa`.`DatePriceList`,
							`isa`.`Price`,
							`sar`.`DatePriceList`,
							`sar`.`Price`,
							372 `StateIDn`						-- 372 Enable Habilitado / 373 Disable Deshabilitado
						FROM `applcore`.`applimptsupplierspricelistarticles` `isa`
							left outer join `applcore`.`applsuptsupplierspricelistarticles` `sar`
								on `isa`.`ArticleSupplierID` = `sar`.`ArticleSupplierID`
									and `isa`.`SupplierIDn` = `sar`.`SupplierIDn`
									and `isa`.`CompanyIDn` = `sar`.`CompanyIDn`
						WHERE (`isa`.`ResultIDn` = 0 OR `isa`.`ResultIDn` is null)
								and  `sar`.`ArticleSupplierID` is null;

			-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			-- 	3.2- Inserta articulos nuevos, estan en la tabla applimp y no en la tabla applsup
			INSERT INTO `applcore`.`applsuptsupplierspricelistarticles`
					(`ArticleSupplierID`,
					`SupplierIDn`,
					`CompanyIDn`,
					`ArticleSupplierDescription`,
					`SupplierPriceListIDn`,
					`Price`,
					`DatePriceList`,
					`PriceListCode`,
                    `StateIDn`,
					`CreatedByIDn`,
					`LastModifiedByIDn`,
					`OwnerIDn`,
					`DateCreated`,
					`DateTimeStamp`,
					`TzNameIDn`,
					`TzOffset`,
					`TableHistory`)
							SELECT `isa`.`ArticleSupplierID`,
									`isa`.`SupplierIDn`,
									`isa`.`CompanyIDn`,
									`isa`.`ArticleSupplierDescription`,
									`isa`.`SupplierPriceListIDn`,
									`isa`.`Price`,
									`isa`.`DatePriceList`,
                                    `isa`.`PriceListCode`,
					-- 				`isa`.`ResultIDn`,
					-- 				`isa`.`ResultDescription`
									372 `StateIDn`,						-- 372 Enable Habilitado / 373 Disable Deshabilitado
									1 `CreatedByIDn`,					-- Usuario que creo el registro
									1 `LastModifiedByIDn`,				-- Usuario que modifico el registro
									1 `OwnerIDn`,						-- Usuario dueño del registro
									current_timestamp `DateCreated`,
									current_timestamp `DateTimeStamp`,
									1206 `TzNameIDn`,		-- America/Buenos_Aires
									timestampdiff(minute, utc_timestamp(), current_timestamp()) `TzOffset`,
									null `TableHistory`
								FROM `applcore`.`applimptsupplierspricelistarticles` `isa`
									left outer join `applcore`.`applsuptsupplierspricelistarticles` `sar`
										on `isa`.`ArticleSupplierID` = `sar`.`ArticleSupplierID`
											and `isa`.`SupplierIDn` = `sar`.`SupplierIDn`
											and `isa`.`CompanyIDn` = `sar`.`CompanyIDn`
								WHERE (`isa`.`ResultIDn` = 0 OR `isa`.`ResultIDn` is null)
										and  `sar`.`ArticleSupplierID` is null;

			-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			-- 	3.3- Elimina los datos YA importados, ya que estan en las dos tabla
			DELETE `applcore`.`applimptsupplierspricelistarticles`
			FROM `applcore`.`applimptsupplierspricelistarticles`
					INNER JOIN `applcore`.`applsuptsupplierspricelistarticles` `sar`
						on `applcore`.`applimptsupplierspricelistarticles`.`ArticleSupplierID` = `sar`.`ArticleSupplierID`
							and `applcore`.`applimptsupplierspricelistarticles`.`SupplierIDn` = `sar`.`SupplierIDn`
							and `applcore`.`applimptsupplierspricelistarticles`.`CompanyIDn` = `sar`.`CompanyIDn`;
			-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- #################################################################################################################################################################################################

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Muestra la informacion
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

			select * from `applcore`.`applsuptsupplierspricelisthistory` `sph`;
			select * from `applcore`.`applsuptsupplierspricelistarticles` `sar`;
            select * from `applcore`.`applimptsupplierspricelistarticles` `isa`;
            

            select * from `applcore`.`applsuptsupplierspricelisthistory` 
				where ArticleSupplierID = 202033
						or ArticleSupplierID = 202141
                        or ArticleSupplierID = 204082
			order by ArticleSupplierID
            ;
            

			select * from `applcore`.`applsuptsupplierspricelistarticles` `sar` WHERE TableHistory is not null;
            select * from `applcore`.`applimptsupplierspricelistarticles` `isa`;
            
            select * from `applcore`.`applsuptsupplierspricelistarticles` `sar` WHERE StateIDn = 373;
            DELETE from `applcore`.`applsuptsupplierspricelisthistory`;
			DELETE from `applcore`.`applsuptsupplierspricelistarticles`;
            DELETE from `applcore`.`applimptsupplierspricelistarticles`;
            
