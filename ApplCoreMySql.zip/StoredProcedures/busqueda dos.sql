						-- Maxima Precision		-- Intermedia		-- Sin Precisio
-- Si pasa 1 parametros, el valor 0					valor 0				valor 0
-- Si pasa 2 parametros, el valor -1				valor 0				valor 0
-- Si pasa 3 parametros, el valor -2				valor -1			valor 0
-- Si pasa 4 parametros, el valor -3				valor -2			valor 0

-- Esto se define en 
-- Precision Maxima = Q.Param - 1
-- Precision Intermedia = Q.Param - 1
						-- Si Q.Param <= 2	--> 0
                        -- Si Q.Param > 2	--> Q.Param - 2
-- Precision Baja = 0

set @vLookupPrecicion = -0;
-- NO funciona, no ordena los datos
SELECT `aof`.`CompanyIDn`, `aof`.`ArticleIDn`
			,`de`.`IDName`
			, `pla`.`Price`
			, count(*)
                FROM `applcore`.`appllogtarticlesoptionalfields` `aof` 
					inner join `applcore`.`applsaletpricelistarticles` `pla`
						ON `aof`.`ArticleIDn` = `pla`.`ArticleIDn`
							AND `aof`.`CompanyIDn` = `pla`.`CompanyIDn`
					INNER JOIN `ApplCore`.`ApplTDataElement` `de`
						ON `pla`.`ArticleIDn` = `de`.`IDNum`
							AND `pla`.`CompanyIDn` = `de`.`CompanyIDn`
				WHERE `aof`.`CompanyIDn` = 2142 AND `aof`.`StateIDn` = 372
					AND (`aof`.`FieldValueIDn` = 36				-- 48 Resma
							 -- OR `aof`.`FieldValueIDn` = 22 		-- 22 Pampa
                             OR `aof`.`FieldValueIDn` = 23 		-- 23 Boreal
							 OR `aof`.`FieldValueIDn` = 33 		-- 33 A4
                             -- OR `aof`.`FieldValueIDn` = 36		-- 36 70gr
                             -- OR `aof`.`FieldValueIDn` = 42 		-- 42 Color
						)	
				GROUP BY `aof`.`CompanyIDn`, `aof`.`ArticleIDn`,`de`.`IDName` , `pla`.`Price`
                HAVING count(*) > -@vLookupPrecicion
                ORDER BY count(*) DESC
;



-- #####################################################################################################################################################
-- #####################################################################################################################################################
set @vLookupPrecicion = -0;
set @vIDNameBuscado = '7793456993066';
SELECT `pla`.`ArticleIDn`,
	`de`.`IDName`,
    `pla`.`PriceListIDn`,
    `pla`.`CompanyIDn`,
    `pla`.`Price`,-
    `pla`.`PriceDate`,
    `pla`.`PriceListCode`,
    `aof`.`Quantity`
    ,`aof`.`Quantity` + @vLookupPrecicion `Rtado`
    ,if(`aof`.`Quantity` + @vLookupPrecicion > 0,'Show','Hide') `T/F`
    ,if(`aof`.`Quantity` > -@vLookupPrecicion,'Show','Hide') `T/F`
FROM `applcore`.`applsaletpricelistarticles` `pla`
	INNER JOIN (SELECT `CompanyIDn`, `ArticleIDn`, count(*) `Quantity`
                FROM `applcore`.`appllogtarticlesoptionalfields`
				WHERE `CompanyIDn` = 2142 AND `StateIDn` = 372
					AND `FieldValueIDn` IN (SELECT IDNum FROM `ApplCore`.`ApplTDataElement` `de` WHERE `de`.`IDName` LIKE CONCAT('%',@vIDNameBuscado,'%'))
				GROUP BY `CompanyIDn`, `ArticleIDn`
                HAVING count(*) > -@vLookupPrecicion
                ) `aof` 
					ON `pla`.`ArticleIDn` = `aof`.`ArticleIDn`
						AND `pla`.`CompanyIDn` = `aof`.`CompanyIDn`
	INNER JOIN `ApplCore`.`ApplTDataElement` `de`
			ON `pla`.`ArticleIDn` = `de`.`IDNum`
				AND `pla`.`CompanyIDn` = `de`.`CompanyIDn`
ORDER BY `aof`.`Quantity` DESC
;


