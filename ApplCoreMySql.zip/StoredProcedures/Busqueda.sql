-- Primero debe buscar los FieldValueIDn
-- Luego con estos codigos debe buscar la ocurrencia
/*
SELECT `art`.`ArticleIDn`, `de`.`IDName`, `bus`.`Quantity`
FROM `applcore`.`appllogtarticles` `art`
	INNER JOIN (
				SELECT `CompanyIDn`, `ArticleIDn`, count(*) 'Quantity' 
                FROM `applcore`.`appllogtarticlesoptionalfields`
				WHERE `CompanyIDn` = 2142 AND `StateIDn` = 372
					AND (`FieldValueIDn` = 22 OR `FieldValueIDn` = 33 OR `FieldValueIDn` = 48 OR `FieldValueIDn` = 36)
				GROUP BY `CompanyIDn`, `ArticleIDn`
                ORDER BY count(*) DESC
				) `bus` 
					ON `art`.`ArticleIDn` = `bus`.`ArticleIDn`
	INNER JOIN `ApplCore`.`ApplTDataElement` `de`
			ON `art`.`ArticleIDn` = `de`.`IDNum`
ORDER BY `bus`.`Quantity` DESC;

/*
SELECT * FROM applcore.appllogtarticlesoptionalfields;
select * FROM applcore.appllogvarticlesoptionalfields ORDER BY TableField;
select * from `ApplCore`.`ApplTDataElement` where ScopeIDn = 2205;

select * from `ApplCore`.`ApplTDataElement` where lower(IDName) like '%boreal%' and ScopeIDn <> 2205;

select * from `ApplCore`.`ApplTDataElement`
where ScopeIDn <> 2205 and (lower(IDName) like '%resma%'
							or lower(IDName) like '%a4%'
							or lower(IDName) like '%pampa%'
                            or lower(IDName) like '%70gr%'
                            );

select * from `ApplCore`.`ApplTDataElement` where IDNum = 23 or IDNum = 48 or IDNum = 34;

USE applcore;
SELECT SPLIT_STRING('23!48!34','!',4) 'SPLIT'
*/

						-- Maxima Precision		-- Intermedia		-- Sin Precisio
-- Si pasa 1 parametros, el valor 0					valor 0				valor 0
-- Si pasa 2 parametros, el valor -1				valor 0				valor 0
-- Si pasa 3 parametros, el valor -2				valor -1			valor 0
-- Si pasa 4 parametros, el valor -3				valor -2			valor 0

-- Esto se define en 
-- Precision Maxima = Q.Param - 1
-- Precision Intermedia = Q.Param - 1
						-- Si Q.Param <= 2	--> 0
                        -- Si Q.Param > 2	--> Q.Param - 2
-- Precision Baja = 0

set @vLookupPrecicion = 0;
SELECT `pla`.`ArticleIDn`,
	`de`.`IDName`,
    `pla`.`PriceListIDn`,
    `pla`.`CompanyIDn`,
    `pla`.`Price`,
    `pla`.`PriceDate`,
    `pla`.`PriceListCode`,
    `aof`.`Quantity`
    ,`aof`.`Quantity` + @vLookupPrecicion `Rtado`
    ,if(`aof`.`Quantity` + @vLookupPrecicion > 0,'Show','Hide') `T/F`
FROM `applcore`.`applsaletpricelistarticles` `pla`
	INNER JOIN (SELECT `CompanyIDn`, `ArticleIDn`, count(*) `Quantity`
                FROM `applcore`.`appllogtarticlesoptionalfields`
				WHERE `CompanyIDn` = 2142 AND `StateIDn` = 372
					AND (`FieldValueIDn` = 48				-- Resma
							 -- OR `FieldValueIDn` = 22 		-- Pampa
							 -- OR `FieldValueIDn` = 33 		-- A4
                             -- OR `FieldValueIDn` = 36		-- 70gr
						)	
				GROUP BY `CompanyIDn`, `ArticleIDn`
                -- ORDER BY count(*) DESC
                ) `aof` 
					ON `pla`.`ArticleIDn` = `aof`.`ArticleIDn`
						AND `pla`.`CompanyIDn` = `aof`.`CompanyIDn`
	INNER JOIN `ApplCore`.`ApplTDataElement` `de`
			ON `pla`.`ArticleIDn` = `de`.`IDNum`
				AND `pla`.`CompanyIDn` = `de`.`CompanyIDn`
-- WHERE `aof`.`Quantity` + @vLookupPrecicion > 0
ORDER BY `aof`.`Quantity` DESC
;

/*
22	Pampa
33	A4
36	70gr
48	Resma
*/