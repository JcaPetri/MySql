-- #################################################################################################################################################################################################
-- Verifica que los registros que se estan insertando Ya no esten creados en la tabla DataElement, Articles, ArticlesSupplierArticles
SELECT `asp`.`ArticleIDn` `TableArticlesSupplierArticles`, `art`.`ArticleIDn` `TableArticles`, `ia`.`SupplierIDn`, `ia`.`ArticleSupplierID`, `de`.`IDNum`, `ia`.`IDName`, `de`.`IDName` `DeIDName`, `de`.`ID`
	FROM `applcore`.`applimptarticles` `ia` 
		INNER JOIN `ApplCore`.`ApplTDataElement` `de` 
			ON `ia`.`IDName` = `de`.`IDName`
		LEFT OUTER JOIN `applcore`.`appllogtarticles` `art`
			ON `de`.`IDNum` = `art`.`ArticleIDn`
		LEFT OUTER JOIN `applcore`.`appllogtarticlessuppliersarticles` `asp`
			ON `ia`.`ArticleSupplierID` = `asp`.`ArticleSupplierID`
	   ;

-- Importante: Los Articulos que se quieren importar estan creados en el diccionario tabla dataElement
-- Solo se deben agregar en las tablas:
-- 										AppllogTArticles
-- 										AppllogTArticlesSupplierArticles
-- Comentario: estos articulos es como no existieran para el sistema, solo estan creados en el diccionario

-- #################################################################################################################################################################################################
-- Setea las variables
-- -----------------------------------------------------------------------------------------------------------------------------------------
set @vIDNameStructureIDn = 1;		-- Es el IDNum de la estructura del IDName - si es multivaluado - aqui esta la estructura
set @vScopeIDn = 2205;				-- Tabla ApplLogTArticles
set @vLanguageIDn = 734;			-- Español
set @vCompanyIDn = 2142; 			-- 2142 Peperina / 2143 Tagle / 2144 UniversalBuildCompany
set @vIDCode = 0;					-- 0 = Codigo incrementalmente autogenerado - Codigo numerico establecido por el usuario, permite organizar los contenidos de la tabla por rangos
set @vDefinitionIDn = 2070;			-- bpmndefaultdefinition
set @vInformationTypeIDn = 381;		-- 381 Data / 382 Software
set @vIDIsUsed = 1;					-- True
set @vStateIDn = 372;				-- 372 Enable Habilitado / 373 Disable Deshabilitado
set @vCreatedByIDn = 1;				-- Usuario
set @vLastModifiedByIDn = 1;		-- Usuario
set @vOwnerIDn = 1;					-- Usuario
set @vDateCreated = current_timestamp;			-- Es la fecha de creacion del registro, es la fecha y hora actual segun el posicionamiento actual
set @vDateTimeStamp = current_timestamp;			-- Es la fecha de la ultima modificacion del registro, es la fecha y hora actual segun el posicionamiento actual
set @vTzNameIDn = 1206;				-- America/Buenos_Aires
set @vTzOffset = timestampdiff(minute, utc_timestamp(), current_timestamp());	-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro 
set @vTableHistory = null;			-- Es el historico del registro
-- Variables para insertar los registros en la tabla ApplLogArticles
set @ArticleGeneralIDn = 2;					-- Es el IDNum de las caracteristicas Generales del Articulo, esta en la tabla appllogtarticlesgeneral
set @BarCode = null;						-- Es el codigo de barra
set @StockEnable = 1;						-- True = 1 / False = 0

-- #################################################################################################################################################################################################
-- 1.- Inserta todos los registros en la tabla `ApplCore`.`ApplLogTArticles` que estan en la tabla ApplCore.ApplimpTArticles
-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
INSERT INTO `ApplCore`.`ApplLogTArticles`
		(`ArticleIDn`,
		`CompanyIDn`,
		`ArticleGeneralIDn`,
		`BarCode`,
		`StockEnable`,
		`StateIDn`,
		`CreatedByIDn`,
		`LastModifiedByIDn`,
		`OwnerIDn`,
		`DateCreated`,
		`DateTimeStamp`,
		`TzNameIDn`,
		`TzOffset`,
		`TableHistory`)
			SELECT 	`de`.`IDNum` 'ArticleIDn',						-- Valor numerico unico autogenerado, que se genero en la consulta anterior
				@vCompanyIDn `CompanyIDn`,			-- Es el IDNum de la Compania dueña del Registro, Scope = 25, 2207 System, 7566 Tagle, 7565 Peperina
				@ArticleGeneralIDn,					-- Es el IDNum de las caracteristicas Generales del Articulo, esta en la tabla appllogtarticlesgeneral
                @BarCode,							-- Es el codigo de barra
                @StockEnable,						-- True = 1 / False = 0
                @vStateIDn `StateIDn`,						-- Es el IDNum del estado del registro, Scope = 21 tSisState, 372 Ena, 373 Dis
				@vCreatedByIDn `CreatedByIDn`,					-- Es el IdNum del usuario que creo el registro, Scope = 231 UserTUser, numeros variales
				@vLastModifiedByIDn `LastModifiedByIDn`,				-- Es el IdNum del ultimo usuario que modifico el registro, Scope = 231 UserTUser, numeros variales
				@vOwnerIDn `OwnerIDn`,						-- Es el IdNum del usuario dueño del registro, Scope = 231 UserTUser, numeros variales
				@vDateCreated `DateCreated`,		-- Es la fecha de creacion del registro, es la fecha y hora actual segun el posicionamiento actual
				@vDateTimeStamp `DateTimeStamp`,	-- Es la fecha de la ultima modificacion del registro, es la fecha y hora actual segun el posicionamiento actual
													-- Cuando se crea el registro, el DateCreated y DateTimeStamp son iguales
				@vTzNameIDn, 						-- Es el IdNum de la Time Zone del la fecha
				@vTzOffset `TzOffset`, 				-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
									-- como es en horas y minutos, aqui se registra la diferencia real en horas y minutos
				@vTableHistory `TableHistory`	-- Es el historico del registro
			FROM `applcore`.`applimptarticles` `ia`
				INNER JOIN `applcore`.`appltdataelement` `de`
					ON `ia`.`IDName` = `de`.`IDName`;

-- #################################################################################################################################################################################################
-- 2.- Inserta en la tabla `ApplCore`.`AppllogTArticlesSuppliersArticles` la relacion entre los articulos y el proveedor
-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	INSERT INTO `applcore`.`appllogtarticlessuppliersarticles`
		(`ArticleIDn`,
		`ArticleSupplierID`,
		`SupplierIDn`,
		`CompanyIDn`,
		`StateIDn`,
		`CreatedByIDn`,
		`LastModifiedByIDn`,
		`OwnerIDn`,
		`DateCreated`,
		`DateTimeStamp`,
		`TzNameIDn`,
		`TzOffset`,
		`TableHistory`)
		SELECT 	`de`.`IDNum` 'ArticleIDn',						-- Valor numerico unico autogenerado, que se genero en la consulta anterior
				-- `ia`.ID `ID`,					-- UniqueIdentifier, es autogenerado
				`ia`.`ArticleSupplierID`, 			-- Es el codigo del articulo para ese proveedor
				-- `ia`.IDName,						-- Es la descripcion del articulo
				`ia`.`SupplierIDn`,					-- Es el codigo del proveedor del articulo
				@vCompanyIDn `CompanyIDn`,			-- Es el IDNum de la Compania dueña del Registro, Scope = 25, 2207 System, 7566 Tagle, 7565 Peperina
				@vStateIDn `StateIDn`,						-- Es el IDNum del estado del registro, Scope = 21 tSisState, 372 Ena, 373 Dis
				@vCreatedByIDn `CreatedByIDn`,					-- Es el IdNum del usuario que creo el registro, Scope = 231 UserTUser, numeros variales
				@vLastModifiedByIDn `LastModifiedByIDn`,				-- Es el IdNum del ultimo usuario que modifico el registro, Scope = 231 UserTUser, numeros variales
				@vOwnerIDn `OwnerIDn`,						-- Es el IdNum del usuario dueño del registro, Scope = 231 UserTUser, numeros variales
				@vDateCreated `DateCreated`,		-- Es la fecha de creacion del registro, es la fecha y hora actual segun el posicionamiento actual
				@vDateTimeStamp `DateTimeStamp`,	-- Es la fecha de la ultima modificacion del registro, es la fecha y hora actual segun el posicionamiento actual
													-- Cuando se crea el registro, el DateCreated y DateTimeStamp son iguales
				@vTzNameIDn, 						-- Es el IdNum de la Time Zone del la fecha
				@vTzOffset `TzOffset`, 				-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
									-- como es en horas y minutos, aqui se registra la diferencia real en horas y minutos
				@vTableHistory `TableHistory`	-- Es el historico del registro
			FROM `applcore`.`applimptarticles` `ia`
				INNER JOIN `applcore`.`appltdataelement` `de`
					ON `ia`.`IDName` = `de`.`IDName`
			WHERE `ia`.`SupplierIDn` <> '' OR `ia`.`ArticleSupplierID` <> '';

