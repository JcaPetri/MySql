-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Appl StProc 016 - ApplLogPTableFieldsValues Calls.sql
-- 2231 ApplLogPTableFieldsValuesCreate
-- -----------------------------
-- Los valores que forman la lista de opciones de cada Field/Columna, se cargan en el ScopeIDn del Field/Columna indicada
-- esto es ya que la clave primaria es TableFieldValueIDn + TableFieldIDn + CompanyIDn
-- Por lo tanto, si se cargara en la tabla ApplTTableFieldsValues ScopeIDn 2206, una determina descripcion, no podria cargarse dentro de varias columnas
-- ya que infringiria la clave de duplicidad. Ej, la palabra Autor, puede ser una marca o puede ser una opcion para otra columna y representan cosas distintas en cada una
-- Conclusion, los valores opcionales de cada columna se cargan en el ScopeIDn de la columna a donde pertenece el valor
-- ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

/*
SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 3 and IDName like '%Appl%' order by IDCode;	--  Lista Tablas
SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 4 order and IDNum >= 2223 by IDCode;	--  Lista las Field/Columns de las Tablas, superior a 2223 son las que se usan para los articulos
SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 6 and IDName like '%Appl%' order by IDCode;	--  Lista Stored Procedure
*/
-- Aclaracion: Este incorporacion solo crea el Diccionario posible, no le asigna valor a ningun objeto
-- 				Primero Definir la columna a la que se le insertara el valor
-- 				Segundo elegir el valor que puede tener esa columna
-- 	no olvidarse de actualizar el IDCode, si se pone 0, se incrementa de a uno

/*
SELECT `CompanyIDn`, `Company`, `ArticleIDn`, `Article` FROM `applcore`.`appllogvarticles` `art`;
SELECT * FROM applcore.applvdataelementoptionfieldvalue;
*/
-- Call Stored Procedures to create a new record, first in ApplTDataElement and then in ApplTTableFieldsValues
-- Parametros para la tabla `ApplCore`.`ApplPDataElementCreate`
set @traceability = 0;
set @vIDName = 'Cartas';				-- Valores que pueden insertarse en el Field, se crea el Valor en la tabla ApplTDataElement por unica vez
										-- Ej: Tabla Articulos Properties, la columna opcional, la Empresa Peperina, puede tener las opciones siguentes: 
										-- 		Columna Brand/Marca: Pampa / Boreal / Triunfante, etc
										-- 		Columna Product: Resma A4 70gr 500u / Resma A4 80gr 500u, etc
set @vIDNameStructureIDn = 1;		-- Es el IDNum de la estructura del IDName - si es multivaluado - aqui esta la estructura
set @vScopeIDn = 2250;				-- Es el IdNum de la TableFieldIDn que es la columna que recibira la lista de opciones disponibles, (que son los Campos/Fields disponibles, estan en el ScopeIDn = 4 SysTTableFields)
											-- Como los valores pertenecen a esa Columna, se ponen en su Scope
											-- SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 4 and IDCode >= 2501 order by IDNum desc, ScopeIDn;
												-- Algunas de las columnas
												-- 		2223	Brand
												-- 		2224	Product
                                                -- 		2225	Size
                                                -- 		2226	Weight
                                                -- 		2227	Color
                                                -- 		2228	Quantity
                                                -- 		2229	Unit
                                                -- 		2232	Product Type
                                                -- 		2249	Thickness
                                                -- 		2250	Model
set @vLanguageIDn = 734;			-- 652 English / 734 Español
set @vCompanyIDn = 2142; 			-- 2142 Peperina / 2143 Tagle / 2144 UniversalBuildCompany
set @vIDCode = 0;					-- Codigo numerico establecido por el usuario, permite organizar los contenidos de la tabla por rangos
set @vDefinitionIDn = 2070;			-- bpmndefaultdefinition
set @vInformationTypeIDn = 381;		-- 381 Data / 382 Software
set @vIDIsUsed = 1;					-- True
set @vStateIDn = 372;				-- 372 Enable Habilitado / 373 Disable Deshabilitado
set @vCreatedByIDn = 1;				-- Usuario
set @vLastModifiedByIDn = 1;		-- Usuario
set @vOwnerIDn = 1;					-- Usuario
set @vTzNameIDn = 1206;				-- America/Buenos_Aires
-- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Parametros para la tabla `ApplCore`.`ApplTTableFieldsValues`
-- Aqui se define a que TableField se asigna el valor creado en la tabla ApplTDataElement
-- set @vTableFieldValueIDn,			-- Se crea luego de que es generado el registro en la tabla ApplPDataElementCreate
-- set @vCompanyIDn,					-- Se cargo para la primer tabla
												-- la clave primaria, es el ArticleIDn + CompanyIDn, solo puede estar el articulo una vez en la compania
set @vTableFieldIDn = @vScopeIDn;		-- El Scope es igual a la Columna donde se insetan los valore

-- ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

-- Ejecuta el Procedimiento Almacenado
CALL `ApplCore`.`ApplPDataElementCreate`
(
	@vSqlState,
	@vErrorCode,
    @vMsgString,
    @vRowAffected,
    @vIDNum,
    @traceability,						-- Activate the traceability of the stored procedure: True = 1 / False = 0
    -- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    -- Parametros para insertar nuevo registro
    uuid(), 				-- vID, UniqueIdentifier
	@vIDName, 				-- vIDName, Código en letras del ID.
    @vIDNameStructureIDn,	-- Es el IDNum de la estructura del IDName - si es multivaluado - aqui esta la estructura
	@vScopeIDn, 			-- vScopeIDn, Es el IDNum del Ambito de Aplicación / Tabla a la que pertenece el registro, numeros variales
    @vLanguageIDn, 			-- vLanguageIDn, Es el IDNum del Idioma del Registro, Scope = 11 TSysLanguage, 652 English -- Codigo del idioma por defecto elegido. Este es el mismo durante todo el sistema.
	@vCompanyIDn, 			-- vCompanyIDn, Es el IDNum de la Compania dueña del Registro, Scope = 25, 2207 System, 7566 Tagle, 7565 Peperina
    @vIDCode,				-- vIDCode, Codigo numerico establecido por el usuario, permite organizar los contenidos de la tabla por rangos, se carga automaticamente si no se especifica
	@vDefinitionIDn, 		-- vDefinitionIDn, Es el IDNum del tipo de definicion del elemento, Scope = 23 tSysDefinition, 2070 bpmndefaultdefinition
	@vInformationTypeIDn, 	-- vInformationTypeIDn, Es el IDNum del tipo de Registro, Scope = 18 tSisInfoType, 381 Data, 382 Software = definición del código, bajo que estandar esta escrito. Define el tipo de dato que es el BaseElement}>, <{puede ser: Data (son los elementos reales que forman el sistema, los procesos, etc.), Software (es la estructura BMPN, XML, XSD).	
	@vIDIsUsed,				-- vIDIsUsed, 1 = true, 0 = false
    @vStateIDn,				-- vStateIDn, Es el IdNum del estado del registro, (Habilitado / Deshabilitado / Eliminado / etc), Scope = 21 tSisState, 372 Ena, 373 Dis
	@vCreatedByIDn, 		-- vCreatedByIDn, Es el IdNum del usuario que creo el registro, Scope = 231 UserTUser, numeros variales
	@vLastModifiedByIDn, 	-- vLastModifiedByIDn, Es el IdNum del ultimo usuario que modifico el registro, Scope = 231 UserTUser, numeros variales
	@vOwnerIDn, 			-- vOwnerIDn, Es el IdNum del usuario dueño del registro, Scope = 231 UserTUser, numeros variales
	current_timestamp,		-- vDateCreated, Es la fecha de creacion del registro, es la fecha y hora actual segun el posicionamiento actual
	current_timestamp,		-- vDateTimeStamp, Es la fecha de la ultima modificacion del registro, es la fecha y hora actual segun el posicionamiento actual
									-- Cuando se crea el registro, el DateCreated y DateTimeStamp son iguales
	@vTzNameIDn,			-- vTzNameIDn, Es el IdNum de la Time Zone del la fecha
	timestampdiff(minute, utc_timestamp(), current_timestamp()),	-- vTzOffset, Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
																	-- como es en horas y minutos, aqui se registra la diferencia real en horas y minutos
	null					-- vTableHistory, Es el historico del registro
);
/*	
SELECT @vSqlState,
	@vErrorCode,
    @vMsgString,
    @vRowAffected,
    @vIDNum;
*/
set @vTableFieldValueIDn = (SELECT @vIDNum); 		-- Es el IdNum del Articulo en el DataElement
														-- ya que es un registro del usuario, no asociado al funcionamiento del System
														-- El name y la descripcion estan dentro de las tablas DataElement y DataDocumentation
-- Ejecuta el Procedimiento Almacenado
CALL `ApplCore`.`ApplLogPTableFieldsValuesCreate`(
	@vSqlState,
	@vErrorCode,
	@vMsgString,
	@vRowAffected,
	@traceability,						-- Activate the traceability of the stored procedure: True = 1 / False = 0
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Parametros para insertar nuevo registro
    @vTableFieldValueIDn, 		-- Es el IdNum de la TableFieldValueIDn se crea en el DataElement
	@vTableFieldIDn, 			-- Es el IdNum de la TableFieldIDn que es la columna que recibira la lista de opciones disponibles, (que son los Campos/Fields disponibles, estan en el ScopeIDn = 4 SysTTableFields)
	@vCompanyIDn,					-- Es el IdNum de la Company al que esta asignado el IDName
												-- la clave primaria, es el ArticleIDn + CompanyIDn, solo puede estar el articulo una vez en la compania
	@vStateIDn,				-- vStateIDn, Es el IdNum del estado del registro, (Habilitado / Deshabilitado / Eliminado / etc), Scope = 21 tSisState, 372 Ena, 373 Dis
	@vCreatedByIDn, 		-- vCreatedByIDn, Es el IdNum del usuario que creo el registro, Scope = 231 UserTUser, numeros variales
	@vLastModifiedByIDn, 	-- vLastModifiedByIDn, Es el IdNum del ultimo usuario que modifico el registro, Scope = 231 UserTUser, numeros variales
	@vOwnerIDn, 			-- vOwnerIDn, Es el IdNum del usuario dueño del registro, Scope = 231 UserTUser, numeros variales
	current_timestamp,		-- vDateCreated, Es la fecha de creacion del registro, es la fecha y hora actual segun el posicionamiento actual
	current_timestamp,		-- vDateTimeStamp, Es la fecha de la ultima modificacion del registro, es la fecha y hora actual segun el posicionamiento actual
									-- Cuando se crea el registro, el DateCreated y DateTimeStamp son iguales
	@vTzNameIDn,			-- vTzNameIDn, Es el IdNum de la Time Zone del la fecha
	timestampdiff(minute, utc_timestamp(), current_timestamp()),	-- vTzOffset, Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
																	-- como es en horas y minutos, aqui se registra la diferencia real en horas y minutos
	null					-- vTableHistory, Es el historico del registro
);
/*
SELECT @vSqlState,
	@vErrorCode,
    @vMsgString,
    @vRowAffected
    ;
*/
-- Lista las tablas donde se insertaron los datos
SELECT * FROM `ApplCore`.`ApplTDataElement` where ScopeIDn = @vScopeIDn order by IDNum desc;		-- 2206	ApplTTableFieldsValues
-- SELECT * FROM applcore.appllogvtablefieldsvalues;

-- Lista la tabla SysTSqlTimes
-- 2231 ApplLogPTableFieldsValuesCreate
-- SELECT * FROM `bpmcore`.`systsqltimes` WHERE ProcessIDn = 2231 ORDER BY ProcessIDn, ProcessNumber desc, ProcessOrder, Stage desc;

/*
	DELETE FROM `ApplCore`.`ApplTDataElement` WHERE IDNum = 6;
	DELETE FROM `bpmcore`.`systsqltimes` WHERE ProcessIDn = 2231;


SELECT * FROM applcore.applvdataelementoptionfieldvalue;

*/

SELECT CompanyIDn, ScopeIDn, IDNum, CONCAT(`Field Scope`,'-',`Field Value`) 'ColFieldValue' FROM applcore.applvdataelementoptionfieldvalue;

