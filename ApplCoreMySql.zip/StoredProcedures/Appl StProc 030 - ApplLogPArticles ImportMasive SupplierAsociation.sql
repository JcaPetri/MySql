-- #######################################################################################################################################################################################################
-- Appl StProc 030 - ApplLogPArticles ImportMasive.sql
-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
/*
            Articles - Importacion Masiva de Articulos Asociados a un Proveedor:
				Appl StProc 030 - ApplLogPArticles ImportMasive SupplierAsociation.sql
				Tablas afectadas: 	`ApplCore`.`ApplTDataElement`						// El Diccionario
									`ApplCore`.`ApplLogTArticles`						// Base General de Articulos
									`Applcore`.`AppllogTArticlesSuppliersArticles`		// Relacion entre los Articulos y sus Proveedores
					-- Aclaracion: puede dar error la ultima consulta si es que en la tabla del proveedor no esta el articulo

*/

-- #################################################################################################################################################################################################
-- Controles
-- -----------------------------------------------------------------------------------------------------------------------------------------
/*
SELECT * FROM applcore.applimptarticles;
DELETE FROM applcore.applimptarticles;

-- SELECT * FROM  ApplCore.ApplTDataElement WHERE LOWER(IDName) LIKE '%Keyroad%';

-- Verifica que no haya duplicados, el IDName no puede estar duplicado
SELECT ArticleSupplierID, IDName, COUNT(*) 'Q' FROM applcore.applimptarticles GROUP BY IDName HAVING COUNT(*) > 1;

-- Verifica que el Codigo de Articulos del Proveedor cuantas veces aparece
SELECT ArticleSupplierID, COUNT(*) 'Q' FROM applcore.applimptarticles GROUP BY ArticleSupplierID HAVING COUNT(*) > 1;
-- En esta consulta puede repetirse varias veces el ArticleSupplierID, ya que puede ser que distintos articulos para el proveedor sea el mismo
-- Ejemplo de esto es, un cuaderno cuadriculado o rallado, para el proveedor es lo mismo y para nosotros es distinto, lo llevamos por separado

-- Verifica que los nombres de los articulos ya no esten importados para esa company
SELECT * FROM `applcore`.`applimptarticles` `ai` 
	INNER JOIN `ApplCore`.`ApplTDataElement` `de` 
		ON `ai`.`IDName` = `de`.`IDName`
			-- AND `ai`.`CompanyIDn` = `de`.`CompanyIDn`;

-- Si los codigos ya estan creados en el diccionario, verifica si estan creados en las otras dos tablas que son:
-- 										AppllogTArticles
-- 										AppllogTArticlesSupplierArticles
-- Para solucionar esto ejecutar la consulta: Appl StProc 030 - ApplLogPArticles Corrige Tablas Articles y SupplierAsociation.sql
-- Comentario: estos articulos es como no existieran para el sistema, solo estan creados en el diccionario
SELECT `asp`.`ArticleIDn` `TableArticlesSupplierArticles`, `art`.`ArticleIDn` `TableArticles`, `ia`.`SupplierIDn`, `ia`.`ArticleSupplierID`, `de`.`IDNum`, `ia`.`IDName`, `de`.`IDName` `DeIDName`, `de`.`ID`
	FROM `applcore`.`applimptarticles` `ia` 
		INNER JOIN `ApplCore`.`ApplTDataElement` `de` 
			ON `ia`.`IDName` = `de`.`IDName`
		LEFT OUTER JOIN `applcore`.`appllogtarticles` `art`
			ON `de`.`IDNum` = `art`.`ArticleIDn`
		LEFT OUTER JOIN `applcore`.`appllogtarticlessuppliersarticles` `asp`
			ON `ia`.`ArticleSupplierID` = `asp`.`ArticleSupplierID`
	   ;

Luego ejecutar la consulta y volver a generar la base de importacion de datos
	SELECT `CompanyIDn`, `Company`, `ArticleIDn`, `Article` FROM `applcore`.`appllogvarticles` `art`;

*/

-- #######################################################################################################################################################################################################
-- Verifica que todos los Articulos estan en la tabla de Proveedores ApplSupTSuppliersPriceListArticles
-- -----------------------------------------------------------------------------------------------------------------------------------------
-- este error se produce, porque no se puede asociar un articulo con la lista del proveedor si el mismo no lo tiene disponible
/*
SELECT `ai`.`SupplierIDn`, `ai`.`ArticleSupplierID`, `ai`.`IDName` 
FROM `applcore`.`applimptarticles` `ai`
	LEFT OUTER JOIN `applcore`.`applsuptsupplierspricelistarticles` `spla`
		ON `ai`.`ArticleSupplierID` = `spla`.`ArticleSupplierID`
			AND `ai`.`SupplierIDn` = `spla`.`SupplierIDn`
WHERE `spla`.`ArticleSupplierID` IS NULL;

DELETE FROM `applcore`.`applimptarticles` 
WHERE ArticleSupplierID = 167596 
	OR ArticleSupplierID = 160661
    OR ArticleSupplierID = 151437;

Articulos Pendientes de cargar porque no estan en la Lista de Precio de Montenegro ya que esta desactualizada al momento de la carga
*/
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

-- #######################################################################################################################################################################################################
-- Este es un ajuste eventual
-- -----------------------------------------------------------------------------------------------------------------------------------------
/*	Actualiza el ID desde la tabla ApplTDataElement -- Esto es por si los valores a importar ya estan cargados en la tabla DataElement
SELECT * FROM applcore.applimptarticles;
UPDATE `applcore`.`applimptarticles` `ia`
	INNER JOIN `ApplCore`.`ApplTDataElement` `de`
		ON `ia`.`IDName` = `de`.`IDName`
SET `ia`.`ID` = `de`.`ID`;

UPDATE `applcore`.`applimptarticles` `ia`
SET `ia`.`IDName` = REPLACE(IDName, ";", ",");

SELECT IDName, REPLACE(IDName, ";", ",") IDName FROM applcore.applimptarticles;

*/
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

-- #################################################################################################################################################################################################
-- Setea las variables
-- -----------------------------------------------------------------------------------------------------------------------------------------
set @vIDNameStructureIDn = 1;		-- Es el IDNum de la estructura del IDName - si es multivaluado - aqui esta la estructura
set @vScopeIDn = 2205;				-- Tabla ApplLogTArticles
set @vLanguageIDn = 734;			-- Español
set @vCompanyIDn = 2142; 			-- 2142 Peperina / 2143 Tagle / 2144 UniversalBuildCompany
set @vIDCode = 0;					-- 0 = Codigo incrementalmente autogenerado - Codigo numerico establecido por el usuario, permite organizar los contenidos de la tabla por rangos
set @vDefinitionIDn = 2070;			-- bpmndefaultdefinition
set @vInformationTypeIDn = 381;		-- 381 Data / 382 Software
set @vIDIsUsed = 1;					-- True
set @vStateIDn = 372;				-- 372 Enable Habilitado / 373 Disable Deshabilitado
set @vCreatedByIDn = 1;				-- Usuario
set @vLastModifiedByIDn = 1;		-- Usuario
set @vOwnerIDn = 1;					-- Usuario
set @vDateCreated = current_timestamp;			-- Es la fecha de creacion del registro, es la fecha y hora actual segun el posicionamiento actual
set @vDateTimeStamp = current_timestamp;			-- Es la fecha de la ultima modificacion del registro, es la fecha y hora actual segun el posicionamiento actual
set @vTzNameIDn = 1206;				-- America/Buenos_Aires
set @vTzOffset = timestampdiff(minute, utc_timestamp(), current_timestamp());	-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro 
set @vTableHistory = null;			-- Es el historico del registro
-- Variables para insertar los registros en la tabla ApplLogArticles
set @ArticleGeneralIDn = 2;					-- Es el IDNum de las caracteristicas Generales del Articulo, esta en la tabla appllogtarticlesgeneral
set @BarCode = null;						-- Es el codigo de barra
set @StockEnable = 1;						-- True = 1 / False = 0

-- #################################################################################################################################################################################################
-- 1.- Le Asigna un ID uniqueidentifier a todos los registros de la tabla ApplCore.ApplimpTArticles
-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
UPDATE `applcore`.`applimptarticles`
SET `ID` = uuid()
WHERE ID is null;

-- #################################################################################################################################################################################################
-- 2.- Inserta todos los registros en la tabla `ApplCore`.`ApplTDataElement` que estan en la tabla ApplCore.ApplimpTArticles que tienen ID = null
-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	insert into `ApplCore`.`ApplTDataElement`
			(`ID`,
			-- `IDNum`,
			`IDName`,
			`IDNameStructureIDn`,
			`ScopeIDn`,
			`CompanyIDn`,
			`LanguageIDn`,
			`IDCode`,
			`DefinitionIDn`,
			`InformationTypeIDn`,
			`IDIsUsed`,
			`StateIDn`,
			`CreatedByIDn`,
			`LastModifiedByIDn`,
			`OwnerIDn`,
			`DateCreated`,
			`DateTimeStamp`,
			`TzNameIDn`,
			`TzOffset`,
			`TableHistory`)
		SELECT 	`ia`.ID `ID`,					-- UniqueIdentifier, es autogenerado
				-- `ia`.ArticleSupplierID, 		-- Es el codigo del articulo para ese proveedor
				`ia`.IDName,					-- Es la descripcion del articulo
				@vIDNameStructureIDn `IDNameStructureIDn`,	-- Es el IDNum de la estructura del IDName, si es multivaluado, aqui esta la estructura
				@vScopeIDn `ScopeIDn`,				-- Es el IDNum del Ambito de Aplicación / Tabla a la que pertenece el registro, numeros variales
				@vCompanyIDn `CompanyIDn`,			-- Es el IDNum de la Compania dueña del Registro, Scope = 25, 2207 System, 7566 Tagle, 7565 Peperina
				@vLanguageIDn `LanguageIDn`, 		-- Es el IDNum del Idioma del Registro, Scope = 11 TSysLanguage, 652 English -- Codigo del idioma por defecto elegido. Este es el mismo durante todo el sistema.
				@vIDCode `IDCode`,					-- Codigo numerico establecido por el usuario, permite organizar los contenidos de la tabla por rangos, se carga automaticamente si no se especifica
				@vDefinitionIDn `DefinitionIDn`,		-- Es el IDNum del tipo de definicion del elemento, Scope = 23 tSysDefinition, 2070 bpmndefaultdefinition
				@vInformationTypeIDn `InformationTypeIDn`,	-- Es el IDNum del tipo de Registro, Scope = 18 tSisInfoType, 381 Data, 382 Software = definición del código, bajo que estandar esta escrito. Define el tipo de dato que es el BaseElement, puede ser: Data (son los elementos reales que forman el sistema, los procesos, etc.), Software (es la estructura BMPN, XML, XSD).	
				@vIDIsUsed `IDIsUsed`,						-- 1 = true, 0 = false
				@vStateIDn `StateIDn`,						-- Es el IDNum del estado del registro, Scope = 21 tSisState, 372 Ena, 373 Dis
				@vCreatedByIDn `CreatedByIDn`,					-- Es el IdNum del usuario que creo el registro, Scope = 231 UserTUser, numeros variales
				@vLastModifiedByIDn `LastModifiedByIDn`,				-- Es el IdNum del ultimo usuario que modifico el registro, Scope = 231 UserTUser, numeros variales
				@vOwnerIDn `OwnerIDn`,						-- Es el IdNum del usuario dueño del registro, Scope = 231 UserTUser, numeros variales
				@vDateCreated `DateCreated`,		-- Es la fecha de creacion del registro, es la fecha y hora actual segun el posicionamiento actual
				@vDateTimeStamp `DateTimeStamp`,	-- Es la fecha de la ultima modificacion del registro, es la fecha y hora actual segun el posicionamiento actual
													-- Cuando se crea el registro, el DateCreated y DateTimeStamp son iguales
				@vTzNameIDn, 						-- Es el IdNum de la Time Zone del la fecha
				@vTzOffset `TzOffset`, 				-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
									-- como es en horas y minutos, aqui se registra la diferencia real en horas y minutos
				@vTableHistory `TableHistory`	-- Es el historico del registro
			FROM applcore.applimptarticles `ia`;

-- #################################################################################################################################################################################################
-- 3.- Inserta todos los registros en la tabla `ApplCore`.`ApplLogTArticles` que estan en la tabla ApplCore.ApplimpTArticles
-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
INSERT INTO `ApplCore`.`ApplLogTArticles`
		(`ArticleIDn`,
		`CompanyIDn`,
		`ArticleGeneralIDn`,
		`BarCode`,
		`StockEnable`,
		`StateIDn`,
		`CreatedByIDn`,
		`LastModifiedByIDn`,
		`OwnerIDn`,
		`DateCreated`,
		`DateTimeStamp`,
		`TzNameIDn`,
		`TzOffset`,
		`TableHistory`)
			SELECT 	`de`.`IDNum` 'ArticleIDn',						-- Valor numerico unico autogenerado, que se genero en la consulta anterior
				@vCompanyIDn `CompanyIDn`,			-- Es el IDNum de la Compania dueña del Registro, Scope = 25, 2207 System, 7566 Tagle, 7565 Peperina
				@ArticleGeneralIDn,					-- Es el IDNum de las caracteristicas Generales del Articulo, esta en la tabla appllogtarticlesgeneral
                @BarCode,							-- Es el codigo de barra
                @StockEnable,						-- True = 1 / False = 0
                @vStateIDn `StateIDn`,						-- Es el IDNum del estado del registro, Scope = 21 tSisState, 372 Ena, 373 Dis
				@vCreatedByIDn `CreatedByIDn`,					-- Es el IdNum del usuario que creo el registro, Scope = 231 UserTUser, numeros variales
				@vLastModifiedByIDn `LastModifiedByIDn`,				-- Es el IdNum del ultimo usuario que modifico el registro, Scope = 231 UserTUser, numeros variales
				@vOwnerIDn `OwnerIDn`,						-- Es el IdNum del usuario dueño del registro, Scope = 231 UserTUser, numeros variales
				@vDateCreated `DateCreated`,		-- Es la fecha de creacion del registro, es la fecha y hora actual segun el posicionamiento actual
				@vDateTimeStamp `DateTimeStamp`,	-- Es la fecha de la ultima modificacion del registro, es la fecha y hora actual segun el posicionamiento actual
													-- Cuando se crea el registro, el DateCreated y DateTimeStamp son iguales
				@vTzNameIDn, 						-- Es el IdNum de la Time Zone del la fecha
				@vTzOffset `TzOffset`, 				-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
									-- como es en horas y minutos, aqui se registra la diferencia real en horas y minutos
				@vTableHistory `TableHistory`	-- Es el historico del registro
			FROM applcore.applimptarticles `ia`
				INNER JOIN `applcore`.`appltdataelement` `de`
					ON `ia`.`ID` = `de`.`ID`;



-- #################################################################################################################################################################################################
-- 4.- Debe estar creada la Lista de Precios del Proveedor en las tablas `ApplCore`.`ApplSupTSuppliersPriceList`
-- 																		 `ApplCore`.`ApplSupTSuppliersPriceListArticles`
-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
/*
51	LP Montenegro
52	LP Popeye
872	LP Mar-Plast
1788	LP Wow
1789	LP Foko
1792	LP Matemundo
*/


-- #################################################################################################################################################################################################
-- 5.- Inserta en la tabla `ApplCore`.`AppllogTArticlesSuppliersArticles` la relacion entre los articulos y el proveedor
-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	INSERT INTO `applcore`.`appllogtarticlessuppliersarticles`
		(`ArticleIDn`,
		`ArticleSupplierID`,
		`SupplierIDn`,
		`CompanyIDn`,
		`StateIDn`,
		`CreatedByIDn`,
		`LastModifiedByIDn`,
		`OwnerIDn`,
		`DateCreated`,
		`DateTimeStamp`,
		`TzNameIDn`,
		`TzOffset`,
		`TableHistory`)
		SELECT 	`de`.`IDNum` 'ArticleIDn',						-- Valor numerico unico autogenerado, que se genero en la consulta anterior
				-- `ia`.ID `ID`,					-- UniqueIdentifier, es autogenerado
				`ia`.`ArticleSupplierID`, 			-- Es el codigo del articulo para ese proveedor
				-- `ia`.IDName,						-- Es la descripcion del articulo
				`ia`.`SupplierIDn`,					-- Es el codigo del proveedor del articulo
				@vCompanyIDn `CompanyIDn`,			-- Es el IDNum de la Compania dueña del Registro, Scope = 25, 2207 System, 7566 Tagle, 7565 Peperina
				@vStateIDn `StateIDn`,						-- Es el IDNum del estado del registro, Scope = 21 tSisState, 372 Ena, 373 Dis
				@vCreatedByIDn `CreatedByIDn`,					-- Es el IdNum del usuario que creo el registro, Scope = 231 UserTUser, numeros variales
				@vLastModifiedByIDn `LastModifiedByIDn`,				-- Es el IdNum del ultimo usuario que modifico el registro, Scope = 231 UserTUser, numeros variales
				@vOwnerIDn `OwnerIDn`,						-- Es el IdNum del usuario dueño del registro, Scope = 231 UserTUser, numeros variales
				@vDateCreated `DateCreated`,		-- Es la fecha de creacion del registro, es la fecha y hora actual segun el posicionamiento actual
				@vDateTimeStamp `DateTimeStamp`,	-- Es la fecha de la ultima modificacion del registro, es la fecha y hora actual segun el posicionamiento actual
													-- Cuando se crea el registro, el DateCreated y DateTimeStamp son iguales
				@vTzNameIDn, 						-- Es el IdNum de la Time Zone del la fecha
				@vTzOffset `TzOffset`, 				-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
									-- como es en horas y minutos, aqui se registra la diferencia real en horas y minutos
				@vTableHistory `TableHistory`	-- Es el historico del registro
			FROM `applcore`.`applimptarticles` `ia`
				INNER JOIN `applcore`.`appltdataelement` `de`
					ON `ia`.`ID` = `de`.`ID`
			WHERE `ia`.`SupplierIDn` <> '' OR `ia`.`ArticleSupplierID` <> '';
            
-- #################################################################################################################################################################################################
-- Elimina los articulos ya ingresados
DELETE FROM applcore.applimptarticles;

-- #################################################################################################################################################################################################
-- Resultados
SELECT * FROM `ApplCore`.`appltdataelement` WHERE ScopeIDn = 2205;		-- 653 registros
SELECT * FROM `ApplCore`.`ApplLogTArticles`;							-- 653 registros
SELECT * FROM `ApplCore`.`AppllogTArticlesSuppliersArticles`;			-- 514 registros

-- SELECT * FROM `ApplCore`.`ApplImpTArticles`;

-- SELECT `CompanyIDn`, `Company`, `ArticleIDn`, `Article` FROM `applcore`.`appllogvarticles` `art`;
 
 
 