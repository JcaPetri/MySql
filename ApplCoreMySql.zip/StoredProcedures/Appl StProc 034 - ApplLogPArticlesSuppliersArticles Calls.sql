-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Ejecuta el Procedimiento Almacenado:
-- IDNum	IDName/Table								ScopeIDn		IDCode
-- 2238		ApplLogPArticlesSuppliersArticlesCreate			6			 407
-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Lista los Stored Procedures que estan en la tabla BaseElement
-- SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 6 order by IDCode;

-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Lista los Supplier, estan en la tabla ApplTPersons
  SELECT * FROM applcore.applvpersons;
/*
PersonIDn	IDName		Company				Type	TradeName
49			110001		2142	Peperina	0		Estela Montenegro s.a.	831	Buenos Aires 362, X5022AAH Córdoba
*/
-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Lista los articulos disponibles a los cuales se le puede asociar un articulo de un proveedor
  SELECT * FROM applcore.appllogvarticles;
/*
	CompanyIDn			ArticleIDn
	2142	Peperina	7	308485		Pampa Resma A4 70gr x 500h
	2142	Peperina	8	308476		Boreal Resma A4 70gr x 500h						
	2142	Peperina	9	308480		Boreal Resma A4 80gr x 500h				
	2142	Peperina	10	308474		Boreal Resma color A4 75gr x 500h		
	2142	Peperina	11	308499		Triunfante Resma color A4 70gr x 100h
	2142	Peperina	12	308497		Husares Resma A4 120gr x 100h
	2142	Peperina	13	308498		Husares Resma A4 150gr x 100h
	2142	Peperina	14	308477		Boreal Resma T/O 70gr x 500h			
	2142	Peperina	15	308468		Autor Resma A3 80grs x 500h

*/

-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Lista los articulos disponibles de los proveedores
SELECT * FROM applcore.applsuptsupplierspricelistarticles
WHERE lower(ArticleSupplierDescription) like '%resma%';

-- ########################################################################################################################################################################################
-- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Parametros para la tabla `ApplCore`.`ApplLogPArticlesSuppliersArticlesCreate`
-- Aqui no se crea ningun articulo, solo se asocia el ArticleIDn del Supplier/Proveedor con el ArticleIDn de la Company
-- de esta manera, se puede actualizar nuestro articulo con la informacion que nos suministra el proveedor
set @vArticleIDn = 11;						-- Es el IdNum del Articulo en el DataElement
set @vArticleSupplier = '308499';			-- Es Codigo Unico de identificacion del articulo para ese Supplier/Proveedor
											-- Este codigo puede tener hasta 38 caracteres alfanumericos
set @vSupplierIDn = 49;				-- Es el IdNum del Supplier/Proveedor, esta en la tabla ApplTPersons
set @vCompanyIDn = 2142;			-- Es el IdNum de la Company al que esta asignado el registro =, 2142 Peperina
											-- la clave primaria: es el ArticleIDn + ArticleSupplier + SupplierIDn + CompanyIDn
set @vStateIDn = 372;				-- 372 Enable Habilitado / 373 Disable Deshabilitado
set @vCreatedByIDn = 1;				-- Usuario
set @vLastModifiedByIDn = 1;		-- Usuario
set @vOwnerIDn = 1;					-- Usuario
set @vTzNameIDn = 1206;				-- America/Buenos_Aires

-- Ejecuta el Procedimiento Almacenado
CALL `ApplCore`.`ApplLogPArticlesSuppliersArticlesCreate`(
	@vSqlState,
	@vErrorCode,
	@vMsgString,
	@vRowAffected,
	@traceability,						-- Activate the traceability of the stored procedure: True = 1 / False = 0
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Parametros para insertar nuevo registro

	@vArticleIDn,				-- Es el IdNum del Articulo en el DataElement
	@vArticleSupplier,			-- Es Codigo Unico de identificacion del articulo para ese Supplier/Proveedor
										-- Este codigo puede tener hasta 38 caracteres alfanumericos
	@vSupplierIDn,				-- Es el IdNum del Supplier/Proveedor, esta en la tabla ApplTPersons
	@vCompanyIDn,				-- Es el IdNum de la Company al que esta asignado el IDName
											-- la clave primaria: es el ArticleIDn + ArticleSupplier + SupplierIDn + CompanyIDn
	@vStateIDn,				-- vStateIDn, Es el IdNum del estado del registro, (Habilitado / Deshabilitado / Eliminado / etc), Scope = 21 tSisState, 372 Ena, 373 Dis
	@vCreatedByIDn, 		-- vCreatedByIDn, Es el IdNum del usuario que creo el registro, Scope = 231 UserTUser, numeros variales
	@vLastModifiedByIDn, 	-- vLastModifiedByIDn, Es el IdNum del ultimo usuario que modifico el registro, Scope = 231 UserTUser, numeros variales
	@vOwnerIDn, 			-- vOwnerIDn, Es el IdNum del usuario dueño del registro, Scope = 231 UserTUser, numeros variales
	current_timestamp,		-- vDateCreated, Es la fecha de creacion del registro, es la fecha y hora actual segun el posicionamiento actual
	current_timestamp,		-- vDateTimeStamp, Es la fecha de la ultima modificacion del registro, es la fecha y hora actual segun el posicionamiento actual
									-- Cuando se crea el registro, el DateCreated y DateTimeStamp son iguales
	@vTzNameIDn,			-- vTzNameIDn, Es el IdNum de la Time Zone del la fecha
	timestampdiff(minute, utc_timestamp(), current_timestamp()),	-- vTzOffset, Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
																	-- como es en horas y minutos, aqui se registra la diferencia real en horas y minutos
	null					-- vTableHistory, Es el historico del registro
);

SELECT @vSqlState,
	@vErrorCode,
    @vMsgString,
    @vRowAffected
    ;

-- Lista las tablas donde se insertaron los datos
SELECT `as`.`Company`, `as`.`ArticleIDn`, `as`.`Article`, `as`.`TradeName`, `as`.`Price`, `as`.`DatePriceList`, `as`.`PriceListCode`, `as`.`ArticleSupplierID` , `as`.`ArticleSupplierDescription`
FROM `applcore`.`appllogvarticlessuppliersarticles` `as`;


-- Lista la tabla SysTSqlTimes
-- 2238		ApplLogPArticlesSuppliersArticlesCreate	
-- SELECT * FROM `bpmcore`.`systsqltimes` WHERE ProcessIDn = 2238 ORDER BY ProcessIDn, ProcessNumber desc, ProcessOrder, Stage desc;

/*
	DELETE FROM `ApplCore`.`ApplSupTSuppliersPriceListArticles` WHERE SupplierIDn = xxxx;
	DELETE FROM `bpmcore`.`systsqltimes` WHERE ProcessIDn = 2238;
*/


