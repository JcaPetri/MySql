-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Appl StProc 032 - ApplLogPArticlesOptionalFields Calls.sql
-- IDNum	IDName/Table							ScopeIDn	IDCode
-- 2234		ApplLogPArticlesOptionalFieldsSearch		6		  405	
-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
/*
Los Field/Columnas: FieldNumValue, FieldTextValue, son libres y no estandarizadas, el usuario puede cargar cualquier valor
se sugiere tratar de no utilizarlo, ya que no fomenta la estandarizacion y posteriormente las busquedas y/o generacion de informes
*/

-- Call Stored Procedures to create a new record
-- Parametros para la tabla `ApplCore`.`ApplLogTArticlesOptionalFields`
set @traceability = 1;
set @vFieldValuesIDn = '35';			-- Son los IdNum del valor de la propiedad del Articulo |36
											-- 23|36|33
											-- 36 	70gr		-- 48 resma		-- 33 A4		
set @vCompanyIDn = 2142; 			-- Es el IdNum de la Company: 2142 Peperina / 2143 Tagle / 2144 UniversalBuildCompany
set @vStateIDn = 372;				-- 372 Enable Habilitado / 373 Disable Deshabilitado

-- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Ejecuta el Procedimiento Almacenado
CALL `applcore`.`ApplLogPArticlesOptionalFieldsSearchCreate` (
	@vSqlState,
	@vErrorCode,
	@vMsgString,
	@vRowAffected,
	@traceability,						-- Activate the traceability of the stored procedure: True = 1 / False = 0
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Parametros para insertar nuevo registro
	@vFieldValuesIDn,		-- Son los IdNum del valor de la propiedad del Articulo
    @vCompanyIDn, 			-- Es el IdNum de la Company: 2142 Peperina / 2143 Tagle / 2144 UniversalBuildCompany
										-- la clave primaria es la propiedad (columna) vTableFieldIDn + el ArticleIDn (Tabla) + CompanyIDn
	@vStateIDn				-- vStateIDn, Es el IdNum del estado del registro, (Habilitado / Deshabilitado / Eliminado / etc), Scope = 21 tSisState, 372 Ena, 373 Dis
);

/*
SELECT @vSqlState,
	@vErrorCode,
    @vMsgString,
    @vRowAffected
    ;
*/


-- Lista la tabla SysTSqlTimes
-- 2234	ApplLogPArticlesOptionalFieldsSearch
-- SELECT * FROM `bpmcore`.`systsqltimes` WHERE ProcessIDn = 2234 ORDER BY ProcessIDn, ProcessNumber desc, ProcessOrder, Stage desc;

/*
	DELETE FROM `ApplCore`.`ApplTDataElement` WHERE IDNum = 6;
	DELETE FROM `bpmcore`.`systsqltimes` WHERE ProcessIDn = 2234;
*/