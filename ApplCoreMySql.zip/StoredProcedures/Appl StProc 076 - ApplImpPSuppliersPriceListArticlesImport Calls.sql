-- ##########################################################################################################################################################################################
-- ApplImpPSuppliersPriceListArticlesImport
-- IDNum	IDName/Table				 				ScopeIDn	IDCode
-- 2243		ApplImpPSuppliersPriceListArticlesImport		6		  462
-- -----------------------------
-- Lista los Stored Procedures que estan en la tabla BaseElement
-- SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 3 AND IDCode >= 1200 AND IDCode <= 1300;

-- Aclaracion: Informacion Importante para la importacion de datos
		-- Load In File -- No esta habilitado dentro de los procedimientos almacenados ni funciones, por tema Seguridad
		-- SELECT VERSION();		-- Version Instalada de Mysql
		-- Muestra el directorio seguro para importar datos a MySQl
		-- 		SHOW VARIABLES LIKE "secure_file_priv";
		-- 		SELECT @@GLOBAL.secure_file_priv;			-- Muestra lo mismo
		-- Activa la Variable Local para permitir importar datos
		-- 		SET GLOBAL local_infile=1;
		-- 		SHOW GLOBAL VARIABLES LIKE 'local_infile';
        -- Cambia el QueryTimeOut setting
        -- 	Wait TimeOut
        -- 		SET GLOBAL wait_timeout=57600;
        -- 		SHOW GLOBAL VARIABLES LIKE 'wait_timeout';
		-- 		SET GLOBAL wait_timeout=28800;
        -- 	Read TimeOut
        -- 		SET GLOBAL net_read_timeout=360;
        -- 		SHOW GLOBAL VARIABLES LIKE 'net_read_timeout';
        -- 		SET GLOBAL net_read_timeout=30;
        -- 	Connection TimeOut
        -- 		SET GLOBAL connect_timeout=60;
        -- 		SHOW GLOBAL VARIABLES LIKE 'connect_timeout';
        -- 	LockWait TimeOut
        -- 		SET GLOBAL innodb_lock_wait_timeout=100;
        -- 		SHOW GLOBAL VARIABLES LIKE 'innodb_lock_wait_timeout';
        -- MySqlx Connect TimeOut
        -- 		SET GLOBAL mysqlx_connect_timeout=60;
        -- 		SHOW GLOBAL VARIABLES LIKE 'mysqlx_connect_timeout';
        -- 		SET GLOBAL mysqlx_connect_timeout=30;
        -- MySqlx Read TimeOut
        -- 		SET GLOBAL mysqlx_read_timeout=60;
        -- 		SHOW GLOBAL VARIABLES LIKE 'mysqlx_read_timeout';
        -- 		SET GLOBAL mysqlx_read_timeout=30;
        -- Connect TimeOut
        -- 		SET GLOBAL connect_timeout=200;
        -- 		SHOW GLOBAL VARIABLES LIKE 'connect_timeout';
        -- 		SET GLOBAL connect_timeout=100;
        -- mysqlx_idle_worker_thread_timeout TimeOut
        -- 		SET GLOBAL mysqlx_idle_worker_thread_timeout=120;
        -- 		SHOW GLOBAL VARIABLES LIKE 'mysqlx_idle_worker_thread_timeout';
        -- 		SET GLOBAL mysqlx_idle_worker_thread_timeout=60;        
        
        
        
/*
-- Lista las fechas que tuvieron actualizacion de precios
	SELECT DatePriceList, COUNT(*) 'Q'
	FROM applcore.applsuptsupplierspricelistarticles
	GROUP BY DatePriceList
	ORDER BY DatePriceList DESC;
    
set @vFileSource = 'C:\\ProgramData\\MySQL\\MySQL Server 8.0\\Uploads\\';									-- Es la ruta de acceso del archivo
set @vFileName = 'LP Estela Montenegro - Imp_ApplSupTSuppliersPriceListArticles_20201228.csv';				-- Es el nombre del archivo

*/
-- Call Stored Procedures para depurar los datos
-- Parametros para la tabla `ApplCore`.`ApplImpPSuppliersPriceListArticlesImport`
set @traceability = 0;
set @vDateFormat = 'dd/mm/yyyy';	-- Formato de la Fecha
set @vCreatedByIDn = 1;				-- Usuario
set @vLastModifiedByIDn = 1;		-- Usuario
set @vOwnerIDn = 1;					-- Usuario
set @vTzNameIDn = 1206;				-- America/Buenos_Aires
-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
USE `ApplCore`;
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Import Data
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
DELETE FROM `ApplCore`.`ApplImpTSuppliersPriceListArticles`;
-- Al Inicio Pone a Cero el contador de la Tabla
ALTER TABLE `applcore`.`applimptsupplierspricelistarticles` AUTO_INCREMENT = 0;

-- SELECT * FROM `ApplCore`.`ApplImpTSuppliersPriceListArticles`;
-- LP Estela Montenegro - Imp_ApplSupTSuppliersPriceListArticles_20201228
-- LP Estela Montenegro - Imp_ApplSupTSuppliersPriceListArticles_20210127
-- LP Estela Montenegro - Imp_ApplSupTSuppliersPriceListArticles_20210223
-- LP Estela Montenegro - Imp_ApplSupTSuppliersPriceListArticles_20210329
-- LP Estela Montenegro - Imp_ApplSupTSuppliersPriceListArticles_20210414
-- LP Estela Montenegro - Imp_ApplSupTSuppliersPriceListArticles_20210507
-- LP Estela Montenegro - Imp_ApplSupTSuppliersPriceListArticles_20210529
-- LP Estela Montenegro - Imp_ApplSupTSuppliersPriceListArticles_20210624
-- LP Estela Montenegro - Imp_ApplSupTSuppliersPriceListArticles_20210715
-- LP Estela Montenegro - Imp_ApplSupTSuppliersPriceListArticles_20210803
-- LP Estela Montenegro - Imp_ApplSupTSuppliersPriceListArticles_20210907
-- LP Estela Montenegro - Imp_ApplSupTSuppliersPriceListArticles_20211004
-- LP Estela Montenegro - Imp_ApplSupTSuppliersPriceListArticles_20211102
-- LP Estela Montenegro - Imp_ApplSupTSuppliersPriceListArticles_20211203
-- LP Estela Montenegro - Imp_ApplSupTSuppliersPriceListArticles_20211221
-- LP Estela Montenegro - Imp_ApplSupTSuppliersPriceListArticles_20220128
-- LP Estela Montenegro - Imp_ApplSupTSuppliersPriceListArticles_20220209
-- LP Estela Montenegro - Imp_ApplSupTSuppliersPriceListArticles_20220301
-- LP Estela Montenegro - Imp_ApplSupTSuppliersPriceListArticles_20220315
-- LP Estela Montenegro - Imp_ApplSupTSuppliersPriceListArticles_20220330

-- LP MarPlast - Imp_ApplSupTSuppliersPriceListArticles_20220316

-- LP Wow - Imp_ApplSupTSuppliersPriceListArticles_20220401

-- LP Foko - Imp_ApplSupTSuppliersPriceListArticles_20220401

-- LOAD DATA INFILE 'C:\\ProgramData\\MySQL\\MySQL Server 8.0\\Uploads\\LP Estela Montenegro - Imp_ApplSupTSuppliersPriceListArticles_20220315.csv'
LOAD DATA INFILE 'C:\\ProgramData\\MySQL\\MySQL Server 8.0\\Uploads\\LP Foko - Imp_ApplSupTSuppliersPriceListArticles_20220401.csv'
		-- Para que funcione se debe poner doble \\ ya que es un caracter especial
INTO TABLE `ApplCore`.`ApplImpTSuppliersPriceListArticles` 
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(ArticleSupplierID, SupplierIDn, CompanyIDn, ArticleSupplierDescription, SupplierPriceListIDn, Price, DatePriceList, PriceListCode);

-- Ejecuta el Procedimiento Almacenado para depurar los datos y asegurar que esten correctos
CALL `ApplCore`.`ApplImpPSuppliersPriceListArticlesDebug`
(
	@vSqlState,
	@vErrorCode,
    @vMsgString,
    @vRowAffected,
    @traceability,						-- Activate the traceability of the stored procedure: True = 1 / False = 0
    -- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    -- Parametros para ejecutar la depuracion
	@vDateFormat				-- Es el formato de la fecha
);
	
SELECT @vSqlState,
	@vErrorCode,
    @vMsgString,
    @vRowAffected,
    @vIDNum;

-- ########################################################################################################################################################################################
-- ########################################################################################################################################################################################
-- ########################################################################################################################################################################################

-- Ejecuta el Procedimiento Almacenado para Importar los datos a las Tablas Definitivas
CALL `ApplCore`.`ApplImpPSuppliersPriceListArticlesImport`(
	@vSqlState,
	@vErrorCode,
	@vMsgString,
	@vRowAffected,
	@traceability,						-- Activate the traceability of the stored procedure: True = 1 / False = 0
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Parametros para ejecutar la importacion
	@vCreatedByIDn, 		-- vCreatedByIDn, Es el IdNum del usuario que creo el registro, Scope = 231 UserTUser, numeros variales
	@vLastModifiedByIDn, 	-- vLastModifiedByIDn, Es el IdNum del ultimo usuario que modifico el registro, Scope = 231 UserTUser, numeros variales
	@vOwnerIDn, 			-- vOwnerIDn, Es el IdNum del usuario dueño del registro, Scope = 231 UserTUser, numeros variales
	current_timestamp,		-- vDateCreated, Es la fecha de creacion del registro, es la fecha y hora actual segun el posicionamiento actual
	current_timestamp,		-- vDateTimeStamp, Es la fecha de la ultima modificacion del registro, es la fecha y hora actual segun el posicionamiento actual
									-- Cuando se crea el registro, el DateCreated y DateTimeStamp son iguales
	@vTzNameIDn,			-- vTzNameIDn, Es el IdNum de la Time Zone del la fecha
	timestampdiff(minute, utc_timestamp(), current_timestamp()),	-- vTzOffset, Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
																	-- como es en horas y minutos, aqui se registra la diferencia real en horas y minutos
	null					-- vTableHistory, Es el historico del registro
);

SELECT @vSqlState,
	@vErrorCode,
    @vMsgString,
    @vRowAffected
    ;

-- ########################################################################################################################################################################################
-- ########################################################################################################################################################################################
-- ########################################################################################################################################################################################

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
/*
            select * from `applcore`.`applsuptsupplierspricelisthistory` where DatePriceList = '2021-05-07';
			select * from `applcore`.`applsuptsupplierspricelistarticles` `sar` where DatePriceList = '2021-05-07';
            select * from `applcore`.`applimptsupplierspricelistarticles` `isa`;
*/

-- Lista las fechas que tuvieron actualizacion de precios
	SELECT CompanyIDn, SupplierIDn, DatePriceList, COUNT(*) 'Q'
	FROM applcore.applsuptsupplierspricelistarticles
	GROUP BY CompanyIDn, SupplierIDn, DatePriceList
	ORDER BY CompanyIDn, SupplierIDn, DatePriceList DESC;

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Lista las tablas donde se insertaron los datos
-- SELECT * FROM `ApplCore`.`ApplTDataElement` where ScopeIDn = 2239;		-- 2205	ApplArtTArticles
-- SELECT * FROM `ApplCore`.`ApplSupTSuppliersPriceList`;
-- SELECT * FROM Applcore.ApplSupTSuppliersPriceListArticles WHERE SupplierIDn = 1754;

-- Lista la tabla SysTSqlTimes
-- 2241	ApplSupPSuppliersPriceListCreate
-- SELECT * FROM `bpmcore`.`systsqltimes` WHERE ProcessIDn = 2241 ORDER BY ProcessIDn, ProcessNumber desc, ProcessOrder, Stage desc;

/*
	DELETE FROM `ApplCore`.`ApplTDataElement` WHERE IDNum = 50;
	DELETE FROM `bpmcore`.`systsqltimes` WHERE ProcessIDn = 2241;
*/

SELECT * FROM `ApplCore`.`ApplImpTSuppliersPriceListArticles`;
/*
SELECT * FROM Applcore.ApplSupTSuppliersPriceListArticles WHERE SupplierIDn = 1755;

SELECT * FROM Applcore.ApplSupTSuppliersPriceListArticles WHERE ArticleSupplierID = 'W15001';

AND lower(ArticleSupplierDescription) like '%nece%';
W15001	1754	2142	Mochila cordura
W15002	1754	2142	Mochila mini
W15001	1754	2142	Neceser / Portacosmetico
W15002	1754	2142	Neceser cordura masculino
*/

/*
CompanyIDn	SupplierIDn		DatePriceList		  Quantity
2142			49		2022-03-30 00:00:00			461
2142			49		2022-03-15 00:00:00			958
2142			49		2022-03-01 00:00:00			672
2142			49		2022-02-09 00:00:00			445
2142			49		2022-01-28 00:00:00			249
2142			49		2021-12-21 00:00:00			231
2142			49		2021-12-03 00:00:00			224
2142			49		2021-11-02 00:00:00			173
2142			49		2021-10-04 00:00:00			37
2142			49		2021-09-07 00:00:00			128
2142			49		2021-08-03 00:00:00			72
2142			49		2021-07-15 00:00:00			40
2142			49		2021-06-24 00:00:00			63
2142			49		2021-05-29 00:00:00			118
2142			49		2021-05-07 00:00:00			35
2142			49		2021-04-14 00:00:00			29
2142			49		2021-03-29 00:00:00			29
2142			49		2021-02-23 00:00:00			92
2142			49		2021-01-27 00:00:00			82
2142			49		2020-12-28 00:00:00			584
2142			868		2022-03-16 00:00:00			2636
2142			1754	2022-03-16 00:00:00			67
*/



/*	Corrige un registro
UPDATE `applcore`.`applsuptsupplierspricelistarticles`
SET `DatePriceList` = '2022-03-16 00:00:00',
TableHistory = "SetOff"				-- 	"SetNull", "SetOff"
WHERE `ArticleSupplierID` = 'W15002' AND `SupplierIDn` = 1754 AND `CompanyIDn` = 2142;

UPDATE `applcore`.`applimptsupplierspricelistarticles`
SET `ArticleSupplierID` = 'W02008'
WHERE `IDNum` = 47;

UPDATE `applcore`.`applimptsupplierspricelistarticles`
SET `ResultIDn` = null, `ResultDescription` = null
WHERE `IDNum` = 47;


*/