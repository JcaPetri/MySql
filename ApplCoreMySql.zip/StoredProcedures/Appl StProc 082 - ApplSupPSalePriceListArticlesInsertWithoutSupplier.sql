-- #####################################################################################################################################################
-- Appl StProc 082 - ApplSupPSalePriceListArticlesInsertWithoutSupplier.sql
-- #####################################################################################################################################################
-- Articulos SIN Proveedor/Supplier
-- #####################################################################################################################################################
-- Definicion de Parametros
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
set @vPriceListIDn = 117;			-- Es el IdNum de la Lista de Precios, esta en la tabla DataElement
set @vCompanyIDn = 2142; 			-- 2142 Peperina / 2143 Tagle / 2144 UniversalBuildCompany
set @vPrice = 1;					-- El valor del Precio es 1, ya que no tiene proveedor para tomar referencia, luego se actualizan uno por uno o por listado
set @vPriceDate = current_timestamp;							-- Es la fecha de la Lista de Precio, puede no coincidir con la fecha actual
set @vPriceListCode = 'LPM 2022 01';						-- Es el codigo de la lista de preciosset @vStateIDn = 372;				-- 372 Enable Habilitado / 373 Disable Deshabilitado
set @vCreatedByIDn = 1;				-- Usuario
set @vLastModifiedByIDn = 0;		-- Usuario
set @vOwnerIDn = 0;					-- Usuario
set	@vDateCreated = current_timestamp;						-- Es la fecha de creacion del registro, es la fecha y hora actual segun el posicionamiento actual
set @vDateTimeStamp = current_timestamp;					-- Es la fecha de la ultima modificacion del registro, es la fecha y hora actual segun el posicionamiento actual
set @vTzOffset = timestampdiff(minute, utc_timestamp(), current_timestamp());
set @vTzNameIDn = 1206;				-- America/Buenos_Aires
-- #####################################################################################################################################################
-- Articulos SIN Proveedor/Supplier
	-- Lista los Articulos que no tienen asociado un proveedor, por tal razon se deben actualizar uno por uno
    -- Primero se carga el articulo en la lista de precios con valor $1 y luego se actualiza el precio por el listado
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
/*INSERT INTO `applcore`.`applsaletpricelistarticles`
		(`ArticleIDn`,
		`PriceListIDn`,
		`CompanyIDn`,
		`Price`,
		`PriceDate`,
		`PriceListCode`,
		`StateIDn`,
		`CreatedByIDn`,
		`LastModifiedByIDn`,
		`OwnerIDn`,
		`DateCreated`,
		`DateTimeStamp`,
		`TzNameIDn`,
		`TzOffset`,
		`TableHistory`
		)*/
		SELECT `art`.`ArticleIDn`,						-- Es el IdNum del Articulo, esta en la tabla DataElement
				@vPriceListIDn `PriceListIDn`,			-- Es el IdNum de la Lista de Precios, esta en la tabla DataElement
				`art`.`CompanyIDn`,						-- Es el IdNum de la Company al que esta asignado el IDName
																-- la clave primaria: es el ArticleIDn + PriceListIDn + CompanyIDn
																-- como cada articulo puede estar en varias listas de precios, aqui es donde se asignan a ellas
				@vPrice `Price`,								-- Es el precio del articulo, es un valor autocalculado, en funcion de los parametros de actualizacion
				ifnull(@vPriceDate,current_timestamp) `PriceDate`,							-- Es la fecha de la Lista de Precio, puede no coincidir con la fecha actual
																-- ya que el proceso de actualizacion puede diferir de la fecha de la lista de precios que se actualiza
				@vPriceListCode `PriceListCode`,						-- Es el codigo de la lista de precios
				@vStateIDn `StateIDn`,							-- Es el IDNum del estado del registro, Scope = 21 tSisState, 372 Ena, 373 Dis
				@vCreatedByIDn `CreatedByIDn`,					-- Es el IdNum del usuario que creo el registro, Scope = 231 UserTUser, numeros variales
				@vLastModifiedByIDn `LastModifiedByIDn`,			-- Es el IdNum del ultimo usuario que modifico el registro, Scope = 231 UserTUser, numeros variales
				@vOwnerIDn `OwnerIDn`,							-- Es el IdNum del usuario dueño del registro, Scope = 231 UserTUser, numeros variales
				ifnull(@vDateCreated,current_timestamp) `DateCreated`,		-- Es la fecha de creacion del registro, es la fecha y hora actual segun el posicionamiento actual
				ifnull(@vDateTimeStamp,current_timestamp) `DateTimeStamp`,	-- Es la fecha de la ultima modificacion del registro, es la fecha y hora actual segun el posicionamiento actual
													-- Cuando se crea el registro, el DateCreated y DateTimeStamp son iguales
				@vTzNameIDn, 						-- Es el IdNum de la Time Zone del la fecha
				ifnull(@vTzOffset,timestampdiff(minute, utc_timestamp(), current_timestamp())) `TzOffset`, 
									-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
									-- como es en horas y minutos, aqui se registra la diferencia real en horas y minutos
				@vTableHistory `TableHistory`	-- Es el historico del registro
-- 		SELECT `art`.`CompanyIDn`, `art`.`ArticleIDn`, `de`.`IDName`, `asa`.*
		FROM `applcore`.`appllogtarticles` `art`
			LEFT OUTER JOIN `applcore`.`applsaletpricelistarticles` `spa`
				-- Se asegura que no se traten de insertar articulos que ya estan en la lista de precios
                -- si el articulo esta en la lista de precios, el procedimiento es actualizar el precio
                -- para asegurar esto en la clausula where agrega `spa`.`ArticleIDn` is null
				ON `art`.`ArticleIDn` = `spa`.`ArticleIDn`
					AND `art`.`CompanyIDn` = `spa`.`CompanyIDn`
    				AND `spa`.`StateIDn` = 372			-- Solo elige los valores habilitados
			LEFT OUTER JOIN `applcore`.`appllogtarticlessuppliersarticles` `asa`
				ON `art`.`ArticleIDn` = `asa`.`ArticleIDn`
					AND `art`.`CompanyIDn` = `asa`.`CompanyIDn`
					AND `asa`.`StateIDn` = 372			-- Solo elige los valores habilitados
                    -- No se define el proveedor, para esa empresa puede ser cualquiera, por eso en el where se define que no tenga ningun proveedor
                    -- AND `asa`.`SupplierIDn` = 49		-- Define el proveedor que sera el origen de la actualizacion de la lista de precios
			INNER JOIN `ApplCore`.`appltdataelement` `de`
				ON `art`.`ArticleIDn` = `de`.`IDNum`
		WHERE `asa`.`ArticleSupplierID` IS NULL
				AND `art`.`StateIDn` = 372			-- Solo elige los valores habilitados
				AND `spa`.`ArticleIDn` is null		-- Solo los registros que no estan en la Lp
                -- AND (`art`.`ArticleIDn` <> 197 AND `art`.`ArticleIDn` <> 198)	-- Articulos de Montenegro que no se cargan por desactualizacion de la lista de precios
				;

/*
SELECT * FROM `applcore`.`appllogtarticlessuppliersarticles` `asa`;		-- 265
SELECT * FROM `applcore`.`applsaletpricelistarticles`;					-- 288	Diferencia ya que se incorporaron los Articulos sin Proveedor/Supplier
*/
