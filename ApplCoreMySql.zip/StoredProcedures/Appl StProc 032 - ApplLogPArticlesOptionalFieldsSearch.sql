CREATE DEFINER=`root`@`localhost` PROCEDURE `ApplLogPArticlesOptionalFieldsSearchCreate`( 
	-- Parametros para mostrar los resultados del procedimiento almacenado
	OUT vSqlState char(5), 		-- SqlState, This value is a five-character string (for example, '42S02')
    OUT vErrorCode int,			-- ErrorCode, This value is numeric. It is MySQL-specific and is not portable to other database systems., este se vincula con una descripcion personalizada en la base de datos.
	OUT vMsgString text,		-- MsgString, This string provides a textual description of the error.
	OUT vRowAffected int, 		-- RowAffected, variable para obtener el numero de registros afectados.

	-- Parametros para activar la trazabilidad
    IN vSystsqltimes tinyint,			-- Activate the traceability of the stored procedure: True = 1 / False = 0
    
	-- Parametros para proveer informacion y ejecutar el procedimiento almacenado
    IN vFieldValuesIDn text,			-- Son los IdNum del valor de la propiedad del Articulo
	IN vCompanyIDn int,					-- Es el IdNum de la Company al que esta asignado el IDName
	IN vStateIDn smallint				-- Es el IdNum del estado del registro - Código (Habilitado / Deshabilitado / Eliminado / etc)
)
BEGIN
	-- DECLARE ... VARIABLES
    declare vSP_ProcessIDn int default 0;			-- IDNum del Numero de proceso almacenado, esta en la tabla BaseElement
	declare vSP_ProcessNumber int default 0;		-- Numero de Proceso, dentro de la tabla systsqltimes
    declare vSP_ProcessOrder int default 0;			-- Es el Orden en que se ejecuta el procedimiento almacenado   
	declare vSP_ParamCant int default 0;			-- Son la cantidad de parametros de busqueda que pasa el usuario
    declare vSP_ParamNum int default 0;				-- Es el Parametro actual
    declare vSP_ParamVal int default 0;				-- Es el valor del parametro actual
    
    -- DECLARE ... CONDITION Statement
	declare vSP_NumConditions int default 0;
	declare vSUCCESS condition for sqlstate '99999';			-- ErrCode: 2999 - Message: Stored Procedure Success 
    
	-- exit if Errors occurs for sqlexception
    declare exit handler for sqlexception
        begin
			rollback;								-- Deshace los cambios
            -- SET lc_messages = 'en_US';				-- Define el idioma del error	/ fr_FR
						-- Trazabilidad -
						set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) VALUES (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"ErrHandler-01-Start","Before GetDiag"); end if;
			-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
			get stacked diagnostics vSP_NumConditions = number, vRowAffected = row_count;	-- Take the condition number and the affected rows	, vRowAffected = row_count
						-- Trazabilidad - 
						set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) VALUES (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"GetDiag-ErrHandler-02",concat("vSP_NumConditions = ",convert(vSP_NumConditions,CHAR)," - vRowAffected = ",convert(vRowAffected,CHAR))); end if;
			-- Ajusta las RowAffected
            if vRowAffected = -1 then 
				SET vRowAffected = vRowAffected + 1; 
			end if;
			-- Depend of the vSP_NumConditions value, send the result
			if vSP_NumConditions > 0 then
							-- Trazabilidad - 
							set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) values (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"GetDiag-ErrHandler-03-if",concat("If NumCond > 0 Start - vSP_NumConditions = ",convert(vSP_NumConditions,char))); end if;
				-- Report the first error
				get stacked diagnostics condition vSP_NumConditions vSqlState = returned_sqlstate, vErrorCode = mysql_errno, vMsgString = message_text;		-- Take the ondition information
				-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
				-- Resultado Erróneo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
				-- Todas estas variables se envian dentro del mensaje vMsgString, concatenandolas.	-- , cast(251 AS CHAR), '†'
				-- SQLState five-character string
				set vMsgString = concat(vSqlState, '†', vMsgString);
				-- vRowAffected no depende del vSP_NumConditions, se carga antes del if
							-- Trazabilidad -
							set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) VALUES (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"GetDiag-ErrHandler-04-if","If NumCond > 0 End"); end if;
			else
				-- Carga la informacion general (de o no error se carga lo mismo)
				set vSqlState = 'HY000';				-- informa el resultado: 'HY000' (general error) is used for client-side errors and if server-side errors hasen't MySQL error numbers
				set vErrorCode = 2000;					-- informa el numero de resultado, este se vincula con una descripcion personalizada en la base de datos.
														-- 2,000 to 2,999: Client error codes reserved for use by the client library.
				-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
				-- Resultado Erróneo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
				-- Todas estas variables se envian dentro del mensaje vMsgString, concatenandolas.	-- , cast(251 AS CHAR), '†'
				-- SQLState five-character string, for Client Error use always 'HY000'
				set vMsgString = concat('HY000', '†', 'Unknown MySQL error');
				-- vRowAffected no depende del vSP_NumConditions, se carga antes del if
							-- Trazabilidad -
							set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) VALUES (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"GetDiag-ErrHandler-05-else","If NumCond > 0 Else"); end if;
			END IF;
		END;

	-- Stored Procedures goes success
	declare continue handler for vSUCCESS
		begin
			get stacked diagnostics vSP_NumConditions = number;	-- Take the condition number and the affected rows
			-- Carga la informacion general (de o no error se carga lo mismo)
			set vSqlState = 'HY000';			-- informa el resultado: 'HY000' (general error) is used for client-side errors and if server-side errors hasen't MySQL error numbers
			set vErrorCode = 2999;				-- informa el numero de resultado, (2999: Success Result) este se vincula con una descripcion personalizada en la base de datos.
			-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
			-- Resultado Success, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
			-- Todas estas variables se envian dentro del mensaje vMsgString, concatenandolas.	-- , cast(251 AS CHAR), '†'
			-- SQLState five-character string, for Client Error use always 'HY000'
			set vMsgString = concat('00', '†', 'Stored Procedure Success');
			-- vRowAffected Info viene de la sentencia SQL
						-- Trazabilidad -
						set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) values (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"GetDiag-01-SuccessHandler",concat("Signal Success - vSP_NumConditions: ", vSP_NumConditions," - vRowAffected: ",vRowAffected)); end if;
        end;
        -- Cuando termina este procedimiento continua con el la sentencia del commit y finaliza el Stored Procedure
	-- ############################################################################################################################################################################################################################################################################################
    -- Inicio - Procedimiento Almacenado
    -- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Setea las variables OUT
	set vSqlState = '';			-- SqlState, This value is a five-character string (for example, '42S02')
	set vErrorCode = 0;			-- ErrorCode, This value is numeric. It is MySQL-specific and is not portable to other database systems., este se vincula con una descripcion personalizada en la base de datos.
	set vMsgString = '';		-- MsgString, This string provides a textual description of the error.
	set vRowAffected = 0;		-- RowAffected, variable para obtener el numero de registros afectados.
    
	-- Trazabilidad - 
				-- Define el ProcessNumber que es igual para todo el procedimiento, esta en la tabla systsqltimes, al ultimo proceso le agrega uno
                -- SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 6 order by IDCode;
					-- IDNum	IDName StoProcedure			 				ScopeIDn		IDCode
					-- 2234		ApplLogPArticlesOptionalFieldsSearch			6			  405
				set vSP_ProcessIDn = 2234; select ifnull(max(ProcessNumber),0) + 1 into vSP_ProcessNumber from `bpmcore`.`systsqltimes` where ProcessIDn = vSP_ProcessIDn;
				-- Trazabilidad -
				set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) VALUES (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"StoProcedure-01-Start",concat("Clave Unica recibida; vCompanyIDn ",convert(vCompanyIDn,CHAR))); end if;

    -- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Selecciona los registros
		DROP TEMPORARY TABLE IF EXISTS `TmpArticles`;
        DROP TEMPORARY TABLE IF EXISTS `TmpArticlesFilter`;
        CREATE TEMPORARY TABLE TmpArticles (TmpArticleIDn INT PRIMARY KEY);
        CREATE TEMPORARY TABLE TmpArticlesFilter (TmpArticleIDn INT PRIMARY KEY);
		SET vSP_ParamCant = LENGTH(@vFieldValuesIDn) - LENGTH(REPLACE(@vFieldValuesIDn, '|', '')) + 1;
        SET vSP_ParamNum = 1;
			-- SELECT SPLIT_STRING(@vFieldValuesIDn,'|',vSP_Param), vSP_CantParam;
            -- SELECT vSP_ParamNum, vSP_ParamCant;
				WHILE vSP_ParamNum <= vSP_ParamCant DO
					SET vSP_ParamVal = SPLIT_STRING(@vFieldValuesIDn,'|',vSP_ParamNum);
					IF vSP_ParamNum = 1 THEN
                    -- SELECT vSP_ParamVal, vSP_ParamNum, vSP_ParamCant;
						INSERT INTO TmpArticles (TmpArticleIDn)
						SELECT distinct `ArticleIDn`
							FROM `applcore`.`appllogtarticlesoptionalfields`
							WHERE `StateIDn` = vStateIDn 
									AND `CompanyIDn` = vCompanyIDn
									AND `FieldValueIDn` = vSP_ParamVal;
					ELSE
                        INSERT INTO TmpArticlesFilter (TmpArticleIDn) SELECT TmpArticleIDn FROM TmpArticles;
						-- SELECT * FROM TmpArticlesFilter;
                        DELETE FROM TmpArticles;		-- Elimina todos los registros antes de cargar el nuevo filtro
                        INSERT INTO TmpArticles (TmpArticleIDn)
						SELECT distinct `ArticleIDn`
							FROM `applcore`.`appllogtarticlesoptionalfields` 
								INNER JOIN TmpArticlesFilter ON ArticleIDn = TmpArticleIDn
							WHERE `StateIDn` = vStateIDn 
									AND `CompanyIDn` = vCompanyIDn
									AND `FieldValueIDn` = vSP_ParamVal;
						DELETE FROM TmpArticlesFilter;	-- Elimina todos los registros antes de cargar el nuevo filtro
					END IF;
					SET vSP_ParamNum = vSP_ParamNum + 1;
				END WHILE;
			SELECT * FROM TmpArticles;
   			set vRowAffected = row_count();
						-- Trazabilidad -
						set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) values (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"StoProcedure-02-End",concat("Se cargaron los datos ",convert(vCompanyIDn,char)," row count: ",vRowAffected)); end if;
            DROP TEMPORARY TABLE TmpArticles;
            DROP TEMPORARY TABLE TmpArticlesFilter;
            -- Informa el exito de la operacion
			signal vSUCCESS;
		commit;		-- commit changes 
    -- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    -- Fin - Procedimiento Almacenado
	-- ############################################################################################################################################################################################################################################################################################

end