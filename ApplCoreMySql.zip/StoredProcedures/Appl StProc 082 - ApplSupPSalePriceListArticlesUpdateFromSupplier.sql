-- #####################################################################################################################################################
-- Appl StProc 082 - ApplSupPSalePriceListArticlesUpdateFromSupplier.sql
-- #####################################################################################################################################################
-- #####################################################################################################################################################
-- Articulos CON Proveedor/Supplier
-- #####################################################################################################################################################
-- Definicion de Parametros
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
set @vLastModifiedByIDn = 1;		-- Usuario que actualizo el registro
set @vDateTimeStamp = current_timestamp;					-- Es la fecha de la ultima modificacion del registro, es la fecha y hora actual segun el posicionamiento actual
set @vTzOffset = timestampdiff(minute, utc_timestamp(), current_timestamp());
set @vTzNameIDn = 1206;				-- America/Buenos_Aires

-- #####################################################################################################################################################
-- Articulos que tienen asignado un Proveedor/Supplier
	-- Actualiza los Precios de la Lista de Precios
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
UPDATE `applcore`.`applsaletpricelistarticles` `spla`
		INNER JOIN `applcore`.`appllogtarticlessuppliersarticles` `asa`
			ON `spla`.`ArticleIDn` = `asa`.`ArticleIDn`
				AND  `spla`.`CompanyIDn` = `asa`.`CompanyIDn`
		INNER JOIN `applcore`.`applsuptsupplierspricelistarticles` `spl`
			ON `asa`.`ArticleSupplierID` = `spl`.`ArticleSupplierID`
				AND `asa`.`SupplierIDn` = `spl`.`SupplierIDn`
				AND `asa`.`CompanyIDn` = `spl`.`CompanyIDn`
		INNER JOIN `applcore`.`appltdataelement` `de`
			ON `de`.`IDNum` = `spla`.`ArticleIDn`
SET `spla`.`Price` = FncRoundInt(IF(INSTR(lower(`de`.`IDName`), 'resma') > 0,`spl`.`Price` * 1.6,`spl`.`Price` * 2)),
		`spla`.`PriceDate` = `spl`.`DatePriceList`,
		`spla`.`PriceListCode` = `spl`.`PriceListCode`,
		`spla`.`StateIDn` = `spl`.`StateIDn`,
		`spla`.`LastModifiedByIDn` = @vLastModifiedByIDn,
		`spla`.`DateTimeStamp` = @vDateTimeStamp,
		`spla`.`TzNameIDn` = @vTzNameIDn,
		`spla`.`TzOffset` = @vTzOffset
        ,`spla`.`TableHistory` = "SetOff"				-- 	"SetNull", "SetOff"
;

/*
UPDATE `applcore`.`applsaletpricelistarticles` `spla`
SET `spla`.`TableHistory` = null;
*/

-- #####################################################################################################################################################
-- Muestra el resultado, de lo que seria el From con sus vinculso
/*
SELECT `spla`.`CompanyIDn`, `spla`.`ArticleIDn`, `de`.`IDName`, `spla`.`Price`, `spla`.`PriceDate`, `spla`.`PriceListCode`, `spl`.`ArticleSupplierID`
	, DATEDIFF(NOW(), `spla`.`PriceDate`) `AntPrice`
-- , `spla`.`TableHistory`
FROM `applcore`.`applsaletpricelistarticles` `spla`
	INNER JOIN `applcore`.`appllogtarticlessuppliersarticles` `asa`
		ON `spla`.`ArticleIDn` = `asa`.`ArticleIDn`
			AND  `spla`.`CompanyIDn` = `asa`.`CompanyIDn`
	INNER JOIN `applcore`.`applsuptsupplierspricelistarticles` `spl`
		ON `asa`.`ArticleSupplierID` = `spl`.`ArticleSupplierID`
			AND `asa`.`SupplierIDn` = `spl`.`SupplierIDn`
            AND `asa`.`CompanyIDn` = `spl`.`CompanyIDn`
	INNER JOIN `applcore`.`appltdataelement` `de`
		ON `de`.`IDNum` = `spla`.`ArticleIDn`
WHERE `spla`.`ArticleIDn` = 570;
*/

-- #####################################################################################################################################################
-- Consultas de Control
/*
-- Consultas de control
	SELECT * FROM applcore.appllogvarticles WHERE LOWER(Article) LIKE '%pizzi%' ;
	SELECT * FROM applcore.appllogvarticlesoptionalfields WHERE LOWER(Article) LIKE '%pizzi%' ORDER BY ArticleIDn;

*/

-- #####################################################################################################################################################
SELECT * FROM `applcore`.`appllogtarticles` `art`;
SELECT * FROM `applcore`.`applsuptsupplierspricelistarticles` `spl`;
SELECT * FROM `applcore`.`appllogtarticlessuppliersarticles` `asa`;		-- 265
SELECT * FROM `applcore`.`applsaletpricelistarticles`;					-- 288	Diferencia ya que se incorporaron los Articulos sin Proveedor/Supplier

