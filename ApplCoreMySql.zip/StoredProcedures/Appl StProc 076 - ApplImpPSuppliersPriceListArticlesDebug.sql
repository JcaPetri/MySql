USE `ApplCore`;
DROP procedure IF EXISTS `ApplImpPSuppliersPriceListArticlesDebug`;

DELIMITER $$
USE `ApplCore`$$
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Appl StProc 076 - ApplImpPSuppliersPriceListArticlesDebug.sql
-- IDNum	IDName/Table								ScopeIDn	IDCode
-- 2243		ApplImpPSuppliersPriceListArticlesDebug		6		  462
-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

CREATE DEFINER=`root`@`localhost` PROCEDURE `ApplImpPSuppliersPriceListArticlesDebug`( 
	-- Parametros para mostrar los resultados del procedimiento almacenado
	OUT vSqlState char(5), 		-- SqlState, This value is a five-character string (for example, '42S02')
    OUT vErrorCode int,			-- ErrorCode, This value is numeric. It is MySQL-specific and is not portable to other database systems., este se vincula con una descripcion personalizada en la base de datos.
	OUT vMsgString TEXT,		-- MsgString, This string provides a textual description of the error.
	OUT vRowAffected int, 		-- RowAffected, variable para obtener el numero de registros afectados.

	-- Parametros para activar la trazabilidad
    IN vSystsqltimes tinyint,			-- Activate the traceability of the stored procedure: True = 1 / False = 0
    
	-- Parametros para proveer informacion y ejecutar el procedimiento almacenado
    IN vDateFormat varchar(10)			-- Es el formato de la fecha
)
BEGIN
	-- DECLARE ... VARIABLES
    declare vSP_ProcessIDn int default 0;			-- IDNum del Numero de proceso almacenado, esta en la tabla BaseElement
	declare vSP_ProcessNumber int default 0;		-- Numero de Proceso, dentro de la tabla systsqltimes
    declare vSP_ProcessOrder int default 0;			-- Es el Orden en que se ejecuta el procedimiento almacenado   
    
	-- DECLARE ... CONDITION Statement
	declare vSP_NumConditions int default 0;
	declare vSUCCESS condition for sqlstate '99999';			-- ErrCode: 2999 - Message: Stored Procedure Success 
    
	-- exit if Errors occurs for sqlexception
    declare exit handler for sqlexception
        begin
			rollback;								-- Deshace los cambios
            -- SET lc_messages = 'en_US';				-- Define el idioma del error	/ fr_FR
						-- Trazabilidad -
						set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) VALUES (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"ErrHandler-01-Start","Before GetDiag"); end if;
			-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
			get stacked diagnostics vSP_NumConditions = number, vRowAffected = row_count;	-- Take the condition number and the affected rows	, vRowAffected = row_count
						-- Trazabilidad - 
						set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) VALUES (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"GetDiag-ErrHandler-02",concat("vSP_NumConditions = ",convert(vSP_NumConditions,CHAR)," - vRowAffected = ",convert(vRowAffected,CHAR))); end if;
			-- Ajusta las RowAffected
            if vRowAffected = -1 then 
				SET vRowAffected = vRowAffected + 1; 
			end if;
			-- Depend of the vSP_NumConditions value, send the result
			if vSP_NumConditions > 0 then
							-- Trazabilidad - 
							set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) values (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"GetDiag-ErrHandler-03-if",concat("If NumCond > 0 Start - vSP_NumConditions = ",convert(vSP_NumConditions,char))); end if;
				-- Report the first error
				get stacked diagnostics condition vSP_NumConditions vSqlState = returned_sqlstate, vErrorCode = mysql_errno, vMsgString = message_text;		-- Take the ondition information
				-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
				-- Resultado Erróneo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
				-- Todas estas variables se envian dentro del mensaje vMsgString, concatenandolas.	-- , cast(251 AS CHAR), '†'
				-- SQLState five-character string
				set vMsgString = concat(vSqlState, '†', vMsgString);
				-- vRowAffected no depende del vSP_NumConditions, se carga antes del if
							-- Trazabilidad -
							set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) VALUES (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"GetDiag-ErrHandler-04-if","If NumCond > 0 End"); end if;
			else
				-- Carga la informacion general (de o no error se carga lo mismo)
				set vSqlState = 'HY000';				-- informa el resultado: 'HY000' (general error) is used for client-side errors and if server-side errors hasen't MySQL error numbers
				set vErrorCode = 2000;					-- informa el numero de resultado, este se vincula con una descripcion personalizada en la base de datos.
														-- 2,000 to 2,999: Client error codes reserved for use by the client library.
				-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
				-- Resultado Erróneo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
				-- Todas estas variables se envian dentro del mensaje vMsgString, concatenandolas.	-- , cast(251 AS CHAR), '†'
				-- SQLState five-character string, for Client Error use always 'HY000'
				set vMsgString = concat('HY000', '†', 'Unknown MySQL error');
				-- vRowAffected no depende del vSP_NumConditions, se carga antes del if
							-- Trazabilidad -
							set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) VALUES (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"GetDiag-ErrHandler-05-else","If NumCond > 0 Else"); end if;
			END IF;
		END;

	-- Stored Procedures goes success
	declare continue handler for vSUCCESS
		begin
			get stacked diagnostics vSP_NumConditions = number;	-- Take the condition number and the affected rows
			-- Carga la informacion general (de o no error se carga lo mismo)
			set vSqlState = 'HY000';			-- informa el resultado: 'HY000' (general error) is used for client-side errors and if server-side errors hasen't MySQL error numbers
			set vErrorCode = 2999;				-- informa el numero de resultado, (2999: Success Result) este se vincula con una descripcion personalizada en la base de datos.
			-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
			-- Resultado Success, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
			-- Todas estas variables se envian dentro del mensaje vMsgString, concatenandolas.	-- , cast(251 AS CHAR), '†'
			-- SQLState five-character string, for Client Error use always 'HY000'
			set vMsgString = concat('00', '†', 'Stored Procedure Success');
			-- vRowAffected Info viene de la sentencia SQL
						-- Trazabilidad -
						set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) values (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"GetDiag-01-SuccessHandler",concat("Signal Success - vSP_NumConditions: ", vSP_NumConditions," - vRowAffected: ",vRowAffected)); end if;
        end;
        -- Cuando termina este procedimiento continua con el la sentencia del commit y finaliza el Stored Procedure
	-- ############################################################################################################################################################################################################################################################################################
    -- Inicio - Procedimiento Almacenado
    -- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Setea las variables OUT
	set vSqlState = '';			-- SqlState, This value is a five-character string (for example, '42S02')
	set vErrorCode = 0;			-- ErrorCode, This value is numeric. It is MySQL-specific and is not portable to other database systems., este se vincula con una descripcion personalizada en la base de datos.
	set vMsgString = '';		-- MsgString, This string provides a textual description of the error.
	set vRowAffected = 0;		-- RowAffected, variable para obtener el numero de registros afectados.
    
	-- Trazabilidad - 
				-- Define el ProcessNumber que es igual para todo el procedimiento, esta en la tabla systsqltimes, al ultimo proceso le agrega uno
                -- SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 6 order by IDCode;
					-- IDNum	IDName StoProcedure			 				ScopeIDn		IDCode
					-- 2243		ApplImpPSuppliersPriceListArticlesDebug		6		 	 462
				set vSP_ProcessIDn = 2243; select ifnull(max(ProcessNumber),0) + 1 into vSP_ProcessNumber from `bpmcore`.`systsqltimes` where ProcessIDn = vSP_ProcessIDn;
				-- Trazabilidad -
				set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) VALUES (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"StoProcedure-01-Start",concat("Clave Unica recibida; vCompanyIDn ",convert(vCompanyIDn,CHAR))); end if;

    -- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Inserta el nuevo registro
		start transaction;		-- start a new transaction
		-- #################################################################################################################################################################################################
		-- DEPURACION DE DATOS
		-- 		ACLARACION:
		-- 					Luego de cada depuracion si el registro no es apto para su utilizacion se pone el ResultIDn y ResultDescription
		-- 					de esta manera no se utiliza y se evitan errores, tambien se lo informan al Cliente que no se actualizo
		-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		-- Elimina los espacios en blanco
		-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		UPDATE `ApplCore`.`ApplImpTSuppliersPriceListArticles` 
		SET
			`ArticleSupplierID` = TRIM(ArticleSupplierID),
			`SupplierIDn` = TRIM(SupplierIDn),
			`CompanyIDn` = TRIM(CompanyIDn),
			`ArticleSupplierDescription` = TRIM(ArticleSupplierDescription),
			`SupplierPriceListIDn` = TRIM(SupplierPriceListIDn),
			`Price` = TRIM(Price),
			`DatePriceList` = TRIM(DatePriceList),
			`PriceListCode` = TRIM(PriceListCode),
            `Barcode` = TRIM(Barcode)
			;

		-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		-- Verifica que las columnas tengan el tipo de dato correcto
		-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		UPDATE `ApplCore`.`applimptsupplierspricelistarticles`
		SET `ResultIDn` = 1,
			`ResultDescription` = 'The value of SupplierIDn, or CompanyIDn or SupplierPriceListIDn are not Int'
		WHERE FncIsInt(`SupplierIDn`) = 0 
				OR FncIsInt(`CompanyIDn`) = 0
				OR FncIsInt(`SupplierPriceListIDn`) = 0;

		-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		-- Verifica que la Company este dado de alta en la tabla SuppliersPriceList 
		-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		UPDATE `ApplCore`.`applimptsupplierspricelistarticles` `ISpl`
				left outer join `ApplCore`.`ApplSupTSuppliersPriceList` `Spl` 
					on `ISpl`.`CompanyIDn`= `Spl`.`CompanyIDn`
		SET `ResultIDn` = 1,
			`ResultDescription` = 'The value of CompanyIDn doesn`t exist'
		WHERE `Spl`.`CompanyIDn` is null;

		-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		-- Verifica que el Supplier para esa Company este dado de alta en la tabla SuppliersPriceList
		-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		UPDATE `ApplCore`.`applimptsupplierspricelistarticles` `ISpl`
				left outer join `ApplCore`.`ApplSupTSuppliersPriceList` `Spl` 
					on `ISpl`.`SupplierIDn`= `Spl`.`SupplierIDn`
						and `ISpl`.`CompanyIDn`= `Spl`.`CompanyIDn`
		SET `ResultIDn` = 1,
			`ResultDescription` = 'The value of SupplierIDn doesn`t exist'
		WHERE `Spl`.`SupplierIDn` is null;

		-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		-- Verifica que la Lista de Precios para ese Supplier y esa Company este dado de alta
		-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		UPDATE `ApplCore`.`applimptsupplierspricelistarticles` `ISpl`
				left outer join `ApplCore`.`ApplSupTSuppliersPriceList` `Spl` 
					on `ISpl`.`SupplierPriceListIDn`= `Spl`.`SupplierPriceListIDn`
						and`ISpl`.`SupplierIDn`= `Spl`.`SupplierIDn`
						and `ISpl`.`CompanyIDn`= `Spl`.`CompanyIDn`
		SET `ResultIDn` = 1,
			`ResultDescription` = 'The value of SupplierPriceListIDn doesn`t exist'
		WHERE `Spl`.`SupplierPriceListIDn` is null;

		-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		-- Actualiza informacion que viene erronea del Supplier/Proveedor y que nunca lo resuelve
		-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		-- Esto se asocia a la tabla ApplImpTSuppliersPriceListArticlesFix, y se vincula con la clave primaria es el ArticleSupplierID + SupplierIDn + CompanyIDn
		-- Ej, 302044, este articulo en la descripcion contiene el ID 302044CANOPLA INTERVEN TUBO FANTASIA 1201
		UPDATE `applcore`.`applimptsupplierspricelistarticles` `Spl`
			INNER JOIN `applcore`.`applimptsupplierspricelistarticlesfix` `SplF`
				ON `Spl`.`ArticleSupplierID` = `SplF`.`ArticleSupplierID`
					AND `Spl`.`SupplierIDn` = `SplF`.`SupplierIDn`
					AND `Spl`.`CompanyIDn` = `SplF`.`CompanyIDn`
		SET `Spl`.`ArticleSupplierDescription` = `SplF`.`ArticleSupplierDescription`
			, `Spl`.`ResultIDn` = 0
			, `Spl`.`ResultDescription` = 'Fix the ArticleSupplierDescription';

		-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		-- Verifica que el Precio sea un numero
		-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		-- Actualiza el campo Price ajustando al formato MySql
		UPDATE `ApplCore`.`applimptsupplierspricelistarticles`
		SET `Price` = FncConvDecimal(`Price`);

		-- Establece los registros en 1 que no son decimales transformables
		UPDATE `ApplCore`.`applimptsupplierspricelistarticles`
		SET `ResultIDn` = 1,
			`ResultDescription` = 'The value of Price are not number'
		WHERE FncIsDecimal(`Price`) = 0;

		-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		-- Verifica que la Fecha tenga formato correcto
		-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		-- Actualiza el campo DateLastUpdate ajustando la fecha al formato MySql
		UPDATE `ApplCore`.`applimptsupplierspricelistarticles`
		SET `DatePriceList` = FncConvDate(DatePriceList, vDateFormat);

		-- Establece los registros en 1 que no son fecha transformable
		UPDATE `ApplCore`.`applimptsupplierspricelistarticles`
		SET `ResultIDn` = 1,
			`ResultDescription` = 'The value of DatePriceList are not valid Date'
		WHERE FncIsDate(`DatePriceList`) = 0;

		-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		-- Verifica que no haya duplicados y que infrinjan la clave ID
		-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		UPDATE `ApplCore`.`applimptsupplierspricelistarticles` `isa`
			INNER JOIN (
						SELECT `ArticleSupplierID`,
								`SupplierIDn`,
								`CompanyIDn`,
								COUNT(*) 'Q'
						FROM `applcore`.`applimptsupplierspricelistarticles`
						GROUP BY `ArticleSupplierID`,
								`SupplierIDn`,
								`CompanyIDn`
						HAVING COUNT(*) > 1
						) `isad`
							on `isa`.`ArticleSupplierID` = `isad`.`ArticleSupplierID`
								and `isa`.`SupplierIDn` = `isad`.`SupplierIDn`
								and `isa`.`CompanyIDn` = `isad`.`CompanyIDn`
		SET `ResultIDn` = 1,
			`ResultDescription` = 'The record is duplicated'
		;


			set vRowAffected = row_count();
						-- Trazabilidad -
						set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) values (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"StoProcedure-02-End",concat("Se cargaron los datos ",convert(vCompanyIDn,char)," row count: ",vRowAffected)); end if;
            -- Informa el exito de la operacion
			signal vSUCCESS;

		commit;		-- commit changes 
    -- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    -- Fin - Procedimiento Almacenado
	-- ############################################################################################################################################################################################################################################################################################

end$$

DELIMITER ;