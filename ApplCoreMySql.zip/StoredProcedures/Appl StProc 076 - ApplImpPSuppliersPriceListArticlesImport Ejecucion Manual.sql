USE `ApplCore`;
-- ##########################################################################################################################################################################################
-- Appl StProc 076 - ApplImpPSuppliersPriceListArticlesImport Ejecucion Manual.sql
-- ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Se trabaja sobre la Tabla `applcore`.`ApplSupTSuppliersPriceListArticles` para dejar la lista de precios de los Supplier/Proveedores actualizada

/*
-- #################################################################################################################################################################################################
-- #################################################################################################################################################################################################
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Import Data
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	DELETE FROM `ApplCore`.`ApplImpTSuppliersPriceListArticles`;
	-- Al Inicio Pone a Cero el contador de la Tabla
	ALTER TABLE `applcore`.`applimptsupplierspricelistarticles` AUTO_INCREMENT = 0;

	-- Importar los Datos Manualmente
    
	-- Importar la lista de precios del Excel manualmente en la tabla ApplImpTSuppliersPriceListArticles
	SELECT * FROM  `ApplCore`.`ApplImpTSuppliersPriceListArticles`;

	SELECT CompanyIDn, SupplierIDn, ArticleSupplierID, ArticleSupplierDescription, count(*) Q 
    FROM `ApplCore`.`ApplImpTSuppliersPriceListArticles`
--     WHERE SupplierIDn = 869
    GROUP BY CompanyIDn, SupplierIDn, ArticleSupplierID, ArticleSupplierDescription
    HAVING count(*) > 1
    ORDER BY count(*) DESC;

	select * 
    FROM applcore.applsuptsupplierspricelistarticles 
    WHERE SupplierIDn = 869;

*/

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Parametros para la tabla `ApplCore`.`ApplImpPSuppliersPriceListArticlesImport`
	set @vDateFormat = 'dd/mm/yyyy';			-- Formato de la Fecha
	set @vDateCreated = current_timestamp;		-- Es la fecha de creacion del registro
	set @vDateTimeStamp = current_timestamp;	-- Es la fecha de la ultima modificacion del registro
	set @vCreatedByIDn = 1;						-- Usuario
	set @vLastModifiedByIDn = 1;				-- Usuario
	set @vOwnerIDn = 1;							-- Usuario
	set @vTzOffset = timestampdiff(minute, utc_timestamp(), current_timestamp());	
				-- vTzOffset, Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
				-- como es en horas y minutos, aqui se registra la diferencia real en horas y minutos
	set @vTzNameIDn = 1206;				-- America/Buenos_Aires
	set @vTableHistory =  null;			-- Es el historico del registro

	CALL `ApplCore`.`ApplImpPSuppliersPriceListArticlesDebug`
	(
		@vSqlState,
		@vErrorCode,
		@vMsgString,
		@vRowAffected,
		@traceability,						-- Activate the traceability of the stored procedure: True = 1 / False = 0
		-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		-- Parametros para ejecutar la depuracion
		@vDateFormat				-- Es el formato de la fecha
	);
		
	SELECT @vSqlState,
		@vErrorCode,
		@vMsgString,
		@vRowAffected,
		@vIDNum;

	-- Resultado
 	-- SELECT * FROM  `ApplCore`.`ApplImpTSuppliersPriceListArticles` WHERE ResultIDn <> null;

-- #################################################################################################################################################################################################
-- #################################################################################################################################################################################################
	-- Importa los Datos a Tabla applsuptsupplierspricelistarticles
	-- Para ello sigue los siguientes pasos:
	-- 		1.- Desactiva los articulos que no estan mas en la base importada, estan en la tabla applsup y no en la tabla applimp
	-- 		2.- Actualiza articulos que ya estan incorporado, ya que estan en las dos tablas
	-- 		3.- Inserta articulos nuevos, estan en la tabla applimp y no en la tabla applsup
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

	-- #################################################################################################################################################################################################
	-- 0.- Toma el Supplier/Proveedor que al que se le van a actualizar los precios
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- #################################################################################################################################################################################################
	-- 1.- Desactiva los articulos que no estan mas en la base importada, estan en la tabla applsup y no en la tabla applimp
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- 	1.1- Desactiva los articulos que no estan mas en la base importada, estan en la tabla applsup y no en la tabla applimp
		-- 		de la tabla `ApplCore`.`ApplSupTSuppliersPriceListArticles`
		UPDATE `applcore`.`ApplSupTSuppliersPriceListArticles` `sar`
			LEFT JOIN (SELECT `CompanyIDn`, `SupplierIDn`, `ArticleSupplierID`
							FROM `applcore`.`applimptsupplierspricelistarticles`
							WHERE `ResultIDn` = 0 OR `ResultIDn` is null		-- Solo toma los registros actualizables
						   ) `isa`
								ON `sar`.`ArticleSupplierID` = `isa`.`ArticleSupplierID`
									AND `sar`.`SupplierIDn` = `isa`.`SupplierIDn`
									AND `sar`.`CompanyIDn` = `isa`.`CompanyIDn`
		SET
				`sar`.`StateIDn` = 373,									-- 372 Enable Habilitado / 373 Disable Deshabilitado
				-- 	`sar`.`CreatedByIDn` = vCreatedByIDn,				-- Usuario
				`sar`.`LastModifiedByIDn` = @vLastModifiedByIDn,			-- Usuario
				-- `sar`.`OwnerIDn` = vOwnerIDn,						-- Usuario
				-- `sar`.`DateCreated` = vDateCreated,					-- Es la fecha de la creacion del regisgtro
				`sar`.`DateTimeStamp` = @vDateTimeStamp,					-- Es la fecha que se ejecuta el procedimiento
				`sar`.`TzNameIDn` = @vTzNameIDn,							-- America/Buenos_Aires
				`sar`.`TzOffset` = timestampdiff(minute, utc_timestamp(), current_timestamp())
		WHERE `sar`.`SupplierIDn` = @vSupplierIDn  AND `isa`.`ArticleSupplierID` is null;		-- Solo toma los registros actualizables


/*		 -- Muestra los datos 
					SELECT `sar`.*
                    FROM `applcore`.`applsuptsupplierspricelistarticles` `sar`
							LEFT JOIN (SELECT `CompanyIDn`, `SupplierIDn`, `ArticleSupplierID`
										FROM `applcore`.`applimptsupplierspricelistarticles`
										WHERE `ResultIDn` = 0 OR `ResultIDn` is null		-- Solo toma los registros actualizables
									   ) `isa`
											ON `sar`.`ArticleSupplierID` = `isa`.`ArticleSupplierID`
												AND `sar`.`SupplierIDn` = `isa`.`SupplierIDn`
												AND `sar`.`CompanyIDn` = `isa`.`CompanyIDn`
				WHERE `sar`.`SupplierIDn` = @vSupplierIDn  AND `isa`.`ArticleSupplierID` is null;		-- Solo toma los registros actualizables
				
			-- ACLARACION:
				-- Como la tabla applsuptsupplierspricelistarticles tiene la lista de varios Proveedores, se debe filtrar por proveedor `sar`.`SupplierIDn` = @vSupplierIDn
                -- ya que sino cuando se actualiza la lista de otro proveedor, con el left join se anulan todos los otros proveedores
				-- No se eliminan de la tabla applimptsupplierspricelistarticles ya que no estan, el proveedor no los trabaja mas

		-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		-- 1.2- Desactiva los articulos que no estan mas en la base importada, estan en la tabla applsup y no en la tabla applimp
		-- 		de la tabla `ApplCore`.`ApplSupTSuppliersPriceListHistory`
		UPDATE `applcore`.`applsuptsupplierspricelisthistory` `sph`
			LEFT JOIN (SELECT `CompanyIDn`, `SupplierIDn`, `ArticleSupplierID`
							FROM `applcore`.`applimptsupplierspricelistarticles`
							WHERE `ResultIDn` = 0 OR `ResultIDn` is null		-- Solo toma los registros actualizables
						   ) `isa`
								ON `sph`.`ArticleSupplierID` = `isa`.`ArticleSupplierID`
 									AND `sph`.`SupplierIDn` = `isa`.`SupplierIDn`
 									AND `sph`.`CompanyIDn` = `isa`.`CompanyIDn`
		SET `StateIDn` = 373									-- 372 Enable Habilitado / 373 Disable Deshabilitado
		WHERE `isa`.`ArticleSupplierID` is null;		-- Solo toma los registros actualizables
        /* -- Muestra los datos 
				SELECT `sph`.ArticleSupplierID, `isa`.`IDNum` FROM `applcore`.`ApplSupTSuppliersPriceListHistory` `sph`
							LEFT JOIN (SELECT `CompanyIDn`, `SupplierIDn`, `ArticleSupplierID`
										FROM `applcore`.`applimptsupplierspricelistarticles`
										WHERE `ResultIDn` = 0 OR `ResultIDn` is null		-- Solo toma los registros actualizables
									   ) `isa`
											ON `sph`.`ArticleSupplierID` = `isa`.`ArticleSupplierID`
												AND `sph`.`SupplierIDn` = `isa`.`SupplierIDn`
												AND `sph`.`CompanyIDn` = `isa`.`CompanyIDn`
				WHERE `isa`.`ArticleSupplierID` is null;
				*/
			-- No se eliminan de la tabla applimptsupplierspricelistarticles ya que no estan, el proveedor no los trabaja mas
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

	-- #################################################################################################################################################################################################
	-- 2.- Actualiza articulos que ya estan incorporado, ya que estan en las dos tablas
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- 2.1- Inserta en la tabla los Articulos que tuvieron cambio de precios, ya que estan en las dos tablas
	-- Primero se ejecuta esta consulta para que impacte en el Historico, ya que la base de la consulta es la diferencia entre los datos importados y los de la base
	INSERT INTO `applcore`.`applsuptsupplierspricelisthistory`
			(`ArticleSupplierID`,
			`SupplierIDn`,
			`CompanyIDn`,
			`DatePriceList`,
			`Price`,
			`DatePriceListBefore`,
			`PriceBefore`,
			`StateIDn`
			)
				SELECT `isa`.`ArticleSupplierID`,
						`isa`.`SupplierIDn`,
						`isa`.`CompanyIDn`,
						`isa`.`DatePriceList`,
						`isa`.`Price`,
						`sar`.`DatePriceList`,
						`sar`.`Price`,
						 372 `StateIDn`						-- 372 Enable Habilitado / 373 Disable Deshabilitado
					FROM `applcore`.`applimptsupplierspricelistarticles` `isa`
						INNER JOIN `applcore`.`applsuptsupplierspricelistarticles` `sar`
							ON `isa`.`ArticleSupplierID` = `sar`.`ArticleSupplierID`
								and `isa`.`SupplierIDn` = `sar`.`SupplierIDn`
								and `isa`.`CompanyIDn` = `sar`.`CompanyIDn`
				WHERE (`isa`.`ResultIDn` = 0 OR `isa`.`ResultIDn` is null)
					AND (`isa`.`Price` <> `sar`.`Price`);
					-- Solo actualiza en esta tabla si hay cambio de precios
							-- OR `isa`.`ArticleSupplierDescription` <> `sar`.`ArticleSupplierDescription`
							-- OR `isa`.`SupplierPriceListIDn` <> `sar`.`SupplierPriceListIDn`);

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- 2.1- Actualiza articulos que ya estan incorporado, ya que estan en las dos tablas
	-- Una vez ejecutada esta consulta, se iguala la informacion importada con la base actual
	-- Si un articulo se rehabilito, aqui deberia actualizarse
	UPDATE `applcore`.`applsuptsupplierspricelistarticles` `sar`
		INNER JOIN `applcore`.`applimptsupplierspricelistarticles` `isa`
				on `sar`.`ArticleSupplierID` = `isa`.`ArticleSupplierID`
					and `sar`.`SupplierIDn` = `isa`.`SupplierIDn`
					and `sar`.`CompanyIDn` = `isa`.`CompanyIDn`
	SET
			`sar`.`ArticleSupplierDescription` = `isa`.`ArticleSupplierDescription`,
			`sar`.`SupplierPriceListIDn` = `isa`.`SupplierPriceListIDn`,
			`sar`.`Price` = `isa`.`Price`,
			`sar`.`DatePriceList` = `isa`.`DatePriceList`,
			`sar`.`PriceListCode` = `isa`.`PriceListCode`,
            `sar`.`Barcode` = `isa`.`Barcode`,
			`sar`.`StateIDn` = 372,									-- 372 Enable Habilitado / 373 Disable Deshabilitado
			-- `sar`.`CreatedByIDn` = vCreatedByIDn ,				-- Usuario que creo el registro
			`sar`.`LastModifiedByIDn` = @vLastModifiedByIDn ,		-- Usuario que modifico el registro
			-- `sar`.`OwnerIDn` = vOwnerIDn,						-- Usuario dueño del registro
			-- `sar`.`DateCreated` = vDateCreated,						-- Es la fecha de creacion del registro
			`sar`.`DateTimeStamp` = @vDateTimeStamp,					-- Es la fecha que se ejecuta el procedimiento
			`sar`.`TzNameIDn` = @vTzNameIDn,							-- America/Buenos_Aires
			`sar`.`TzOffset` = timestampdiff(minute, utc_timestamp(), current_timestamp())
				WHERE (`isa`.`ResultIDn` = 0 OR `isa`.`ResultIDn` is null)
					AND (`isa`.`Price` <> `sar`.`Price` 
							OR `isa`.`ArticleSupplierDescription` <> `sar`.`ArticleSupplierDescription`
							OR `isa`.`SupplierPriceListIDn` <> `sar`.`SupplierPriceListIDn`);

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Elimina los datos YA actualizados, estan en las dos tablas
	DELETE `applcore`.`applimptsupplierspricelistarticles`
	FROM `applcore`.`applimptsupplierspricelistarticles`
			INNER JOIN `applcore`.`applsuptsupplierspricelistarticles` `sar`
				on `applcore`.`applimptsupplierspricelistarticles`.`ArticleSupplierID` = `sar`.`ArticleSupplierID`
					and `applcore`.`applimptsupplierspricelistarticles`.`SupplierIDn` = `sar`.`SupplierIDn`
					and `applcore`.`applimptsupplierspricelistarticles`.`CompanyIDn` = `sar`.`CompanyIDn`;
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

	-- #################################################################################################################################################################################################
	-- 	3.- Inserta articulos nuevos, estan en la tabla applsuptsupplierspricelisthistory
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- 	3.1- Inserta articulos nuevos, estan en la tabla applsuptsupplierspricelisthistory
	-- Primero se ejecuta esta consulta para que impacte en el Historico, ya que la base de la consulta es la diferencia entre los datos importados y los de la base
	INSERT INTO `applcore`.`applsuptsupplierspricelisthistory`
			(`ArticleSupplierID`,
			`SupplierIDn`,
			`CompanyIDn`,
			`DatePriceList`,
			`Price`,
			`DatePriceListBefore`,
			`PriceBefore`,
			`StateIDn`
			)
			SELECT `isa`.`ArticleSupplierID`,
					`isa`.`SupplierIDn`,
					`isa`.`CompanyIDn`,
					`isa`.`DatePriceList`,
					`isa`.`Price`,
					`sar`.`DatePriceList`,
					`sar`.`Price`,
					372 `StateIDn`						-- 372 Enable Habilitado / 373 Disable Deshabilitado
				FROM `applcore`.`applimptsupplierspricelistarticles` `isa`
					left outer join `applcore`.`applsuptsupplierspricelistarticles` `sar`
						on `isa`.`ArticleSupplierID` = `sar`.`ArticleSupplierID`
							and `isa`.`SupplierIDn` = `sar`.`SupplierIDn`
							and `isa`.`CompanyIDn` = `sar`.`CompanyIDn`
				WHERE (`isa`.`ResultIDn` = 0 OR `isa`.`ResultIDn` is null)
						and  `sar`.`ArticleSupplierID` is null;

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- 	3.2- Inserta articulos nuevos, estan en la tabla applimp y no en la tabla applsup
	-- Una vez ejecutada esta consulta, se iguala la informacion importada con la base actual
	INSERT INTO `applcore`.`applsuptsupplierspricelistarticles`
			(`ArticleSupplierID`,
			`SupplierIDn`,
			`CompanyIDn`,
			`ArticleSupplierDescription`,
			`SupplierPriceListIDn`,
			`Price`,
			`DatePriceList`,
			`PriceListCode`,
            `Barcode`,
			`StateIDn`,
			`CreatedByIDn`,
			`LastModifiedByIDn`,
			`OwnerIDn`,
			`DateCreated`,
			`DateTimeStamp`,
			`TzNameIDn`,
			`TzOffset`,
			`TableHistory`)
					SELECT `isa`.`ArticleSupplierID`,
							`isa`.`SupplierIDn`,
							`isa`.`CompanyIDn`,
							`isa`.`ArticleSupplierDescription`,
							`isa`.`SupplierPriceListIDn`,
							`isa`.`Price`,
							`isa`.`DatePriceList`,
							`isa`.`PriceListCode`,
                            `isa`.`Barcode`,
			-- 				`isa`.`ResultIDn`,
			-- 				`isa`.`ResultDescription`
							372 `StateIDn`,						-- 372 Enable Habilitado / 373 Disable Deshabilitado
							@vCreatedByIDn `CreatedByIDn`,					-- Usuario que creo el registro
							@vLastModifiedByIDn `LastModifiedByIDn`,				-- Usuario que modifico el registro
							@vOwnerIDn `OwnerIDn`,						-- Usuario dueño del registro
							@vDateCreated `DateCreated`,
							@vDateTimeStamp `DateTimeStamp`,
							@vTzNameIDn `TzNameIDn`,		-- America/Buenos_Aires
							timestampdiff(minute, utc_timestamp(), current_timestamp()) `TzOffset`,
							null `TableHistory`
						FROM `applcore`.`applimptsupplierspricelistarticles` `isa`
							left outer join `applcore`.`applsuptsupplierspricelistarticles` `sar`
								on `isa`.`ArticleSupplierID` = `sar`.`ArticleSupplierID`
									and `isa`.`SupplierIDn` = `sar`.`SupplierIDn`
									and `isa`.`CompanyIDn` = `sar`.`CompanyIDn`
						WHERE (`isa`.`ResultIDn` = 0 OR `isa`.`ResultIDn` is null)
								and  `sar`.`ArticleSupplierID` is null;

	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- 	3.3- Elimina los datos YA importados, ya que estan en las dos tabla
	DELETE `applcore`.`applimptsupplierspricelistarticles`
	FROM `applcore`.`applimptsupplierspricelistarticles`
			INNER JOIN `applcore`.`applsuptsupplierspricelistarticles` `sar`
				on `applcore`.`applimptsupplierspricelistarticles`.`ArticleSupplierID` = `sar`.`ArticleSupplierID`
					and `applcore`.`applimptsupplierspricelistarticles`.`SupplierIDn` = `sar`.`SupplierIDn`
					and `applcore`.`applimptsupplierspricelistarticles`.`CompanyIDn` = `sar`.`CompanyIDn`;
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- #################################################################################################################################################################################################

-- Lista las fechas que tuvieron actualizacion de precios
	SELECT spla.CompanyIDn, spla.SupplierIDn, per.TradeName, spla.DatePriceList, COUNT(*) 'Q'
	FROM applcore.applsuptsupplierspricelistarticles spla
		LEFT OUTER JOIN applcore.appltpersons per
			ON spla.CompanyIDn = per.CompanyIDn
					AND
				spla.SupplierIDn = per.PersonIDn
    -- WHERE SupplierIDn = 869
	GROUP BY spla.CompanyIDn, spla.SupplierIDn, per.TradeName, spla.DatePriceList
	ORDER BY spla.CompanyIDn, spla.SupplierIDn, spla.DatePriceList DESC;

/*
select * FROM applcore.applsuptsupplierspricelistarticles where SupplierIDn = 868 and StateIDn = 373;
delete  FROM applcore.applsuptsupplierspricelistarticles where SupplierIDn = 868;
select SupplierIDn, count(*) FROM applcore.applsuptsupplierspricelistarticles group by SupplierIDn
select SupplierIDn, count(*) FROM applcore.applsuptsupplierspricelisthistory group by SupplierIDn
*/
    -- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    -- Fin - Procedimiento Almacenado
	-- ############################################################################################################################################################################################################################################################################################

SELECT * FROM `applcore`.`applimptsupplierspricelistarticles`;
