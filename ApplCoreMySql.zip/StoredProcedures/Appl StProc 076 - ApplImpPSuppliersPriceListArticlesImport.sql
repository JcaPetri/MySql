USE `ApplCore`;
DROP procedure IF EXISTS `ApplImpPSuppliersPriceListArticlesImport`;

DELIMITER $$
USE `ApplCore`$$
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Appl StProc 076 - ApplImpPSuppliersPriceListArticlesImport.sql
-- IDNum	IDName/Table								ScopeIDn	IDCode
-- 2243		ApplImpPSuppliersPriceListArticlesImport		6		  462
-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

CREATE DEFINER=`root`@`localhost` PROCEDURE `ApplImpPSuppliersPriceListArticlesImport`( 
	-- Parametros para mostrar los resultados del procedimiento almacenado
	OUT vSqlState char(5), 		-- SqlState, This value is a five-character string (for example, '42S02')
    OUT vErrorCode int,			-- ErrorCode, This value is numeric. It is MySQL-specific and is not portable to other database systems., este se vincula con una descripcion personalizada en la base de datos.
	OUT vMsgString TEXT,		-- MsgString, This string provides a textual description of the error.
	OUT vRowAffected int, 		-- RowAffected, variable para obtener el numero de registros afectados.

	-- Parametros para activar la trazabilidad
    IN vSystsqltimes tinyint,			-- Activate the traceability of the stored procedure: True = 1 / False = 0
    
	-- Parametros para proveer informacion y ejecutar el procedimiento almacenado
	IN vCreatedByIDn mediumint,			-- Es el IdNum del usuario que creo el registro
	IN vLastModifiedByIDn mediumint,	-- Es el IdNum del ultimo usuario que modifico el registro
	IN vOwnerIDn mediumint,				-- Es el IdNum del dueño del registro
	IN vDateCreated datetime,			-- Es la fecha de creacion del registro
	IN vDateTimeStamp datetime,			-- Es la fecha de la ultima modificacion del registro
	IN vTzNameIDn smallint,				-- Es el IdNum de la Time Zone del la fecha
	IN vTzOffset smallint,				-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
	IN vTableHistory text 			 	-- Es el historico del registro
)
BEGIN
	-- DECLARE ... VARIABLES
    declare vSP_ProcessIDn int default 0;			-- IDNum del Numero de proceso almacenado, esta en la tabla BaseElement
	declare vSP_ProcessNumber int default 0;		-- Numero de Proceso, dentro de la tabla systsqltimes
    declare vSP_ProcessOrder int default 0;			-- Es el Orden en que se ejecuta el procedimiento almacenado   
    
	-- DECLARE ... CONDITION Statement
	declare vSP_NumConditions int default 0;
	declare vSUCCESS condition for sqlstate '99999';			-- ErrCode: 2999 - Message: Stored Procedure Success 
    
	-- exit if Errors occurs for sqlexception
    declare exit handler for sqlexception
        begin
			rollback;								-- Deshace los cambios
            -- SET lc_messages = 'en_US';				-- Define el idioma del error	/ fr_FR
						-- Trazabilidad -
						set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) VALUES (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"ErrHandler-01-Start","Before GetDiag"); end if;
			-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
			get stacked diagnostics vSP_NumConditions = number, vRowAffected = row_count;	-- Take the condition number and the affected rows	, vRowAffected = row_count
						-- Trazabilidad - 
						set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) VALUES (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"GetDiag-ErrHandler-02",concat("vSP_NumConditions = ",convert(vSP_NumConditions,CHAR)," - vRowAffected = ",convert(vRowAffected,CHAR))); end if;
			-- Ajusta las RowAffected
            if vRowAffected = -1 then 
				SET vRowAffected = vRowAffected + 1; 
			end if;
			-- Depend of the vSP_NumConditions value, send the result
			if vSP_NumConditions > 0 then
							-- Trazabilidad - 
							set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) values (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"GetDiag-ErrHandler-03-if",concat("If NumCond > 0 Start - vSP_NumConditions = ",convert(vSP_NumConditions,char))); end if;
				-- Report the first error
				get stacked diagnostics condition vSP_NumConditions vSqlState = returned_sqlstate, vErrorCode = mysql_errno, vMsgString = message_text;		-- Take the ondition information
				-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
				-- Resultado Erróneo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
				-- Todas estas variables se envian dentro del mensaje vMsgString, concatenandolas.	-- , cast(251 AS CHAR), '†'
				-- SQLState five-character string
				set vMsgString = concat(vSqlState, '†', vMsgString);
				-- vRowAffected no depende del vSP_NumConditions, se carga antes del if
							-- Trazabilidad -
							set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) VALUES (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"GetDiag-ErrHandler-04-if","If NumCond > 0 End"); end if;
			else
				-- Carga la informacion general (de o no error se carga lo mismo)
				set vSqlState = 'HY000';				-- informa el resultado: 'HY000' (general error) is used for client-side errors and if server-side errors hasen't MySQL error numbers
				set vErrorCode = 2000;					-- informa el numero de resultado, este se vincula con una descripcion personalizada en la base de datos.
														-- 2,000 to 2,999: Client error codes reserved for use by the client library.
				-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
				-- Resultado Erróneo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
				-- Todas estas variables se envian dentro del mensaje vMsgString, concatenandolas.	-- , cast(251 AS CHAR), '†'
				-- SQLState five-character string, for Client Error use always 'HY000'
				set vMsgString = concat('HY000', '†', 'Unknown MySQL error');
				-- vRowAffected no depende del vSP_NumConditions, se carga antes del if
							-- Trazabilidad -
							set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) VALUES (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"GetDiag-ErrHandler-05-else","If NumCond > 0 Else"); end if;
			END IF;
		END;

	-- Stored Procedures goes success
	declare continue handler for vSUCCESS
		begin
			get stacked diagnostics vSP_NumConditions = number;	-- Take the condition number and the affected rows
			-- Carga la informacion general (de o no error se carga lo mismo)
			set vSqlState = 'HY000';			-- informa el resultado: 'HY000' (general error) is used for client-side errors and if server-side errors hasen't MySQL error numbers
			set vErrorCode = 2999;				-- informa el numero de resultado, (2999: Success Result) este se vincula con una descripcion personalizada en la base de datos.
			-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
			-- Resultado Success, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
			-- Todas estas variables se envian dentro del mensaje vMsgString, concatenandolas.	-- , cast(251 AS CHAR), '†'
			-- SQLState five-character string, for Client Error use always 'HY000'
			set vMsgString = concat('00', '†', 'Stored Procedure Success');
			-- vRowAffected Info viene de la sentencia SQL
						-- Trazabilidad -
						set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) values (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"GetDiag-01-SuccessHandler",concat("Signal Success - vSP_NumConditions: ", vSP_NumConditions," - vRowAffected: ",vRowAffected)); end if;
        end;
        -- Cuando termina este procedimiento continua con el la sentencia del commit y finaliza el Stored Procedure
	-- ############################################################################################################################################################################################################################################################################################
    -- Inicio - Procedimiento Almacenado
    -- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Setea las variables OUT
	set vSqlState = '';			-- SqlState, This value is a five-character string (for example, '42S02')
	set vErrorCode = 0;			-- ErrorCode, This value is numeric. It is MySQL-specific and is not portable to other database systems., este se vincula con una descripcion personalizada en la base de datos.
	set vMsgString = '';		-- MsgString, This string provides a textual description of the error.
	set vRowAffected = 0;		-- RowAffected, variable para obtener el numero de registros afectados.
    
	-- Trazabilidad - 
				-- Define el ProcessNumber que es igual para todo el procedimiento, esta en la tabla systsqltimes, al ultimo proceso le agrega uno
                -- SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 6 order by IDCode;
					-- IDNum	IDName StoProcedure			 				ScopeIDn		IDCode
					-- 2244		ApplImpPSuppliersPriceListArticlesImport		6		 	 463
				set vSP_ProcessIDn = 2244; select ifnull(max(ProcessNumber),0) + 1 into vSP_ProcessNumber from `bpmcore`.`systsqltimes` where ProcessIDn = vSP_ProcessIDn;
				-- Trazabilidad -
				set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) VALUES (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"StoProcedure-01-Start",concat("Clave Unica recibida; vCompanyIDn ",convert(vCompanyIDn,CHAR))); end if;

    -- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Inserta el nuevo registro
		start transaction;		-- start a new transaction
			-- #################################################################################################################################################################################################
			-- #################################################################################################################################################################################################
			-- Importa los Datos a Tabla applsuptsupplierspricelistarticles
			-- Para ello sigue los siguientes pasos:
			-- 		1.- Desactiva los articulos que no estan mas en la base importada, estan en la tabla applsup y no en la tabla applimp
			-- 		2.- Actualiza articulos que ya estan incorporado, ya que estan en las dos tablas
			-- 		3.- Inserta articulos nuevos, estan en la tabla applimp y no en la tabla applsup
			-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

			-- #################################################################################################################################################################################################
			-- 1.- Desactiva los articulos que no estan mas en la base importada, estan en la tabla applsup y no en la tabla applimp
			-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			-- 	1.1- Desactiva los articulos que no estan mas en la base importada, estan en la tabla applsup y no en la tabla applimp
				-- 		de la tabla `ApplCore`.`ApplSupTSuppliersPriceListArticles`
				UPDATE `applcore`.`ApplSupTSuppliersPriceListArticles` `sar`
					LEFT JOIN (SELECT `CompanyIDn`, `SupplierIDn`, `ArticleSupplierID`
									FROM `applcore`.`applimptsupplierspricelistarticles`
									WHERE `ResultIDn` = 0 OR `ResultIDn` is null		-- Solo toma los registros actualizables
								   ) `isa`
										ON `sar`.`ArticleSupplierID` = `isa`.`ArticleSupplierID`
											AND `sar`.`SupplierIDn` = `isa`.`SupplierIDn`
											AND `sar`.`CompanyIDn` = `isa`.`CompanyIDn`
				SET
						`sar`.`StateIDn` = 373,									-- 372 Enable Habilitado / 373 Disable Deshabilitado
						-- 	`sar`.`CreatedByIDn` = vCreatedByIDn,				-- Usuario
						`sar`.`LastModifiedByIDn` = @vLastModifiedByIDn,			-- Usuario
						-- `sar`.`OwnerIDn` = vOwnerIDn,						-- Usuario
						-- `sar`.`DateCreated` = vDateCreated,					-- Es la fecha de la creacion del regisgtro
						`sar`.`DateTimeStamp` = @vDateTimeStamp,					-- Es la fecha que se ejecuta el procedimiento
						`sar`.`TzNameIDn` = @vTzNameIDn,							-- America/Buenos_Aires
						`sar`.`TzOffset` = timestampdiff(minute, utc_timestamp(), current_timestamp())
				WHERE `isa`.`ArticleSupplierID` is null;		-- Solo toma los registros actualizables
				
				/* -- Muestra los datos 
							SELECT `sar`.ArticleSupplierID, `isa`.`IDNum` FROM `applcore`.`applsuptsupplierspricelistarticles` `sar`
									LEFT JOIN (SELECT `CompanyIDn`, `SupplierIDn`, `ArticleSupplierID`
												FROM `applcore`.`applimptsupplierspricelistarticles`
												WHERE `ResultIDn` = 0 OR `ResultIDn` is null		-- Solo toma los registros actualizables
											   ) `isa`
													ON `sar`.`ArticleSupplierID` = `isa`.`ArticleSupplierID`
														AND `sar`.`SupplierIDn` = `isa`.`SupplierIDn`
														AND `sar`.`CompanyIDn` = `isa`.`CompanyIDn`
						WHERE `isa`.`ArticleSupplierID` is null;		-- Solo toma los registros actualizables
						*/
					-- No se eliminan de la tabla applimptsupplierspricelistarticles ya que no estan, el proveedor no los trabaja mas

				-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
				-- 1.2- Desactiva los articulos que no estan mas en la base importada, estan en la tabla applsup y no en la tabla applimp
				-- 		de la tabla `ApplCore`.`ApplSupTSuppliersPriceListHistory`
				UPDATE `applcore`.`applsuptsupplierspricelisthistory` `sph`
					LEFT JOIN (SELECT `CompanyIDn`, `SupplierIDn`, `ArticleSupplierID`
									FROM `applcore`.`applimptsupplierspricelistarticles`
									WHERE `ResultIDn` = 0 OR `ResultIDn` is null		-- Solo toma los registros actualizables
								   ) `isa`
										ON `sph`.`ArticleSupplierID` = `isa`.`ArticleSupplierID`
											AND `sph`.`SupplierIDn` = `isa`.`SupplierIDn`
											AND `sph`.`CompanyIDn` = `isa`.`CompanyIDn`
				SET `StateIDn` = 373									-- 372 Enable Habilitado / 373 Disable Deshabilitado
				WHERE `isa`.`ArticleSupplierID` is null;		-- Solo toma los registros actualizables
				/* -- Muestra los datos 
						SELECT `sph`.ArticleSupplierID, `isa`.`IDNum` FROM `applcore`.`ApplSupTSuppliersPriceListHistory` `sph`
									LEFT JOIN (SELECT `CompanyIDn`, `SupplierIDn`, `ArticleSupplierID`
												FROM `applcore`.`applimptsupplierspricelistarticles`
												WHERE `ResultIDn` = 0 OR `ResultIDn` is null		-- Solo toma los registros actualizables
											   ) `isa`
													ON `sph`.`ArticleSupplierID` = `isa`.`ArticleSupplierID`
														AND `sph`.`SupplierIDn` = `isa`.`SupplierIDn`
														AND `sph`.`CompanyIDn` = `isa`.`CompanyIDn`
						WHERE `isa`.`ArticleSupplierID` is null;
						*/
					-- No se eliminan de la tabla applimptsupplierspricelistarticles ya que no estan, el proveedor no los trabaja mas
			-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

			-- #################################################################################################################################################################################################
			-- 2.- Actualiza articulos que ya estan incorporado, ya que estan en las dos tablas
			-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			-- 2.1- Inserta en la tabla los Articulos que tuvieron cambio de precios, ya que estan en las dos tablas
			-- Primero se ejecuta esta consulta para que impacte en el Historico, ya que la base de la consulta es la diferencia entre los datos importados y los de la base
            INSERT INTO `applcore`.`applsuptsupplierspricelisthistory`
					(`ArticleSupplierID`,
					`SupplierIDn`,
					`CompanyIDn`,
					`DatePriceList`,
					`Price`,
					`DatePriceListBefore`,
					`PriceBefore`,
					`StateIDn`
					)
						SELECT `isa`.`ArticleSupplierID`,
								`isa`.`SupplierIDn`,
								`isa`.`CompanyIDn`,
								`isa`.`DatePriceList`,
								`isa`.`Price`,
								`sar`.`DatePriceList`,
								`sar`.`Price`,
								 372 `StateIDn`						-- 372 Enable Habilitado / 373 Disable Deshabilitado
							FROM `applcore`.`applimptsupplierspricelistarticles` `isa`
								INNER JOIN `applcore`.`applsuptsupplierspricelistarticles` `sar`
									on `isa`.`ArticleSupplierID` = `sar`.`ArticleSupplierID`
										and `isa`.`SupplierIDn` = `sar`.`SupplierIDn`
										and `isa`.`CompanyIDn` = `sar`.`CompanyIDn`
						WHERE (`isa`.`ResultIDn` = 0 OR `isa`.`ResultIDn` is null)
							AND (`isa`.`Price` <> `sar`.`Price`);
                            -- Solo actualiza en esta tabla si hay cambio de precios
									-- OR `isa`.`ArticleSupplierDescription` <> `sar`.`ArticleSupplierDescription`
                                    -- OR `isa`.`SupplierPriceListIDn` <> `sar`.`SupplierPriceListIDn`);

			-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
            -- 2.1- Actualiza articulos que ya estan incorporado, ya que estan en las dos tablas
            -- Una vez ejecutada esta consulta, se iguala la informacion importada con la base actual
			UPDATE `applcore`.`applsuptsupplierspricelistarticles` `sar`
				INNER JOIN `applcore`.`applimptsupplierspricelistarticles` `isa`
						on `sar`.`ArticleSupplierID` = `isa`.`ArticleSupplierID`
							and `sar`.`SupplierIDn` = `isa`.`SupplierIDn`
							and `sar`.`CompanyIDn` = `isa`.`CompanyIDn`
			SET
					`sar`.`ArticleSupplierDescription` = `isa`.`ArticleSupplierDescription`,
					`sar`.`SupplierPriceListIDn` = `isa`.`SupplierPriceListIDn`,
					`sar`.`Price` = `isa`.`Price`,
					`sar`.`DatePriceList` = `isa`.`DatePriceList`,
                    `sar`.`PriceListCode` = `isa`.`PriceListCode`,
					`sar`.`StateIDn` = 372,									-- 372 Enable Habilitado / 373 Disable Deshabilitado
					-- `sar`.`CreatedByIDn` = vCreatedByIDn ,				-- Usuario que creo el registro
					`sar`.`LastModifiedByIDn` = vLastModifiedByIDn ,		-- Usuario que modifico el registro
					-- `sar`.`OwnerIDn` = vOwnerIDn,						-- Usuario dueño del registro
					-- `sar`.`DateCreated` = vDateCreated,						-- Es la fecha de creacion del registro
					`sar`.`DateTimeStamp` = vDateTimeStamp,					-- Es la fecha que se ejecuta el procedimiento
					`sar`.`TzNameIDn` = vTzNameIDn,							-- America/Buenos_Aires
					`sar`.`TzOffset` = timestampdiff(minute, utc_timestamp(), current_timestamp())
						WHERE (`isa`.`ResultIDn` = 0 OR `isa`.`ResultIDn` is null)
							AND (`isa`.`Price` <> `sar`.`Price` 
									OR `isa`.`ArticleSupplierDescription` <> `sar`.`ArticleSupplierDescription`
                                    OR `isa`.`SupplierPriceListIDn` <> `sar`.`SupplierPriceListIDn`);

			-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			-- Elimina los datos YA actualizados, estan en las dos tablas
			DELETE `applcore`.`applimptsupplierspricelistarticles`
			FROM `applcore`.`applimptsupplierspricelistarticles`
					INNER JOIN `applcore`.`applsuptsupplierspricelistarticles` `sar`
						on `applcore`.`applimptsupplierspricelistarticles`.`ArticleSupplierID` = `sar`.`ArticleSupplierID`
							and `applcore`.`applimptsupplierspricelistarticles`.`SupplierIDn` = `sar`.`SupplierIDn`
							and `applcore`.`applimptsupplierspricelistarticles`.`CompanyIDn` = `sar`.`CompanyIDn`;
			-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

			-- #################################################################################################################################################################################################
			-- 	3.- Inserta articulos nuevos, estan en la tabla applsuptsupplierspricelisthistory
			-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			-- 	3.1- Inserta articulos nuevos, estan en la tabla applsuptsupplierspricelisthistory
			-- Primero se ejecuta esta consulta para que impacte en el Historico, ya que la base de la consulta es la diferencia entre los datos importados y los de la base
            INSERT INTO `applcore`.`applsuptsupplierspricelisthistory`
					(`ArticleSupplierID`,
					`SupplierIDn`,
					`CompanyIDn`,
					`DatePriceList`,
					`Price`,
                    `DatePriceListBefore`,
                    `PriceBefore`,
					`StateIDn`
					)
					SELECT `isa`.`ArticleSupplierID`,
							`isa`.`SupplierIDn`,
							`isa`.`CompanyIDn`,
							`isa`.`DatePriceList`,
							`isa`.`Price`,
							`sar`.`DatePriceList`,
							`sar`.`Price`,
							372 `StateIDn`						-- 372 Enable Habilitado / 373 Disable Deshabilitado
						FROM `applcore`.`applimptsupplierspricelistarticles` `isa`
							left outer join `applcore`.`applsuptsupplierspricelistarticles` `sar`
								on `isa`.`ArticleSupplierID` = `sar`.`ArticleSupplierID`
									and `isa`.`SupplierIDn` = `sar`.`SupplierIDn`
									and `isa`.`CompanyIDn` = `sar`.`CompanyIDn`
						WHERE (`isa`.`ResultIDn` = 0 OR `isa`.`ResultIDn` is null)
								and  `sar`.`ArticleSupplierID` is null;

			-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			-- 	3.2- Inserta articulos nuevos, estan en la tabla applimp y no en la tabla applsup
			-- Una vez ejecutada esta consulta, se iguala la informacion importada con la base actual
			INSERT INTO `applcore`.`applsuptsupplierspricelistarticles`
					(`ArticleSupplierID`,
					`SupplierIDn`,
					`CompanyIDn`,
					`ArticleSupplierDescription`,
					`SupplierPriceListIDn`,
					`Price`,
					`DatePriceList`,
					`PriceListCode`,
                    `StateIDn`,
					`CreatedByIDn`,
					`LastModifiedByIDn`,
					`OwnerIDn`,
					`DateCreated`,
					`DateTimeStamp`,
					`TzNameIDn`,
					`TzOffset`,
					`TableHistory`)
							SELECT `isa`.`ArticleSupplierID`,
									`isa`.`SupplierIDn`,
									`isa`.`CompanyIDn`,
									`isa`.`ArticleSupplierDescription`,
									`isa`.`SupplierPriceListIDn`,
									`isa`.`Price`,
									`isa`.`DatePriceList`,
                                    `isa`.`PriceListCode`,
					-- 				`isa`.`ResultIDn`,
					-- 				`isa`.`ResultDescription`
									372 `StateIDn`,						-- 372 Enable Habilitado / 373 Disable Deshabilitado
									vCreatedByIDn `CreatedByIDn`,					-- Usuario que creo el registro
									vLastModifiedByIDn `LastModifiedByIDn`,				-- Usuario que modifico el registro
									vOwnerIDn `OwnerIDn`,						-- Usuario dueño del registro
									vDateCreated `DateCreated`,
									vDateTimeStamp `DateTimeStamp`,
									vTzNameIDn `TzNameIDn`,		-- America/Buenos_Aires
									timestampdiff(minute, utc_timestamp(), current_timestamp()) `TzOffset`,
									null `TableHistory`
								FROM `applcore`.`applimptsupplierspricelistarticles` `isa`
									left outer join `applcore`.`applsuptsupplierspricelistarticles` `sar`
										on `isa`.`ArticleSupplierID` = `sar`.`ArticleSupplierID`
											and `isa`.`SupplierIDn` = `sar`.`SupplierIDn`
											and `isa`.`CompanyIDn` = `sar`.`CompanyIDn`
								WHERE (`isa`.`ResultIDn` = 0 OR `isa`.`ResultIDn` is null)
										and  `sar`.`ArticleSupplierID` is null;

			-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			-- 	3.3- Elimina los datos YA importados, ya que estan en las dos tabla
			DELETE `applcore`.`applimptsupplierspricelistarticles`
			FROM `applcore`.`applimptsupplierspricelistarticles`
					INNER JOIN `applcore`.`applsuptsupplierspricelistarticles` `sar`
						on `applcore`.`applimptsupplierspricelistarticles`.`ArticleSupplierID` = `sar`.`ArticleSupplierID`
							and `applcore`.`applimptsupplierspricelistarticles`.`SupplierIDn` = `sar`.`SupplierIDn`
							and `applcore`.`applimptsupplierspricelistarticles`.`CompanyIDn` = `sar`.`CompanyIDn`;
			-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			-- #################################################################################################################################################################################################


			set vRowAffected = row_count();
						-- Trazabilidad -
						set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) values (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"StoProcedure-02-End",concat("Se cargaron los datos ",convert(vCompanyIDn,char)," row count: ",vRowAffected)); end if;
            -- Informa el exito de la operacion
			signal vSUCCESS;

		commit;		-- commit changes 
    -- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    -- Fin - Procedimiento Almacenado
	-- ############################################################################################################################################################################################################################################################################################

end$$

DELIMITER ;