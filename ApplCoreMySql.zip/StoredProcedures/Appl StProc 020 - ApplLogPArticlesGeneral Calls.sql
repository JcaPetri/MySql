-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ApplLogPArticlesGeneralCreate
-- -----------------------------
-- Lista los Stored Procedures que estan en la tabla BaseElement
SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 3 and IDName like '%Appl%' order by IDCode;
SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE IDNum = 652;
SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 11 order by IDCode;

-- Aclaracion: no olvidarse de actualizar el IDCode

-- Call Stored Procedures to create a new record, first in BpmfouPBaseElementCreate and then in SysTStoredProcedures
-- Parametros para la tabla `applcore`.`ApplPDataElementCreate`
set @traceability = 1;
set @vIDName = 'ArtPropGralInm';	-- Nombre del General Articles Parameters
set @vIDNameStructureIDn = 1;		-- Es el IDNum de la estructura del IDName - si es multivaluado - aqui esta la estructura
set @vScopeIDn = 2203;				-- 2203	ApplLogTArticlesGeneral (Tabla)
set @vLanguageIDn = 652;			-- English
set @vCompanyIDn = 2142; 			-- 2142 Peperina / 2143 Tagle / 2144 UniversalBuildCompany
set @vIDCode = 0;					-- Codigo numerico establecido por el usuario, permite organizar los contenidos de la tabla por rangos, si el valor es 0 se incrementa 1 para ese ScopeIDn y CompanyIDn
set @vDefinitionIDn = 2070;			-- bpmndefaultdefinition
set @vInformationTypeIDn = 381;		-- 381 Data / 382 Software
set @vIDIsUsed = 1;					-- True
set @vStateIDn = 372;				-- 372 Enable Habilitado / 373 Disable Deshabilitado
set @vCreatedByIDn = 1;				-- Usuario
set @vLastModifiedByIDn = 0;		-- Usuario
set @vOwnerIDn = 0;					-- Usuario
set @vTzNameIDn = 1206;				-- America/Buenos_Aires
-- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Parametros para la tabla `applcore`.`appllogparticlesgeneralcreate`
-- set @vArticleGeneralIDn,				-- Se crea luego de que es generado el registro en la tabla ApplPDataElementCreate
-- set @vCompanyIDn,					-- Se cargo para la primer tabla
set @vScalesUse = 0;					-- True = 1 / False = 0, Habilita el uso de escalas para el artículo
set @vStockEnable = 0;					-- True = 1 / False = 0, Habilita si se lleva stock del artículo
set @vGroupUse = 0;						-- True = 1 / False = 0, Habilita la utilización de las Groups/partidas por el artículo
set @vGroupAutomaticNumbering = 0;		-- True = 1 / False = 0, Habilita la utilización de la numeracion automatica de Groups/Partidas lo da el sistema
set @vGroupAutoDownloadByAge = 0;		-- True = 1 / False = 0, Habilita la descarga automática de Groups/partida por antigüedad
set @vSeriesUse = 0;					-- True = 1 / False = 0, Habilita el uso de series
set @vSeriesUseMandatory = 0;			-- True = 1 / False = 0, Establece como obligatorio el uso de las series
set @vSeriesUseReentry = 0;				-- True = 1 / False = 0, Admite reingreso de series, activa la comprobación de que no haya series duplicadas (actuales o ya vendidas).
set @vSeriesUseValidate = 0;			-- True = 1 / False = 0, Valida el número de serie de egreso, que exista en el sistema. Cuando se carga un comprobante de egreso valida que los números de series disponibles existan.

-- Ejecuta el Procedimiento Almacenado
CALL `applcore`.`ApplPDataElementCreate`
(
	@vSqlState,
	@vErrorCode,
    @vMsgString,
    @vRowAffected,
    @vIDNum,
    @traceability,						-- Activate the traceability of the stored procedure: True = 1 / False = 0
    -- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    -- Parametros para insertar nuevo registro
    uuid(), 				-- vID, UniqueIdentifier
	@vIDName, 				-- vIDName, Código en letras del ID.
    @vIDNameStructureIDn,	-- Es el IDNum de la estructura del IDName - si es multivaluado - aqui esta la estructura
	@vScopeIDn, 			-- vScopeIDn, Es el IDNum del Ambito de Aplicación / Tabla a la que pertenece el registro, numeros variales
    @vLanguageIDn, 			-- vLanguageIDn, Es el IDNum del Idioma del Registro, Scope = 11 TSysLanguage, 652 English -- Codigo del idioma por defecto elegido. Este es el mismo durante todo el sistema.
	@vCompanyIDn, 			-- vCompanyIDn, Es el IDNum de la Compania dueña del Registro, Scope = 25, 2207 System, 7566 Tagle, 7565 Peperina
    @vIDCode,				-- vIDCode, Codigo numerico establecido por el usuario, permite organizar los contenidos de la tabla por rangos, se carga automaticamente si no se especifica
	@vDefinitionIDn, 		-- vDefinitionIDn, Es el IDNum del tipo de definicion del elemento, Scope = 23 tSysDefinition, 2070 bpmndefaultdefinition
	@vInformationTypeIDn, 	-- vInformationTypeIDn, Es el IDNum del tipo de Registro, Scope = 18 tSisInfoType, 381 Data, 382 Software = definición del código, bajo que estandar esta escrito. Define el tipo de dato que es el BaseElement}>, <{puede ser: Data (son los elementos reales que forman el sistema, los procesos, etc.), Software (es la estructura BMPN, XML, XSD).	
	@vIDIsUsed,				-- vIDIsUsed, 1 = true, 0 = false
    @vStateIDn,				-- vStateIDn, Es el IdNum del estado del registro, (Habilitado / Deshabilitado / Eliminado / etc), Scope = 21 tSisState, 372 Ena, 373 Dis
	@vCreatedByIDn, 		-- vCreatedByIDn, Es el IdNum del usuario que creo el registro, Scope = 231 UserTUser, numeros variales
	@vLastModifiedByIDn, 	-- vLastModifiedByIDn, Es el IdNum del ultimo usuario que modifico el registro, Scope = 231 UserTUser, numeros variales
	@vOwnerIDn, 			-- vOwnerIDn, Es el IdNum del usuario dueño del registro, Scope = 231 UserTUser, numeros variales
	current_timestamp,		-- vDateCreated, Es la fecha de creacion del registro, es la fecha y hora actual segun el posicionamiento actual
	current_timestamp,		-- vDateTimeStamp, Es la fecha de la ultima modificacion del registro, es la fecha y hora actual segun el posicionamiento actual
									-- Cuando se crea el registro, el DateCreated y DateTimeStamp son iguales
	@vTzNameIDn,			-- vTzNameIDn, Es el IdNum de la Time Zone del la fecha
	timestampdiff(minute, utc_timestamp(), current_timestamp()),	-- vTzOffset, Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
																	-- como es en horas y minutos, aqui se registra la diferencia real en horas y minutos
	null					-- vTableHistory, Es el historico del registro
);
	
SELECT @vSqlState,
	@vErrorCode,
    @vMsgString,
    @vRowAffected,
    @vIDNum;

set @vArticleGeneralIDn = (SELECT @vIDNum); 	-- Es el IdNum del General Articulo en el DataElement
													-- ya que es un registro del usuario, no asociado al funcionamiento del System
													-- El name y la descripcion estan dentro de las tablas DataElement y DataDocumentation
-- Ejecuta el Procedimiento Almacenado
CALL `applcore`.`appllogparticlesgeneralcreate`
(	
	@vSqlState,
	@vErrorCode,
	@vMsgString,
	@vRowAffected,
	@traceability,						-- Activate the traceability of the stored procedure: True = 1 / False = 0
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Parametros para insertar nuevo registro
	@vArticleGeneralIDn,		-- Es el IdNum del General Articulo en el DataElement
													-- ya que es un registro del usuario, no asociado al funcionamiento del System
													-- El name y la descripcion estan dentro de las tablas DataElement y DataDocumentation
	@vCompanyIDn,					-- Es el IdNum de la Company al que esta asignado el IDName
													-- la clave primaria, es el GeneralIDn (Tabla) + CompanyIDn
	@vScalesUse,						-- True = 1 / False = 0, Habilita el uso de escalas para el artículo
	@vStockEnable,						-- True = 1 / False = 0, Habilita si se lleva stock del artículo
	@vGroupUse,						-- True = 1 / False = 0, Habilita la utilización de las Groups/partidas por el artículo
	@vGroupAutomaticNumbering,		-- True = 1 / False = 0, Habilita la utilización de la numeracion automatica de Groups/Partidas lo da el sistema
	@vGroupAutoDownloadByAge,		-- True = 1 / False = 0, Habilita la descarga automática de Groups/partida por antigüedad
	@vSeriesUse,							-- True = 1 / False = 0, Habilita el uso de series
	@vSeriesUseMandatory,		-- True = 1 / False = 0, Establece como obligatorio el uso de las series
	@vSeriesUseReentry,			-- True = 1 / False = 0, Admite reingreso de series, activa la comprobación de que no haya series duplicadas (actuales o ya vendidas).
	@vSeriesUseValidate,			-- True = 1 / False = 0, Valida el número de serie de egreso, que exista en el sistema. Cuando se carga un comprobante de egreso valida que los números de series disponibles existan.
	@vStateIDn,				-- vStateIDn, Es el IdNum del estado del registro, (Habilitado / Deshabilitado / Eliminado / etc), Scope = 21 tSisState, 372 Ena, 373 Dis
	@vCreatedByIDn, 		-- vCreatedByIDn, Es el IdNum del usuario que creo el registro, Scope = 231 UserTUser, numeros variales
	@vLastModifiedByIDn, 	-- vLastModifiedByIDn, Es el IdNum del ultimo usuario que modifico el registro, Scope = 231 UserTUser, numeros variales
	@vOwnerIDn, 			-- vOwnerIDn, Es el IdNum del usuario dueño del registro, Scope = 231 UserTUser, numeros variales
	current_timestamp,		-- vDateCreated, Es la fecha de creacion del registro, es la fecha y hora actual segun el posicionamiento actual
	current_timestamp,		-- vDateTimeStamp, Es la fecha de la ultima modificacion del registro, es la fecha y hora actual segun el posicionamiento actual
									-- Cuando se crea el registro, el DateCreated y DateTimeStamp son iguales
	@vTzNameIDn,			-- vTzNameIDn, Es el IdNum de la Time Zone del la fecha
	timestampdiff(minute, utc_timestamp(), current_timestamp()),	-- vTzOffset, Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
																	-- como es en horas y minutos, aqui se registra la diferencia real en horas y minutos
	null					-- vTableHistory, Es el historico del registro
);

SELECT @vSqlState,
	@vErrorCode,
    @vMsgString,
    @vRowAffected
    ;

-- Lista las tablas donde se insertaron los datos
SELECT * FROM `applcore`.`appltdataelement` where ScopeIDn = 2203;		-- 2203	ApplLogTArticlesGeneral
SELECT * FROM `applcore`.`appllogtarticlesgeneral`;

-- Lista la tabla SysTSqlTimes
SELECT * FROM `bpmcore`.`systsqltimes` WHERE ProcessIDn = 2219 ORDER BY ProcessIDn, ProcessNumber desc, ProcessOrder, Stage desc;

/*
	DELETE FROM `bpmcore`.`systcompanies` WHERE CompanyIDn = 2209;
	DELETE FROM `bpmcore`.`systsqltimes` WHERE ProcessIDn = 2209;
*/




