-- #####################################################################################################################################################
-- Appl StProc 082 - ApplSupPSalePriceListArticlesInsertFromSupplier.sql
-- #####################################################################################################################################################
-- #####################################################################################################################################################
-- Articulos CON Proveedor/Supplier
-- #####################################################################################################################################################
-- Definicion de Parametros
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
set @vCompanyIDn = 2142; 			-- 2142 Peperina / 2143 Tagle / 2144 UniversalBuildCompany
set @vPriceListIDn = 117;			-- Es el IdNum de la Lista de Precios de Ventas, esta en la tabla applsaletpricelist
set @vSupplierIDn = 49;				-- Define el proveedor que sera el origen de la actualizacion de la lista de precios
											-- Surge de la tabla Person, Query: SELECT PersonIDn, TradeName FROM applcore.applvpersons;
												/*
													49		Estela Montenegro s.a.
													868		Mar-Plast s.a.
													869		Popeye LMG s.r.l.
													870		El Auditor s.a.
													871		Papelera Cumbre s.a.
													1754	Wow
													1755	Tienda Foko
													1756	Matemundo
                                                */
set @vSupplierPriceListIDn = 51;	-- Define que lista de precios del proveedor sera la utilizada como base para actualizar los precios
								/*
										51		LP Montenegro
										52		LP Popeye
										872		LP Mar-Plast
										1788	LP Wow
										1789	LP Foko
										1792	LP Matemundo
								*/
set @vPriceDate = current_timestamp;						-- Es la fecha de la Lista de Precio, puede no coincidir con la fecha actual
set @vPriceListCode = 'LPM 2022 01';		-- (Lista Precio Minorista)				-- Es el codigo de la lista de preciosset @vStateIDn = 372;				-- 372 Enable Habilitado / 373 Disable Deshabilitado
set @vCreatedByIDn = 1;				-- Usuario
set @vLastModifiedByIDn = 1;		-- Usuario
set @vOwnerIDn = 1;					-- Usuario
set	@vDateCreated = current_timestamp;						-- Es la fecha de creacion del registro, es la fecha y hora actual segun el posicionamiento actual
set @vDateTimeStamp = current_timestamp;					-- Es la fecha de la ultima modificacion del registro, es la fecha y hora actual segun el posicionamiento actual
set @vTzOffset = timestampdiff(minute, utc_timestamp(), current_timestamp());
set @vTzNameIDn = 1206;				-- America/Buenos_Aires

-- #####################################################################################################################################################
-- Articulos que tienen asignado un Proveedor/Supplier
-- 1.- Primero se asegura que si el articulo esta habilitado en la base de ApplLogTArticle, esta habilitado en las listas de precios
-- el Where es que este Deshabilitado en la tabla de Lista de Precios y habilitado en la tabla de Articulos
/*
	UPDATE `applcore`.`applsaletpricelistarticles` `spa`
			INNER JOIN `applcore`.`appllogtarticles` `art`
				ON `spa`.`ArticleIDn` = `art`.`ArticleIDn`
					AND `spa`.`CompanyIDn` = `art`.`CompanyIDn`
	SET `spa`.`StateIDn` = 372,
		-- 	`sar`.`CreatedByIDn` = vCreatedByIDn,					-- Usuario que crea el registro
		`spa`.`LastModifiedByIDn` = @vLastModifiedByIDn,			-- Usuario que modifica el registro
		-- `sar`.`OwnerIDn` = vOwnerIDn,							-- Usuario dueño del registro
		-- `sar`.`DateCreated` = vDateCreated,						-- Es la fecha de la creacion del regisgtro
		`spa`.`DateTimeStamp` = @vDateTimeStamp,					-- Es la fecha que se ejecuta el procedimiento
		`spa`.`TzNameIDn` = @vTzNameIDn,							-- America/Buenos_Aires
		`spa`.`TzOffset` = timestampdiff(minute, utc_timestamp(), current_timestamp())
	WHERE `spa`.`StateIDn` = 373 AND `art`.`StateIDn` = 372;

*/
	-- -----------------------------------------------------------------------------------------------------------------------------------------------------
	-- Muestra los articulos que estaria rehabilitando
	/*
        SELECT `spa`.`CompanyIDn`, `spa`.`PriceListIDn`, `spa`.`ArticleIDn`,  `de01`.`IDName` `Description`, `spa`.`Price`
				, `spa`.`StateIDn`, `art`.`StateIDn` `Table Article StateIDn`
		FROM `applcore`.`applsaletpricelistarticles` `spa`
			INNER JOIN `applcore`.`appllogtarticles` `art`
				ON `spa`.`ArticleIDn` = `art`.`ArticleIDn`
					AND `spa`.`CompanyIDn` = `art`.`CompanyIDn`
			INNER JOIN `applcore`.`appltdataelement` `de01`
				ON `spa`.`ArticleIDn` = `de01`.`IDNum`
		WHERE `spa`.`StateIDn` = 373 AND `art`.`StateIDn` = 372;
		-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
*/

-- 2.- Inserta solo los valores que no estan en la Lista de Precios y si en la lista de Articulos
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
INSERT INTO `applcore`.`applsaletpricelistarticles`
		(`ArticleIDn`,
		`PriceListIDn`,
		`CompanyIDn`,
		`Price`,
		`PriceDate`,
		`PriceListCode`,
		`StateIDn`,
		`CreatedByIDn`,
		`LastModifiedByIDn`,
		`OwnerIDn`,
		`DateCreated`,
		`DateTimeStamp`,
		`TzNameIDn`,
		`TzOffset`,
		`TableHistory`
		)
		SELECT `art`.`ArticleIDn`,						-- Es el IdNum del Articulo, esta en la tabla DataElement
				@vPriceListIDn `PriceListIDn`,			-- Es el IdNum de la Lista de Precios de Ventas, esta en la tabla applsaletpricelist
				`art`.`CompanyIDn`,						-- Es el IdNum de la Company al que esta asignado el IDName
																-- la clave primaria: es el ArticleIDn + PriceListIDn + CompanyIDn
																-- como cada articulo puede estar en varias listas de precios, aqui es donde se asignan a ellas
				`spl`.`Price` * 2 `Price`,								-- Es el precio del articulo, es un valor autocalculado, en funcion de los parametros de actualizacion
				ifnull(@vPriceDate,current_timestamp) `PriceDate`,							-- Es la fecha de la Lista de Precio, puede no coincidir con la fecha actual
																-- ya que el proceso de actualizacion puede diferir de la fecha de la lista de precios que se actualiza
				@vPriceListCode `PriceListCode`,						-- Es el codigo de la lista de precios
				@vStateIDn `StateIDn`,							-- Es el IDNum del estado del registro, Scope = 21 tSisState, 372 Ena, 373 Dis
				@vCreatedByIDn `CreatedByIDn`,					-- Es el IdNum del usuario que creo el registro, Scope = 231 UserTUser, numeros variales
				@vLastModifiedByIDn `LastModifiedByIDn`,			-- Es el IdNum del ultimo usuario que modifico el registro, Scope = 231 UserTUser, numeros variales
				@vOwnerIDn `OwnerIDn`,							-- Es el IdNum del usuario dueño del registro, Scope = 231 UserTUser, numeros variales
				ifnull(@vDateCreated,current_timestamp) `DateCreated`,		-- Es la fecha de creacion del registro, es la fecha y hora actual segun el posicionamiento actual
				ifnull(@vDateTimeStamp,current_timestamp) `DateTimeStamp`,	-- Es la fecha de la ultima modificacion del registro, es la fecha y hora actual segun el posicionamiento actual
													-- Cuando se crea el registro, el DateCreated y DateTimeStamp son iguales
				@vTzNameIDn, 						-- Es el IdNum de la Time Zone del la fecha
				ifnull(@vTzOffset,timestampdiff(minute, utc_timestamp(), current_timestamp())) `TzOffset`, 
									-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
									-- como es en horas y minutos, aqui se registra la diferencia real en horas y minutos
				@vTableHistory `TableHistory`	-- Es el historico del registro
		FROM `applcore`.`appllogtarticles` `art`
			LEFT OUTER JOIN `applcore`.`applsaletpricelistarticles` `spa`	
				-- Se asegura que no se traten de insertar articulos que ya estan en la lista de precios de ventas (SalePriceList)
                -- si el articulo esta en la lista de precios, el procedimiento es actualizar el precio
                -- para asegurar esto en la clausula where agrega `spa`.`ArticleIDn` is null
				ON `art`.`ArticleIDn` = `spa`.`ArticleIDn`
					AND `art`.`CompanyIDn` = `spa`.`CompanyIDn`
                    AND `spa`.`PriceListIDn` = @vPriceListIDn			-- Es el IdNum de la Lista de Precios de Ventas, esta en la tabla applsaletpricelist
    				AND `spa`.`StateIDn` = 372							-- Solo elige los valores habilitados
			INNER JOIN `applcore`.`appllogtarticlessuppliersarticles` `asa`
				ON `art`.`ArticleIDn` = `asa`.`ArticleIDn`
					AND `art`.`CompanyIDn` = `asa`.`CompanyIDn`
					AND `asa`.`SupplierIDn` = @vSupplierIDn			-- Define el Supplier/proveedor que sera el origen de la actualizacion de la lista de precios
                    AND `asa`.`StateIDn` = 372						-- Solo elige los valores habilitados
			LEFT OUTER JOIN `applcore`.`applsuptsupplierspricelistarticles` `spl`
				ON `asa`.`ArticleSupplierID` = `spl`.`ArticleSupplierID`
					AND `asa`.`SupplierIDn` = `spl`.`SupplierIDn`
                    AND `asa`.`CompanyIDn` = `spl`.`CompanyIDn`
                    AND `spl`.`SupplierPriceListIDn` = @vSupplierPriceListIDn	-- Define que lista de precios del proveedor sera la utilizada como base para actualizar los precios
					AND `spl`.`StateIDn` = 372						-- Solo elige los valores habilitados
		WHERE `art`.`StateIDn` = 372			-- Solo elige los valores habilitados
				AND `spa`.`ArticleIDn` is null		-- Solo los registros que no estan en la Lp
		;


/*
SELECT * FROM `applcore`.`appllogtarticles` `art`
SELECT * FROM `applcore`.`applsuptsupplierspricelistarticles` `spl` 
		WHERE StateIDn = 373 and SupplierIDn = 868 and SupplierPriceListIDn = 872
			;	-- 7429 
SELECT * FROM `applcore`.`appllogtarticlessuppliersarticles` `asa`;		-- 363
SELECT * FROM `applcore`.`applsaletpricelistarticles`;					-- 493	Diferencia ya que se incorporaron los Articulos sin Proveedor/Supplier


	-- -----------------------------------------------------------------------------------------------------------------------------------------------------
	-- Corrige errores
	UPDATE `applcore`.`applsuptsupplierspricelistarticles`
	SET
	`StateIDn` = 372,
		TableHistory = "SetOff"				-- 	"SetNull", "SetOff"
	WHERE `CompanyIDn` = 2142 AND SupplierIDn = 49 AND SupplierPriceListIDn = 51 AND StateIDn = 373

	SELECT * FROM `applcore`.`appllogtarticles` `art` WHERE ArticleIDn  >= 1757
	select * from `applcore`.`appllogtarticlessuppliersarticles` `asa` where  ArticleIDn >= 1757
	SELECT * FROM `applcore`.`applsaletpricelistarticles` where ArticleIDn >= 1757
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
*/

	-- -----------------------------------------------------------------------------------------------------------------------------------------------------
	-- Muestra Sale Price List y sus descripciones
	/*
        SELECT `spa`.`CompanyIDn`, `spa`.`PriceListIDn`, `spa`.`ArticleIDn`,  `de01`.`IDName` `Description`, `spa`.`Price`
				, `spa`.`StateIDn`
		FROM `applcore`.`applsaletpricelistarticles` `spa`
			INNER JOIN `applcore`.`appllogtarticles` `art`
				ON `spa`.`ArticleIDn` = `art`.`ArticleIDn`
					AND `spa`.`CompanyIDn` = `art`.`CompanyIDn`
			INNER JOIN `applcore`.`appltdataelement` `de01`
				ON `spa`.`ArticleIDn` = `de01`.`IDNum`
		WHERE `spa`.`StateIDn` = 372;
		-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
*/

