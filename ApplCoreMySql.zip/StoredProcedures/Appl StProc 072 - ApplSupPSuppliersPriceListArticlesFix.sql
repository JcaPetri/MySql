SELECT * FROM applcore.applimptsupplierspricelistarticlesfix;

	INSERT INTO `applcore`.`applimptsupplierspricelistarticlesfix`
			(`ArticleSupplierID`,
			`SupplierIDn`,
			`CompanyIDn`,
			`ArticleSupplierDescription`,
			`StateIDn`,
			`CreatedByIDn`,
			`LastModifiedByIDn`,
			`OwnerIDn`,
			`DateCreated`,
			`DateTimeStamp`,
			`TzNameIDn`,
			`TzOffset`,
			`TableHistory`)
		SELECT 302044 `ArticleSupplierID`,
				49 `SupplierIDn`,
				2142 `CompanyIDn`,
				'CANOPLA INTERVEN TUBO FANTASIA' `ArticleSupplierDescription`,
				372 `StateIDn`,							-- Es el IDNum del estado del registro, Scope = 21 tSisState, 372 Ena, 373 Dis
				1 `CreatedByIDn`,					-- Es el IdNum del usuario que creo el registro, Scope = 231 UserTUser, numeros variales
				0 `LastModifiedByIDn`,			-- Es el IdNum del ultimo usuario que modifico el registro, Scope = 231 UserTUser, numeros variales
				0 `OwnerIDn`,							-- Es el IdNum del usuario dueño del registro, Scope = 231 UserTUser, numeros variales
				current_timestamp `DateCreated`,		-- Es la fecha de creacion del registro, es la fecha y hora actual segun el posicionamiento actual
				current_timestamp `DateTimeStamp`,	-- Es la fecha de la ultima modificacion del registro, es la fecha y hora actual segun el posicionamiento actual
													-- Cuando se crea el registro, el DateCreated y DateTimeStamp son iguales
				1206, 						-- Es el IdNum de la Time Zone del la fecha
				timestampdiff(minute, utc_timestamp(), current_timestamp()) `TzOffset`, 
									-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
									-- como es en horas y minutos, aqui se registra la diferencia real en horas y minutos
				null `TableHistory`;	-- Es el historico del registro
;

