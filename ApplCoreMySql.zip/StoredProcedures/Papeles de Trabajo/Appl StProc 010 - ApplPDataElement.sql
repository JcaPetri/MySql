-- Bld StProc 01 - BuildTProyect.sql


-- Lista los Company disponibles
USE `bpmncore`;
SELECT * FROM `bpmncore`.`bpmfoutbaseelement` WHERE `ScopeIDn` = 25 Order by IDNum;
/*
	2142	Peperina
	2143	Tagle
	2144	UniversalBuildCompany
*/

-- Lista los posibles PermissionSet
SELECT * FROM `bpmncore`.`bpmfoutbaseelement` WHERE `ScopeIDn` = 24311 Order by IDNum;
/*
		32768	tSisPermissionSet
		32769	UserSystemRead
		32770	UserSystemWrite
		32771	UserRead
		32772	UserWrite
		32773	UserRoleRead
		32774	UserRoleWrite
		32775	UserPermissionRead
		32776	UserPermissionWrite
		32777	BaseElementRead
		32778	BaseElementWrite
		32779	BpmFoundRead
		32780	BpmFoundWrite
		32781	UserSystemReadExcep
		32782	tSisPermissionSetFree 15
*/

-- Lista los PermissionSetType
SELECT * FROM `bpmncore`.`bpmfoutbaseelement` WHERE `ScopeIDn` = 26 Order by IDNum;
/*
	26	tSisPermissionSetType
	2434	IsCustom
	2435	IsSystem
	2436	tSisPermissionSetTypeFree 4
*/

-- Lista los PermissionSet
SELECT * FROM usercore.uservpermissionset;
	SELECT * FROM `buildcore`.`bldtproyect`;

-- Inserta un nuevo Proyect
INSERT INTO `buildcore`.`bldtproyect`
		(`ProyectIDn`,
		`StateIDn`,
		`CreatedByIDn`,
		`LastModifiedByIDn`,
		`OwnerIDn`,
		-- `DateCreated`,
		-- `DateTimeStamp`,
		`TzNameIDn`,
		`TzOffset`,
		`TableHistory`)
	SELECT 	7566 `CompanyIDn`,			-- 7566 Tagle, 7565 Peperina
		 `PermiSetIDn`,
		0 `PermiSetIsGrant`,		-- Puede ser True (1) o False (0) MutingPermission, si es True otorga permisos, si es False le saca permisos al objeto. 
		0 `HasActivationRequired`,	-- Indica si el conjunto de permisos requiere una sesión activa asociada (cierto) o no (falso). Para cierta informacion Free, no es necesario que este el usuario Activo.
		2434 `PermiSetTypeIDn`,		-- 2434 IsCustom, 2435 IsSystem
		514 `StateIDn`,				-- Define el tipo de dato que es el BaseElement, puede ser: Data (son los elementos reales que forman el sistema, los procesos, etc.), Software (es la estructura BMPN, XML, XSD).	
		1 `CreatedByIDn`,
		0 `LastModifiedByIDn`,
		0 `OwnerIDn`,
		-- `DateCreated`,			 UTC_TIMESTAMP(),				-- Tabla BpmfouTBaseElement [DateBaseElement] -- Fecha de actualizacion.
		-- `DateTimeStamp`,			 UTC_TIMESTAMP(),				-- Tabla BpmfouTBaseElement [DateBaseElement] -- Fecha de actualizacion.
		1333 `TzNameIDn`,			-- Tabla BpmfouTBaseElement [TzName] -- Define el Time Zone del UTC
		-233 `TzOffset`,			-- Tabla BpmfouTBaseElement [TzOffset] -- Carga el tiempo Offset del UTC hasta la hora del servidor 
		null `TableHistory`;


-- Muestra los PermissionSet asignados a cada empresa
SELECT * FROM usercore.uservpermissionset;