-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Ejecuta el Procedimiento Almacenado:
-- IDNum	IDName/Table															ScopeIDn		IDCode
-- xxx		Appl StProc 034 - ApplLogPArticlesSuppliersArticlesImportMasivos			6			 407
-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

-- Valores Importados a Insertar en la tabla ApplLogTArticlesSuppliersArticles
SELECT * FROM applcore.applimptarticlessuppliersarticles;

-- Valores de la Tabla
SELECT * FROM `ApplCore`.`ApplLogTArticlesSuppliersArticles` `asa`
ORDER BY CompanyIDn, SupplierIDn, ArticleSupplierID, ArticleIDn;

-- DELETE FROM `ApplCore`.`ApplImpTArticlesSuppliersArticles`;
-- Determina si hay duplicados
SELECT CompanyIDn, SupplierIDn, ArticleSupplierID, ArticleIDn, COUNT(*) Q FROM applcore.applimptarticlessuppliersarticles GROUP BY CompanyIDn, SupplierIDn, ArticleSupplierID, ArticleIDn HAVING COUNT(*) > 1;

-- ########################################################################################################################################################################################
-- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Parametros para la tabla `ApplCore`.`ApplLogPArticlesSuppliersArticlesCreate`
-- Aqui no se crea ningun articulo, solo se asocia el ArticleIDn del Supplier/Proveedor con el ArticleIDn de la Company
-- de esta manera, se puede actualizar nuestro articulo con la informacion que nos suministra el proveedor
set @vStateIDn = 372;						-- 372 Enable Habilitado / 373 Disable Deshabilitado
set @vCreatedByIDn = 1;						-- Es el IdNum del usuario que creo el registro, Scope = 231 UserTUser, numeros variales
set @vLastModifiedByIDn = 1;				-- Es el IdNum del ultimo usuario que modifico el registro, Scope = 231 UserTUser, numeros variales
set @vOwnerIDn = 1;							-- Es el IdNum del usuario dueño del registro, Scope = 231 UserTUser, numeros variales
set @vDateCreated = current_timestamp; 		-- Es la fecha de creacion del registro, es la fecha y hora actual segun el posicionamiento actual
set @vDateTimeStamp = current_timestamp;	-- Es la fecha de la ultima modificacion del registro, es la fecha y hora actual segun el posicionamiento actual
set @vTzNameIDn = 1206;						-- America/Buenos_Aires
set @vTzOffset = timestampdiff(minute, utc_timestamp(), current_timestamp()); 		-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro

-- #################################################################################################################################################################################################
-- 4.- Inserta en la tabla `ApplCore`.`AppllogTArticlesSuppliersArticles` la relacion entre los articulos y el proveedor
-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	INSERT INTO `applcore`.`appllogtarticlessuppliersarticles`
		(`ArticleIDn`,
		`ArticleSupplierID`,
		`SupplierIDn`,
		`CompanyIDn`,
		`StateIDn`,
		`CreatedByIDn`,
		`LastModifiedByIDn`,
		`OwnerIDn`,
		`DateCreated`,
		`DateTimeStamp`,
		`TzNameIDn`,
		`TzOffset`,
		`TableHistory`)
		SELECT 	`iasa`.`ArticleIDn`,						-- Valor numerico unico autogenerado, que se genero en la consulta anterior
				`iasa`.`ArticleSupplierID`, 			-- Es el codigo del articulo para ese proveedor
				`iasa`.`SupplierIDn`,					-- Es el codigo del proveedor del articulo
				`iasa`.`CompanyIDn`,			-- Es el IDNum de la Compania dueña del Registro, Scope = 25, 2207 System, 7566 Tagle, 7565 Peperina
				@vStateIDn `StateIDn`,						-- Es el IDNum del estado del registro, Scope = 21 tSisState, 372 Ena, 373 Dis
				@vCreatedByIDn `CreatedByIDn`,				-- Es el IdNum del usuario que creo el registro, Scope = 231 UserTUser, numeros variales
				@vLastModifiedByIDn `LastModifiedByIDn`,	-- Es el IdNum del ultimo usuario que modifico el registro, Scope = 231 UserTUser, numeros variales
				@vOwnerIDn `OwnerIDn`,						-- Es el IdNum del usuario dueño del registro, Scope = 231 UserTUser, numeros variales
				@vDateCreated `DateCreated`,		-- Es la fecha de creacion del registro, es la fecha y hora actual segun el posicionamiento actual
				@vDateTimeStamp `DateTimeStamp`,	-- Es la fecha de la ultima modificacion del registro, es la fecha y hora actual segun el posicionamiento actual
													-- Cuando se crea el registro, el DateCreated y DateTimeStamp son iguales
				@vTzNameIDn, 						-- Es el IdNum de la Time Zone del la fecha
				@vTzOffset `TzOffset`, 				-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
									-- como es en horas y minutos, aqui se registra la diferencia real en horas y minutos
				@vTableHistory `TableHistory`	-- Es el historico del registro
		FROM `ApplCore`.`ApplImptArticlesSuppliersArticles` `iasa`
				LEFT OUTER JOIN `ApplCore`.`ApplLogTArticlesSuppliersArticles` `asa`		-- Se asegura que no esten ya incorporados
					ON `iasa`.`CompanyIDn` = `asa`.`CompanyIDn`
						AND `iasa`.`SupplierIDn` = `asa`.`SupplierIDn`
                        AND `iasa`.`ArticleSupplierID` = `asa`.`ArticleSupplierID`
                        AND `iasa`.`ArticleIDn` = `asa`.`ArticleIDn`
			WHERE `asa`.`ArticleIDn` IS NULL;		-- Se asegura que la relacion no este ya incorporada

-- Elimina los datos de la Tabla de Importacion
DELETE FROM `ApplCore`.`ApplImpTArticlesSuppliersArticles`;

/*
-- Lista las tablas donde se insertaron los datos
SELECT `as`.`Company`, `as`.`ArticleIDn`, `as`.`Article`, `as`.`TradeName`, `as`.`Price`, `as`.`DatePriceList`, `as`.`PriceListCode`, `as`.`ArticleSupplierID` , `as`.`ArticleSupplierDescription`
FROM `applcore`.`appllogvarticlessuppliersarticles` `as`;
*/
SELECT * FROM `ApplCore`.`ApplLogTArticlesSuppliersArticles` `asa`
ORDER BY DateCreated DESC, CompanyIDn, SupplierIDn, ArticleSupplierID, ArticleIDn;

