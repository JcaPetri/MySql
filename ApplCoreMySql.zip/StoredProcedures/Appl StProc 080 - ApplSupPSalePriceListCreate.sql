USE `applcore`;
DROP procedure IF EXISTS `ApplPSalePriceListCreate`;

DELIMITER $$
USE `applcore`$$
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Appl StProc 070 - ApplPSalePriceListCreate.sql
-- IDNum	IDName/Table						ScopeIDn	IDCode
-- 2245		ApplPSalePriceListCreate				6		 460
-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

CREATE DEFINER=`root`@`localhost` PROCEDURE `ApplPSalePriceListCreate`( 
	-- Parametros para mostrar los resultados del procedimiento almacenado
	OUT vSqlState char(5), 		-- SqlState, This value is a five-character string (for example, '42S02')
    OUT vErrorCode int,			-- ErrorCode, This value is numeric. It is MySQL-specific and is not portable to other database systems., este se vincula con una descripcion personalizada en la base de datos.
	OUT vMsgString TEXT,		-- MsgString, This string provides a textual description of the error.
	OUT vRowAffected int, 		-- RowAffected, variable para obtener el numero de registros afectados.

	-- Parametros para activar la trazabilidad
    IN vSystsqltimes tinyint,			-- Activate the traceability of the stored procedure: True = 1 / False = 0

	-- Parametros para proveer informacion y ejecutar el procedimiento almacenado
	IN vPriceListIDn int,				-- Es el IdNum de la Lista de Precios, esta en la tabla DataElement
												-- El IDName y el Documentation estan en sus tablas respectivas
    IN vCompanyIDn int,					-- Es el IdNum de la Company al que esta asignado el IDName
												-- la clave primaria: es el SupplierPriceListIDn + SupplierIDn + CompanyIDn
    IN vPriceListDecimal tinyint,		-- Es la cantidad de decimales que lleva la lista de precios
    IN vDateFrom datetime,				-- Es la fecha desde que toma vigencia la lista de precios
    IN vDateTo datetime,				-- Es la fecha hasta que tiene vigencia la lista de precios
												-- Un proveedor puede pasar una lista que entre en vigencia un dia especifico que dure un tiempo determinado
	IN vCurrencyIDn int,				-- Es el IdNum de la moneda de la lista de precios
	IN vPriceTaxTypeIDn int,			-- Es el IdNum del tipo precio con relacion a los impuestos
												-- Eje, PrecioFinal/PrecioNetoImpuesto
	IN vStateIDn smallint,				-- Es el IdNum del estado del registro - Código (Habilitado / Deshabilitado / Eliminado / etc)
	IN vCreatedByIDn mediumint,			-- Es el IdNum del usuario que creo el registro
	IN vLastModifiedByIDn mediumint,	-- Es el IdNum del ultimo usuario que modifico el registro
	IN vOwnerIDn mediumint,				-- Es el IdNum del dueño del registro
	IN vDateCreated datetime,			-- Es la fecha de creacion del registro
	IN vDateTimeStamp datetime,			-- Es la fecha de la ultima modificacion del registro
	IN vTzNameIDn smallint,				-- Es el IdNum de la Time Zone del la fecha
	IN vTzOffset smallint,				-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
	IN vTableHistory text 			 	-- Es el historico del registro
)
BEGIN
	-- DECLARE ... VARIABLES
    declare vSP_ProcessIDn int default 0;			-- IDNum del Numero de proceso almacenado, esta en la tabla BaseElement
	declare vSP_ProcessNumber int default 0;		-- Numero de Proceso, dentro de la tabla systsqltimes
    declare vSP_ProcessOrder int default 0;			-- Es el Orden en que se ejecuta el procedimiento almacenado   

	-- DECLARE ... CONDITION Statement
	declare vSP_NumConditions int default 0;
	declare vSUCCESS condition for sqlstate '99999';			-- ErrCode: 2999 - Message: Stored Procedure Success 
    
	-- exit if Errors occurs for sqlexception
    declare exit handler for sqlexception
        begin
			rollback;								-- Deshace los cambios
            -- SET lc_messages = 'en_US';				-- Define el idioma del error	/ fr_FR
						-- Trazabilidad -
						set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) VALUES (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"ErrHandler-01-Start","Before GetDiag"); end if;
			-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
			get stacked diagnostics vSP_NumConditions = number, vRowAffected = row_count;	-- Take the condition number and the affected rows	, vRowAffected = row_count
						-- Trazabilidad - 
						set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) VALUES (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"GetDiag-ErrHandler-02",concat("vSP_NumConditions = ",convert(vSP_NumConditions,CHAR)," - vRowAffected = ",convert(vRowAffected,CHAR))); end if;
			-- Ajusta las RowAffected
            if vRowAffected = -1 then 
				SET vRowAffected = vRowAffected + 1; 
			end if;
			-- Depend of the vSP_NumConditions value, send the result
			if vSP_NumConditions > 0 then
							-- Trazabilidad - 
							set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) values (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"GetDiag-ErrHandler-03-if",concat("If NumCond > 0 Start - vSP_NumConditions = ",convert(vSP_NumConditions,char))); end if;
				-- Report the first error
				get stacked diagnostics condition vSP_NumConditions vSqlState = returned_sqlstate, vErrorCode = mysql_errno, vMsgString = message_text;		-- Take the ondition information
				-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
				-- Resultado Erróneo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
				-- Todas estas variables se envian dentro del mensaje vMsgString, concatenandolas.	-- , cast(251 AS CHAR), '†'
				-- SQLState five-character string
				set vMsgString = concat(vSqlState, '†', vMsgString);
				-- vRowAffected no depende del vSP_NumConditions, se carga antes del if
							-- Trazabilidad -
							set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) VALUES (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"GetDiag-ErrHandler-04-if","If NumCond > 0 End"); end if;
			else
				-- Carga la informacion general (de o no error se carga lo mismo)
				set vSqlState = 'HY000';				-- informa el resultado: 'HY000' (general error) is used for client-side errors and if server-side errors hasen't MySQL error numbers
				set vErrorCode = 2000;					-- informa el numero de resultado, este se vincula con una descripcion personalizada en la base de datos.
														-- 2,000 to 2,999: Client error codes reserved for use by the client library.
				-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
				-- Resultado Erróneo, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
				-- Todas estas variables se envian dentro del mensaje vMsgString, concatenandolas.	-- , cast(251 AS CHAR), '†'
				-- SQLState five-character string, for Client Error use always 'HY000'
				set vMsgString = concat('HY000', '†', 'Unknown MySQL error');
				-- vRowAffected no depende del vSP_NumConditions, se carga antes del if
							-- Trazabilidad -
							set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) VALUES (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"GetDiag-ErrHandler-05-else","If NumCond > 0 Else"); end if;
			END IF;
		END;

	-- Stored Procedures goes success
	declare continue handler for vSUCCESS
		begin
			get stacked diagnostics vSP_NumConditions = number;	-- Take the condition number and the affected rows
			-- Carga la informacion general (de o no error se carga lo mismo)
			set vSqlState = 'HY000';			-- informa el resultado: 'HY000' (general error) is used for client-side errors and if server-side errors hasen't MySQL error numbers
			set vErrorCode = 2999;				-- informa el numero de resultado, (2999: Success Result) este se vincula con una descripcion personalizada en la base de datos.
			-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------
			-- Resultado Success, carga las variables que no se completan con la ejecucion del procedimiento almacenado.
			-- Todas estas variables se envian dentro del mensaje vMsgString, concatenandolas.	-- , cast(251 AS CHAR), '†'
			-- SQLState five-character string, for Client Error use always 'HY000'
			set vMsgString = concat('00', '†', 'Stored Procedure Success');
			-- vRowAffected Info viene de la sentencia SQL
						-- Trazabilidad -
						set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) values (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"GetDiag-01-SuccessHandler",concat("Signal Success - vSP_NumConditions: ", vSP_NumConditions," - vRowAffected: ",vRowAffected)); end if;
        end;
        -- Cuando termina este procedimiento continua con el la sentencia del commit y finaliza el Stored Procedure
	-- ############################################################################################################################################################################################################################################################################################
    -- Inicio - Procedimiento Almacenado
    -- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Setea las variables OUT
	set vSqlState = '';			-- SqlState, This value is a five-character string (for example, '42S02')
	set vErrorCode = 0;			-- ErrorCode, This value is numeric. It is MySQL-specific and is not portable to other database systems., este se vincula con una descripcion personalizada en la base de datos.
	set vMsgString = '';		-- MsgString, This string provides a textual description of the error.
	set vRowAffected = 0;		-- RowAffected, variable para obtener el numero de registros afectados.
    
	-- Trazabilidad - 
				-- Define el ProcessNumber que es igual para todo el procedimiento, esta en la tabla systsqltimes, al ultimo proceso le agrega uno
                -- SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 6 order by IDCode;
					-- IDNum	IDName StoProcedure			 		ScopeIDn		IDCode
					-- 2245		ApplPSalePriceListCreate				6		 460
				set vSP_ProcessIDn = 2245; select ifnull(max(ProcessNumber),0) + 1 into vSP_ProcessNumber from `bpmcore`.`systsqltimes` where ProcessIDn = vSP_ProcessIDn;
				-- Trazabilidad -
				set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) VALUES (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"StoProcedure-01-Start",concat("Clave Unica recibida; vCompanyIDn ",convert(vCompanyIDn,CHAR))); end if;

    -- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Inserta el nuevo registro
		start transaction;		-- start a new transaction
			-- Inserta el nuevo Registro
            INSERT INTO `applcore`.`applsaletpricelist`
					(`PriceListIDn`,
					`CompanyIDn`,
					`PriceListDecimal`,
					`DateFrom`,
					`DateTo`,
					`CurrencyIDn`,
					`PriceTaxTypeIDn`,
					`StateIDn`,
					`CreatedByIDn`,
					`LastModifiedByIDn`,
					`OwnerIDn`,
					`DateCreated`,
					`DateTimeStamp`,
					`TzNameIDn`,
					`TzOffset`,
					`TableHistory`)
				select
					vPriceListIDn `SupplierPriceListIDn`,			-- Es el IdNum de la Lista de Precios, esta en la tabla DataElement
																			-- El IDName y el Documentation estan en sus tablas respectivas
					vCompanyIDn `CompanyIDn`,						-- Es el IdNum de la Company al que esta asignado el IDName
																			-- la clave primaria: es el SupplierPriceListIDn + SupplierIDn + CompanyIDn
					vPriceListDecimal `PriceListDecimal`,			-- Es la cantidad de decimales que lleva la lista de precios
					vDateFrom `DateFrom`,							-- Es la fecha desde que toma vigencia la lista de precios
					vDateTo `DateTo`,								-- Es la fecha hasta que tiene vigencia la lista de precios
																		-- Un proveedor puede pasar una lista que entre en vigencia un dia especifico que dure un tiempo determinado
					vCurrencyIDn `CurrencyIDn`,						-- Es el IdNum de la moneda de la lista de precios
					vPriceTaxTypeIDn `PriceTaxTypeIDn`,				-- Es el IdNum del tipo precio con relacion a los impuestos
																				-- Eje, PrecioFinal/PrecioNetoImpuesto
                    vStateIDn `StateIDn`,							-- Es el IDNum del estado del registro, Scope = 21 tSisState, 372 Ena, 373 Dis
					vCreatedByIDn `CreatedByIDn`,					-- Es el IdNum del usuario que creo el registro, Scope = 231 UserTUser, numeros variales
					vLastModifiedByIDn `LastModifiedByIDn`,			-- Es el IdNum del ultimo usuario que modifico el registro, Scope = 231 UserTUser, numeros variales
					vOwnerIDn `OwnerIDn`,							-- Es el IdNum del usuario dueño del registro, Scope = 231 UserTUser, numeros variales
					ifnull(vDateCreated,current_timestamp) `DateCreated`,		-- Es la fecha de creacion del registro, es la fecha y hora actual segun el posicionamiento actual
					ifnull(vDateTimeStamp,current_timestamp) `DateTimeStamp`,	-- Es la fecha de la ultima modificacion del registro, es la fecha y hora actual segun el posicionamiento actual
														-- Cuando se crea el registro, el DateCreated y DateTimeStamp son iguales
					vTzNameIDn, 						-- Es el IdNum de la Time Zone del la fecha
					ifnull(vTzOffset,timestampdiff(minute, utc_timestamp(), current_timestamp())) `TzOffset`, 
										-- Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
										-- como es en horas y minutos, aqui se registra la diferencia real en horas y minutos
					vTableHistory `TableHistory`;	-- Es el historico del registro

			set vRowAffected = row_count();
						-- Trazabilidad -
						set vSP_ProcessOrder = vSP_ProcessOrder + 1; if vSystsqltimes = 1 then insert into `bpmcore`.`systsqltimes` (`ProcessIDn`,`ProcessNumber`,`ProcessOrder`,`Stage`,`Comments`) values (vSP_ProcessIDn,vSP_ProcessNumber,vSP_ProcessOrder,"StoProcedure-02-End",concat("Se cargaron los datos ",convert(vCompanyIDn,char)," row count: ",vRowAffected)); end if;
            -- Informa el exito de la operacion
			signal vSUCCESS;

		commit;		-- commit changes 
    -- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    -- Fin - Procedimiento Almacenado
	-- ############################################################################################################################################################################################################################################################################################

end$$

DELIMITER ;