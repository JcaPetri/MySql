-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ApplPPersonsCreate
-- IDNum	IDName/Table		ScopeIDn	IDCode
-- 2235		ApplTPersons			3		1208
-- -----------------------------
-- Lista los Stored Procedures que estan en la tabla BaseElement
/*
SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 3 and IDName like '%Appl%' order by IDCode;
SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE IDNum = 2205;		
SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 11 order by IDCode;
*/

-- Aclaracion: no olvidarse de actualizar el IDCode, si se pone 0, se incrementa de a uno

-- Call Stored Procedures to create a new record, first in ApplTDataElement and then in ApplTPersons
-- Parametros para la tabla `ApplCore`.`ApplPDataElementCreate`
set @traceability = 0;
set @vIDName = '110008';			-- Código del Cliente 6 dígitos, ver manual de Tango, este debe ser unico
											-- 1 = Libreria, 11
set @vIDNameStructureIDn = 1;		-- Es el IDNum de la estructura del IDName - si es multivaluado - aqui esta la estructura
set @vScopeIDn = 2235;				-- 2235	ApplTPersons (Tabla)
set @vLanguageIDn = 734;			-- 652 English / 734 Español
set @vCompanyIDn = 2142; 			-- 2142 Peperina / 2143 Tagle / 2144 UniversalBuildCompany
set @vIDCode = 0;					-- Codigo numerico establecido por el usuario, permite organizar los contenidos de la tabla por rangos, si es 0 se carga automaticamente para ese scope
set @vDefinitionIDn = 2070;			-- bpmndefaultdefinition
set @vInformationTypeIDn = 381;		-- 381 Data / 382 Software
set @vIDIsUsed = 1;					-- True
set @vStateIDn = 372;				-- 372 Enable Habilitado / 373 Disable Deshabilitado
set @vCreatedByIDn = 1;				-- Usuario
set @vLastModifiedByIDn = 1;		-- Usuario
set @vOwnerIDn = 1;					-- Usuario
set @vTzNameIDn = 1206;				-- America/Buenos_Aires
-- ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Parametros para la tabla `ApplCore`.`ApplTPersons`
-- set @vPersonIDn,							-- Es el IdNum de Cliente/Proveedor en el DataElement
-- set @vCompanyIDn,						-- Se cargo para la primer tabla
												-- la clave primaria: es el PersonIDn + CompanyIDn, solo puede estar un Cliente/Proveedor una vez en la compania
set @vPersonTypeIDn = 0;					-- Es el IdNum del Tipo de Person, Client/Supplier or Both
set @vTradeName = 'Matemundo';			-- Es el Nombre Comercial del Cliente/Proveedor
set @vCountryIDn = 831;						-- Es el IdNum del Pais, 	831 AR -- SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 12 AND IDName = 'AR';
set @vAddress = 'Junín 355, C1026 ABG, Buenos Aires';		-- La Direccion
set @vSalesUsualCurrencyIDn = 1777;			-- Es el IdNum de la moneda usual de Ventas del Cliente, 	1777 ARS
												-- SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE ScopeIDn = 14 AND IDName = 'ARS';
set @vSalesPriceListIDn = 0;				-- Es el IdNum de la listade precios

-- Ejecuta el Procedimiento Almacenado
CALL `ApplCore`.`ApplPDataElementCreate`
(
	@vSqlState,
	@vErrorCode,
    @vMsgString,
    @vRowAffected,
    @vIDNum,
    @traceability,						-- Activate the traceability of the stored procedure: True = 1 / False = 0
    -- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    -- Parametros para insertar nuevo registro
    uuid(), 				-- vID, UniqueIdentifier
	@vIDName, 				-- vIDName, Código en letras del ID.
    @vIDNameStructureIDn,	-- Es el IDNum de la estructura del IDName - si es multivaluado - aqui esta la estructura
	@vScopeIDn, 			-- vScopeIDn, Es el IDNum del Ambito de Aplicación / Tabla a la que pertenece el registro, numeros variales
    @vLanguageIDn, 			-- vLanguageIDn, Es el IDNum del Idioma del Registro, Scope = 11 TSysLanguage, 652 English -- Codigo del idioma por defecto elegido. Este es el mismo durante todo el sistema.
	@vCompanyIDn, 			-- vCompanyIDn, Es el IDNum de la Compania dueña del Registro, Scope = 25, 2207 System, 7566 Tagle, 7565 Peperina
    @vIDCode,				-- vIDCode, Codigo numerico establecido por el usuario, permite organizar los contenidos de la tabla por rangos, se carga automaticamente si no se especifica
	@vDefinitionIDn, 		-- vDefinitionIDn, Es el IDNum del tipo de definicion del elemento, Scope = 23 tSysDefinition, 2070 bpmndefaultdefinition
	@vInformationTypeIDn, 	-- vInformationTypeIDn, Es el IDNum del tipo de Registro, Scope = 18 tSisInfoType, 381 Data, 382 Software = definición del código, bajo que estandar esta escrito. Define el tipo de dato que es el BaseElement}>, <{puede ser: Data (son los elementos reales que forman el sistema, los procesos, etc.), Software (es la estructura BMPN, XML, XSD).	
	@vIDIsUsed,				-- vIDIsUsed, 1 = true, 0 = false
    @vStateIDn,				-- vStateIDn, Es el IdNum del estado del registro, (Habilitado / Deshabilitado / Eliminado / etc), Scope = 21 tSisState, 372 Ena, 373 Dis
	@vCreatedByIDn, 		-- vCreatedByIDn, Es el IdNum del usuario que creo el registro, Scope = 231 UserTUser, numeros variales
	@vLastModifiedByIDn, 	-- vLastModifiedByIDn, Es el IdNum del ultimo usuario que modifico el registro, Scope = 231 UserTUser, numeros variales
	@vOwnerIDn, 			-- vOwnerIDn, Es el IdNum del usuario dueño del registro, Scope = 231 UserTUser, numeros variales
	current_timestamp,		-- vDateCreated, Es la fecha de creacion del registro, es la fecha y hora actual segun el posicionamiento actual
	current_timestamp,		-- vDateTimeStamp, Es la fecha de la ultima modificacion del registro, es la fecha y hora actual segun el posicionamiento actual
									-- Cuando se crea el registro, el DateCreated y DateTimeStamp son iguales
	@vTzNameIDn,			-- vTzNameIDn, Es el IdNum de la Time Zone del la fecha
	timestampdiff(minute, utc_timestamp(), current_timestamp()),	-- vTzOffset, Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
																	-- como es en horas y minutos, aqui se registra la diferencia real en horas y minutos
	null					-- vTableHistory, Es el historico del registro
);
	
SELECT @vSqlState,
	@vErrorCode,
    @vMsgString,
    @vRowAffected,
    @vIDNum;

set @vPersonIDn = (SELECT @vIDNum); 		-- Es el IdNum del Articulo en el DataElement
													-- ya que es un registro del usuario, no asociado al funcionamiento del System
													-- El name y la descripcion estan dentro de las tablas DataElement y DataDocumentation
-- Ejecuta el Procedimiento Almacenado
CALL `ApplCore`.`ApplPPersonsCreate`(
	@vSqlState,
	@vErrorCode,
	@vMsgString,
	@vRowAffected,
	@traceability,						-- Activate the traceability of the stored procedure: True = 1 / False = 0
	-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	-- Parametros para insertar nuevo registro
	@vPersonIDn, 					-- Es el IdNum del Articulo en el DataElement
	@vCompanyIDn,					-- Es el IdNum de la Company al que esta asignado el IDName
												-- la clave primaria, es el ArticleIDn + CompanyIDn, solo puede estar el articulo una vez en la compania
	@vPersonTypeIDn,				-- Es el IdNum del Tipo de Person, Client/Supplier or Both
	@vTradeName,					-- Es el Nombre Comercial del Cliente/Proveedor
	@vCountryIDn,					-- Es el IdNum del Pais
	@vAddress,						-- La Direccion
	@vSalesUsualCurrencyIDn,		-- Es el IdNum de la moneda usual de Ventas del Cliente
	@vSalesPriceListIDn,			-- Es el IdNum de la listade precios
	@vStateIDn,						-- vStateIDn, Es el IdNum del estado del registro, (Habilitado / Deshabilitado / Eliminado / etc), Scope = 21 tSisState, 372 Ena, 373 Dis
	@vCreatedByIDn, 				-- vCreatedByIDn, Es el IdNum del usuario que creo el registro, Scope = 231 UserTUser, numeros variales
	@vLastModifiedByIDn, 			-- vLastModifiedByIDn, Es el IdNum del ultimo usuario que modifico el registro, Scope = 231 UserTUser, numeros variales
	@vOwnerIDn, 					-- vOwnerIDn, Es el IdNum del usuario dueño del registro, Scope = 231 UserTUser, numeros variales
	current_timestamp,				-- vDateCreated, Es la fecha de creacion del registro, es la fecha y hora actual segun el posicionamiento actual
	current_timestamp,				-- vDateTimeStamp, Es la fecha de la ultima modificacion del registro, es la fecha y hora actual segun el posicionamiento actual
										-- Cuando se crea el registro, el DateCreated y DateTimeStamp son iguales
	@vTzNameIDn,					-- vTzNameIDn, Es el IdNum de la Time Zone del la fecha
	timestampdiff(minute, utc_timestamp(), current_timestamp()),	-- vTzOffset, Es la diferencia horario entre el Zero Time Zone y la zona desde donde se modifico el registro
																	-- como es en horas y minutos, aqui se registra la diferencia real en horas y minutos
	null							-- vTableHistory, Es el historico del registro
);

SELECT @vSqlState,
	@vErrorCode,
    @vMsgString,
    @vRowAffected
    ;

-- Lista las tablas donde se insertaron los datos
SELECT * FROM `ApplCore`.`ApplTDataElement` where ScopeIDn = 2235;		-- 2235	ApplTPersons
SELECT * FROM `ApplCore`.`ApplTPersons`;

-- Lista la tabla SysTSqlTimes
-- 2237	ApplPPersonsCreate
-- SELECT * FROM `bpmcore`.`systsqltimes` WHERE ProcessIDn = 2237 ORDER BY ProcessIDn, ProcessNumber desc, ProcessOrder, Stage desc;

/*
	DELETE FROM `ApplCore`.`ApplTDataElement` WHERE IDNum = 6;
	DELETE FROM `bpmcore`.`systsqltimes` WHERE ProcessIDn = 2237;
*/


