UPDATE `applcore`.`appltdataelement`
SET 
	`ScopeIDn` = 2239, 
	-- `IDName` = 'N10',
		TableHistory = "SetOff"				-- 	"SetNull", "SetOff"facclit
-- WHERE `IDNum` = 329
WHERE `ID` = 'd8a29bb5-cb85-42fa-b243-70f323cbebe7';

SELECT * FROM applcore.appltdataelement  
WHERE IDNum = 1789;appllogtarticlesoptionalfieldsappltdataelement
WHERE `ID` = 'd8a29bb5-cb85-42fa-b243-70f323cbebe7';


/*
SELECT * FROM applcore.appltdataelement  WHERE ScopeIDn = 2205;
SELECT * FROM `bpmcore`.`bpmfoutbaseelement` WHERE IDNum = 2205 or IDNum >= 2223;
*/