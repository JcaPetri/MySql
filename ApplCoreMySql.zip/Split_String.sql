-- -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
DROP FUNCTION IF EXISTS SPLIT_STRING;
DELIMITER $
CREATE FUNCTION 
   SPLIT_STRING (vString VARCHAR(1024), vDelimiter CHAR(1) , vPosition INT)
   RETURNS VARCHAR(1024)
   DETERMINISTIC -- always returns same results for same input parameters
    BEGIN
        DECLARE n INT ;
        -- get max number of items
        SET n = LENGTH(vString) - LENGTH(REPLACE(vString, vDelimiter, '')) + 1;
		--  RETURN n;		-- Si no esta el delimitador, devuelve todo el contenido
        IF vPosition > n THEN
            RETURN NULL;
        ELSE
            RETURN SUBSTRING_INDEX(SUBSTRING_INDEX(vString, vDelimiter, vPosition), vDelimiter, -1);        
        END IF;
    END
$
DELIMITER ;

SET @agg = "G1|G2" ;		-- G1;G2;G3;G4;

SELECT SPLIT_STRING(@agg,'|',1) ;
SELECT SPLIT_STRING(@agg,'|',2) ;
SELECT SPLIT_STRING(@agg,';',3) ;
SELECT SPLIT_STRING(@agg,';',4) ;
SELECT SPLIT_STRING(@agg,';',5) ;
SELECT SPLIT_STRING(@agg,';',6) ;



set @vParam = '23|36|28|';
SELECT SPLIT_STRING(@vParam,'|',5);

SELECT LENGTH(@vParam) - LENGTH(REPLACE(@vParam, '|', '')) 'QPar';



