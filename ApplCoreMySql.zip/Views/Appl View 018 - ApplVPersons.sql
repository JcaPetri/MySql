USE `ApplCore`;
DROP view IF EXISTS `ApplVPersons`;

DELIMITER $$
USE `ApplCore`$$
CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `ApplCore`.`ApplVPersons` AS
	SELECT `Per`.`PersonIDn`,
			`De01`.`IDName` AS `Person`,
			`Per`.`CompanyIDn`,
			`Be01`.`IDName` AS `Company`,
			`Per`.`PersonTypeIDn`,
			`Per`.`TradeName`,
			`Per`.`CountryIDn`,
			`Per`.`Address`,
			`Per`.`SalesUsualCurrencyIDn`,
			`Per`.`SalesPriceListIDn`,
			`Per`.`StateIDn`,
			`Per`.`CreatedByIDn`,
			`Per`.`LastModifiedByIDn`,
			`Per`.`OwnerIDn`,
			`Per`.`DateCreated`,
			`Per`.`DateTimeStamp`,
			`Per`.`TzNameIDn`,
			`Per`.`TzOffset`,
			`Per`.`TableHistory`
		FROM `applcore`.`appltpersons` `Per`
			inner join `ApplCore`.`ApplTDataElement` `De01`
				on `Per`.`PersonIDn` = `De01`.`IDNum`
			inner join `bpmcore`.`bpmfoutbaseelement` `Be01`
				on `Per`.`CompanyIDn` = `Be01`.`IDNum`
	ORDER BY `Per`.`CompanyIDn`,
			`Per`.`PersonIDn`
			$$
    
DELIMITER ;

