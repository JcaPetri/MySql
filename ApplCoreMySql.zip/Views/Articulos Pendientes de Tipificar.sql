SELECT * FROM applcore.appllogvarticles `art`
	LEFT OUTER JOIN applcore.appllogtarticlesoptionalfields  `ofa`
		ON `art`.`CompanyIDn` = `ofa`.`CompanyIDn`
			AND `art`.`ArticleIDn` = `ofa`.`ArticleIDn`
WHERE `ofa`.`ArticleIDn` IS NULL
;