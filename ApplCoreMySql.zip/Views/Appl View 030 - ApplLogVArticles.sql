USE `applcore`;
DROP view IF EXISTS `ApplLogVArticles`;

DELIMITER $$
USE `applcore`$$
CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `applcore`.`ApplLogVArticles` AS
		SELECT `Ar`.`CompanyIDn`,
			`Be01`.`IDName` AS `Company`,
            `Ar`.`ArticleIDn`,
			`De01`.`IDName` AS `Article`,
			`Ar`.`ArticleGeneralIDn`,
			`De02`.`IDName` AS `ArticleGeneral`,
			`Ar`.`StockEnable`,
			`Ar`.`StateIDn`,
			`Ar`.`CreatedByIDn`,
			`Ar`.`LastModifiedByIDn`,
			`Ar`.`OwnerIDn`,
			`Ar`.`DateCreated`,
			`Ar`.`DateTimeStamp`,
			`Ar`.`TzNameIDn`,
			`Ar`.`TzOffset`,
			`Ar`.`TableHistory`
		FROM `applcore`.`appllogtarticles` `Ar`
			inner join `applcore`.`appltdataelement` `De01`
				on `Ar`.`ArticleIDn` = `De01`.`IDNum`
			inner join `bpmcore`.`bpmfoutbaseelement` `Be01`
				on `Ar`.`CompanyIDn` = `Be01`.`IDNum`
			inner join `applcore`.`appltdataelement` `De02`
				on `Ar`.`ArticleGeneralIDn` = `De02`.`IDNum`                
	ORDER BY `Ar`.`CompanyIDn`,
			`Ar`.`ArticleIDn`
			$$
    
DELIMITER ;

