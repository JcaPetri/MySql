-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Appl View 032 - ApplLogVArticlesOptionalFields.sql
-- IDNum	IDName/Table						ScopeIDn	IDCode
-- 		ApplLogVArticlesOptionalFields		
-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


USE `applcore`;
DROP view IF EXISTS `ApplLogVArticlesOptionalFields`;

DELIMITER $$
USE `applcore`$$
CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `applcore`.`ApplLogVArticlesOptionalFields` AS
    SELECT 	`Aof`.`CompanyIDn`,
			`Be02`.`IDName` AS `Company`,
			`Aof`.`ArticleIDn`,
            `De01`.`IDName` AS `Article`,
			`Aof`.`TableFieldIDn`,
			`Be01`.`IDName` AS `TableField`,
			`Aof`.`FieldValueIDn`,
            `De02`.`IDName` AS `FieldValue`,
			`Aof`.`FieldNumValue`,
			`Aof`.`FieldTextValue`,
			`Aof`.`StateIDn`,
			`Aof`.`CreatedByIDn`,
			`Aof`.`LastModifiedByIDn`,
			`Aof`.`OwnerIDn`,
			`Aof`.`DateCreated`,
			`Aof`.`DateTimeStamp`,
			`Aof`.`TzNameIDn`,
			`Aof`.`TzOffset`,
			`Aof`.`TableHistory`
		FROM `applcore`.`appllogtarticlesoptionalfields` `Aof`
			inner join `bpmcore`.`bpmfoutbaseelement` `Be01`
				on `Aof`.`TableFieldIDn` = `Be01`.`IDNum`
			inner join `applcore`.`appltdataelement` `De01`
				on `Aof`.`ArticleIDn` = `De01`.`IDNum`
			inner join `bpmcore`.`bpmfoutbaseelement` `Be02`
				on `Aof`.`CompanyIDn` = `Be02`.`IDNum`
			inner join `applcore`.`appltdataelement` `De02`
				on `Aof`.`FieldValueIDn` = `De02`.`IDNum`                
	ORDER BY `Aof`.`CompanyIDn`,
			`Aof`.`ArticleIDn`,
			`Aof`.`TableFieldIDn`
			$$
    
DELIMITER ;




