USE `applcore`;
DROP view IF EXISTS `ApplSaleVPriceList`;

DELIMITER $$
USE `applcore`$$
CREATE 
VIEW `applcore`.`ApplSaleVPriceList` AS
		SELECT `spla`.`CompanyIDn`, `be01`.`IDName` `Company`, `spla`.`ArticleIDn`, `de01`.`IDName` `Article`, 
				FncRound(`spla`.`Price`,0) `Price`, DATE_FORMAT(`spla`.`PriceDate`, "%d-%b-%Y") `PriceDate`, 	-- %m
				`spla`.`PriceListCode`	-- , `spl`.`ArticleSupplierID`
			, DATEDIFF(NOW(), `spla`.`PriceDate`) `AntPrice`
		-- , `spla`.`TableHistory`
		FROM `applcore`.`applsaletpricelistarticles` `spla`
/*			INNER JOIN `applcore`.`appllogtarticlessuppliersarticles` `asa`
				ON `spla`.`ArticleIDn` = `asa`.`ArticleIDn`
					AND  `spla`.`CompanyIDn` = `asa`.`CompanyIDn`
			INNER JOIN `applcore`.`applsuptsupplierspricelistarticles` `spl`
				ON `asa`.`ArticleSupplierID` = `spl`.`ArticleSupplierID`
					AND `asa`.`SupplierIDn` = `spl`.`SupplierIDn`
					AND `asa`.`CompanyIDn` = `spl`.`CompanyIDn`
-- Elimino la relacion con los supplier ya que hay articulos que no tienen identificado uno

*/			INNER JOIN `applcore`.`appltdataelement` `de01`
				ON `spla`.`ArticleIDn` = `de01`.`IDNum`
			INNER JOIN `bpmcore`.`bpmfoutbaseelement` `be01`
				ON `spla`.`CompanyIDn` = `be01`.`IDNum`
			$$
    
DELIMITER ;
/*
-- Controles
SELECT * FROM `applcore`.`applsaletpricelistarticles` `spla`;	-- Total 651 rows

-- Verifica el State de los precios de los articulos
SELECT StateIDn, COUNT(*) Q FROM `applcore`.`applsaletpricelistarticles` `spla` GROUP BY StateIDn;

-- Total 514 rows
SELECT `spla`.ArticleIDn, `asa`.ArticleIDn FROM `applcore`.`applsaletpricelistarticles` `spla`
			LEFT OUTER JOIN `applcore`.`appllogtarticlessuppliersarticles` `asa`
				ON `spla`.`ArticleIDn` = `asa`.`ArticleIDn`
					AND  `spla`.`CompanyIDn` = `asa`.`CompanyIDn`;
  */                  
                    
                    