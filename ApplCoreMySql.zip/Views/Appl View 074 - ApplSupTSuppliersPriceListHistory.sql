-- Analisis de como se actualizan los precios
-- Segun la ultima actualizacion, cual era la fecha anterior, nos da la antiguedad del precio
SELECT `sph`.`DatePriceList`,
    `sph`.`DatePriceListBefore`,
    COUNT(*) 'Q'
FROM `applcore`.`applsuptsupplierspricelisthistory` `sph`
GROUP BY `sph`.`DatePriceList`,
    `sph`.`DatePriceListBefore`
ORDER BY `sph`.`DatePriceList` desc,
    `sph`.`DatePriceListBefore` desc;

/* 
Actualizacion		
2021-03-29 00:00:00		2021-02-23 00:00:00		278		-- Estos productos se actualizaron dentro del mes
2021-03-29 00:00:00		2021-01-27 00:00:00		138		-- estos desde el 27 de enero
2021-03-29 00:00:00		2020-12-28 00:00:00		309		-- esto desde el 28 de diciembre
2021-03-29 00:00:00								84
*/



SELECT `sph`.`ArticleSupplierID`,
    `sph`.`SupplierIDn`,
    `sph`.`CompanyIDn`,
    `sph`.`DatePriceList`,
    `sph`.`Price`,
    `sph`.`DatePriceListBefore`,
	`sph`.`PriceBefore`,
    `sph`.`StateIDn`
FROM `applcore`.`applsuptsupplierspricelisthistory` `sph`
WHERE `sph`.`StateIDn` = 372 and `sph`.`DatePriceListBefore` = '2021-03-29'
ORDER BY `sph`.`ArticleSupplierID`
;




-- SELECT * FROM applcore.applsuptsupplierspricelisthistory;

SELECT `sph`.`ArticleSupplierID`,
    `sph`.`SupplierIDn`,
    `sph`.`CompanyIDn`,
    `sph`.`DatePriceList`,
    `sph`.`Price`,
    `sph`.`DatePriceListBefore`,
	`sph`.`PriceBefore`,
    `sph`.`StateIDn`
FROM `applcore`.`applsuptsupplierspricelisthistory` `sph`
WHERE `sph`.`StateIDn` = 372 and `sph`.`PriceBefore` is not null
ORDER BY `sph`.`ArticleSupplierID`
;


-- Articulos que tuvieron variacion de precio
SELECT `sph`.`ArticleSupplierID`,
    `sph`.`SupplierIDn`,
    `sph`.`CompanyIDn`,
    COUNT(*) 'Q'
FROM `applcore`.`applsuptsupplierspricelisthistory` `sph`
GROUP BY `sph`.`ArticleSupplierID`,
    `sph`.`SupplierIDn`,
    `sph`.`CompanyIDn`
HAVING COUNT(*) > 1
ORDER BY COUNT(*) DESC;
