SELECT `aof`.`CompanyIDn`, `aof`.`ArticleIDn`, MIN(`del`.`IDName`) `Articles`, ROUND(`pla`.`Price`,0) `Price`, COUNT(*) Q
FROM `applcore`.`appllogtarticlesoptionalfields` `aof`
	LEFT OUTER JOIN `applcore`.`appltdataelement` `del` ON
		`aof`.`CompanyIDn` = `del`.`CompanyIDn`
			AND
		`aof`.`ArticleIDn` = `del`.`IDNum`
	LEFT OUTER JOIN `applcore`.`applsaletpricelistarticles` `pla` ON
		`aof`.`CompanyIDn` = `pla`.`CompanyIDn`
			AND
		`aof`.`ArticleIDn` = `pla`.`ArticleIDn`
			AND
		`pla`.`PriceListIDn` = 117
	LEFT OUTER JOIN `applcore`.`appltdataelement` `del1` ON
		`aof`.`CompanyIDn` = `del1`.`CompanyIDn`
			AND
		`aof`.`FieldVAlueIDn` = `del1`.`IDNum`
-- WHERE LOWER(`del1`.`IDName`) LIKE LOWER('%recibo%')
-- 	OR LOWER(`del1`.`IDName`) LIKE LOWER('%obelisco%')
GROUP BY `aof`.`CompanyIDn`, `aof`.`ArticleIDn`
ORDER BY COUNT(*) DESC;