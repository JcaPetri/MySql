-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Appl View 016 - ApplVTableFieldsValues.sql
-- xxxx ApplLogVTableFieldsValuesCreate
-- -----------------------------

USE `ApplCore`;
DROP view IF EXISTS `ApplLogVTableFieldsValues`;

DELIMITER $$
USE `ApplCore`$$
CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `ApplCore`.`ApplLogVTableFieldsValues` AS
	SELECT `Tfv`.`CompanyIDn`,
            `Be02`.`IDName` AS `Company`,
			`Tfv`.`TableFieldIDn`,
			`Be01`.`IDName` AS `TableField`,
			`Tfv`.`TableFieldValueIDn`,
			`De01`.`IDName` AS `TableFieldValue`,
			`Tfv`.`StateIDn`,
			`Tfv`.`CreatedByIDn`,
			`Tfv`.`LastModifiedByIDn`,
			`Tfv`.`OwnerIDn`,
			`Tfv`.`DateCreated`,
			`Tfv`.`DateTimeStamp`,
			`Tfv`.`TzNameIDn`,
			`Tfv`.`TzOffset`,
			`Tfv`.`TableHistory`
		FROM `applcore`.`applttablefieldsvalues` `Tfv`
			inner join `ApplCore`.`appltdataelement` `De01`
				on `Tfv`.`TableFieldValueIDn` = `De01`.`IDNum`
			inner join `bpmcore`.`bpmfoutbaseelement` `Be01`
				on `Tfv`.`TableFieldIDn` = `Be01`.`IDNum`
			inner join `bpmcore`.`bpmfoutbaseelement` `Be02`
				on `Tfv`.`CompanyIDn` = `Be02`.`IDNum`
	ORDER BY `Tfv`.`CompanyIDn`,
			`Tfv`.`TableFieldIDn`,
			`Tfv`.`TableFieldValueIDn`
			$$
    
DELIMITER ;

