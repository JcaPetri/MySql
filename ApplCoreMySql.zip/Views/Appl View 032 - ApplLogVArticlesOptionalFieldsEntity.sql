-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Appl View 032 - ApplLogVArticlesOptionalFields.sql
-- IDNum	IDName/Table						ScopeIDn	IDCode
-- 		ApplLogVArticlesOptionalFields		
-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


USE `ApplCore`;
DROP view IF EXISTS `ApplLogVArticlesOptionalFieldsEntity`;

DELIMITER $$
USE `ApplCore`$$
CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `ApplCore`.`ApplLogVArticlesOptionalFieldsEntity` AS
	SELECT 	CONCAT(`Aof`.`CompanyIDn`,`Aof`.`ArticleIDn`,`Aof`.`TableFieldIDn`,`Aof`.`FieldValueIDn`) 'id',
				`Aof`.`FieldValueIDn`,
				`De01`.`IDName` AS `FieldValue`,
				`Aof`.`FieldNumValue`,
				`Aof`.`FieldTextValue`
			FROM `applcore`.`appllogtarticlesoptionalfields` `Aof`
				inner join `applcore`.`appltdataelement` `De01`
					on `Aof`.`FieldValueIDn` = `De01`.`IDNum`                
		WHERE `Aof`.`StateIDn` = 372
			$$
    
DELIMITER ;




