SELECT ag.`ArticleGeneralIDn`,
	de01.IDName 'ArticleGeneral',
    ag.`CompanyIDn`,
	be01.IDName 'Company',
    ag.`ScalesUse`,
    ag.`StockEnable`,
    ag.`GroupUse`,
    ag.`GroupAutomaticNumbering`,
    ag.`GroupAutoDownloadByAge`,
    ag.`SeriesUse`,
    ag.`SeriesUseMandatory`,
    ag.`SeriesUseReentry`,
    ag.`SeriesUseValidate`,
    ag.`StateIDn`,
    ag.`CreatedByIDn`,
    ag.`LastModifiedByIDn`,
    ag.`OwnerIDn`,
    ag.`DateCreated`,
    ag.`DateTimeStamp`,
    ag.`TzNameIDn`,
    ag.`TzOffset`,
    ag.`TableHistory`
FROM `applcore`.`appllogtarticlesgeneral` ag
	inner join `applcore`.`appltdataelement` de01 on ag.ArticleGeneralIDn = de01.IDNum and ag.CompanyIDn = de01.CompanyIDn
	inner join `bpmcore`.`bpmfoutbaseelement` be01 on ag.CompanyIDn = be01.IDNum
;



/*
SELECT `appltdataelement`.`ID`,
    `appltdataelement`.`IDNum`,
    `appltdataelement`.`IDName`,
    `appltdataelement`.`IDNameStructureIDn`,
    `appltdataelement`.`ScopeIDn`,
    `appltdataelement`.`CompanyIDn`,
    `appltdataelement`.`LanguageIDn`,
    `appltdataelement`.`IDCode`,
    `appltdataelement`.`DefinitionIDn`,
    `appltdataelement`.`InformationTypeIDn`,
    `appltdataelement`.`IDIsUsed`,
    `appltdataelement`.`StateIDn`,
    `appltdataelement`.`CreatedByIDn`,
    `appltdataelement`.`LastModifiedByIDn`,
    `appltdataelement`.`OwnerIDn`,
    `appltdataelement`.`DateCreated`,
    `appltdataelement`.`DateTimeStamp`,
    `appltdataelement`.`TzNameIDn`,
    `appltdataelement`.`TzOffset`,
    `appltdataelement`.`TableHistory`
FROM `applcore`.`appltdataelement` where ScopeIDn = 2203 and CompanyIDn = 2142;

*/