
-- SELECT * FROM applcore.appllogvarticlessuppliersarticles;

USE `applcore`;
DROP view IF EXISTS `ApplLogVArticlesSuppliersArticles`;

DELIMITER $$
USE `applcore`$$
CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `applcore`.`ApplLogVArticlesSuppliersArticles` AS
		SELECT `asa`.`CompanyIDn`,
				`Be01`.`IDName` AS `Company`,
				`asa`.`ArticleIDn`,
				`De01`.`IDName` AS `Article`,
				`asa`.`SupplierIDn`,
                `Pe01`.`TradeName`,
                `Sa01`.`Price`,
                `Sa01`.`DatePriceList`,
                `asa`.`ArticleSupplierID`,
                `Sa01`.`ArticleSupplierDescription`,
                `Sa01`.`PriceListCode`,
    			`asa`.`StateIDn`,
				`asa`.`CreatedByIDn`,
				`asa`.`LastModifiedByIDn`,
				`asa`.`OwnerIDn`,
				`asa`.`DateCreated`,
				`asa`.`DateTimeStamp`,
				`asa`.`TzNameIDn`,
				`asa`.`TzOffset`,
				`asa`.`TableHistory`
		FROM `applcore`.`appllogtarticlessuppliersarticles` `asa`
			inner join `bpmcore`.`bpmfoutbaseelement` `Be01`
				on `asa`.`CompanyIDn` = `Be01`.`IDNum`
					and 372 = `Be01`.`StateIDn`
            inner join `applcore`.`appltdataelement` `De01`
				on `asa`.`ArticleIDn` = `De01`.`IDNum`
					and 372 = `De01`.`StateIDn`		
			inner join `applcore`.`appltpersons` `Pe01`
				on `asa`.`SupplierIDn` = `Pe01`.`PersonIDn`
					and 372 = `Pe01`.`StateIDn`
			inner join `applcore`.`applsuptsupplierspricelistarticles` `Sa01`
				on `asa`.`ArticleSupplierID` = `Sa01`.`ArticleSupplierID`
					and `asa`.`SupplierIDn` = `Sa01`.`SupplierIDn`
					and `asa`.`CompanyIDn` = `Sa01`.`CompanyIDn`
					and 372 = `Sa01`.`StateIDn`
	WHERE `asa`.`StateIDn` = 372
    ORDER BY `asa`.`CompanyIDn`,
			`asa`.`ArticleIDn`
			$$
            
DELIMITER ;

/*
SELECT `asa`.`ArticleIDn`,
    `asa`.`ArticleSupplierID`,
    `asa`.`SupplierIDn`,
    `asa`.`CompanyIDn`,
    `asa`.`StateIDn`,
    `asa`.`CreatedByIDn`,
    `asa`.`LastModifiedByIDn`,
    `asa`.`OwnerIDn`,
    `asa`.`DateCreated`,
    `asa`.`DateTimeStamp`,
    `asa`.`TzNameIDn`,
    `asa`.`TzOffset`,
    `asa`.`TableHistory`
FROM `applcore`.`appllogtarticlessuppliersarticles` `asa`;


SELECT `applsuptsupplierspricelistarticles`.`ArticleSupplierID`,
    `applsuptsupplierspricelistarticles`.`SupplierIDn`,
    `applsuptsupplierspricelistarticles`.`CompanyIDn`,
    `applsuptsupplierspricelistarticles`.`ArticleSupplierDescription`,
    `applsuptsupplierspricelistarticles`.`SupplierPriceListIDn`,
    `applsuptsupplierspricelistarticles`.`Price`,
    `applsuptsupplierspricelistarticles`.`DatePriceList`,
    `applsuptsupplierspricelistarticles`.`PriceListCode`,
    `applsuptsupplierspricelistarticles`.`StateIDn`,
    `applsuptsupplierspricelistarticles`.`CreatedByIDn`,
    `applsuptsupplierspricelistarticles`.`LastModifiedByIDn`,
    `applsuptsupplierspricelistarticles`.`OwnerIDn`,
    `applsuptsupplierspricelistarticles`.`DateCreated`,
    `applsuptsupplierspricelistarticles`.`DateTimeStamp`,
    `applsuptsupplierspricelistarticles`.`TzNameIDn`,
    `applsuptsupplierspricelistarticles`.`TzOffset`,
    `applsuptsupplierspricelistarticles`.`TableHistory`
FROM `applcore`.`applsuptsupplierspricelistarticles`;
*/
