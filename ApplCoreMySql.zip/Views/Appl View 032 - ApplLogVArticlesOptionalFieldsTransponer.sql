-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- Appl View 032 - ApplLogVArticlesOptionalFieldsTranspTransp.sql
-- IDNum	IDName/Table						ScopeIDn	IDCode
-- 		ApplLogVArticlesOptionalFieldsTransp		
-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

/*
USE `applcore`;
DROP view IF EXISTS `ApplLogVArticlesOptionalFieldsTransp`;

DELIMITER $$
USE `applcore`$$
CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `applcore`.`ApplLogVArticlesOptionalFieldsTransp` AS
*/
-- SELECT TableFieldIDn, TableField, count(*) FROM applcore.appllogvarticlesoptionalfields group by TableFieldIDn, TableField order by TableFieldIDn;

select CompanyIDn, ArticleIDn, TableFieldIDn, FieldValueIDn, count(*) FROM `applcore`.`appllogtarticlesoptionalfields`
group by CompanyIDn, ArticleIDn, TableFieldIDn
order by CompanyIDn, ArticleIDn, TableFieldIDn;


select CompanyIDn, ArticleIDn, IF(TableFieldIDn = 2225, 2225, NULL) `2225`
-- , IF(TableFieldIDn = 2224, 2224, NULL) `2224`
,CASE WHEN TableFieldIDn = 2223 THEN 2223
	 WHEN TableFieldIDn = 2225 THEN 2225
     ELSE NULL
END `DL` 
, count(*) 
FROM `applcore`.`appllogtarticlesoptionalfields`
group by CompanyIDn, ArticleIDn
order by CompanyIDn, ArticleIDn;


    SELECT 	-- `Aof`.`CompanyIDn`,
			`Be01`.`IDName` AS `Company`,
			`Aof`.`ArticleIDn`,
            `De01`.`IDName` AS `Article`,
			IF(`Aof`.`TableFieldIDn` = 2232, 2232, null) AS `Product Type`,
            IF(`Aof`.`TableFieldIDn` = 2223, `De02`.`IDName`, null) AS `Brand`
            /*,
            IF(`Aof`.`TableFieldIDn` = 2224, `De02`.`IDName`, null) AS `Product`,
            IF(`Aof`.`TableFieldIDn` = 2225, `De02`.`IDName`, null) AS `Size`,
            IF(`Aof`.`TableFieldIDn` = 2226, `De02`.`IDName`, null) AS `Weight`,
            IF(`Aof`.`TableFieldIDn` = 2227, `De02`.`IDName`, null) AS `Color`,
            IF(`Aof`.`TableFieldIDn` = 2228, `De02`.`IDName`, null) AS `Quantity`,
            IF(`Aof`.`TableFieldIDn` = 2229, `De02`.`IDName`, null) AS `Unit`,
			IF(`Aof`.`TableFieldIDn` = 2250, `De02`.`IDName`, null) AS `Model`,
            IF(`Aof`.`TableFieldIDn` = 2251, `De02`.`IDName`, null) AS `Barcode`
            */
            -- `Be01`.`IDName` AS `TableField`,
			-- `Aof`.`FieldValueIDn`,
            -- `De02`.`IDName` AS `FieldValue`
		FROM `applcore`.`appllogtarticlesoptionalfields` `Aof`
			inner join `bpmcore`.`bpmfoutbaseelement` `Be01`
				on `Aof`.`CompanyIDn` = `Be01`.`IDNum`
			inner join `applcore`.`appltdataelement` `De01`
				on `Aof`.`ArticleIDn` = `De01`.`IDNum`
			inner join `applcore`.`appltdataelement` `De02`
				on `Aof`.`FieldValueIDn` = `De02`.`IDNum`                

-- select * FROM `applcore`.`appllogtarticlesoptionalfields` `Aof`

	GROUP BY `Be01`.`IDName`,
			`Aof`.`ArticleIDn`,
            `De01`.`IDName`
	ORDER BY `Aof`.`CompanyIDn`,
			`Aof`.`ArticleIDn`,
			`Aof`.`TableFieldIDn`
/*			$$
    
DELIMITER ;

*/


